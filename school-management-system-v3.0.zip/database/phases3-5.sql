-- Review/apply after phase2.sql. Assign memberships explicitly through trusted administration.
create table if not exists public.school_memberships(user_id uuid primary key references public.profiles(id) on delete cascade,class_ids uuid[] not null default '{}',student_ids uuid[] not null default '{}');
create table if not exists public.school_classes(id uuid primary key default gen_random_uuid(),school_id uuid not null,branch_id uuid not null references public.branches(id),name text not null);
create table if not exists public.school_students(id uuid primary key default gen_random_uuid(),school_id uuid not null,branch_id uuid not null references public.branches(id),class_id uuid not null references public.school_classes(id),name text not null,guardian_phone text);
create table if not exists public.workflow_modules(module text primary key,config jsonb not null);
create table if not exists public.school_workflows(id uuid primary key,school_id uuid not null,branch_id uuid not null references public.branches(id),class_id uuid references public.school_classes(id),student_id uuid references public.school_students(id),author_id uuid not null references public.profiles(id),module text not null references public.workflow_modules(module),version int not null default 1,payload jsonb not null,updated_at timestamptz not null default now());
create index if not exists workflow_scope_idx on public.school_workflows(school_id,branch_id,module,updated_at desc);
create index if not exists workflow_student_idx on public.school_workflows(student_id,module);
create index if not exists workflow_class_idx on public.school_workflows(class_id,module);
create index if not exists students_class_idx on public.school_students(class_id);
alter table public.school_memberships enable row level security; alter table public.school_classes enable row level security; alter table public.school_students enable row level security; alter table public.school_workflows enable row level security; alter table public.workflow_modules enable row level security;
revoke all on public.school_memberships,public.school_classes,public.school_students,public.school_workflows,public.workflow_modules from public,anon,authenticated;
grant select on public.school_memberships,public.school_classes,public.school_students,public.school_workflows,public.workflow_modules to authenticated;
grant all on public.school_memberships,public.school_classes,public.school_students,public.school_workflows,public.workflow_modules to service_role;
create policy "Own workflow membership" on public.school_memberships for select to authenticated using(user_id=(select auth.uid()) and exists(select 1 from public.profiles where id=(select auth.uid())));
create policy "Read workflow catalogue" on public.workflow_modules for select to authenticated using(true);
create policy "Scoped student roster" on public.school_students for select to authenticated using(exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.school_id=school_students.school_id and (p.role='owner' or (branch_id=any(p.branch_ids) and (p.role in ('principal','accountant') or exists(select 1 from public.school_memberships m where m.user_id=p.id and ((p.role='teacher' and school_students.class_id=any(m.class_ids)) or (p.role in ('parent','student') and school_students.id=any(m.student_ids)))))))));
create policy "Scoped class list" on public.school_classes for select to authenticated using(exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.school_id=school_classes.school_id and (p.role='owner' or (branch_id=any(p.branch_ids) and (p.role='principal' or exists(select 1 from public.school_memberships m where m.user_id=p.id and school_classes.id=any(m.class_ids)) or exists(select 1 from public.school_students s where s.class_id=school_classes.id))))));

create or replace function private.workflow_allowed(m text,sid uuid,bid uuid,cid uuid,student uuid,author uuid,body jsonb,writing boolean default false) returns boolean language plpgsql stable security invoker set search_path='' as $$
declare p public.profiles; membership public.school_memberships; cfg jsonb; perms jsonb; need text;
begin
 if auth.uid() is null then return false; end if;
 select * into p from public.profiles where id=auth.uid() and active and role=auth.jwt()->'app_metadata'->>'role' and coalesce(policy_id::text,'')=coalesce(auth.jwt()->'app_metadata'->>'policy_id','');
 if p.id is null or p.school_id<>sid or not private.school_active(sid) or not exists(select 1 from public.branches where id=bid and school_id=sid and active) then return false; end if;
 select config into cfg from public.workflow_modules where module=m;
 if cfg is null or not (cfg->case when writing then 'writers' else 'readers' end) ? p.role then return false; end if;
 if p.role='owner' then return true; end if;
 if not bid=any(p.branch_ids) then return false; end if;
 need:=case when m in ('privacy','notifications','leaves','calendar','activity') then 'workspace.read' when p.role in ('parent','student') then 'child.read' when m='expenses' and p.role='principal' then 'workspace.read' when m in ('fees','expenses','payroll','certificates','reconciliation') then 'finance.manage' when m='admissions' then 'users.manage' else 'academics.read' end;
 select payload->'permissions' into perms from public.admin_records where resource='roles' and school_id=sid and (case when p.policy_id is not null then id=p.policy_id else payload->>'role'=p.role and not coalesce((payload->>'custom')::boolean,false) end) limit 1;
 if perms is not null and not perms ? need then return false; end if;
 if m in ('privacy','notifications','activity') then return author=p.id or (m='activity' and p.role='principal'); end if;
 select * into membership from public.school_memberships where user_id=p.id;
 if p.role='teacher' then return (m='leaves' and author=p.id) or (cid is not null and cid=any(membership.class_ids)); end if;
 if p.role in ('parent','student') then
   if m='marks' and body->>'status'<>'Published' then return false; end if;
   if m='certificates' and body->>'status'<>'Issued' then return false; end if;
   if m='lessons' and body->>'status'<>'Approved' then return false; end if;
   return (student is not null and student=any(membership.student_ids)) or (student is null and cid is not null and exists(select 1 from public.school_students s where s.class_id=cid and s.id=any(membership.student_ids))) or (student is null and cid is null and m in ('calendar','announcements'));
 end if;
 return true;
end $$;
revoke all on function private.workflow_allowed(text,uuid,uuid,uuid,uuid,uuid,jsonb,boolean) from public,anon;
grant execute on function private.workflow_allowed(text,uuid,uuid,uuid,uuid,uuid,jsonb,boolean) to authenticated;
create policy "Read authorized workflow" on public.school_workflows for select to authenticated using(private.workflow_allowed(module,school_id,branch_id,class_id,student_id,author_id,payload->'data',false));
create or replace function public.workflow_context(p_branch uuid) returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('students',coalesce((select jsonb_agg(jsonb_build_object('id',id,'name',name,'classId',class_id,'branchId',branch_id) order by name) from public.school_students where branch_id=p_branch),'[]'::jsonb),'classes',coalesce((select jsonb_agg(jsonb_build_object('id',id,'name',name,'branchId',branch_id) order by name) from public.school_classes where branch_id=p_branch),'[]'::jsonb));
$$;
create or replace function public.workflow_list(p_module text,p_scope jsonb) returns jsonb language sql stable security invoker set search_path='' as $$
 with accessible as(select * from public.school_workflows where branch_id=(p_scope->>'branchId')::uuid and (coalesce(p_scope->>'classId','')='' or class_id is null or class_id=(p_scope->>'classId')::uuid) and (coalesce(p_scope->>'studentId','')='' or student_id is null or student_id=(p_scope->>'studentId')::uuid)), matching as(select * from accessible where (p_module='all' or module=p_module) and (coalesce(p_scope->>'date','')='' or payload->'data'->>'date'=p_scope->>'date') and (coalesce(p_scope->>'title','')='' or payload->'data'->>'title'=p_scope->>'title') and (coalesce(p_scope->>'subject','')='' or payload->'data'->>'subject'=p_scope->>'subject') and (coalesce(p_scope->>'search','')='' or (payload->'data')::text ilike '%'||(p_scope->>'search')||'%')), paged as(select * from matching order by updated_at desc,id limit least(500,greatest(1,coalesce((p_scope->>'pageSize')::int,12))) offset greatest(0,coalesce((p_scope->>'page')::int,0))*least(500,greatest(1,coalesce((p_scope->>'pageSize')::int,12))))
 select jsonb_build_object('rows',coalesce((select jsonb_agg(payload||jsonb_build_object('version',version,'updatedAt',updated_at) order by updated_at desc,id) from paged),'[]'::jsonb),'total',(select count(*) from matching),'counts',coalesce((select jsonb_object_agg(module,count) from(select module,count(*) from accessible group by module) c),'{}'::jsonb));
$$;
create or replace function private.workflow_save_checked(p_record jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare old public.school_workflows; p public.profiles; rid uuid; sid uuid; bid uuid; cid uuid; student uuid; author uuid; m text; body jsonb; result jsonb; field jsonb; next_version int; event text; rule record; queued_id uuid;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 rid:=(p_record->>'id')::uuid;sid:=(p_record->>'schoolId')::uuid;bid:=(p_record->>'branchId')::uuid;cid:=nullif(p_record->>'classId','')::uuid;student:=nullif(p_record->>'studentId','')::uuid;author:=(p_record->>'authorId')::uuid;m:=p_record->>'module';body:=p_record->'data';
 if not private.workflow_allowed(m,sid,bid,cid,student,author,body,true) then raise exception 'Workflow access denied'; end if;
 select * into p from public.profiles where id=auth.uid();
 if m='classes' and cid=rid then insert into public.school_classes(id,school_id,branch_id,name) values(cid,sid,bid,body->>'title') on conflict(id) do update set name=excluded.name where public.school_classes.school_id=sid and public.school_classes.branch_id=bid; end if;
 if cid is not null and not exists(select 1 from public.school_classes where id=cid and school_id=sid and branch_id=bid) then raise exception 'Class is outside this campus'; end if;
 if student is not null and not exists(select 1 from public.school_students where id=student and school_id=sid and branch_id=bid and (cid is null or class_id=cid)) then raise exception 'Student is outside this class'; end if;
 if jsonb_typeof(body)<>'object' then raise exception 'Invalid record data'; end if;
 for field in select jsonb_array_elements(config->'fields') from public.workflow_modules where module=m loop
  if coalesce((field->>'required')::boolean,false) and coalesce(body->>(field->>'key'),'')='' then raise exception 'Required field: %',field->>'label'; end if;
  if field->>'type'='number' then if coalesce(body->>(field->>'key'),'')<>'' then if (body->>(field->>'key'))::numeric<0 then raise exception 'Negative number not allowed'; end if; end if; end if;
  if field ? 'options' and coalesce(body->>(field->>'key'),'')<>'' and not field->'options' ? (body->>(field->>'key')) then raise exception 'Invalid option'; end if;
 end loop;
 if m='marks' and ((body->>'maximum')::numeric<=0 or (body->>'score')::numeric>(body->>'maximum')::numeric) then raise exception 'Invalid marks'; end if;
 if m='fees' and coalesce((body->>'discount')::numeric,0)>(body->>'amount')::numeric then raise exception 'Discount exceeds the fee'; end if;
 if p.role in ('parent','student') and (author<>p.id or (m<>'notifications' and body->>'status'<>'Requested')) then raise exception 'Family requests must await approval'; end if;
 if p.role='teacher' and ((m='leaves' and body->>'status'<>'Requested') or (m='lessons' and body->>'status'='Approved')) then raise exception 'Approval is reserved for school leaders'; end if;
 select * into old from public.school_workflows where id=rid for update;
 if old.id is not null and (old.version<>(p_record->>'version')::int or old.school_id<>sid or old.branch_id<>bid or old.module<>m or old.author_id<>author or (old.class_id is distinct from cid and not(m='admissions' and body->>'status'='Transferred')) or old.student_id is distinct from student) then raise exception 'Record changed or scope cannot be reassigned'; end if;
 if old.id is null and author<>auth.uid() then raise exception 'Invalid author'; end if;
 next_version:=coalesce(old.version,0)+1;result:=p_record||jsonb_build_object('version',next_version,'updatedAt',now());
 insert into public.school_workflows(id,school_id,branch_id,class_id,student_id,author_id,module,version,payload) values(rid,sid,bid,cid,student,author,m,next_version,result) on conflict(id) do update set payload=excluded.payload,version=excluded.version,updated_at=now();
 if m='admissions' and body->>'status' in ('Admitted','Transferred') and cid is not null then insert into public.school_students(id,school_id,branch_id,class_id,name) values(rid,sid,bid,cid,body->>'applicant') on conflict(id) do update set class_id=excluded.class_id,name=excluded.name where public.school_students.school_id=sid and public.school_students.branch_id=bid; end if;
 queued_id:=gen_random_uuid(); insert into public.school_workflows(id,school_id,branch_id,author_id,module,payload) values(queued_id,sid,bid,auth.uid(),'activity',jsonb_build_object('id',queued_id,'schoolId',sid,'branchId',bid,'classId',null,'studentId',null,'authorId',auth.uid(),'module','activity','version',1,'updatedAt',now(),'data',jsonb_build_object('title',case when old.id is null then 'Created ' else 'Updated ' end||m,'date',current_date,'notes',rid)));
 insert into public.admin_records(id,school_id,branch_id,resource,payload) select gen_random_uuid(),sid,bid,'audit',jsonb_build_object('id',gen_random_uuid(),'schoolId',sid,'branchId',bid,'version',1,'actor',p.name,'action',case when old.id is null then 'Created' else 'Updated' end,'resource',m,'details',rid::text,'createdAt',now());
 event:=case when m='attendance' and body->>'status'='Absent' then 'Absence' when m='marks' and body->>'status'='Published' then 'Result published' when m='announcements' then 'Announcement' when m='fees' and body->>'status'<>'Paid' then 'Fee reminder' else null end;
 if event is not null and (old.id is null or old.payload->'data' is distinct from body) then
  for rule in select * from public.school_workflows where school_id=sid and module='automations' and payload->'data'->>'event'=event and payload->'data'->>'status'='Enabled' loop
   if student is not null and exists(select 1 from public.school_workflows n join public.school_memberships pm on pm.user_id=n.author_id where n.module='notifications' and n.school_id=sid and student=any(pm.student_ids) and n.payload->'data'->>'status'='Disabled' and n.payload->'data'->>'event'=case event when 'Absence' then 'Attendance' when 'Fee reminder' then 'Fees' when 'Result published' then 'Results' else 'Announcements' end) then continue; end if;
   queued_id:=gen_random_uuid(); insert into public.school_workflows(id,school_id,branch_id,class_id,student_id,author_id,module,payload) values(queued_id,sid,bid,cid,student,auth.uid(),'whatsapp',jsonb_build_object('id',queued_id,'schoolId',sid,'branchId',bid,'classId',cid,'studentId',student,'authorId',auth.uid(),'module','whatsapp','version',1,'updatedAt',now(),'data',jsonb_build_object('title',event,'template',rule.payload->'data'->>'template','recipient',coalesce((select guardian_phone from public.school_students where id=student),''),'date',current_date,'status','Queued','notes','Awaiting configured delivery worker')));
  end loop;
 end if;
 return result;
end $$;
revoke all on function private.workflow_save_checked(jsonb) from public,anon;
grant execute on function private.workflow_save_checked(jsonb) to authenticated;
create or replace function public.workflow_save(p_record jsonb) returns jsonb language sql security invoker set search_path='' as $$ select private.workflow_save_checked(p_record); $$;
create or replace function private.workflow_remove_checked(p_id uuid,p_version int) returns jsonb language plpgsql security definer set search_path='' as $$
declare r public.school_workflows; p public.profiles;
begin
 select * into p from public.profiles where id=auth.uid() and active;
 select * into r from public.school_workflows where id=p_id for update;
 if p.id is null or p.role not in ('owner','principal','accountant') or r.id is null or r.module in ('privacy','whatsapp') or r.version<>p_version or not private.workflow_allowed(r.module,r.school_id,r.branch_id,r.class_id,r.student_id,r.author_id,r.payload->'data',true) then raise exception 'Deletion denied or record changed'; end if;
 delete from public.school_workflows where id=p_id;
 insert into public.admin_records(id,school_id,branch_id,resource,payload) values(gen_random_uuid(),r.school_id,r.branch_id,'audit',jsonb_build_object('id',gen_random_uuid(),'schoolId',r.school_id,'branchId',r.branch_id,'version',1,'actor',p.name,'action','Deleted','resource',r.module,'details',r.id::text,'createdAt',now()));
 return jsonb_build_object('deleted',true);
end $$;
revoke all on function private.workflow_remove_checked(uuid,int) from public,anon;
grant execute on function private.workflow_remove_checked(uuid,int) to authenticated;
create or replace function public.workflow_remove(p_id uuid,p_version int) returns jsonb language sql security invoker set search_path='' as $$ select private.workflow_remove_checked(p_id,p_version); $$;
revoke all on function public.workflow_context(uuid),public.workflow_list(text,jsonb),public.workflow_save(jsonb),public.workflow_remove(uuid,int) from public,anon;
grant execute on function public.workflow_context(uuid),public.workflow_list(text,jsonb),public.workflow_save(jsonb),public.workflow_remove(uuid,int) to authenticated;
create policy "Read attached classroom material" on storage.objects for select to authenticated using(bucket_id='school-files' and exists(select 1 from public.school_workflows r where r.payload->'data'->>'filePath'=storage.objects.name));
do $$ begin if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='school_workflows') then alter publication supabase_realtime add table public.school_workflows; end if; end $$;
-- Delivery updates are accepted only from the signature-verified server webhook.
create or replace function public.workflow_delivery(p_provider_id text,p_status text) returns jsonb language plpgsql security invoker set search_path='' as $$
begin
 if p_status not in ('Sent','Delivered','Read','Failed') then raise exception 'Invalid delivery status'; end if;
 update public.school_workflows set payload=payload||jsonb_build_object('version',version+1,'updatedAt',now(),'data',payload->'data'||jsonb_build_object('status',p_status)),version=version+1,updated_at=now()
 where module='whatsapp' and payload->'data'->>'providerId'=p_provider_id and payload->'data'->>'status'<>'Read'
 and (p_status='Failed' or coalesce(array_position(array['Queued','Sent','Delivered','Read'],payload->'data'->>'status'),0)<=array_position(array['Queued','Sent','Delivered','Read'],p_status));
 return jsonb_build_object('updated',found);
end $$;
revoke all on function public.workflow_delivery(text,text) from public,anon,authenticated;
grant execute on function public.workflow_delivery(text,text) to service_role;
