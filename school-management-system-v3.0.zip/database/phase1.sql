-- Phase 1 schema contract. Run in a development Supabase project before live mode.
-- No users, authorization claims, or tenants are created by this file.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  school_id uuid not null,
  name text not null,
  email text not null,
  role text not null check (role in ('owner','principal','teacher','parent','student','accountant','master')),
  branch_ids uuid[] not null default '{}'
);
create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null,
  name text not null,
  city text not null,
  short_name text not null
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete cascade,
  title text not null,
  body text not null,
  created_at timestamptz not null default now(),
  read boolean not null default false
);
create index if not exists branches_school_id_idx on public.branches(school_id);
create index if not exists notifications_user_branch_created_idx on public.notifications(user_id,branch_id,created_at desc);
create index if not exists notifications_branch_id_idx on public.notifications(branch_id);
alter table public.profiles enable row level security;
alter table public.branches enable row level security;
alter table public.notifications enable row level security;
revoke all on public.profiles, public.branches, public.notifications from anon, authenticated;
grant select on public.profiles, public.branches, public.notifications to authenticated;
grant update(read) on public.notifications to authenticated;
drop policy if exists "Read own provisioned profile" on public.profiles;
create policy "Read own provisioned profile" on public.profiles for select to authenticated
  using (id = (select auth.uid()) and role = (select auth.jwt()->'app_metadata'->>'role'));
-- A trusted provisioning process maintains school_id, role, and branch_ids.
-- Client users cannot promote themselves or assign additional campuses.
drop policy if exists "Assigned campuses in own school" on public.branches;
create policy "Assigned campuses in own school" on public.branches for select to authenticated
  using (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.school_id = branches.school_id and branches.id = any(p.branch_ids)));
drop policy if exists "Read own scoped notifications" on public.notifications;
create policy "Read own scoped notifications" on public.notifications for select to authenticated
  using (user_id = (select auth.uid()) and (branch_id is null or exists (select 1 from public.branches b where b.id = notifications.branch_id)));
drop policy if exists "Mark own scoped notifications read" on public.notifications;
create policy "Mark own scoped notifications read" on public.notifications for update to authenticated
  using (user_id = (select auth.uid()) and (branch_id is null or exists (select 1 from public.branches b where b.id = notifications.branch_id)))
  with check (user_id = (select auth.uid()) and (branch_id is null or exists (select 1 from public.branches b where b.id = notifications.branch_id)));
insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('school-files','school-files',false,5242880,array['application/pdf','text/csv','image/png','image/jpeg'])
on conflict(id) do nothing;
-- Files are private and confined to school/campus/user folders.
drop policy if exists "Upload own campus files" on storage.objects;
create policy "Upload own campus files" on storage.objects for insert to authenticated
with check (bucket_id = 'school-files' and (storage.foldername(storage.objects.name))[3] = (select auth.uid())::text and exists (
  select 1 from public.profiles p join public.branches b on b.school_id = p.school_id
  where p.id = (select auth.uid()) and p.school_id::text = (storage.foldername(storage.objects.name))[1]
  and b.id::text = (storage.foldername(storage.objects.name))[2] and b.id = any(p.branch_ids)
));
drop policy if exists "Read own campus files" on storage.objects;
create policy "Read own campus files" on storage.objects for select to authenticated
using (bucket_id = 'school-files' and (storage.foldername(storage.objects.name))[3] = (select auth.uid())::text and exists (
  select 1 from public.profiles p join public.branches b on b.school_id = p.school_id
  where p.id = (select auth.uid()) and p.school_id::text = (storage.foldername(storage.objects.name))[1]
  and b.id::text = (storage.foldername(storage.objects.name))[2] and b.id = any(p.branch_ids)
));
-- Publish notifications for Realtime if not already enabled in this project.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'notifications') then
    alter publication supabase_realtime add table public.notifications;
  end if;
end $$;
