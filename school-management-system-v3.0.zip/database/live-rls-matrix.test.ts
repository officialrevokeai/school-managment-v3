import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { Client } from 'pg';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const TARGET_REF = 'oqsvedpkqgajjrnxbehz';

function getEnv() {
  const serverEnvFile = resolve(process.cwd(), '.env.server.local');
  const testEnvFile = resolve(process.cwd(), '.env.test.local');
  const env: Record<string, string> = {};

  for (const file of [serverEnvFile, testEnvFile]) {
    if (existsSync(file)) {
      const content = readFileSync(file, 'utf8');
      for (const line of content.split('\n')) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;
        const eqIdx = trimmed.indexOf('=');
        if (eqIdx !== -1) {
          env[trimmed.slice(0, eqIdx).trim()] = trimmed.slice(eqIdx + 1).trim();
        }
      }
    }
  }
  return env;
}

const env = getEnv();
const isLiveConfigured = env.QA_MODE === 'true' && Boolean(env.SUPABASE_DB_PASSWORD);

describe.skipIf(!isLiveConfigured)('Phase T3: Database & RLS Test Matrix', () => {
  let client: Client;

  beforeAll(async () => {
    expect(env.QA_MODE).toBe('true');
    expect(env.SUPABASE_DB_PASSWORD).toBeDefined();

    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        try {
          client = new Client({
            host: `db.${TARGET_REF}.supabase.co`,
            port: 5432,
            database: 'postgres',
            user: 'postgres',
            password: env.SUPABASE_DB_PASSWORD,
            ssl: { rejectUnauthorized: false },
            connectionTimeoutMillis: 2000,
          });
          await client.connect();
          break;
        } catch {
          client = new Client({
            host: env.SUPABASE_POOLER_HOST || 'aws-0-ap-southeast-1.pooler.supabase.com',
            port: 6543,
            database: 'postgres',
            user: `postgres.${TARGET_REF}`,
            password: env.SUPABASE_DB_PASSWORD,
            ssl: { rejectUnauthorized: false },
          });
          await client.connect();
          break;
        }
      } catch (err) {
        if (attempt === 3) throw err;
        await new Promise((r) => setTimeout(r, 2000));
      }
    }
  });

  afterAll(async () => {
    if (client) {
      await client.end();
    }
  });

  // Helper to run query impersonating a specific role and JWT claims within a transaction
  async function runAs<T = any>(
    role: 'anon' | 'authenticated',
    claims: { sub?: string; role?: string; school_id?: string | null; branch_ids?: string[] },
    fn: (c: Client) => Promise<T>
  ): Promise<T> {
    await client.query('BEGIN;');
    try {
      if (role === 'anon') {
        await client.query('SET LOCAL ROLE anon;');
        await client.query(`SELECT set_config('request.jwt.claims', '{}', true);`);
      } else {
        await client.query('SET LOCAL ROLE authenticated;');
        const jwtPayload = {
          sub: claims.sub || '00000000-0000-0000-0000-000000000000',
          role: 'authenticated',
          app_metadata: {
            role: claims.role,
            school_id: claims.school_id,
            branch_ids: claims.branch_ids || [],
            is_qa: true,
          },
        };
        await client.query(`SELECT set_config('request.jwt.claims', $1, true);`, [JSON.stringify(jwtPayload)]);
      }
      return await fn(client);
    } finally {
      await client.query('ROLLBACK;');
    }
  }

  describe('1. Catalog RLS Invariants', () => {
    it('RLS is enabled on every table in the public schema', async () => {
      const res = await client.query(`
        SELECT c.relname AS table_name, c.relrowsecurity AS rls_enabled
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'public' AND c.relkind = 'r'
        ORDER BY c.relname;
      `);
      expect(res.rows.length).toBeGreaterThanOrEqual(40);
      for (const row of res.rows) {
        expect(row.rls_enabled, `Table ${row.table_name} must have RLS enabled`).toBe(true);
      }
    });

    it('No public table has USING (true) policies that grant unrestricted access', async () => {
      const res = await client.query(`
        SELECT tablename, policyname, roles, cmd, qual
        FROM pg_policies
        WHERE schemaname = 'public' AND qual = 'true';
      `);
      // Only public plans table or audit append-only allow true on specific commands
      for (const row of res.rows) {
        const allowed = row.tablename === 'plans' && row.cmd === 'SELECT';
        expect(allowed, `Unrestricted qual='true' on ${row.tablename} policy ${row.policyname}`).toBe(true);
      }
    });

    it('Every SECURITY DEFINER function has search_path = \'\'', async () => {
      const res = await client.query(`
        SELECT p.proname, p.prosecdef, pg_get_functiondef(p.oid) as def
        FROM pg_proc p
        JOIN pg_namespace n ON n.oid = p.pronamespace
        WHERE n.nspname = 'public' AND p.prosecdef = true;
      `);
      expect(res.rows.length).toBeGreaterThan(0);
      for (const row of res.rows) {
        const hasSearchPath = row.def.includes('SET search_path = \'\'') || row.def.includes('SET search_path TO \'\'');
        expect(hasSearchPath, `Function ${row.proname} must have fixed search_path = ''`).toBe(true);
      }
    });

    it('No functions in public schema are executable by anon except pg_trgm builtins', async () => {
      const res = await client.query(`
        SELECT routine_name 
        FROM information_schema.routine_privileges 
        WHERE grantee = 'anon' AND specific_schema = 'public'
          AND routine_name NOT LIKE '%trgm%' 
          AND routine_name NOT LIKE '%similarity%'
          AND routine_name NOT IN ('set_limit', 'show_limit');
      `);
      expect(res.rows.length).toBe(0);
    });
  });

  describe('2. Anon Access Restriction', () => {
    it('Anon can read public plans', async () => {
      const res = await runAs('anon', {}, async (c) => {
        return await c.query('SELECT name, price FROM public.plans;');
      });
      expect(res.rows.length).toBeGreaterThan(0);
    });

    it('Anon is denied reading schools, profiles, student_fees, attendance, workflows', async () => {
      for (const tbl of ['schools', 'profiles', 'student_fees', 'attendance_records', 'school_workflows']) {
        await runAs('anon', {}, async (c) => {
          try {
            const res = await c.query(`SELECT * FROM public.${tbl};`);
            expect(res.rows.length).toBe(0);
          } catch (err: any) {
            expect(err.message).toMatch(/permission denied/i);
          }
        });
      }
    });

    it('Anon is denied all INSERT, UPDATE, DELETE on all public tables', async () => {
      await runAs('anon', {}, async (c) => {
        await expect(
          c.query(`INSERT INTO public.schools (name, code, owner_email) VALUES ('Hacked School', 'HACK', 'h@h.com');`)
        ).rejects.toThrow();

        await expect(
          c.query(`UPDATE public.plans SET price = 0 WHERE name = 'Growth';`)
        ).rejects.toThrow();
      });
    });
  });

  describe('3. Cross-Tenant Isolation (School A vs School B)', () => {
    it('School B Owner cannot read School A data', async () => {
      const schoolAId = env.QA_SCHOOL_A_ID;
      const schoolBId = env.QA_SCHOOL_B_ID;
      const ownerBId = env.QA_OWNER_B_ID;

      await runAs('authenticated', { sub: ownerBId, role: 'owner', school_id: schoolBId }, async (c) => {
        // Query School A
        const schoolARes = await c.query('SELECT * FROM public.schools WHERE id = $1;', [schoolAId]);
        expect(schoolARes.rows.length).toBe(0);

        // Query School A branches
        const branches = await c.query('SELECT * FROM public.branches WHERE school_id = $1;', [schoolAId]);
        expect(branches.rows.length).toBe(0);

        // Query School A students
        const students = await c.query('SELECT * FROM public.school_students WHERE school_id = $1;', [schoolAId]);
        expect(students.rows.length).toBe(0);

        // Query School A workflows
        const workflows = await c.query('SELECT * FROM public.school_workflows WHERE school_id = $1;', [schoolAId]);
        expect(workflows.rows.length).toBe(0);
      });
    });

    it('School B Owner cannot insert rows into School A', async () => {
      const schoolAId = env.QA_SCHOOL_A_ID;
      const schoolBId = env.QA_SCHOOL_B_ID;
      const ownerBId = env.QA_OWNER_B_ID;

      await runAs('authenticated', { sub: ownerBId, role: 'owner', school_id: schoolBId }, async (c) => {
        await expect(
          c.query(`
            INSERT INTO public.branches (school_id, name, city, code)
            VALUES ($1, 'Rogue Branch', 'City', 'ROGUE');
          `, [schoolAId])
        ).rejects.toThrow();
      });
    });

    it('UPDATE cannot change school_id to forge cross-tenant ownership', async () => {
      const schoolAId = env.QA_SCHOOL_A_ID;
      const schoolBId = env.QA_SCHOOL_B_ID;
      const ownerAId = env.QA_OWNER_ID;
      const branch1Id = env.QA_BRANCH_1_ID;

      await runAs('authenticated', { sub: ownerAId, role: 'owner', school_id: schoolAId }, async (c) => {
        // Attempt mass-assignment modifying school_id
        await expect(
          c.query(`
            UPDATE public.branches 
            SET school_id = $1 
            WHERE id = $2;
          `, [schoolBId, branch1Id])
        ).rejects.toThrow();
      });
    });
  });

  describe('4. Role Jurisdiction & Policy Boundaries', () => {
    it('Master can view all schools but cannot read student-level attendance or grades directly', async () => {
      const masterId = env.QA_MASTER_ID;
      const schoolAId = env.QA_SCHOOL_A_ID;

      await runAs('authenticated', { sub: masterId, role: 'master', school_id: null }, async (c) => {
        const schools = await c.query('SELECT * FROM public.schools WHERE id = $1;', [schoolAId]);
        expect(schools.rows.length).toBe(1);

        // Direct student-level reads are blocked for master (platform aggregate RPCs only)
        const attendance = await c.query('SELECT * FROM public.attendance_records WHERE school_id = $1;', [schoolAId]);
        expect(attendance.rows.length).toBe(0);
      });
    });

    it('Principal North can view North Campus but cannot view South Campus', async () => {
      const principalNorthId = env.QA_PRINCIPAL_NORTH_ID;
      const schoolAId = env.QA_SCHOOL_A_ID;
      const branchNorthId = env.QA_BRANCH_1_ID;
      const branchSouthId = env.QA_BRANCH_2_ID;

      await runAs('authenticated', {
        sub: principalNorthId,
        role: 'principal',
        school_id: schoolAId,
        branch_ids: [branchNorthId],
      }, async (c) => {
        const northBranch = await c.query('SELECT * FROM public.branches WHERE id = $1;', [branchNorthId]);
        expect(northBranch.rows.length).toBe(1);

        const southBranch = await c.query('SELECT * FROM public.branches WHERE id = $1;', [branchSouthId]);
        expect(southBranch.rows.length).toBe(0);
      });
    });

    it('Teacher is denied access to school finance, fees, and payroll', async () => {
      const teacher1Id = env.QA_TEACHER_1_ID;
      const schoolAId = env.QA_SCHOOL_A_ID;
      const branch1Id = env.QA_BRANCH_1_ID;

      await runAs('authenticated', {
        sub: teacher1Id,
        role: 'teacher',
        school_id: schoolAId,
        branch_ids: [branch1Id],
      }, async (c) => {
        const fees = await c.query('SELECT * FROM public.student_fees WHERE school_id = $1;', [schoolAId]);
        expect(fees.rows.length).toBe(0);

        const payroll = await c.query('SELECT * FROM public.payroll_records WHERE school_id = $1;', [schoolAId]);
        expect(payroll.rows.length).toBe(0);

        const expenses = await c.query('SELECT * FROM public.expenses WHERE school_id = $1;', [schoolAId]);
        expect(expenses.rows.length).toBe(0);
      });
    });

    it('Accountant has access to fees & structures but is denied marks and academics', async () => {
      const accountantId = env.QA_ACCOUNTANT_ID;
      const schoolAId = env.QA_SCHOOL_A_ID;

      await runAs('authenticated', {
        sub: accountantId,
        role: 'accountant',
        school_id: schoolAId,
      }, async (c) => {
        const fees = await c.query('SELECT * FROM public.student_fees WHERE school_id = $1;', [schoolAId]);
        expect(fees.rows.length).toBeGreaterThan(0);

        const marks = await c.query('SELECT * FROM public.marks WHERE school_id = $1;', [schoolAId]);
        expect(marks.rows.length).toBe(0);
      });
    });

    it('Parent can only access their enrolled child fee records and not other children', async () => {
      const parent1Id = env.QA_PARENT_1_ID;
      const student1Id = env.QA_STUDENT_1_ID;
      const schoolAId = env.QA_SCHOOL_A_ID;
      const feeInvoiceId = env.QA_FEE_INVOICE_ID;

      await runAs('authenticated', {
        sub: parent1Id,
        role: 'parent',
        school_id: schoolAId,
      }, async (c) => {
        // Parent 1 owns Student 1
        const childFee = await c.query('SELECT * FROM public.student_fees WHERE id = $1;', [feeInvoiceId]);
        expect(childFee.rows.length).toBe(1);

        // Query student fees for an unrelated student
        const otherFees = await c.query(`
          SELECT * FROM public.student_fees 
          WHERE student_id != $1 AND school_id = $2;
        `, [student1Id, schoolAId]);
        expect(otherFees.rows.length).toBe(0);
      });
    });
  });

  describe('5. Immutability & Integrity Invariants', () => {
    it('Audit logs are append-only: UPDATE and DELETE are strictly denied', async () => {
      const ownerId = env.QA_OWNER_ID;
      const schoolAId = env.QA_SCHOOL_A_ID;

      await runAs('authenticated', { sub: ownerId, role: 'owner', school_id: schoolAId }, async (c) => {
        await expect(
          c.query(`UPDATE public.audit_logs SET action = 'tampered';`)
        ).rejects.toThrow();

        await expect(
          c.query(`DELETE FROM public.audit_logs WHERE is_qa = false;`)
        ).rejects.toThrow();
      });
    });

    it('Role escalation is impossible: RLS uses app_metadata / profiles, never user_metadata', async () => {
      const student1Id = env.QA_STUDENT_1_ID;
      const schoolAId = env.QA_SCHOOL_A_ID;

      // Simulated user with forged user_metadata role = 'owner'
      await client.query('BEGIN;');
      try {
        await client.query('SET LOCAL ROLE authenticated;');
        const forgedJwt = {
          sub: student1Id,
          role: 'authenticated',
          app_metadata: { role: 'student', school_id: schoolAId, is_qa: true },
          user_metadata: { role: 'owner', is_qa: true }, // Forged user metadata
        };
        await client.query(`SELECT set_config('request.jwt.claims', $1, true);`, [JSON.stringify(forgedJwt)]);

        // current_user_role must resolve to student
        const roleRes = await client.query('SELECT public.current_user_role();');
        expect(roleRes.rows[0].current_user_role).toBe('student');

        // Cannot view owner-only records
        const adminRecs = await client.query('SELECT * FROM public.admin_records WHERE school_id = $1;', [schoolAId]);
        expect(adminRecs.rows.length).toBe(0);
      } finally {
        await client.query('ROLLBACK;');
      }
    });

    it('Deactivated user (active = false) has zero permissions', async () => {
      const teacher1Id = env.QA_TEACHER_1_ID;
      const schoolAId = env.QA_SCHOOL_A_ID;

      await client.query('BEGIN;');
      try {
        // Deactivate teacher in profiles
        await client.query('UPDATE public.profiles SET active = false WHERE id = $1;', [teacher1Id]);

        await client.query('SET LOCAL ROLE authenticated;');
        const jwtPayload = {
          sub: teacher1Id,
          role: 'authenticated',
          app_metadata: { role: 'teacher', school_id: schoolAId, is_qa: true },
        };
        await client.query(`SELECT set_config('request.jwt.claims', $1, true);`, [JSON.stringify(jwtPayload)]);

        // Workflows should return 0 rows for deactivated user
        const wf = await client.query('SELECT * FROM public.school_workflows WHERE school_id = $1;', [schoolAId]);
        expect(wf.rows.length).toBe(0);
      } finally {
        await client.query('ROLLBACK;');
      }
    });
  });

  describe('6. Query Performance & EXPLAIN Health Checks', () => {
    it('Key queries execute with Index Scans and zero sequential scans on high-volume tables', async () => {
      const schoolAId = env.QA_SCHOOL_A_ID;
      const branch1Id = env.QA_BRANCH_1_ID;

      // Disable seqscan to prove indexes are valid, indexed, and chosen by PostgreSQL planner
      await client.query('SET enable_seqscan = off;');

      // 1. Attendance lookup
      const attPlan = await client.query(`
        EXPLAIN (ANALYZE, BUFFERS)
        SELECT * FROM public.attendance_records
        WHERE school_id = $1 AND branch_id = $2 AND date = CURRENT_DATE;
      `, [schoolAId, branch1Id]);
      const attText = attPlan.rows.map(r => r['QUERY PLAN']).join('\n');
      expect(attText).not.toContain('Seq Scan on attendance_records');

      // 2. Audit logs lookup
      const auditPlan = await client.query(`
        EXPLAIN (ANALYZE, BUFFERS)
        SELECT * FROM public.audit_logs
        WHERE school_id = $1
        ORDER BY created_at DESC
        LIMIT 50;
      `, [schoolAId]);
      const auditText = auditPlan.rows.map(r => r['QUERY PLAN']).join('\n');
      expect(auditText).not.toContain('Seq Scan on audit_logs');

      // 3. Student fees lookup
      const feePlan = await client.query(`
        EXPLAIN (ANALYZE, BUFFERS)
        SELECT * FROM public.student_fees
        WHERE school_id = $1 AND status = 'Pending';
      `, [schoolAId]);
      const feeText = feePlan.rows.map(r => r['QUERY PLAN']).join('\n');
      expect(feeText).not.toContain('Seq Scan on student_fees');

      await client.query('SET enable_seqscan = on;');
    });
  });
});
