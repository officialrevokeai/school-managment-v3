import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { PGlite } from "@electric-sql/pglite";
import { readFile } from "node:fs/promises";
const db = new PGlite();
const owner = "11111111-1111-1111-1111-111111111111";
const master = "22222222-2222-2222-2222-222222222222";
const school = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa";
const branch = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb";
const recordId = "cccccccc-cccc-cccc-cccc-cccccccccccc";
async function asUser(id: string, role: string) {
  await db.exec("reset role");
  await db.query(
    "select set_config('request.jwt.claim.sub',$1,false),set_config('request.jwt.claims',$2,false)",
    [id, JSON.stringify({ app_metadata: { role } })],
  );
  await db.exec("set role authenticated");
}
beforeAll(async () => {
  await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
  create schema auth; create schema storage;
  create table auth.users(id uuid primary key,raw_app_meta_data jsonb default '{}');
  create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
  create function auth.jwt() returns jsonb language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb $$;
  grant usage on schema auth,storage to authenticated;
  create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
  create table storage.objects(id uuid default gen_random_uuid(),bucket_id text,name text);
  alter table storage.objects enable row level security;
  create function storage.foldername(text) returns text[] language sql immutable as $$ select (string_to_array($1,'/'))[1:array_length(string_to_array($1,'/'),1)-1] $$;
  create publication supabase_realtime;
  `);
  await db.exec(await readFile("database/phase1.sql", "utf8"));
  await db.query("insert into auth.users(id) values($1),($2)", [owner, master]);
  await db.query(
    "insert into public.profiles(id,school_id,name,email,role,branch_ids) values($1,$3,'School Owner','owner@test.edu','owner',array[$4::uuid]),($2,$3,'Platform Admin','master@test.edu','master',array[$4::uuid])",
    [owner, master, school, branch],
  );
  await db.query(
    "insert into public.branches(id,school_id,name,city,short_name) values($1,$2,'North Campus','Bengaluru','North')",
    [branch, school],
  );
  await db.exec(await readFile("database/phase2.sql", "utf8"));
  await db.exec(await readFile("database/phases3-5.sql", "utf8"));
  await db.exec(await readFile("database/workflow-catalog.sql", "utf8"));
}, 180000);
afterAll(async () => {
  await db.close();
});
describe("Phase 2 SQL authorization", () => {
  it("enforces classroom, family, and accountant workflow boundaries", async () => {
    await db.exec("reset role");
    const teacher = "33333333-3333-3333-3333-333333333333",
      parent = "44444444-4444-4444-4444-444444444444",
      accountant = "55555555-5555-5555-5555-555555555555",
      classA = "66666666-6666-6666-6666-666666666666",
      classB = "77777777-7777-7777-7777-777777777777",
      childA = "88888888-8888-8888-8888-888888888888",
      childB = "99999999-9999-9999-9999-999999999999";
    for (const [id, role] of [
      [teacher, "teacher"],
      [parent, "parent"],
      [accountant, "accountant"],
    ]) {
      await db.query("insert into auth.users(id) values($1)", [id]);
      await db.query(
        "insert into public.profiles(id,school_id,name,email,role,branch_ids) values($1,$2,$3,$4,$3,array[$5::uuid])",
        [id, school, role, `${role}@test.edu`, branch],
      );
    }
    await db.query(
      "insert into public.school_classes(id,school_id,branch_id,name) values($1,$3,$4,'8A'),($2,$3,$4,'9B')",
      [classA, classB, school, branch],
    );
    await db.query(
      "insert into public.school_students(id,school_id,branch_id,class_id,name) values($1,$3,$4,$5,'Child A'),($2,$3,$4,$6,'Child B')",
      [childA, childB, school, branch, classA, classB],
    );
    await db.query(
      "insert into public.school_memberships(user_id,class_ids,student_ids) values($1,array[$3::uuid],array[]::uuid[]),($2,array[]::uuid[],array[$4::uuid])",
      [teacher, parent, classA, childA],
    );
    await asUser(owner, "owner");
    const make = (id: string, cid: string, sid: string, status: string) => ({
      id,
      schoolId: school,
      branchId: branch,
      classId: cid,
      studentId: sid,
      authorId: owner,
      module: "marks",
      version: 1,
      updatedAt: new Date().toISOString(),
      data: {
        title: "Assessment",
        subject: "Math",
        date: "2026-10-31",
        score: 80,
        maximum: 100,
        status,
        notes: "",
      },
    });
    const first = make(
      "abababab-abab-abab-abab-abababababab",
      classA,
      childA,
      "Published",
    );
    await db.query("select public.workflow_save($1::jsonb)", [
      JSON.stringify(first),
    ]);
    await db.query("select public.workflow_save($1::jsonb)", [
      JSON.stringify(
        make(
          "cdcdcdcd-cdcd-cdcd-cdcd-cdcdcdcdcdcd",
          classB,
          childB,
          "Published",
        ),
      ),
    ]);
    await asUser(teacher, "teacher");
    const list = await db.query<{ r: { rows: { studentId: string }[] } }>(
      "select public.workflow_list($1,$2::jsonb) as r",
      ["marks", JSON.stringify({ branchId: branch })],
    );
    expect(list.rows[0]?.r.rows.map((r) => r.studentId)).toEqual([childA]);
    await expect(
      db.query("select public.workflow_save($1::jsonb)", [
        JSON.stringify(
          make("dededede-dede-dede-dede-dededededede", classB, childB, "Draft"),
        ),
      ]),
    ).rejects.toThrow("access denied");
    await asUser(parent, "parent");
    const family = await db.query<{ r: { rows: { studentId: string }[] } }>(
      "select public.workflow_list($1,$2::jsonb) as r",
      ["marks", JSON.stringify({ branchId: branch })],
    );
    expect(family.rows[0]?.r.rows.map((r) => r.studentId)).toEqual([childA]);
    await asUser(accountant, "accountant");
    expect(
      (
        await db.query(
          "select * from public.school_workflows where module=$1",
          ["marks"],
        )
      ).rows,
    ).toHaveLength(0);
    await asUser(owner, "owner");
  });
  it("allows a scoped owner write and produces an append-only audit event", async () => {
    await asUser(owner, "owner");
    const record = {
      id: recordId,
      schoolId: school,
      branchId: branch,
      version: 1,
      reference: "REC-01",
      description: "Tuition collection",
      kind: "Income",
      category: "Tuition",
      amount: 5000,
      date: "2026-10-31",
      status: "Paid",
    };
    const saved = await db.query<{ result: { version: number } }>(
      "select public.admin_save($1,$2::jsonb) as result",
      ["finance", JSON.stringify(record)],
    );
    expect(saved.rows[0]?.result.version).toBe(1);
    const summary = await db.query<{ result: { income: number } }>(
      "select public.admin_summary($1::jsonb) as result",
      [JSON.stringify({ schoolId: school })],
    );
    expect(summary.rows[0]?.result.income).toBe(5000);
    await expect(
      db.exec("delete from public.admin_records where resource='audit'"),
    ).rejects.toThrow();
  });
  it("rejects cross-tenant writes and stale versions", async () => {
    await asUser(owner, "owner");
    const base = {
      id: recordId,
      schoolId: school,
      branchId: branch,
      version: 1,
      reference: "REC-01",
      description: "Tuition collection",
      kind: "Income",
      category: "Tuition",
      amount: 6000,
      date: "2026-10-31",
      status: "Paid",
    };
    await expect(
      db.query("select public.admin_save($1,$2::jsonb)", [
        "finance",
        JSON.stringify({
          ...base,
          schoolId: "dddddddd-dddd-dddd-dddd-dddddddddddd",
        }),
      ]),
    ).rejects.toThrow("School access denied");
    await db.query("select public.admin_save($1,$2::jsonb)", [
      "finance",
      JSON.stringify(base),
    ]);
    await expect(
      db.query("select public.admin_save($1,$2::jsonb)", [
        "finance",
        JSON.stringify(base),
      ]),
    ).rejects.toThrow("Record changed");
  });
  it("fails closed when no trusted actor exists", async () => {
    await asUser("", "owner");
    await expect(
      db.query("select public.admin_delete($1,$2,$3::jsonb,$4)", [
        "finance",
        recordId,
        JSON.stringify({ schoolId: school }),
        2,
      ]),
    ).rejects.toThrow("Authentication required");
  });
  it("revokes school data immediately when the platform suspends it", async () => {
    await asUser(master, "master");
    const list = await db.query<{
      result: { rows: { id: string; version: number; status: string }[] };
    }>("select public.admin_list($1,$2::jsonb,$3::jsonb) as result", [
      "schools",
      JSON.stringify({ schoolId: school }),
      "{}",
    ]);
    const existing = list.rows[0]?.result.rows[0];
    expect(existing).toBeDefined();
    await db.query("select public.admin_save($1,$2::jsonb)", [
      "schools",
      JSON.stringify({ ...existing, status: "Suspended" }),
    ]);
    await asUser(owner, "owner");
    const profiles = await db.query("select id from public.profiles");
    expect(profiles.rows).toHaveLength(0);
    await expect(
      db.query("select public.admin_delete($1,$2,$3::jsonb,$4)", [
        "finance",
        recordId,
        JSON.stringify({ schoolId: school }),
        2,
      ]),
    ).rejects.toThrow("School owner access required");
  });
});
