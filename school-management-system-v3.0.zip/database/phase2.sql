-- Apply after phase1.sql in a development Supabase project.
-- Administrative documents use typed, versioned JSON payloads; tenant columns stay relational.
create schema if not exists private;
revoke all on schema private from public, anon;
grant usage on schema private to authenticated;
alter table public.profiles add column if not exists active boolean not null default true;
alter table public.profiles add column if not exists policy_id uuid;
alter table public.branches add column if not exists active boolean not null default true;
create table if not exists public.admin_records (
  id uuid primary key,
  school_id uuid not null,
  branch_id uuid,
  resource text not null check(resource in ('schools','branches','users','finance','roles','settings','templates','audit','analytics')),
  payload jsonb not null check(jsonb_typeof(payload) = 'object'),
  version integer not null default 1 check(version > 0),
  updated_at timestamptz not null default now()
);
create index if not exists admin_records_scope_idx on public.admin_records(resource,school_id,branch_id,updated_at desc,id);
create unique index if not exists admin_school_code_idx on public.admin_records(lower(payload->>'code')) where resource = 'schools';
create unique index if not exists admin_user_email_idx on public.admin_records(school_id,lower(payload->>'email')) where resource = 'users';
create unique index if not exists admin_role_idx on public.admin_records(school_id,(payload->>'role')) where resource = 'roles' and coalesce((payload->>'custom')::boolean,false)=false;
create unique index if not exists admin_settings_idx on public.admin_records(school_id) where resource = 'settings';
alter table public.admin_records enable row level security;
revoke all on public.admin_records from public,anon,authenticated;
grant select on public.admin_records to authenticated;
grant all on public.admin_records to service_role;

-- This narrowly scoped lookup deliberately bypasses admin_records RLS to avoid recursive profile policies.
create or replace function private.school_active(p_school uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select (select auth.uid()) is not null and exists(select 1 from public.admin_records r where r.resource='schools' and r.id=p_school and r.payload->>'status'='Active');
$$;
revoke all on function private.school_active(uuid) from public,anon;
grant execute on function private.school_active(uuid) to authenticated;
drop policy if exists "Read own provisioned profile" on public.profiles;
create policy "Read own provisioned profile" on public.profiles for select to authenticated using (
  id=(select auth.uid()) and active and role=(select auth.jwt()->'app_metadata'->>'role') and coalesce(policy_id::text,'')=coalesce((select auth.jwt()->'app_metadata'->>'policy_id'),'') and (role='master' or private.school_active(school_id))
);
drop policy if exists "Assigned campuses in own school" on public.branches;
create policy "Assigned campuses in own school" on public.branches for select to authenticated using (
  active and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.school_id=branches.school_id and (p.role='owner' or branches.id=any(p.branch_ids)))
);
drop policy if exists "Read own scoped notifications" on public.notifications;
create policy "Read own scoped notifications" on public.notifications for select to authenticated using(user_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid())) and (branch_id is null or exists(select 1 from public.branches b where b.id=notifications.branch_id)));
drop policy if exists "Mark own scoped notifications read" on public.notifications;
create policy "Mark own scoped notifications read" on public.notifications for update to authenticated using(user_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid())) and (branch_id is null or exists(select 1 from public.branches b where b.id=notifications.branch_id))) with check(user_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid())) and (branch_id is null or exists(select 1 from public.branches b where b.id=notifications.branch_id)));
drop policy if exists "Read scoped administration" on public.admin_records;
create policy "Read scoped administration" on public.admin_records for select to authenticated using (
  exists(select 1 from public.profiles p where p.id=(select auth.uid()) and (
    (p.role='master' and (resource in ('schools','audit') or (resource='roles' and school_id='00000000-0000-0000-0000-000000000000'::uuid))) or
    (p.role='owner' and school_id=p.school_id and resource<>'schools') or
    (resource='roles' and (school_id=p.school_id or school_id='00000000-0000-0000-0000-000000000000'::uuid))
  ))
);

create or replace function private.audit_admin_change() returns trigger language plpgsql security definer set search_path='' as $$
declare r public.admin_records; who uuid; event_id uuid; actor_name text;
begin
  if tg_op='DELETE' then r:=old; else r:=new; end if;
  if r.resource='audit' then return null; end if;
  who:=coalesce(auth.uid(),nullif(current_setting('app.provision_actor',true),'')::uuid);
  select name into actor_name from public.profiles where id=who;
  event_id:=gen_random_uuid();
  insert into public.admin_records(id,school_id,resource,payload) values(event_id,r.school_id,'audit',jsonb_build_object('id',event_id,'schoolId',r.school_id,'branchId',null,'version',1,'actor',coalesce(actor_name,'Trusted provisioning'),'action',tg_op,'resource',r.resource,'details',r.resource||' record '||r.id::text,'createdAt',now()));
  return null;
end $$;
revoke all on function private.audit_admin_change() from public,anon,authenticated;
drop trigger if exists audit_admin_change on public.admin_records;
create trigger audit_admin_change after insert or update or delete on public.admin_records for each row execute function private.audit_admin_change();

create or replace function public.admin_list(p_resource text,p_scope jsonb,p_options jsonb default '{}') returns jsonb language sql stable security invoker set search_path='' as $$
  with allowed as (
    select r.* from public.admin_records r where r.resource=p_resource
    and (p_resource='schools' or (p_resource='audit' and (select auth.jwt()->'app_metadata'->>'role')='master') or r.school_id=(p_scope->>'schoolId')::uuid)
    and (coalesce(p_scope->>'branchId','')='' or p_resource in ('roles','settings') or r.branch_id=(p_scope->>'branchId')::uuid)
    and (coalesce(p_options->>'search','')='' or r.payload::text ilike '%'||(p_options->>'search')||'%')
    and r.payload @> coalesce(p_options->'filters','{}'::jsonb)
    and (coalesce(p_options->>'from','')='' or left(coalesce(r.payload->>'date',r.payload->>'createdAt',''),10)>=p_options->>'from')
    and (coalesce(p_options->>'to','')='' or left(coalesce(r.payload->>'date',r.payload->>'createdAt',''),10)<=p_options->>'to')
  ), paged as (select * from allowed order by updated_at desc,id limit least(500,greatest(1,coalesce((p_options->>'pageSize')::int,50))) offset greatest(0,coalesce((p_options->>'page')::int,0))*least(500,greatest(1,coalesce((p_options->>'pageSize')::int,50))))
  select jsonb_build_object('rows',coalesce((select jsonb_agg(payload||jsonb_build_object('version',version) order by updated_at desc,id) from paged),'[]'::jsonb),'total',(select count(*) from allowed));
$$;

-- Writes are restricted to one checked private function. Direct table writes stay revoked.
create or replace function private.admin_save_checked(p_resource text,p_record jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare actor public.profiles; existing public.admin_records; rid uuid; sid uuid; bid uuid; next_version int; result jsonb;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into actor from public.profiles where id=auth.uid() and active and role=auth.jwt()->'app_metadata'->>'role';
  if actor.id is null or actor.role not in ('owner','master') then raise exception 'Administrative access required'; end if;
  if p_resource not in ('schools','branches','users','finance','roles','settings','templates') then raise exception 'Resource cannot be edited'; end if;
  if not p_record ?& array['id','schoolId','branchId','version'] then raise exception 'Missing record metadata'; end if;
  if p_resource='schools' and not p_record ?& array['name','code','ownerEmail','plan','status','monthlyFee','createdAt'] then raise exception 'Incomplete school'; end if;
  if p_resource='branches' and not p_record ?& array['name','city','code','principal','capacity','status'] then raise exception 'Incomplete campus'; end if;
  if p_resource='users' and not p_record ?& array['name','email','role','status','phone','joinedAt'] then raise exception 'Incomplete directory record'; end if;
  if p_resource='finance' and not p_record ?& array['reference','description','kind','category','amount','date','status'] then raise exception 'Incomplete transaction'; end if;
  if p_resource='roles' and not p_record ?& array['name','role','permissions'] then raise exception 'Incomplete role'; end if;
  if p_resource='settings' and not p_record ?& array['name','academicYear','logoPath','senderNumber','financeRole','overrideEnabled','requireMfa','sessionMinutes','privacyEmail','retentionDays'] then raise exception 'Incomplete settings'; end if;
  if p_resource='templates' and not p_record ?& array['name','category','body','status'] then raise exception 'Incomplete template'; end if;
  rid:=(p_record->>'id')::uuid; sid:=(p_record->>'schoolId')::uuid; bid:=nullif(p_record->>'branchId','')::uuid;
  if actor.role='owner' then
    if sid<>actor.school_id or not private.school_active(sid) or p_resource='schools' then raise exception 'School access denied'; end if;
  elsif not (p_resource='schools' or (p_resource='roles' and sid='00000000-0000-0000-0000-000000000000'::uuid)) then raise exception 'Platform resource required'; end if;
  if p_resource='schools' and (rid<>sid or p_record->>'status' not in ('Active','Suspended','Deleted') or (p_record->>'monthlyFee')::numeric<0) then raise exception 'Invalid school record'; end if;
  if p_resource='branches' and (length(p_record->>'name')<2 or (p_record->>'capacity')::int<1 or bid<>rid) then raise exception 'Invalid campus record'; end if;
  if p_resource='users' and (p_record->>'role' not in ('principal','teacher','parent','student','accountant') or p_record->>'status' not in ('Active','Inactive') or p_record->>'email' not like '%@%') then raise exception 'Invalid directory record'; end if;
  if p_resource='finance' and ((p_record->>'amount')::numeric<=0 or p_record->>'kind' not in ('Income','Expense') or p_record->>'status' not in ('Paid','Pending','Overdue')) then raise exception 'Invalid financial record'; end if;
  if p_resource='roles' and (p_record->>'role' not in ('principal','teacher','parent','student','accountant') or p_record->'permissions' ? 'master.manage' or not p_record->'permissions' ? 'workspace.read') then raise exception 'Protected role or permission'; end if;
  if p_resource='settings' and ((p_record->>'sessionMinutes')::int not between 15 and 480 or (p_record->>'retentionDays')::int not between 30 and 3650 or p_record->>'senderNumber' !~ '^\+[1-9][0-9]{7,14}$') then raise exception 'Invalid school configuration'; end if;
  if p_resource='templates' then p_record:=jsonb_set(p_record,'{status}','"Draft"'::jsonb); end if;
  if bid is not null and p_resource<>'branches' and not exists(select 1 from public.admin_records where resource='branches' and school_id=sid and id=bid) then raise exception 'Campus is outside this school'; end if;
  select * into existing from public.admin_records where id=rid for update;
  if existing.id is not null and (existing.school_id<>sid or existing.resource<>p_resource or existing.version<>(p_record->>'version')::int) then raise exception 'Record changed; refresh before saving'; end if;
  if existing.id is not null and p_resource='schools' and (existing.payload->>'ownerEmail'<>p_record->>'ownerEmail' or existing.payload->>'code'<>p_record->>'code') then raise exception 'Login identity changes require trusted Auth administration'; end if;
  if existing.id is null and p_resource='schools' then raise exception 'Use trusted school provisioning'; end if;
  next_version:=coalesce(existing.version,0)+1; result:=p_record||jsonb_build_object('version',next_version);
  insert into public.admin_records(id,school_id,branch_id,resource,payload,version) values(rid,sid,bid,p_resource,result,next_version)
    on conflict(id) do update set payload=excluded.payload,version=excluded.version,branch_id=excluded.branch_id,updated_at=now();
  if p_resource='branches' then
    insert into public.branches(id,school_id,name,city,short_name,active) values(rid,sid,p_record->>'name',p_record->>'city',p_record->>'name',p_record->>'status'='Active')
      on conflict(id) do update set name=excluded.name,city=excluded.city,short_name=excluded.short_name,active=excluded.active;
    update public.profiles set branch_ids=array(select distinct unnest(branch_ids||array[rid])) where school_id=sid and role='owner';
  end if;
  if p_resource='users' then
    if nullif(p_record->>'policyId','') is not null and not exists(select 1 from public.admin_records where id=(p_record->>'policyId')::uuid and resource='roles' and school_id=sid and payload->>'role'=p_record->>'role') then raise exception 'Role policy is outside this school or base role'; end if;
    update public.profiles set name=p_record->>'name',role=p_record->>'role',branch_ids=array[bid],active=p_record->>'status'='Active',policy_id=nullif(p_record->>'policyId','')::uuid where school_id=sid and lower(email)=lower(p_record->>'email') and role<>'owner';
    update auth.users u set raw_app_meta_data=coalesce(u.raw_app_meta_data,'{}'::jsonb)||jsonb_build_object('role',p_record->>'role','policy_id',nullif(p_record->>'policyId','')) where exists(select 1 from public.profiles p where p.id=u.id and p.school_id=sid and lower(p.email)=lower(p_record->>'email') and p.role<>'owner');
  end if;
  return result;
end $$;
revoke all on function private.admin_save_checked(text,jsonb) from public,anon;
grant execute on function private.admin_save_checked(text,jsonb) to authenticated;
create or replace function public.admin_save(p_resource text,p_record jsonb) returns jsonb language sql security invoker set search_path='' as $$ select private.admin_save_checked(p_resource,p_record); $$;

create or replace function private.admin_delete_checked(p_resource text,p_id uuid,p_scope jsonb,p_version int) returns jsonb language plpgsql security definer set search_path='' as $$
declare actor public.profiles; existing public.admin_records; sid uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into actor from public.profiles where id=auth.uid() and active and role=auth.jwt()->'app_metadata'->>'role';
  sid:=(p_scope->>'schoolId')::uuid;
  if actor.id is null or actor.role<>'owner' or actor.school_id<>sid or not private.school_active(sid) then raise exception 'School owner access required'; end if;
  if p_resource not in ('branches','users','finance','templates') then raise exception 'Protected resource'; end if;
  select * into existing from public.admin_records where id=p_id and school_id=sid and resource=p_resource for update;
  if existing.id is null or existing.version<>p_version then raise exception 'Record changed; refresh before deleting'; end if;
  if p_resource='branches' and exists(select 1 from public.admin_records where resource='users' and school_id=sid and branch_id=p_id) then raise exception 'Move assigned people before deleting this campus'; end if;
  if p_resource='users' then update public.profiles set active=false where school_id=sid and lower(email)=lower(existing.payload->>'email') and role<>'owner'; end if;
  if p_resource='branches' then
    delete from public.branches where id=p_id and school_id=sid;
    update public.profiles set branch_ids=array_remove(branch_ids,p_id) where school_id=sid;
  end if;
  delete from public.admin_records where id=p_id;
  return jsonb_build_object('deleted',true);
end $$;
revoke all on function private.admin_delete_checked(text,uuid,jsonb,int) from public,anon;
grant execute on function private.admin_delete_checked(text,uuid,jsonb,int) to authenticated;
create or replace function public.admin_delete(p_resource text,p_id text,p_scope jsonb,p_version int) returns jsonb language sql security invoker set search_path='' as $$ select private.admin_delete_checked(p_resource,p_id::uuid,p_scope,p_version); $$;

create or replace function public.admin_summary(p_scope jsonb) returns jsonb language sql stable security invoker set search_path='' as $$
 with scoped as (select resource,payload from public.admin_records where school_id=(p_scope->>'schoolId')::uuid and (coalesce(p_scope->>'branchId','')='' or branch_id=(p_scope->>'branchId')::uuid)),
 finances as (select payload from scoped where resource='finance'), people as (select payload from scoped where resource='users' and payload->>'status'='Active'), schools as (select payload from public.admin_records where resource='schools' and (coalesce(p_scope->>'from','')='' or left(payload->>'createdAt',10)>=p_scope->>'from') and (coalesce(p_scope->>'to','')='' or left(payload->>'createdAt',10)<=p_scope->>'to')),
 months as (select generate_series(date_trunc('month',now())-interval '5 months',date_trunc('month',now()),interval '1 month') as month),
 revenue as (select to_char(month,'Mon') as label,month,coalesce(sum((payload->>'amount')::numeric) filter(where payload->>'kind'='Income'),0) as income,coalesce(sum((payload->>'amount')::numeric) filter(where payload->>'kind'='Expense'),0) as expense from months left join finances on left(payload->>'date',7)=to_char(month,'YYYY-MM') and payload->>'status'='Paid' group by month)
 select jsonb_build_object(
 'students',(select count(*) from people where payload->>'role'='student'),'staff',(select count(*) from people where payload->>'role' in ('teacher','principal','accountant')),
 'attendance',coalesce((select jsonb_agg(jsonb_build_object('label',to_char(month::date,'Mon'),'value',rate) order by month) from (select left(payload->>'date',7)||'-01' as month,round(100.0*sum((payload->>'present')::numeric)/nullif(sum((payload->>'total')::numeric),0),1) as rate from scoped where resource='analytics' group by left(payload->>'date',7)) monthly where rate is not null),'[]'::jsonb),
 'income',coalesce((select sum((payload->>'amount')::numeric) from finances where payload->>'kind'='Income' and payload->>'status'='Paid'),0),
 'expenses',coalesce((select sum((payload->>'amount')::numeric) from finances where payload->>'kind'='Expense' and payload->>'status'='Paid'),0),
 'outstanding',coalesce((select sum((payload->>'amount')::numeric) from finances where payload->>'kind'='Income' and payload->>'status'<>'Paid'),0),
 'schools',(select count(*) from schools),'active',(select count(*) from schools where payload->>'status'='Active'),'suspended',(select count(*) from schools where payload->>'status'<>'Active'),
 'mrr',coalesce((select sum((payload->>'monthlyFee')::numeric) from schools where payload->>'status'='Active'),0),
 'revenue',case when (select auth.jwt()->'app_metadata'->>'role')='master' then coalesce((select jsonb_agg(jsonb_build_object('label',payload->>'code','value',case when payload->>'status'='Active' then (payload->>'monthlyFee')::numeric else 0 end)) from (select payload from schools order by (payload->>'monthlyFee')::numeric desc limit 10) top_schools),'[]'::jsonb) else coalesce((select jsonb_agg(jsonb_build_object('label',label,'value',income,'secondary',expense) order by month) from revenue),'[]'::jsonb) end,
 'enrollment',case when (select auth.jwt()->'app_metadata'->>'role')='master' then coalesce((select jsonb_agg(jsonb_build_object('label',plan,'value',(select count(*) from schools where payload->>'plan'=plan and payload->>'status'='Active'))) from unnest(array['Starter','Growth','Enterprise']) plan),'[]'::jsonb) else coalesce((select jsonb_agg(jsonb_build_object('label',b.payload->>'code','value',(select count(*) from people p where p.payload->>'branchId'=b.payload->>'id' and p.payload->>'role'='student'))) from scoped b where b.resource='branches'),'[]'::jsonb) end
 );
$$;

-- Only the trusted Edge Function can finalize Auth + school provisioning.
create or replace function public.provision_school_record(p_school jsonb,p_owner_id uuid,p_actor uuid) returns jsonb language plpgsql security invoker set search_path='' as $$
declare sid uuid; bid uuid; rid uuid; item jsonb;
begin
 if not exists(select 1 from public.profiles where id=p_actor and role='master' and active) then raise exception 'Platform administrator required'; end if;
 sid:=(p_school->>'id')::uuid; bid:=gen_random_uuid(); perform set_config('app.provision_actor',p_actor::text,true);
 insert into public.admin_records(id,school_id,resource,payload) values(sid,sid,'schools',p_school);
 insert into public.branches(id,school_id,name,city,short_name) values(bid,sid,'Main Campus','Unassigned','Main Campus');
 insert into public.admin_records(id,school_id,branch_id,resource,payload) values(bid,sid,bid,'branches',jsonb_build_object('id',bid,'schoolId',sid,'branchId',bid,'version',1,'name','Main Campus','city','Unassigned','code',p_school->>'code'||'-MAIN','principal','','capacity',1000,'status','Active'));
 insert into public.profiles(id,school_id,name,email,role,branch_ids) values(p_owner_id,sid,p_school->>'name'||' Owner',p_school->>'ownerEmail','owner',array[bid]);
 for item in select payload from public.admin_records where resource='roles' and school_id='00000000-0000-0000-0000-000000000000'::uuid loop
  rid:=gen_random_uuid(); insert into public.admin_records(id,school_id,resource,payload) values(rid,sid,'roles',item||jsonb_build_object('id',rid,'schoolId',sid,'version',1));
 end loop;
 return p_school;
end $$;
revoke all on function public.provision_school_record(jsonb,uuid,uuid) from public,anon,authenticated;
grant execute on function public.provision_school_record(jsonb,uuid,uuid) to service_role;
revoke all on function public.admin_list(text,jsonb,jsonb),public.admin_save(text,jsonb),public.admin_delete(text,text,jsonb,int),public.admin_summary(jsonb) from public,anon;
grant execute on function public.admin_list(text,jsonb,jsonb),public.admin_save(text,jsonb),public.admin_delete(text,text,jsonb,int),public.admin_summary(jsonb) to authenticated;

-- Bootstrap existing Phase 1 tenants and campuses without replacing any configured records.
insert into public.admin_records(id,school_id,resource,payload)
select school_id,school_id,'schools',jsonb_build_object('id',school_id,'schoolId',school_id,'branchId',null,'version',1,'name',max(name)||' School','code','SCH-'||left(school_id::text,8),'ownerEmail',max(email),'plan','Starter','status','Active','monthlyFee',0,'createdAt',current_date)
from public.profiles where role='owner' group by school_id on conflict do nothing;
insert into public.admin_records(id,school_id,branch_id,resource,payload)
select id,school_id,id,'branches',jsonb_build_object('id',id,'schoolId',school_id,'branchId',id,'version',1,'name',short_name,'city',city,'code',left(id::text,8),'principal','','capacity',1000,'status',case when active then 'Active' else 'Inactive' end)
from public.branches on conflict do nothing;
insert into public.admin_records(id,school_id,resource,payload)
select gen_random_uuid(),scope,'roles',jsonb_build_object('id',rid,'schoolId',scope,'branchId',null,'version',1,'name',role_name,'role',role_name,'permissions',grants)
from (select distinct school_id as scope from public.profiles where role='owner' union select '00000000-0000-0000-0000-000000000000'::uuid) schools
cross join (values
 ('owner','["workspace.read","users.manage","branches.manage","academics.read","attendance.manage","finance.manage","child.read","whatsapp.manage","system.manage"]'::jsonb),
 ('principal','["workspace.read","users.manage","academics.read","attendance.manage"]'::jsonb),
 ('teacher','["workspace.read","academics.read","attendance.manage"]'::jsonb),
 ('parent','["workspace.read","child.read"]'::jsonb),
 ('student','["workspace.read","child.read"]'::jsonb),
 ('accountant','["workspace.read","finance.manage"]'::jsonb)
) defaults(role_name,grants)
cross join lateral (select gen_random_uuid() as rid) ids on conflict do nothing;
-- Keep document IDs aligned with their relational keys, including seeded role policies.
update public.admin_records set payload=jsonb_set(payload,'{id}',to_jsonb(id::text)) where payload->>'id'<>id::text;
