# Database API & Remote Procedure Calls (RPC)

All client-to-database mutations and complex aggregations execute through typed Remote Procedure Calls (RPCs) and Edge Functions.

## Core Admin RPCs

### `admin_summary(p_scope: jsonb)`
Returns high-level statistics for the dashboard according to the caller's role.
- **Parameters**: `p_scope` (`{ schoolId: string, branchId?: string, from?: string, to?: string }`)
- **Returns**:
  ```json
  {
    "students": 450,
    "staff": 32,
    "attendance": [{ "label": "Oct", "value": 94.2 }],
    "income": 1250000.00,
    "expenses": 820000.00,
    "outstanding": 140000.00,
    "revenue": [{ "label": "Oct", "value": 240000, "secondary": 160000 }],
    "enrollment": [{ "label": "Main", "value": 450 }]
  }
  ```

### `admin_list(p_resource: text, p_scope: jsonb, p_options: jsonb)`
Keyset/offset paginated listing of administrative records.
- **Parameters**:
  - `p_resource`: Resource name (`branches`, `users`, `finance`, `roles`, `settings`, `audit`)
  - `p_scope`: Scope filter (`{ schoolId: string, branchId?: string }`)
  - `p_options`: Pagination and search (`{ page?: number, pageSize?: number, search?: string }`)
- **Returns**: `{ rows: any[], total: number }`

### `admin_save(p_resource: text, p_record: jsonb)`
Saves or updates an administrative record with optimistic concurrency version control.
- **Parameters**: `p_resource`, `p_record` (`{ id, schoolId, branchId, version, ...data }`)
- **Returns**: Updated record with incremented version.

### `admin_delete(p_resource: text, p_id: text, p_scope: jsonb, p_version: int)`
Removes an administrative record if version matches.

---

## Domain Workflow RPCs

### `workflow_context(p_branch: uuid)`
Fetches lightweight roster context for dropdowns and form selectors.
- **Returns**: `{ students: Array<{ id, name, classId, branchId }>, classes: Array<{ id, name, branchId }> }`

### `workflow_list(p_module: text, p_scope: jsonb)`
Returns workflow records for academic, pastoral, or operational modules.
- **Returns**: `{ rows: FlowRecord[], total: number, counts: Record<string, number> }`

### `workflow_save(p_record: jsonb)`
Validates schema and business rules against `workflow_modules` and persists workflow records. Emits background activity audit and triggers WhatsApp automation outbox jobs where configured.

### `workflow_remove(p_id: uuid, p_version: int)`
Safely deletes workflow items with audit logging.

---

## High-Throughput Batch Operations

### `attendance_mark_bulk(p_class_id, p_branch_id, p_date, p_records)`
Atomically upserts daily attendance for an entire classroom roster.

### `marks_upsert_bulk(p_exam_id, p_class_id, p_subject_id, p_branch_id, p_marks)`
Records grades and scores in bulk for examination processing.

### `fee_collect_payment(p_student_fee_id, p_amount, p_method, p_notes)`
Settles student invoices, updates outstanding balances, and returns a generated unique receipt number.

### `search_global(p_query: text)`
Trigram-accelerated global search across students, staff, classes, and campuses.
