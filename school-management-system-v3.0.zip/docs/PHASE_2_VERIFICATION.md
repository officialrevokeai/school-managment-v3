# Phase 2 — implementation and verification

Implemented on 31 October 2026. Phase 3 has not started.

## Delivered

- Hidden Master workspace: dashboard, school creation with generated credentials, school list/search/status filters, typed confirmation for suspend/restore/remove access, contracted school-wise subscription revenue with creation-date filters, global role defaults, and platform audit history.
- Owner dashboard: server-aggregated directory counts and finance totals, lazily loaded income/expense, enrollment and attendance-summary charts, campus scope, recent activity and shortcuts.
- Campuses, community directory, finance entries and WhatsApp template editors: validated forms, sorting, paging, search/status filters, role filters, financial date filters, exports, destructive confirmations, and mobile card actions.
- Community CSV import: quoted-field parser, schema and campus validation, duplicate checks, preview, bounded batches and explicit partial-failure feedback. Bulk activate/deactivate works on selected visible records.
- Role matrix with custom roles based on standard roles. Custom policies can be assigned to directory members. Existing linked live accounts receive trusted metadata/profile updates and require token refresh. The navigation and Can hook consume saved policies. Owner/platform boundaries remain protected.
- Branding name and logo, academic year, sender-number configuration, template editing, default financial responsibility, idle timeout, privacy contact, retention preference and a warned Owner override setting. WhatsApp connectivity/approval/delivery remains Phase 5.
- Read-only role previews using existing Owner summary data. Full role business screens remain in Phases 3 and 4.
- Mock data persists locally, including generated demo owner accounts with salted password hashes. A newly provisioned school's owner can log in and sees only that school's main campus and records.
- SQL RLS contract, checked/versioned write functions, append-only audit trigger, relational campus synchronization, linked-account role/campus/status updates, school suspension boundary and server-side aggregates. A TypeScript Edge Function handles privileged Auth provisioning without exposing a service key to the browser.

## Automated verification

`npm test`: **17 tests pass** across five suites. These cover basic role separation, mock campus and account isolation, custom-role persistence, optimistic-concurrency rejection, usable generated credentials, suspended-school denial, CSV quoting and malformed input, and local PostgreSQL RLS/write behavior.

`npm run build`: strict frontend compilation, Vite production build and bundle-budget check pass. The measured login + mock-auth dependency graph is **155.4 KiB gzip**, below the 200 KiB budget. Charts and administrative tables/forms remain separate lazy chunks. No Lighthouse score is claimed.

`npm run typecheck:edge` checks the Edge Function against the installed Supabase/Zod types and a narrow local Deno API declaration. Deployment/integration still requires a Supabase development project.

SQL was executed in PGlite with minimal Supabase Auth/Storage stubs. Tests verify actual PostgreSQL policies and functions, while hosted Auth, Storage, Realtime and Edge integration remain unverified until a project is configured. Schema-compatible types are included; they must be regenerated from the deployed database before release.

## Browser verification

- Owner dashboard rendered with real mock aggregates and lazy charts.
- A campus was created; its record and switcher option both appeared.
- A custom finance role was created, confirmed, saved, and appeared in the directory assignment selector.
- Mobile sign-out completed, followed by the separate Master login.
- The Master created a new school; its entry appeared in the school list and the one-time credentials dialog opened. Generated-credential sign-in is covered by the automated adapter test.
- Phase 1 already verified a 390px layout without horizontal overflow, dialog gating/Escape/focus restoration and table virtualization.
- The final Owner attendance-summary chart rendered with monthly data. A 768px check confirmed the 80px tablet rail and no horizontal overflow; a 1280px check confirmed the 244px desktop sidebar and no horizontal overflow. The Owner navigation contains no Master link. Viewport overrides were reset after verification.

Review screenshots: [Desktop dashboard](phase2-dashboard-desktop.jpg), [mobile dashboard](phase2-dashboard.jpg).

The demo browser contains the fictional records created during these checks. No live school or Auth account was changed.

## Run and review

```powershell
npm ci
Copy-Item .env.example .env.local
npm run dev
npm test
npm run build
npm run typecheck:edge
npm run delivery
```

Owner demo: `owner@greenwood.edu` / `Campus@2026`. Master demo: open `/sys-master`, then `master@greenwood.edu` / `Campus@2026`.

Review the Owner dashboard, create/edit a campus or person, filter the financial register, import a small CSV, create and assign a custom role, edit school settings, inspect audit events, and use the Master school-access confirmations. Every enabled Phase 2 route is listed in the role's navigation.

## Live setup

Review and apply `database/phase1.sql`, then `database/phase2.sql` in a development Supabase project. The second file bootstraps existing Owner schools/campuses and standard role defaults. Provision a trusted Master Auth user with matching `app_metadata.role` and `profiles.role`. Deploy the `provision-school` function through Supabase, setting its `APP_ORIGIN` secret to the exact frontend origin. Supabase's server-only service-role secret must never enter frontend environment variables.

School removal is a retained, reversible access status. Directory deletion is permanent within the app and requires typed confirmation. New directory rows do not automatically create Auth users or send invitations; only the Master school-provisioning workflow creates an owner login. Existing linked Auth accounts are updated by checked SQL. Sender numbers and templates are saved configuration, rather than a claim of a connected WhatsApp service. Retention days are a preference, rather than an automatic deletion schedule.
