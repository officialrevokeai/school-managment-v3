# Phase 1 verification

Verified on 31 October 2026. The build and test commands require execution outside this machine's restrictive filesystem sandbox because esbuild reads parent directories during module resolution.

## Automated checks

- Strict TypeScript compilation and Vite production build pass.
- 8 tests pass: master-role separation, finance/academics separation, signed-out denial, role redirects, rejected credentials, campus isolation, notification account isolation, and remember-me restoration/sign-out.
- The production build includes a separate budget checker for the initial login and mock-auth dependency graph. Its build output reports compressed JavaScript and fails at 200 KiB.

## Browser checks completed

- Light and dark sign-in screens rendered.
- Empty-field login validation appeared inline and focused the email/code input.
- Demo Owner signed in successfully and reached the Owner workspace.
- Owner switched to Central Campus; notification drawer displayed the Central Campus scope.
- Marking a notification as read reduced the unread count optimistically.
- A 390px mobile layout showed bottom navigation and no horizontal overflow (document width 375px with the 15px scrollbar inside the 390px viewport).
- Mobile component confirmation disabled the confirm action until the exact phrase matched. Escape dismissed the dialog, restored focus to its trigger, and removed background inertness.
- A 250-record table rendered 13 mobile cards, confirming virtualization rather than rendering the entire list.
- The mobile More drawer displayed account identity and the sign-out action.

## Verification limits

The in-app browser transport closed during the final account-switch check. Reconnection attempts failed, so the final mobile sign-out/Teacher-login sequence, a tablet-width pass, and screenshot file export were not verified. Role and campus restrictions are covered by the automated tests above. The temporary browser viewport could not be reset after transport loss.

No Supabase project or credentials were supplied. Live Auth recovery, RLS behavior, Realtime delivery, Storage, and database-generated types require integration verification against a provisioned development project. `src/types/database.ts` is a schema-compatible contract, not a claim that remote type generation was performed. No Lighthouse score is claimed.
