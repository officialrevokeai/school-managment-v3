# School Management System v3.0 — all phases

The local frontend now includes phases 1–5. Mock mode runs without external accounts. Shared workspaces keep validation, loading/error handling, record editing, pagination, CSV exports, campus scoping, and role access consistent.

## Run

Requires Node 22.13+ and npm. Run from the project folder:

```powershell
npm ci
Copy-Item .env.example .env.local
npm run dev
```

Open Vite's printed localhost URL. Choose a demo role, click **Use demo**, then sign in. All demo accounts use `Campus@2026`. Owner, principal, teacher, parent, student, and accountant emails are `<role>@greenwood.edu`. Master uses `master@greenwood.edu` at the separate `/sys-master` login.

## Delivered

- Foundation: soft UI light/dark themes, responsive shell, component library, authentication adapters, permissions, private uploads, accessible dialogs and reduced motion.
- Master/Owner: school provisioning, access suspension, campus and user administration, roles, permission matrices, revenue/analytics, branding, settings, template records, audit viewer, and read-only role views within the Owner's authorized scope.
- Principal: school overview, admissions pipeline and table, class/subject records, timetable, attendance, teacher performance, lesson review, expenses, meetings, announcements, and reports.
- Teacher: assigned-class scope, timetable, fast attendance tap grid and mark-all-present, keyboard-navigable marks and feedback, draft/publication flow, assignments, study materials, lessons, leave requests, announcements, and family messages.
- Parent/Student: own-child scope with a multi-child switcher, attendance, assignments, published results and progress chart, notices, timetable/calendar, fee dues, receipt/document downloads, certificates, messages, consent requests, and notification preferences.
- Accountant: student/admission fee view, fees, discounts/scholarships/fines, expenses/invoices/vendor records, payroll, certificates, reports, and reconciliation. Academic records and user administration are restricted.
- WhatsApp: connection check, approved-template test selection, delivery log, automation rules, sender settings, and TypeScript Edge Functions for Meta sends and signed delivery callbacks.
- System controls: campus-scoped caches, optimistic updates with rollback, cleaned-up realtime subscriptions, activity/audit records, and consent/export/deletion request workflows.

Admissions and classes synchronize the live roster when an application becomes Admitted/Transferred. Actual Auth identities, guardians, and class assignments require trusted membership provisioning. A record labelled Teacher is not sufficient to grant access.

## Verification

`npm test`: 21 passing tests across six files, including real PostgreSQL execution through PGlite for school, classroom, child, and finance authorization. Mock tests cover stale writes, tenant restrictions, draft-result privacy, and idempotent simulated payments.

`npm run build`: strict frontend and Edge Function TypeScript checks plus production bundling pass. Initial login and mock-auth JavaScript is 161.8 KiB gzip, below the 200 KiB budget. Vite reports a raw entry chunk slightly over 500 kB. A Lighthouse score has not been measured.

Browser smoke checks verified a Teacher's 12-student class, persisted an attendance change, opened the gradebook, and verified the Parent portal's two-child scope and corresponding update. Screenshots are in this folder. Earlier phase verification documents are historical snapshots.

To review manually: sign in as Teacher, mark attendance, enter marks and publish; sign in as Parent, switch children and compare visible records; open a fee and exercise the explicitly labelled payment simulation; sign in as Accountant and verify academic routes are denied. Owner can review all permitted campus workflows and WhatsApp demo logs. No external message is sent in mock mode.

## Live Supabase setup

Apply these SQL files in order to a development project:

1. `database/phase1.sql`
2. `database/phase2.sql`
3. `database/phases3-5.sql`
4. `database/workflow-catalog.sql`

The catalog is generated from frontend module definitions with `node --experimental-strip-types scripts/workflow-catalog.ts`. Provision Auth users, matching trusted role metadata/profiles, campuses, `school_classes`, `school_students`, and explicit `school_memberships` using a trusted administrative process. Do not expose service credentials in the browser. Teachers need classroom memberships; families need child memberships. Populate guardian phone numbers only with appropriate consent.

Configure Auth redirect URLs and storage/realtime settings, set the public Supabase variables in `.env.local`, and set `VITE_USE_MOCK=false`. Generate database types from the configured project and verify them against the included contract. Deploy `provision-school` for real school account provisioning. Live project behavior has not been verified without credentials.

## WhatsApp deployment

Deploy `school-whatsapp` with server secrets `APP_ORIGIN`, `WHATSAPP_TOKEN`, `WHATSAPP_API_VERSION`, `WHATSAPP_PHONE_ID`, and `WHATSAPP_BUSINESS_ID`, in addition to Supabase's server environment. Configure Meta-approved templates and authorized test recipients. Test selection currently supports templates without variable components. Template records track drafts/approval in the UI; submission and approval happen in Meta's tooling. Changing sender records in the app does not rotate the provider's server credential or verified phone ID.

Deploy `whatsapp-webhook` with `WHATSAPP_VERIFY_TOKEN` and `WHATSAPP_APP_SECRET`. Meta callbacks need a public endpoint without platform JWT verification; the handler instead verifies the provider's HMAC signature before applying a delivery update through a service-only RPC. Configure Meta's callback URL and delivery subscriptions. Use **Process outbox** as Owner to flush queued automation records. Scheduled dispatch requires an explicitly configured trusted scheduler; no background external sending is installed automatically.

## Integration limits

- Payments are a clearly labelled local simulation. Live payment is disabled until a gateway and verified payment webhook are integrated. No money is charged.
- Reports, certificates, receipts, and result records download as HTML; exports use CSV. These are editable school records, not digitally signed official documents or generated PDFs.
- Consent and deletion screens create reviewable requests. They do not automatically erase institutional records or export a complete legal data-subject bundle.
- Calendar, finance, messages, and academic administration use shared structured record workspaces. No external payroll, email, banking, or messaging service is implied by saving a record.
- Local demo storage is not a security boundary. RLS, trusted claims, and explicit memberships enforce live boundaries. Supabase/Meta end-to-end tests require configured accounts and credentials.

## Source handoff

`npm run delivery` writes every authored source file with paths and complete contents to `docs/PHASE_ALL_SOURCE.md`. The project folder also contains the lockfile for reproducible installation. Production hosting must route deep links to `index.html`.
