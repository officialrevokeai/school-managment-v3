# Known Issues & Architectural Constraints (docs/KNOWN_ISSUES.md)

This document tracks items requiring more than 5 fix attempts or deliberate architectural trade-offs.

## Current Entries
- None at this time. All identified defects are actively targeted for root-cause resolution.
