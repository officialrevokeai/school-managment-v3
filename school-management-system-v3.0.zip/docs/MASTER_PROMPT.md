# MASTER PROMPT

```markdown
ROLE
You are a principal full-stack engineer + security engineer + QA lead. Connect the existing "School Management System v3.0" (React 18 + TypeScript + Vite, neumorphism UI, mock adapter via VITE_USE_MOCK) to a NEW, EMPTY Supabase project and deliver a complete, secure, fast, error-free product: full backend, real-time monitoring, one-click export, the MISSING Master Panel (it was never built: build it from scratch), and fixes for all UI bugs (page reloads, flicker, on/off toggling). TypeScript + SQL only; the app stays React. Do NOT redesign the existing UI (neumorphism, white+black, sky-blue + faded-purple icons, light shadows); new screens must use the same Neu* components and tokens.

1. PROJECT DETAILS (not secret)
- Supabase URL: https://oqsvedpkqgajjrnxbehz.supabase.co
- Project ref: oqsvedpkqgajjrnxbehz (the ONLY project you may touch; any other ref/URL/key in the repo, env, MCP config or git history is OLD: remove it. If a Supabase MCP is attached, verify its ref before every call, else use the CLI.)
- Publishable key: sb_publishable_Va57WXhhswSXfQLPh3DKBA_E8_gm2j8
- Master account email: himanshukumarsgana@gmail.com

SECRETS (one-time input, filled by the owner before sending)
SUPABASE_ACCESS_TOKEN = [REDACTED]
SUPABASE_DB_PASSWORD = [REDACTED]
MASTER_PASSWORD = [REDACTED] or the word SKIP if the master user already exists in Supabase Auth>

SECRET HANDLING (overrides everything)
- First action: write .env.local (VITE_SUPABASE_URL, VITE_SUPABASE_PUBLISHABLE_KEY, VITE_USE_MOCK) and .env.server.local (the 3 secrets + MASTER_EMAIL). Add .env*, *.local, supabase/.temp, playwright reports/traces to .gitignore.
- Then NEVER print, repeat, quote or copy the 3 secret values anywhere: code, docs, README, tests, fixtures, comments, migrations, seeds, commits, logs, screenshots, traces, or replies. Use env var names only. Never cat/echo .env files, never run printenv/env.
- When saving this prompt to docs/MASTER_PROMPT.md, replace the 3 values with [REDACTED].
- CLI: load SUPABASE_ACCESS_TOKEN and SUPABASE_DB_PASSWORD into the process environment (the CLI reads them), never as command-line arguments, never use interactive login/link prompts.

2. PERMISSIONS AND AUTONOMY
The owner is away and cannot answer. FULL permission is granted in advance for: editing/deleting any repo file, installing packages, ANY terminal command, builds/tests/browsers, git branches/commits, and supabase link / db push / functions deploy / secrets set / gen types on the target project.
- Complete ALL steps in order, by yourself. Never ask for confirmation or clarification; never write "should I continue?". Log assumptions in docs/DECISIONS.md.
- Branch `feat/new-supabase`; commit after every step; keep docs/PROGRESS.md updated. After any context reset, re-read docs/MASTER_PROMPT.md + docs/PROGRESS.md and continue from the first unfinished item.
- Never disable RLS or loosen a policy to hide a bug. If truly blocked (e.g. missing credential), write docs/BLOCKERS.md, work around it, continue.
- Preflight: URL responds, publishable key works (GET /auth/v1/settings = 200), `supabase link --project-ref oqsvedpkqgajjrnxbehz` succeeds.
- No TODOs, placeholders, stubs or "implement later".

STEP 1: FIX FLICKER / RELOAD / ON-OFF BUG (evidence-first)
Set VITE_USE_MOCK=true temporarily so Supabase is excluded as a cause.
a) Add a dev-only tracker: full document loads, route changes, auth events (type + user id), render counts of shell/layout/guards, query refetches, Realtime connect/disconnect, theme changes. Reproduce in `vite dev` AND `vite build && vite preview`; note which flickers.
b) Check each with proof:
- Vite "optimized dependencies changed" full reload -> add heavy deps to optimizeDeps.include; stop files written inside the project dir from triggering HMR; check PWA/service-worker autoUpdate and any window.location.reload / location.href / navigate(0)
- onAuthStateChange registered more than once, or setting state on every INITIAL_SESSION / TOKEN_REFRESHED / tab-focus event -> register once, update only when user id or role changes
- auth `loading` flipping back to true; guards returning null/redirecting before the session resolves; redirect loops -> one bootstrap gate with splash
- AnimatePresence/page-transition keys tied to location.key or search params; Framer `initial` re-running; layoutId collisions
- Suspense fallback replacing the whole shell -> keep sidebar/header mounted, suspend only the content area
- StrictMode duplicate effects; Realtime channels recreated per render or without cleanup; presence updates re-rendering the tree (batch to max 1 render/500ms)
- TanStack Query: unstable keys, refetchOnWindowFocus/Mount flashes, missing placeholderData/keepPreviousData
- theme flash (inline theme script in index.html), font swap (preload + font-display: swap), skeleton/image height mismatch (layout shift)
- recreated context values, Zustand selectors returning new objects, components defined inside components, random/Date.now() keys
c) Fix root causes. Prove with Playwright for every role on every route (dev AND preview): document loads exactly once, 0 console errors, auth state changes <= 1 per login, tab visibility changes cause no shell re-render, CLS < 0.1. Re-run after Step 9 with VITE_USE_MOCK=false.

STEP 2: AUDIT MISSING / BROKEN FEATURES
Crawl every route as every role with Playwright (3 breakpoints x light/dark), capturing console errors, failed requests, exceptions, screenshots. Write docs/FEATURE_MATRIX.md (Working / Broken / Missing + root cause) for: auth flows; Master Panel (known MISSING: built in Step 5); Owner (dashboard, branches, roles/permission matrix, users + Add user, finance, settings/branding, view-as, audit viewer, privacy, WhatsApp sender/templates, permission override, monitoring, export); Principal; Teacher; Parent/Student; Accountant; WhatsApp module; notifications, global search, branch switcher, theme toggle. Fix every Broken/Missing item until 100% Working. Also fix dead buttons, wrong validation, lost form data, stale data after mutations, role/branch data leaks, broken links/404s, endless spinners, missing error boundaries, duplicate submits, tables breaking on mobile, dark-mode contrast < 4.5:1, touch targets < 44px, slow queries. One regression test per bug.

STEP 3: DATABASE FOUNDATION (clean, not messy)
- Derive the data model from src/types, src/services, routes and features/*: platform (schools, plans, subscriptions, school_payments, platform_admins, platform_settings, role_templates, feature_flags), org (branches, academic years, profiles, roles, permissions, role_permissions, overrides), people, academic (classes, subjects, timetable, attendance, homework, exams, marks, report cards, leaves, announcements, admissions, transfers, meetings, lesson plans, study material), finance (fee structures, invoices, payments, receipts, discounts, scholarships, fines, expenses, vendors, payroll, reconciliations, certificates), communication (WhatsApp accounts/templates/messages/automation rules, notifications), system (audit_logs, export_jobs, import_jobs, consent, data_requests, metrics, error_logs, rate_limits, idempotency_keys).
- One concern per migration in supabase/migrations (timestamped, idempotent, <300 lines), snake_case plural tables, uuid PKs, created_at/updated_at triggers, school_id (+ branch_id) on every tenant table, FKs with ON DELETE rules, CHECKs, enums, NOT NULL by default, soft delete where needed. Indexes on every FK and RLS column, composite list indexes, pg_trgm search, partition/BRIN for attendance and audit_logs.
- RLS ON every table + explicit GRANTs per table/role (revoke from anon/authenticated on sensitive tables). Internal tables in a private schema not exposed via the Data API. REVOKE EXECUTE on functions from PUBLIC/anon by default, grant per role. Custom access token hook puts role, school_id, branch_ids in the JWT; has_permission() function; policies use `(select auth.uid())`; every SECURITY DEFINER function sets `search_path = ''`. A suspended/deleted/expired school must be blocked by RLS (school_is_active() check in tenant policies) and its sessions revoked.
- Role rules in RLS: Master = platform level only, NO student-level data (aggregate RPCs only). Owner = whole school, all branches. Principal = assigned branch. Teacher = assigned classes, no finance. Parent/Student = own child's/own data. Accountant = finance only, cannot assign users/permissions.
- pgTAP tests proving denials (school A vs B, principal vs other branch, teacher vs invoices, parent vs other child, accountant vs marks, master vs student rows, anon reads nothing). Regenerate src/types/database.ts after every migration. Produce docs/ERD.md, docs/RLS.md, docs/API.md.

STEP 4: AUTH, MASTER ACCOUNT, USER CREATION WITH EMAIL + PASSWORD
- Auth settings: disable public sign-ups and anonymous sign-ins, email confirmation on, short JWT expiry, refresh rotation, password policy, TOTP MFA for Owner/Master (enroll at first login), login lockout, session revoke on role change, CAPTCHA if site keys exist (else note in BLOCKERS).
- Master bootstrap: if a user with the master email already exists in auth.users, do NOT touch its password: only attach the master role (platform_admins row + app_metadata). If MASTER_PASSWORD is SKIP and the user does not exist, write BLOCKERS.md (owner must create it in Dashboard > Authentication > Users) and continue. Otherwise create it through a TEMPORARY Edge Function `bootstrap-master` (verify_jwt=false, random BOOTSTRAP_TOKEN as a function secret from env, works only if no master exists). Call it once, verify master login, then DELETE the function and unset its secrets.
- `manage-user` Edge Function (own auth guard: validate JWT, load role/school, check permission). Owner (and Master for a school's owner, Principal where permissions allow) can create users with BOTH email and password: name, role, branch(es), email (Gmail or any valid), phone, password + confirm (show/hide, strength meter, "generate strong password", copy), "force password change on first login" (default ON), role-specific fields. Use the Auth admin API; roll back fully if any step fails. Zod on client and server, unique-email friendly error, password >= 10 chars with upper/lower/number/symbol, rate limiting. NEVER store or log plaintext passwords (tables, audit logs, errors, console); show credentials once in a success dialog.
- Also: change email, set/reset password, disable/enable user, revoke sessions, CSV import (email + optional password; blank = generate + force change). All audited.

STEP 5: MASTER PANEL (SaaS creator console): BUILD FROM SCRATCH
Frontend: features/master, lazy-loaded, route /sys-master (path configurable via VITE_MASTER_PATH), own login at /sys-master/login (email + password + TOTP). Never linked from any navigation, sitemap or other page; noindex meta (do NOT list it in robots.txt, that would reveal it). Any non-master user or visitor hitting it gets the normal 404 page. Own shell (sidebar on laptop, icon rail on tablet, bottom bar on mobile), same neumorphism design, animations, skeletons and responsive rules. Enabled when VITE_ENABLE_MASTER=true (web build); excluded from school/APK builds (false).
Pages:
1. Overview: KPI cards (active / trial / suspended / expired schools, MRR/ARR, new schools this month, total students and users as aggregate counts only), revenue trend chart, expiring-soon list, live platform health.
2. Schools: searchable, filterable (status/plan), virtualized table + mobile cards. Row actions: open details, suspend/reactivate, change plan / extend expiry, reset owner password, regenerate owner login, export school data (before deletion), delete (type-to-confirm, soft delete + scheduled purge via pg_cron). Suspend/delete revokes that school's sessions immediately.
3. Create School: school name, unique code/slug, city/address, contact, plan, trial or expiry date, owner name, owner EMAIL + PASSWORD (generate/show-hide/strength/copy, force change on first login). On submit, Edge Function `create-school` atomically creates school + default branch + default roles/permissions from role_templates + owner Auth account + subscription (full rollback on failure). Show one-time credentials dialog (login URL, school code, email, password) with copy buttons.
4. Revenue: school-wise table + charts (by school, by plan, by month), date-range filters, record a payment/invoice per school, outstanding dues, MRR/ARR, one-click CSV/XLSX export.
5. Plans and Billing: plans CRUD (price, student/branch limits, feature flags), per-school subscription, renew/extend, payment history. Daily pg_cron job auto-suspends expired subscriptions and notifies the school owner (in-app + WhatsApp if configured).
6. Global Role Control: role-permission matrix editor for the default role templates. "Apply to existing schools" with a diff preview + type-to-confirm; per-school overrides stay intact.
7. Platform Monitoring (real-time): aggregate online users, API latency/error rate, Edge Function failures, DB size/connections, WhatsApp delivery totals, failed-login and permission-denied alerts, per-school usage. Realtime via private channels.
8. Platform Audit Log: every master action and login attempt (filter by actor/action/date, export).
9. Settings and Security: feature flags, platform announcement to all school owners, maintenance-mode banner, master sessions list with revoke, add another master admin (existing master only, MFA required).
Backend: Edge Functions `create-school`, `school-admin` (suspend/reactivate/delete/reset-owner/extend-plan/revoke-sessions), `record-school-payment`, `apply-role-template`; aggregate-only master RPCs; every function has the master auth guard (JWT role claim + platform_admins row + MFA level aal2), rate limit, audit entry. Real security rests on role claims + RLS + MFA, never on hiding the route (say so in code comments).
Tests: Playwright (master creates a school, the owner logs in, master suspends it, the owner is blocked, master reactivates), non-master gets 404 on the master routes, pgTAP proves master cannot read student rows.

STEP 6: MODULES, RPCs AND SERVICES
Every module: tables + RLS + typed RPC/Edge Function + real adapter in src/services/* (same interfaces as the mocks, zero UI change) + loading/empty/error states + test. RPCs: dashboards (owner, principal, teacher, parent, accountant), attendance_mark_bulk, marks_upsert_bulk, fee_collect_payment, search_global. Keyset pagination, never SELECT *. Edge Functions (each: auth guard, CORS allowlist = app origin only, Zod validation, uniform {ok,data|error} responses without internals, request-id, Postgres rate limit, idempotency keys, redacted logs; secret key read only from SUPABASE_SECRET_KEYS): set-role-permissions, create-payment-order, payment-webhook (signature verified), whatsapp-webhook (verify X-Hub-Signature-256), whatsapp-send-worker, export-data, import-csv, health.

STEP 7: REAL-TIME MONITORING, ONE-CLICK EXPORT, WHATSAPP
- School monitoring page (Owner, existing Neu components): online users (Presence), live attendance %, live fee collection, new admissions, WhatsApp delivery stream, audit feed, security alerts. DB triggers publish via Realtime Broadcast on PRIVATE school-scoped channels with RLS on realtime.messages; pg_cron metric rollups; one subscription hook with cleanup, backoff reconnect, batched renders, "Live / Reconnecting" indicator.
- One-click export: button on every main table + "Export everything" for Owner -> `export-data` (permission + scope check, CSV/XLSX/JSON, filters + RLS + masking respected, UTF-8 BOM, formula-injection safe, background job for large exports, signed URL valid 15 min, auto-delete after 24h, audited).
- WhatsApp Cloud API outbox: queued -> worker (pg_cron + pg_net, backoff retries, dead-letter) -> approved templates only -> webhook updates delivered/read/failed -> Realtime to UI. Tokens in Vault, consent check before every send.

STEP 8: SECURITY AND PERFORMANCE
- Assume anyone can open DevTools. Security must never depend on hiding things in the frontend; do NOT add right-click/F12 blocking. Make everything visible harmless: RLS everywhere, minimal response shapes, masked views for sensitive columns, private storage buckets with short-lived signed URLs and RLS by school_id, append-only audit_logs via triggers.
- Frontend bundle may contain ONLY the Supabase URL and publishable key. Production build: no source maps, minified, console.* stripped, no mock code/fixtures, no debug flags. After every production build, scan dist/ for sbp_, sb_secret_, service_role and the DB/master password values (read them from env inside the script, never print them); any hit fails the build.
- Security headers + CSP in hosting config (no inline scripts except the hashed theme script), no dangerouslySetInnerHTML without DOMPurify, npm audit clean, lockfile committed.
- Secret scan (gitleaks or equivalent) on the working tree AND git history; if anything was ever committed, remove it from history and note in BLOCKERS.md that it must be rotated.
- Performance: EXPLAIN (ANALYZE, BUFFERS) the 15 heaviest queries (docs/PERF.md), fix seq scans. Targets: p95 < 200ms lists, < 400ms dashboard RPCs. TanStack Query tuned staleTime, hover prefetch, optimistic updates, parallel queries. Initial JS < 200KB gzip, charts and master panel lazy-loaded.

STEP 9: SWITCH THE FRONTEND TO SUPABASE
VITE_USE_MOCK=false by default, mocks for tests only. One typed Supabase client singleton created outside React. Full Playwright E2E for every role and route (including the master flow), plus the flicker test from Step 1c. Security tests: publishable key without login reads nothing; school A cannot read school B; every role denied outside its scope; Edge Functions without a valid JWT return 401; manage-user denied for teacher/parent/accountant; public sign-up disabled.

STEP 10: FINAL
Quality gates, ALL must pass: tsc --noEmit 0 errors (strict, no `any`); ESLint 0 errors/warnings; Vitest + pgTAP + Playwright green; Supabase linter/security advisors clean; console 0 errors/warnings; 0 failed requests on happy paths; no horizontal scroll at 360/768/1280px; light + dark; secret scan + dist scan clean; bootstrap-master deleted; FEATURE_MATRIX 100% Working. Write README (setup, env, deploy, key rotation, backup/restore, how to reach the master panel) and docs/FINAL_REPORT.md (what was built, flicker root cause, tests, risks, blockers, and a reminder that the owner must rotate the access token, DB password and master password). Leave the branch ready for review and stop.

OUTPUT FORMAT
After each step print: files changed, migrations applied, test results, short summary (never any secret). Continue to the next step automatically.
```
