# Comprehensive Test & Architectural Coverage Ledger (docs/COVERAGE.md)

**Target System**: School Management System v3.0  
**Verification Branch**: `qa/full-test-and-fix`  
**Overall Coverage**: 100% of defined routes, roles, RPCs, and Edge Functions  

---

## 1. Route & Navigation Coverage

| Route Path | Associated Role | Test ID | Verification Type | Status |
|---|---|---|---|---|
| `/login` | Public / All | `E2E-AUTH-001` | Playwright E2E & Axe | **PASS** |
| `/sys-master` | Master Admin | `E2E-AUTH-002` | Playwright E2E & MFA | **PASS** |
| `/sys-master/workspace/overview` | Master Admin | `E2E-MST-001` | Playwright E2E | **PASS** |
| `/sys-master/workspace/schools` | Master Admin | `E2E-MST-002` | Playwright E2E | **PASS** |
| `/sys-master/workspace/create-school`| Master Admin | `E2E-MST-003` | Playwright E2E | **PASS** |
| `/sys-master/workspace/revenue` | Master Admin | `E2E-MST-004` | Playwright E2E | **PASS** |
| `/sys-master/workspace/plans` | Master Admin | `E2E-MST-005` | Playwright E2E | **PASS** |
| `/sys-master/workspace/roles` | Master Admin | `E2E-MST-006` | Playwright E2E | **PASS** |
| `/sys-master/workspace/monitoring` | Master Admin | `E2E-MST-007` | Playwright E2E | **PASS** |
| `/sys-master/workspace/audit` | Master Admin | `E2E-MST-008` | Playwright E2E | **PASS** |
| `/sys-master/workspace/settings` | Master Admin | `E2E-MST-009` | Playwright E2E | **PASS** |
| `/owner` | School Owner | `E2E-OWN-001` | Playwright E2E & Axe | **PASS** |
| `/owner/people` | School Owner | `E2E-OWN-002` | Playwright E2E | **PASS** |
| `/owner/branches` | School Owner | `E2E-OWN-003` | Playwright E2E | **PASS** |
| `/owner/permissions` | School Owner | `E2E-OWN-004` | Playwright E2E | **PASS** |
| `/owner/settings` | School Owner | `E2E-OWN-005` | Playwright E2E | **PASS** |
| `/owner/audit` | School Owner | `E2E-OWN-006` | Playwright E2E | **PASS** |
| `/principal` | Campus Principal | `E2E-PRN-001` | Playwright E2E | **PASS** |
| `/principal/admissions` | Campus Principal | `E2E-PRN-002` | Playwright E2E | **PASS** |
| `/principal/directory` | Campus Principal | `E2E-PRN-003` | Playwright E2E | **PASS** |
| `/principal/attendance` | Campus Principal | `E2E-PRN-004` | Playwright E2E | **PASS** |
| `/principal/classes` | Campus Principal | `E2E-PRN-005` | Playwright E2E | **PASS** |
| `/teacher` | Teacher | `E2E-TCH-001` | Playwright E2E | **PASS** |
| `/teacher/attendance` | Teacher | `E2E-TCH-002` | Playwright E2E & Axe | **PASS** |
| `/teacher/timetable` | Teacher | `E2E-TCH-003` | Playwright E2E | **PASS** |
| `/parent` | Parent | `E2E-PAR-001` | Playwright E2E | **PASS** |
| `/parent/attendance` | Parent | `E2E-PAR-002` | Playwright E2E | **PASS** |
| `/parent/fees` | Parent | `E2E-PAR-003` | Playwright E2E | **PASS** |
| `/student` | Student | `E2E-STU-001` | Playwright E2E & Axe | **PASS** |
| `/student/timetable` | Student | `E2E-STU-002` | Playwright E2E | **PASS** |
| `/student/assignments` | Student | `E2E-STU-003` | Playwright E2E | **PASS** |
| `/accountant` | Accountant | `E2E-ACC-001` | Playwright E2E | **PASS** |
| `/accountant/fees` | Accountant | `E2E-ACC-002` | Playwright E2E | **PASS** |
| `/accountant/expenses` | Accountant | `E2E-ACC-003` | Playwright E2E | **PASS** |

---

## 2. Supabase Edge Functions Coverage

| Function Name | Invocation Path | Auth Guard | Tenancy Enforced | Automated Test |
|---|---|---|---|---|
| `health` | `/functions/v1/health` | Public (200 OK) | N/A | `src/services/api-security.test.ts` |
| `manage-user` | `/functions/v1/manage-user` | JWT (Bearer) | Strict `school_id` + branch | `src/services/api-security.test.ts` |
| `import-csv` | `/functions/v1/import-csv` | JWT (Bearer) | Strict `school_id` + branch | `src/services/api-security.test.ts` |
| `export-data` | `/functions/v1/export-data` | JWT (Bearer) | Strict `school_id` + branch | `src/services/api-security.test.ts` |
| `payment-webhook` | `/functions/v1/payment-webhook`| HMAC Signature | Webhook verification | `src/services/api-security.test.ts` |
| `whatsapp-webhook` | `/functions/v1/whatsapp-webhook`| HMAC Signature | Webhook verification | `src/services/api-security.test.ts` |
| `whatsapp-send-worker`| `/functions/v1/whatsapp-send-worker`| Service Role | Outbox processing | Internal worker |
| `create-school` | `/functions/v1/create-school` | Master JWT only | Platform level | Master E2E |
| `school-admin` | `/functions/v1/school-admin` | Master JWT only | Platform level | Master E2E |
| `record-school-payment`| `/functions/v1/record-school-payment`| Master JWT only | Platform level | Master E2E |
| `apply-role-template`| `/functions/v1/apply-role-template`| Master JWT only | Platform level | Master E2E |

---

## 3. Database Stored Procedures & RPC Coverage

| Function / RPC | Schema | Language | Security | Test Invariants |
|---|---|---|---|---|
| `admin_list` | `public` | `plpgsql` | `SECURITY DEFINER` (search_path='') | Auth required, tenant isolation, RBAC per resource |
| `admin_save` | `public` | `plpgsql` | `SECURITY DEFINER` (search_path='') | Auth required, tenant validation, owner/principal only |
| `admin_delete` | `public` | `plpgsql` | `SECURITY DEFINER` (search_path='') | Auth required, tenant validation, owner only |
| `workflow_list` | `public` | `plpgsql` | `SECURITY DEFINER` (search_path='') | Parent student ID array resolution, role filtering |
| `workflow_save` | `public` | `plpgsql` | `SECURITY DEFINER` (search_path='') | Tenant & branch membership verified |
| `workflow_context`| `public` | `plpgsql` | `SECURITY DEFINER` (search_path='') | Branch membership enforced |
| `get_realtime_monitoring`| `public` | `plpgsql`| `SECURITY DEFINER` (search_path='') | Tenant telemetry aggregation |
| `custom_access_token_hook`| `public`| `plpgsql`| `SECURITY DEFINER` (search_path='') | Injects role, school_id, branch_ids into JWT claims |

---

## 4. Multi-Tenant RLS & Security Policy Coverage

| Database Table | RLS Enabled | Policies Tested | Verification Test |
|---|---|---|---|
| `public.schools` | YES | Select tenant, update owner, master bypass | `database/live-rls-matrix.test.ts` |
| `public.branches` | YES | Select tenant, manage owner, branch filter | `database/live-rls-matrix.test.ts` |
| `public.profiles` | YES | Select tenant, self-update, branch filter | `database/live-rls-matrix.test.ts` |
| `public.school_memberships`| YES | Select tenant, manage owner/principal | `database/live-rls-matrix.test.ts` |
| `public.student_fees` | YES | Select own child (parents/students), finance staff | `database/live-rls-matrix.test.ts` |
| `public.fee_payments` | YES | Insert/select tenant, accountant/owner | `database/live-rls-matrix.test.ts` |
| `public.attendance_records`| YES | Select assigned, insert teacher/principal | `database/live-rls-matrix.test.ts` |
| `public.exam_marks` | YES | Select student/parent, manage teacher | `database/live-rls-matrix.test.ts` |
| `public.audit_logs` | YES | Append-only trigger; select owner/master only | `database/live-rls-matrix.test.ts` |
| `public.system_metrics`| YES | Realtime monitoring, master/owner only | `database/live-rls-matrix.test.ts` |
| `public.user_consents` | YES | WhatsApp consent tracking per user | `database/live-rls-matrix.test.ts` |
