# Row Level Security (RLS) & Access Control Specification

Every table in the PostgreSQL database has Row Level Security enabled (`ALTER TABLE ... ENABLE ROW LEVEL SECURITY`). Default schema privileges have been stripped via `REVOKE ALL ON SCHEMA public FROM anon, authenticated`, and explicit grants are assigned per operational role.

## RLS Enforcement Rules by Role

### 1. Master (`master`)
- Platform-level administrator only.
- Full access to `schools`, `plans`, `subscriptions`, and platform audit logs.
- Strict isolation: zero direct access to student grades, exams, or family messages.

### 2. Owner (`owner`)
- School administrator with full jurisdiction over their school (`school_id`).
- Full access across all campuses/branches within their school.
- Manages campuses, school settings, user provisioning, custom roles, and high-level finance.

### 3. Principal (`principal`)
- Campus-scoped administrator.
- Access strictly restricted to assigned branch (`branch_id = ANY(branch_ids)`).
- Can manage academic rosters, view attendance, review admissions, and read campus expenses.
- Denied platform management and system role reconfiguration.

### 4. Teacher (`teacher`)
- Academic classroom educator.
- Access scoped to assigned classes and branches.
- Can mark attendance, assign homework, upload lesson plans, and enter examination marks.
- Explicitly denied access to school finance, invoices, fees, payroll, and system settings.

### 5. Parent / Student (`parent` / `student`)
- Family-level access.
- Access strictly limited to own profile or enrolled child:
  `student_id = (SELECT auth.uid())` or child membership in `school_memberships`.
- Can view published marks, own attendance history, assigned homework, and outstanding fees.
- Cannot view other students' records or unreleased drafts.

### 6. Accountant (`accountant`)
- School financial officer.
- Full jurisdiction over `fee_structures`, `student_fees`, `fee_payments`, `expenses`, `vendors`, `payroll_records`, and `reconciliations`.
- Strictly denied permission to edit student marks, modify academic timetables, or provision user permissions.

## Key Performance Patterns

1. **Subquery Optimization (`(SELECT auth.uid())`)**:
   PostgreSQL query planner evaluates `(SELECT auth.uid())` as an `InitPlan` once per statement, enabling index scans on FK columns and avoiding per-row function call overhead.

2. **Custom Access Token Hook (`custom_access_token_hook`)**:
   Directly injects `role`, `school_id`, and `branch_ids` into the JWT claims (`app_metadata`). This allows policies to verify tenant and branch boundaries directly from memory without additional profile lookups.

3. **`search_path = ''` on `SECURITY DEFINER` Functions**:
   All database functions execute with an explicit empty search path to eliminate search-path hijacking attacks.
