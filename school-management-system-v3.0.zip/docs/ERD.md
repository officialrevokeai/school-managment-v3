# Entity-Relationship Documentation (ERD)

This document describes the relational data model for the multi-tenant School Management System, hosted on Supabase (PostgreSQL 15+).

## Mermaid Diagram

```mermaid
erDiagram
    schools ||--o{ branches : "has"
    schools ||--o{ subscriptions : "maintains"
    schools ||--o{ profiles : "employs/enrolls"
    schools ||--o{ academic_years : "schedules"
    schools ||--o{ classes : "contains"
    schools ||--o{ student_fees : "bills"
    schools ||--o{ expenses : "logs"

    branches ||--o{ classes : "hosts"
    branches ||--o{ attendance_records : "tracks"
    branches ||--o{ school_workflows : "contains"

    classes ||--o{ class_students : "enrolls"
    classes ||--o{ subjects : "teaches"
    classes ||--o{ timetable_entries : "schedules"
    classes ||--o{ attendance_records : "monitors"
    classes ||--o{ assignments : "assigns"

    profiles ||--o{ class_students : "identified_as"
    profiles ||--o{ attendance_records : "attends"
    profiles ||--o{ marks : "achieves"
    profiles ||--o{ student_fees : "owes"
    profiles ||--o{ fee_payments : "pays/collects"
    profiles ||--o{ notifications : "receives"
    profiles ||--o{ audit_logs : "triggers"

    student_fees ||--o{ fee_payments : "settled_by"
    plans ||--o{ subscriptions : "tiers"
```

## Schema Entities

### Platform Layer
- `schools`: Root tenant table. All tenant data references `school_id`.
- `plans`: Subscription tiers (`Starter`, `Growth`, `Enterprise`).
- `subscriptions`: Active billing subscriptions mapping schools to plans.

### Organization Layer
- `branches`: Physical campuses belonging to a school.
- `academic_years`: School year definitions with active flag.
- `roles`: Custom and system RBAC definitions mapping permissions to roles.
- `profiles`: Application users linked directly to `auth.users(id)`.
- `user_role_overrides`: Granular explicit permission grants/revocations per user.

### Academic Layer
- `classes`: Classroom sections within a branch.
- `subjects`: Courses taught within a class.
- `class_students`: Student enrollment mapping students to classes.
- `timetable_entries`: Class schedule by day of week and time slot.
- `attendance_records`: Daily student attendance records (BRIN indexed).
- `assignments`: Homework, classwork, and deadlines.
- `exams` & `marks`: Examination schedules and student scores.
- `leaves`: Leave requests from staff or students.
- `announcements`: Broadcast updates for school/campus/class.
- `admissions`: Student admission and campus transfer pipeline.
- `meetings` & `lesson_plans`: Staff collaboration tools.

### Finance Layer
- `fee_structures`: Base fee templates by class or frequency.
- `student_fees`: Invoices issued to specific students with discounts and fines.
- `fee_payments`: Receipts and payment ledger transactions.
- `expenses` & `vendors`: Operating expenditures and vendor ledger.
- `payroll_records`: Monthly faculty/staff salary statements.
- `reconciliations`: Monthly cash vs ledger balancing statements.
- `certificates`: Official school certificate records.

### Communication & System
- `whatsapp_accounts`: Meta Cloud API credentials and verified status.
- `whatsapp_templates`: Pre-approved WhatsApp message templates.
- `whatsapp_messages`: Outbox-pattern message queue with delivery statuses.
- `notifications`: In-app notification alerts.
- `audit_logs`: Immutable security audit events (BRIN indexed).
- `admin_records`: Dynamic administrative entity store.
- `school_workflows`: Unified polymorphic workflow records with Realtime publication.
- `idempotency_keys` & `rate_limits`: API resilience structures.
