# School Management System v3.0 - Full QA & Security Test + Fix

## Prompt Instructions
ROLE: Principal QA architect + application security engineer + full-stack engineer. Fully test "School Management System v3.0" (React 18 + TypeScript + Vite frontend, Supabase backend: Postgres/RLS, Auth, Edge Functions, Realtime, Storage; TypeScript + SQL only), find every bug, broken feature and security weakness, FIX them at the root, and prove the fixes with automated regression tests. Do not redesign the UI (neumorphism, white+black, sky-blue + faded-purple icons stay); fixes must use the existing Neu* components and tokens.

1. SCOPE AND SAFETY (authorized testing of the owner's own system)
- Target: Supabase project ref oqsvedpkqgajjrnxbehz (https://oqsvedpkqgajjrnxbehz.supabase.co), the local dev server and `vite preview`. Nothing else. Never test, scan or send traffic to any third-party system (WhatsApp/Meta, payment gateway, email providers): mock or sandbox them.
- Treat all existing non-QA data as REAL: never modify or delete it. Run all tests inside a dedicated QA tenant (school "QA Test School", every row tagged is_qa=true) with QA users per role. Tests must refuse to run unless the target ref matches and QA_MODE=true.
- Before destructive tests, `supabase db dump` (schema + data) into a git-ignored backups/ folder.
- Prefer the local Supabase stack (`supabase start`, needs Docker) for destructive DB/security tests (pgTAP, policy fuzzing). If Docker is unavailable, run them on the remote project inside the QA tenant, using transactions that roll back where possible. Never create a second Supabase project.
- No denial-of-service. Load tests stay modest (<= 50 virtual users, <= 60 seconds) to respect plan limits.
- At the end, delete the QA tenant, all QA users, test data, test files and test credentials, and verify nothing is left.

2. PERMISSIONS AND AUTONOMY
The owner is away and cannot answer. FULL permission is granted in advance for: editing/deleting any repo file, installing dev dependencies, ANY terminal command, browsers/Playwright, git branches/commits, and supabase db push / functions deploy / secrets set / gen types on the target project.
- Run ALL phases in order by yourself. Never ask for confirmation; never write "should I continue?". Log assumptions in docs/DECISIONS.md.
- Branch `qa/full-test-and-fix`; commit after every phase; keep docs/PROGRESS.md updated. Save this prompt as docs/QA_PROMPT.md. After a context reset, re-read both and continue from the first unfinished item.
- If truly blocked (e.g. missing credential), write docs/BLOCKERS.md, work around it, continue.

3. SECRET HANDLING
- Project details (not secret): publishable key is in .env.local; master email himanshukumarsgana@gmail.com. Secrets (SUPABASE_ACCESS_TOKEN, SUPABASE_DB_PASSWORD) are in .env.server.local. NEVER print, repeat, quote or copy them anywhere (code, docs, reports, tests, fixtures, commits, logs, screenshots, traces, replies). Never cat/echo .env files or run printenv. For CLI use, load them into the process environment, never as command-line arguments.
- NEVER use the real master or owner credentials in tests. Create QA users with random generated passwords stored only in a git-ignored .env.test.local. Create a separate QA master admin (TOTP secret captured at enrollment, stored there too) and delete it at the end.
- Playwright traces/videos/reports are git-ignored; disable trace and video for credential-entry steps; redact tokens and passwords from every report. Report findings with redacted evidence only.

4. FIXING RULES (integrity)
- Fix root causes. Never hide a problem: no @ts-ignore, no eslint-disable, no test.skip, no deleting or weakening a failing test, no catch-and-swallow, no mocking away the real behaviour in an E2E, no loosening or disabling RLS/GRANTs, no widening CORS.
- Every fixed bug gets a regression test that fails before the fix and passes after.
- Severity: P0 = security hole / data leak / data loss / auth bypass; P1 = feature or workflow broken; P2 = wrong behaviour, UX, accessibility or performance problem; P3 = polish. Log each in docs/BUGS.md: ID, severity, area, steps, expected vs actual, root cause, fix commit, regression test.
- After each phase T1-T7: fix everything found in that phase (P0 first), re-run that phase, then continue. T9 re-runs everything. If a finding needs more than 5 fix attempts, record it with reasons in docs/KNOWN_ISSUES.md and move on.

PHASE T0: RECON AND TEST PLAN
Read the whole repo and the live Supabase schema. Inventory: routes (per role), components with actions, services, RPCs, Edge Functions, tables, views, policies, GRANTs, triggers, cron jobs, storage buckets, realtime channels, Auth settings, env vars. Write docs/TEST_PLAN.md: every feature/workflow/endpoint/policy with a test ID, owner role, and planned test type. Update docs/FEATURE_MATRIX.md.

PHASE T1: STATIC ANALYSIS, SUPPLY CHAIN, SECRETS
- tsc --noEmit (strict, 0 errors, no `any`), ESLint 0 warnings (add eslint-plugin-security and react-hooks rules), Prettier.
- npm audit: fix or replace every high/critical; verify the lockfile is committed and versions pinned; detect unused/abandoned dependencies.
- Secret scan (gitleaks or equivalent) on the working tree AND full git history; scan config files that may hold tokens (.mcp.json, .vscode, IDE/agent/MCP configs, CI files, supabase/config.toml). If a secret was ever committed, purge it from history and record "rotate this" in docs/SECURITY_REPORT.md (without printing it).
- Production build: no source maps; scan dist/ for sbp_, sb_secret_, service_role, DB/master passwords (read from env inside the script, never print), internal URLs, TODO/debug flags, mock fixtures. The bundle may contain ONLY the Supabase URL and the publishable key.
- Run Supabase security + performance advisors and the database linter; fix everything.
- grep the code for dangerouslySetInnerHTML, innerHTML, eval, new Function, document.write, target=_blank without rel, localStorage/sessionStorage use for sensitive data, console.log of sensitive data, secrets in URLs.

PHASE T2: TEST HARNESS AND QA TENANT
- Vitest (unit), Playwright (E2E + API), pgTAP (DB), k6 or autocannon (light load), @axe-core/playwright (a11y), Lighthouse CI.
- Idempotent seed script `scripts/qa-seed.ts` and teardown `scripts/qa-teardown.ts`: QA school with 2 branches, 1 QA master, 1 owner, 2 principals (one per branch), 3 teachers, 4 parents with multi-child cases, 6 students, 1 accountant, plus classes, timetable, fees, invoices, marks, announcements. Create users through the Edge Function/Auth admin API, never by shortcuts that bypass real flows. A second QA school (School B) exists to test cross-tenant isolation.
- Playwright projects: login-once-per-role storage states, Chromium + Firefox + WebKit, mobile (Pixel 7, iPhone 14), tablet (iPad), desktop 1280.

PHASE T3: DATABASE AND RLS TESTING
Generate the test matrix FROM THE CATALOG (pg_policies, information_schema grants): for every table x role (anon, master, owner, principal A/B, teacher, parent, student, accountant, other-school user) x operation (select/insert/update/delete) assert the expected allow/deny against docs/RLS.md. Also assert:
- RLS enabled on every table in exposed schemas; no `using (true)` / missing WITH CHECK; UPDATE cannot change school_id, branch_id, role, owner_id or any ownership column (mass assignment); INSERT cannot set another tenant's school_id.
- Views use security_invoker; no view or materialized view leaks cross-tenant rows.
- Every SECURITY DEFINER function: fixed search_path = '', explicit permission check inside, EXECUTE revoked from PUBLIC/anon unless intended. List all functions callable by anon and justify each.
- Roles come from app_metadata/JWT claims only. user_metadata is user-editable: prove a user cannot escalate by calling auth.updateUser({data:{role:'owner'}}) and that no policy or hook reads user_metadata.
- Disabled user, suspended school, expired subscription and soft-deleted rows are blocked by RLS, and revoked sessions stop working.
- Master cannot read student-level rows (aggregate RPCs only). Audit log is append-only (update/delete denied for every role). Triggers (updated_at, audit) behave correctly. Constraints, FKs and enums reject bad data.
- Index and query health: EXPLAIN (ANALYZE, BUFFERS) on the 15 heaviest queries; no seq scans on big tables; add missing indexes.
- pg_graphql: disable if unused, otherwise prove it respects RLS. Check what the REST root/OpenAPI exposes to anon and minimize it.

PHASE T4: API TESTING (PostgREST, RPC, Edge Functions, Auth, Storage, Realtime)
- Call every endpoint directly with the publishable key: no token, valid token of every role, tampered/expired/alg=none/other-project JWT, token of a disabled or revoked user. Verify status codes (401 vs 403 vs 404), response shapes, no extra fields, no stack traces or internals in errors, no PII over-fetch.
- PostgREST: resource embedding (select=*,related(*)), filters, ordering, `Prefer: count=exact` leaks, huge page sizes (enforce caps), unbounded queries.
- Edge Functions: missing/invalid auth, wrong role, wrong tenant, malformed/oversized/duplicate bodies (Zod), CORS (only the app origin; preflight behaviour), rate limiting and lockout, idempotency (replay the same request), SSRF and open-redirect attempts, webhook signature verification (invalid, missing, replayed, timing-safe compare), manage-user privilege escalation (principal creating owner, teacher creating anyone, cross-tenant user creation), plaintext passwords never in responses/logs/audit rows.
- Auth: public sign-up disabled, anonymous sign-ins disabled, email enumeration (login/reset give generic messages), password reset and redirect-URL allowlist, refresh-token rotation and reuse, MFA (aal2) enforced for master/owner actions, forced password change on first login, lockout, session revocation, password policy.
- Storage: buckets private, signed-URL TTL, path traversal, cross-tenant object access, file validation (size, MIME vs magic bytes, SVG/HTML script upload, filename sanitation).
- Realtime: private channels only, user from school A cannot subscribe to school B or guess topic names, postgres_changes respects RLS, channels cleaned up on logout.
- Payments: server-computed amounts (client cannot tamper with price), negative/zero/overpayment, double-submit and concurrent payment race (idempotency + row locking), webhook replay, refund consistency, receipt numbering uniqueness.
- WhatsApp: outbox state machine (queued -> sent -> delivered/read/failed), retry/backoff/dead-letter, consent and quiet-hours rules, template-only sending, webhook signature, duplicate suppression (all against a mock WhatsApp server).
- Export/Import: RLS and masking respected, filters respected, signed URL expiry and cleanup, CSV formula injection (cells starting with = + - @ are neutralized), oversized/malformed import files, import dry-run vs commit consistency, rate limits, audit entries.

PHASE T5: FRONTEND E2E WORKFLOWS (every role, every route, every button)
Automated "visit-everything" crawl per role (all routes, all tabs, all modals, every button/form in the QA tenant) with console/network/exception capture, plus scripted business workflows. Each step asserts UI state AND database/API state.
- Master: login + TOTP; create school (owner email + password, one-time credentials dialog); owner logs in; plans/revenue/payment record; suspend -> owner blocked immediately -> reactivate; role-template apply with diff preview; platform audit log; monitoring; add second master (MFA required); unauthenticated/non-master visitors get the normal 404 on /sys-master.
- Owner: forced password change on first login; branches CRUD; add users (email + password, generate, copy, validation, duplicate email) for every role; role matrix edit + permission override with warning; settings/branding; view-as (read-only banner); audit viewer + filters + export; WhatsApp sender/templates (Owner only); monitoring dashboard live updates (two browser contexts); one-click export; privacy requests.
- Principal: admission -> approved -> student created -> class assignment; transfer; timetable CRUD with conflict detection; attendance/enrollment views; teacher performance/lesson-plan review; expenses/meetings; announcement -> visible to the right audience; daily/weekly report; verify branch-only isolation and locked states for global settings.
- Teacher: timetable; mark attendance (tap grid, mark-all-present, optimistic update + rollback on failure) -> parent sees it and an absence WhatsApp outbox row appears; homework create -> parent sees; marks entry with keyboard navigation -> results/report card; leave request -> principal approves -> status updates; message parents (approved templates only); study-material upload; verify no finance/settings access.
- Parent/Student: child switcher; attendance/leave status; homework/marksheets/notices; exam timetable/results/report card download; fee dues -> online payment (sandbox) -> receipt; holidays/calendar; teacher messages; WhatsApp preferences; verify only own child's data (IDOR attempts with other child IDs).
- Accountant: fee structure -> invoice -> payment -> receipt -> reconciliation; discounts/scholarships/fines; expenses/vendor invoices; payroll; certificates; financial reports; verify no academic data and no user/permission assignment.
- Cross-role lifecycle chains: admission -> fee invoice -> payment -> attendance -> exam marks -> report card -> parent download; owner-created user logs in for the first time end to end.
- Form tests: required/invalid/boundary values, double submit, browser back/forward, refresh mid-flow, deep links, 404/403 pages, session expiry modal, logout from one tab propagating to another, concurrent edits in two tabs, token refresh mid-action, offline/slow-network (Playwright network throttling) with retry UI.
- Flicker/reload regression: for each role and route assert the document loads exactly once, 0 console errors/warnings, auth state changes <= 1 per login, tab visibility changes cause no shell re-render, no layout shift (CLS < 0.1), no toggling loading states, theme persists with no flash.

PHASE T6: SECURITY TESTING (assume the attacker has DevTools and the publishable key)
Map findings to OWASP Top 10 and ASVS L2. Try to:
- Break access control: IDOR on every route/param/RPC (sequential and guessed UUIDs), horizontal and vertical privilege escalation per role, cross-tenant and cross-branch reads/writes, forced browsing of /sys-master and admin routes, hidden-field tampering, client-side permission bypass (edit the Zustand/permission store in DevTools: backend must still deny).
- Inject: SQL injection via filters/search/RPC text params/`.or()` filter strings, stored and reflected XSS in every text field (names, announcements, messages, templates, CSV import, file names, error messages), HTML injection in exports and emails, header/CRLF injection, template injection in WhatsApp templates.
- Verify: CSP blocks inline/injected scripts; clickjacking blocked (frame-ancestors); HSTS/security headers on the preview/hosting config; cookies/tokens storage risks; nothing sensitive in localStorage/sessionStorage/URLs/console/network responses/source maps; error messages are generic.
- Business logic: negative or huge numbers, rounding in fees/payroll, race conditions, replay of old requests, role downgrade effect on live sessions.
- Dependency and configuration review: Supabase Auth settings, exposed schemas, extensions, Edge Function secrets list (names only), CORS, redirect URLs, rate limits.
Write docs/SECURITY_REPORT.md: finding ID, severity, OWASP category, affected component, redacted proof, fix, retest result. Fix all P0/P1 immediately.

PHASE T7: NON-FUNCTIONAL
- Performance: Lighthouse CI on login, each role's dashboard and the heaviest list page (mobile + desktop): Performance >= 90, Accessibility >= 95, Best Practices >= 95, CLS < 0.1. Initial JS < 200KB gzip; check route-level code-splitting, lazy charts, image sizing. API p95 < 200ms lists and < 400ms dashboard RPCs under the modest load test; no N+1; no request waterfalls; keyset pagination everywhere; large tables virtualized.
- Realtime and memory: 30-minute soak of the monitoring page with simulated events: no memory growth, no duplicate subscriptions, channels cleaned up, reconnection works after network drop, updates batched.
- Accessibility: axe on every page in light + dark, full keyboard navigation, focus traps in modals/drawers, contrast >= 4.5:1, touch targets >= 44px, reduced-motion respected, labels/aria for icon-only buttons.
- Responsive: 360, 768, 1280 widths x light/dark; no horizontal scroll; tables collapse to cards on mobile; bottom-sheet modals; safe-area insets.
- Cross-browser: Chromium, Firefox, WebKit.
- Resilience: Supabase/API down or 500, slow network, expired token, lost Realtime connection: friendly errors, retry UI, error boundaries on every route, no blank screens.

PHASE T8: FIX LOOP
Run until no P0/P1 remains: triage docs/BUGS.md -> fix -> regression test -> re-run the affected phase. Prioritize P0 security, then P1 broken workflows, then P2, then P3.

PHASE T9: FINAL FULL REGRESSION AND CLEANUP
- Re-run EVERYTHING from T1 to T7 end to end on a clean seed and require 100% pass.
- Final gates, ALL must pass: tsc 0 errors; ESLint 0 warnings; Vitest + pgTAP + Playwright green on all browsers/devices; Supabase advisors clean; gitleaks clean on tree + history; dist scan clean; npm audit with no high/critical; 0 open P0/P1; console 0 errors/warnings and 0 failed requests on happy paths; Lighthouse targets met; FEATURE_MATRIX 100% Working (or justified exceptions in KNOWN_ISSUES.md).
- Teardown: run qa-teardown, delete QA tenant/users/files/credentials and the backups folder only after confirming the data is intact; confirm no test artefacts remain in the project.
- Deliverables: docs/TEST_REPORT.md (coverage per role/feature, pass/fail counts, flaky test list, how to re-run the suite), docs/SECURITY_REPORT.md, docs/BUGS.md, docs/KNOWN_ISSUES.md, docs/FEATURE_MATRIX.md, docs/COVERAGE.md; add npm scripts `test`, `test:e2e`, `test:db`, `test:security`, `qa:seed`, `qa:teardown` and a CI workflow that runs them. Final reminder in the report: the owner must rotate the Supabase access token, DB password and master password. Leave the branch ready for review and stop.
