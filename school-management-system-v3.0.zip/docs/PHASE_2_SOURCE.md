# Phase 2 complete source

All authored files are included below. Install reproducible dependencies from package-lock.json in the project folder.

## .env.example

````text
VITE_USE_MOCK=true
# For live mode, apply database/phase1.sql and database/phase2.sql in your development project.
VITE_SUPABASE_URL=
VITE_SUPABASE_PUBLISHABLE_KEY=
# Optional compatibility with existing projects:
VITE_SUPABASE_ANON_KEY=
# Set to your deployed origin; password reset redirects to /reset-password.
VITE_APP_URL=http://127.0.0.1:5173
# Phase 2: configure APP_ORIGIN in the provision-school Edge Function's server secrets.
# SUPABASE_SERVICE_ROLE_KEY stays server-side; never place it in a VITE variable.

````

## .gitignore

````text
node_modules/
dist/
.env
.env.local
.env.*.local
*.tsbuildinfo
test-results/
.npm-cache/

````

## README.md

````md
# Campus · School Management System v3.0

Smart • Secure • Connected

Phases 1 and 2 provide the local frontend foundation and Owner/Master administration using React 18, strict TypeScript, Vite, Supabase, Tailwind tokens, Framer Motion, TanStack Query v5, Zustand, React Router v6, React Hook Form, Zod, TanStack Table/Virtual, date-fns, lucide-react, and sonner. Recharts is lazy-loaded for the Owner/Master analytics screens.

## Run

Node 22.13+ (Node 24 recommended) and npm are required. From this folder:

```powershell
npm ci
Copy-Item .env.example .env.local
npm run dev
```

Open the URL printed by Vite, normally http://127.0.0.1:5173. The shipped defaults enable mock mode without a backend. Build with `npm run build`, run boundary tests with `npm test`, and preview the production build with `npm run preview`. `npm run delivery` writes the complete authored file contents with paths to `docs/PHASE_2_SOURCE.md`.

## Demo sign-in

Use the role selector and **Use demo** to fill the form, then sign in. Every demo account uses **Campus@2026**.

| Role       | Email                           | Campus access        |
| ---------- | ------------------------------- | -------------------- |
| Owner      | owner@greenwood.edu (or GW-001) | North, Central, East |
| Principal  | principal@greenwood.edu         | North                |
| Teacher    | teacher@greenwood.edu           | North                |
| Parent     | parent@greenwood.edu            | North                |
| Student    | student@greenwood.edu           | North                |
| Accountant | accountant@greenwood.edu        | North                |

The separate, non-linked `/sys-master` sign-in accepts `master@greenwood.edu`, with the same demo password. It does not appear in any navigation. Mock mode simulates access in browser storage and is explicitly labeled Demo. It is not a security boundary for real school data.

## Phase 1 delivered

- Responsive shell, full desktop sidebar, tablet icon rail, mobile bottom navigation and More drawer; breadcrumbs, profile menu, school/campus selection, search, theme, and notifications.
- Login validation, password visibility, remember-me storage selection, error feedback, recovery email flow and reset page, role redirects, 401/403/404 views, protected routes, and session-expired dialog.
- Light/dark/system preference with persistence and reduced-motion support. Reusable library of all requested Phase 1 components, including accessible focus-trapped dialogs, type-to-confirm, file validation, virtualized sortable table/card views, and loading/empty/error states.
- A workspace overview and module directory that clearly explain role access and the delivery roadmap. Functional local preferences and interactive component gallery.
- Adapter interface for auth, assigned campuses, notification reads/updates/subscriptions, and private file uploads. Supabase implementation is dynamically loaded only in live mode. Query keys isolate user + campus. Notification read updates are optimistic with rollback; subscriptions are cleaned up.
- SQL schema/RLS/storage contract and compatible database types. Live generation and validation require a real Supabase project; the included types describe the supplied schema, and are **not represented as generated from a deployed database**.

Phase 2 Master/Owner modules are implemented. Remaining phases are Phase 3 Principal/Teacher; Phase 4 Parent/Student/Accountant; Phase 5 WhatsApp and system controls. See docs/PHASE_2_VERIFICATION.md for the complete Phase 2 feature list and integration limits. Locked navigation explains the phase instead of opening unfinished pages. No messages, payments, invitation emails, or uploaded study materials are sent by this phase.

## Live Supabase setup

1. Use a development Supabase project. Review and apply `database/phase1.sql` followed by `database/phase2.sql` in its SQL editor. This is a schema contract, not an executed or generated migration. It grants only the operations implemented in Phase 1.
2. Provision Auth users through trusted administration. Set `app_metadata.role` to one of the roles, and insert a matching `profiles` row with the same role, school UUID, and assigned campus UUID array. Insert the assigned campus rows. The frontend has no privilege to assign roles, tenants, or campuses. Changing authorization claims requires refreshing/revoking sessions as appropriate.
3. Configure your Auth site URL and allow `${your-origin}/reset-password` as a redirect URL. Use HTTPS for production. Real mode accepts email addresses; demo school codes do not resolve live email identities.
4. Enable the tables in your project's Data API settings if required. Review the Realtime publication and create a test notification for the user to verify realtime delivery.
5. Set `VITE_USE_MOCK=false`, the Supabase URL, public publishable key, and app URL in `.env.local`, then restart Vite. Never use a service-role or secret key in a VITE variable.
6. Generate `src/types/database.ts` from that database using the Supabase dashboard or the CLI command documented in [Supabase type generation](https://supabase.com/docs/guides/api/rest/generating-types). Run the build, and test role/campus/RLS isolation with separate users before going live.

The repository implementations follow the documented [Supabase auth subscription lifecycle](https://supabase.com/docs/reference/javascript/auth-onauthstatechange). All authorization comes from trusted app metadata plus read-only provisioned profiles and RLS. The hidden route adds no security by itself. No live Supabase calls have been verified without a configured project.

Private uploads are stored as `school/campus/user/random-name`. The UI gallery validates files locally and does not upload them; the real storage adapter is provided for future module forms. Client-side validation complements server bucket limits.

## Structure

```text
src/
  app/                  Router, auth bootstrap, error boundaries
  components/layout/    Shell and code-native campus illustration
  components/ui/        Complete reusable component library
  features/auth/        Sign-in and password recovery
  features/workspace/   Overview, directory, status pages
  features/system/      Component gallery and local preferences
  hooks/                Theme, permission, debounce
  lib/                  Permissions, query keys, configuration
  services/             Typed repository contract and Supabase adapter
  store/                Auth and persisted UI state
  types/                Domain and database contract
  styles/               Tailwind + CSS-variable neumorphism tokens
  mocks/                Scoped mock adapter and fixture data
database/phase1.sql      Live schema/RLS/storage contract
```

Later role feature folders are introduced when their phase is authorized. No empty implementation files are shipped.

## What to verify

1. Sign in as Owner, switch campus, and confirm branch-specific notifications change. Read a notification and check the unread count updates. Sign out and try Teacher: only North Campus is available.
2. Try incorrect credentials and empty fields; check the error and keyboard focus. Try the master credentials on the normal sign-in: access is rejected. Open an Owner URL as Teacher: a 403 view appears.
3. Toggle light/dark; choose Use system in preferences and change the OS preference. Refresh to confirm local persistence.
4. Exercise global search, profile menu, More drawer, component dialogs, confirmation, and 250-row virtualized table. Check tab focus stays inside dialogs and returns to the trigger on close.
5. At 390px, 768px, and laptop widths, check the bottom navigation/icon rail/full sidebar. Tables become cards on mobile. Test reduced-motion preference.
6. In live mode, verify forgot-password and reset with an actual email. Test failed API requests, expired sessions, storage restrictions, and Realtime with your provisioned users.

Production hosting needs an SPA fallback to `index.html` for deep links. The initial JS budget is measured from built entry dependencies; chart/table/form screens are lazy routes. Lighthouse >=90 is a target and is not claimed without a measured audit.

## Phase 2 handoff

See [Phase 2 verification and live setup](docs/PHASE_2_VERIFICATION.md). The full current source is in [Phase 2 complete source](docs/PHASE_2_SOURCE.md). Run `npm run typecheck:edge` for the privileged provisioning function. Live Auth provisioning follows the [Supabase server-side Admin API](https://supabase.com/docs/reference/javascript/auth-admin-createuser) and [Edge Function invocation](https://supabase.com/docs/reference/javascript/functions-invoke) contracts.

````

## database/phase1.sql

````sql
-- Phase 1 schema contract. Run in a development Supabase project before live mode.
-- No users, authorization claims, or tenants are created by this file.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  school_id uuid not null,
  name text not null,
  email text not null,
  role text not null check (role in ('owner','principal','teacher','parent','student','accountant','master')),
  branch_ids uuid[] not null default '{}'
);
create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null,
  name text not null,
  city text not null,
  short_name text not null
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete cascade,
  title text not null,
  body text not null,
  created_at timestamptz not null default now(),
  read boolean not null default false
);
create index if not exists branches_school_id_idx on public.branches(school_id);
create index if not exists notifications_user_branch_created_idx on public.notifications(user_id,branch_id,created_at desc);
create index if not exists notifications_branch_id_idx on public.notifications(branch_id);
alter table public.profiles enable row level security;
alter table public.branches enable row level security;
alter table public.notifications enable row level security;
revoke all on public.profiles, public.branches, public.notifications from anon, authenticated;
grant select on public.profiles, public.branches, public.notifications to authenticated;
grant update(read) on public.notifications to authenticated;
drop policy if exists "Read own provisioned profile" on public.profiles;
create policy "Read own provisioned profile" on public.profiles for select to authenticated
  using (id = (select auth.uid()) and role = (select auth.jwt()->'app_metadata'->>'role'));
-- A trusted provisioning process maintains school_id, role, and branch_ids.
-- Client users cannot promote themselves or assign additional campuses.
drop policy if exists "Assigned campuses in own school" on public.branches;
create policy "Assigned campuses in own school" on public.branches for select to authenticated
  using (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.school_id = branches.school_id and branches.id = any(p.branch_ids)));
drop policy if exists "Read own scoped notifications" on public.notifications;
create policy "Read own scoped notifications" on public.notifications for select to authenticated
  using (user_id = (select auth.uid()) and (branch_id is null or exists (select 1 from public.branches b where b.id = notifications.branch_id)));
drop policy if exists "Mark own scoped notifications read" on public.notifications;
create policy "Mark own scoped notifications read" on public.notifications for update to authenticated
  using (user_id = (select auth.uid()) and (branch_id is null or exists (select 1 from public.branches b where b.id = notifications.branch_id)))
  with check (user_id = (select auth.uid()) and (branch_id is null or exists (select 1 from public.branches b where b.id = notifications.branch_id)));
insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('school-files','school-files',false,5242880,array['application/pdf','text/csv','image/png','image/jpeg'])
on conflict(id) do nothing;
-- Files are private and confined to school/campus/user folders.
drop policy if exists "Upload own campus files" on storage.objects;
create policy "Upload own campus files" on storage.objects for insert to authenticated
with check (bucket_id = 'school-files' and (storage.foldername(storage.objects.name))[3] = (select auth.uid())::text and exists (
  select 1 from public.profiles p join public.branches b on b.school_id = p.school_id
  where p.id = (select auth.uid()) and p.school_id::text = (storage.foldername(storage.objects.name))[1]
  and b.id::text = (storage.foldername(storage.objects.name))[2] and b.id = any(p.branch_ids)
));
drop policy if exists "Read own campus files" on storage.objects;
create policy "Read own campus files" on storage.objects for select to authenticated
using (bucket_id = 'school-files' and (storage.foldername(storage.objects.name))[3] = (select auth.uid())::text and exists (
  select 1 from public.profiles p join public.branches b on b.school_id = p.school_id
  where p.id = (select auth.uid()) and p.school_id::text = (storage.foldername(storage.objects.name))[1]
  and b.id::text = (storage.foldername(storage.objects.name))[2] and b.id = any(p.branch_ids)
));
-- Publish notifications for Realtime if not already enabled in this project.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'notifications') then
    alter publication supabase_realtime add table public.notifications;
  end if;
end $$;

````

## database/phase2.sql

````sql
-- Apply after phase1.sql in a development Supabase project.
-- Administrative documents use typed, versioned JSON payloads; tenant columns stay relational.
create schema if not exists private;
revoke all on schema private from public, anon;
grant usage on schema private to authenticated;
alter table public.profiles add column if not exists active boolean not null default true;
alter table public.profiles add column if not exists policy_id uuid;
alter table public.branches add column if not exists active boolean not null default true;
create table if not exists public.admin_records (
  id uuid primary key,
  school_id uuid not null,
  branch_id uuid,
  resource text not null check(resource in ('schools','branches','users','finance','roles','settings','templates','audit','analytics')),
  payload jsonb not null check(jsonb_typeof(payload) = 'object'),
  version integer not null default 1 check(version > 0),
  updated_at timestamptz not null default now()
);
create index if not exists admin_records_scope_idx on public.admin_records(resource,school_id,branch_id,updated_at desc,id);
create unique index if not exists admin_school_code_idx on public.admin_records(lower(payload->>'code')) where resource = 'schools';
create unique index if not exists admin_user_email_idx on public.admin_records(school_id,lower(payload->>'email')) where resource = 'users';
create unique index if not exists admin_role_idx on public.admin_records(school_id,(payload->>'role')) where resource = 'roles' and coalesce((payload->>'custom')::boolean,false)=false;
create unique index if not exists admin_settings_idx on public.admin_records(school_id) where resource = 'settings';
alter table public.admin_records enable row level security;
revoke all on public.admin_records from public,anon,authenticated;
grant select on public.admin_records to authenticated;
grant all on public.admin_records to service_role;

-- This narrowly scoped lookup deliberately bypasses admin_records RLS to avoid recursive profile policies.
create or replace function private.school_active(p_school uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select (select auth.uid()) is not null and exists(select 1 from public.admin_records r where r.resource='schools' and r.id=p_school and r.payload->>'status'='Active');
$$;
revoke all on function private.school_active(uuid) from public,anon;
grant execute on function private.school_active(uuid) to authenticated;
drop policy if exists "Read own provisioned profile" on public.profiles;
create policy "Read own provisioned profile" on public.profiles for select to authenticated using (
  id=(select auth.uid()) and active and role=(select auth.jwt()->'app_metadata'->>'role') and coalesce(policy_id::text,'')=coalesce((select auth.jwt()->'app_metadata'->>'policy_id'),'') and (role='master' or private.school_active(school_id))
);
drop policy if exists "Assigned campuses in own school" on public.branches;
create policy "Assigned campuses in own school" on public.branches for select to authenticated using (
  active and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.school_id=branches.school_id and (p.role='owner' or branches.id=any(p.branch_ids)))
);
drop policy if exists "Read own scoped notifications" on public.notifications;
create policy "Read own scoped notifications" on public.notifications for select to authenticated using(user_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid())) and (branch_id is null or exists(select 1 from public.branches b where b.id=notifications.branch_id)));
drop policy if exists "Mark own scoped notifications read" on public.notifications;
create policy "Mark own scoped notifications read" on public.notifications for update to authenticated using(user_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid())) and (branch_id is null or exists(select 1 from public.branches b where b.id=notifications.branch_id))) with check(user_id=(select auth.uid()) and exists(select 1 from public.profiles p where p.id=(select auth.uid())) and (branch_id is null or exists(select 1 from public.branches b where b.id=notifications.branch_id)));
drop policy if exists "Read scoped administration" on public.admin_records;
create policy "Read scoped administration" on public.admin_records for select to authenticated using (
  exists(select 1 from public.profiles p where p.id=(select auth.uid()) and (
    (p.role='master' and (resource in ('schools','audit') or (resource='roles' and school_id='00000000-0000-0000-0000-000000000000'::uuid))) or
    (p.role='owner' and school_id=p.school_id and resource<>'schools') or
    (resource='roles' and (school_id=p.school_id or school_id='00000000-0000-0000-0000-000000000000'::uuid))
  ))
);

create or replace function private.audit_admin_change() returns trigger language plpgsql security definer set search_path='' as $$
declare r public.admin_records; who uuid; event_id uuid; actor_name text;
begin
  if tg_op='DELETE' then r:=old; else r:=new; end if;
  if r.resource='audit' then return null; end if;
  who:=coalesce(auth.uid(),nullif(current_setting('app.provision_actor',true),'')::uuid);
  select name into actor_name from public.profiles where id=who;
  event_id:=gen_random_uuid();
  insert into public.admin_records(id,school_id,resource,payload) values(event_id,r.school_id,'audit',jsonb_build_object('id',event_id,'schoolId',r.school_id,'branchId',null,'version',1,'actor',coalesce(actor_name,'Trusted provisioning'),'action',tg_op,'resource',r.resource,'details',r.resource||' record '||r.id::text,'createdAt',now()));
  return null;
end $$;
revoke all on function private.audit_admin_change() from public,anon,authenticated;
drop trigger if exists audit_admin_change on public.admin_records;
create trigger audit_admin_change after insert or update or delete on public.admin_records for each row execute function private.audit_admin_change();

create or replace function public.admin_list(p_resource text,p_scope jsonb,p_options jsonb default '{}') returns jsonb language sql stable security invoker set search_path='' as $$
  with allowed as (
    select r.* from public.admin_records r where r.resource=p_resource
    and (p_resource='schools' or (p_resource='audit' and (select auth.jwt()->'app_metadata'->>'role')='master') or r.school_id=(p_scope->>'schoolId')::uuid)
    and (coalesce(p_scope->>'branchId','')='' or p_resource in ('roles','settings') or r.branch_id=(p_scope->>'branchId')::uuid)
    and (coalesce(p_options->>'search','')='' or r.payload::text ilike '%'||(p_options->>'search')||'%')
    and r.payload @> coalesce(p_options->'filters','{}'::jsonb)
    and (coalesce(p_options->>'from','')='' or left(coalesce(r.payload->>'date',r.payload->>'createdAt',''),10)>=p_options->>'from')
    and (coalesce(p_options->>'to','')='' or left(coalesce(r.payload->>'date',r.payload->>'createdAt',''),10)<=p_options->>'to')
  ), paged as (select * from allowed order by updated_at desc,id limit least(500,greatest(1,coalesce((p_options->>'pageSize')::int,50))) offset greatest(0,coalesce((p_options->>'page')::int,0))*least(500,greatest(1,coalesce((p_options->>'pageSize')::int,50))))
  select jsonb_build_object('rows',coalesce((select jsonb_agg(payload||jsonb_build_object('version',version) order by updated_at desc,id) from paged),'[]'::jsonb),'total',(select count(*) from allowed));
$$;

-- Writes are restricted to one checked private function. Direct table writes stay revoked.
create or replace function private.admin_save_checked(p_resource text,p_record jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare actor public.profiles; existing public.admin_records; rid uuid; sid uuid; bid uuid; next_version int; result jsonb;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into actor from public.profiles where id=auth.uid() and active and role=auth.jwt()->'app_metadata'->>'role';
  if actor.id is null or actor.role not in ('owner','master') then raise exception 'Administrative access required'; end if;
  if p_resource not in ('schools','branches','users','finance','roles','settings','templates') then raise exception 'Resource cannot be edited'; end if;
  if not p_record ?& array['id','schoolId','branchId','version'] then raise exception 'Missing record metadata'; end if;
  if p_resource='schools' and not p_record ?& array['name','code','ownerEmail','plan','status','monthlyFee','createdAt'] then raise exception 'Incomplete school'; end if;
  if p_resource='branches' and not p_record ?& array['name','city','code','principal','capacity','status'] then raise exception 'Incomplete campus'; end if;
  if p_resource='users' and not p_record ?& array['name','email','role','status','phone','joinedAt'] then raise exception 'Incomplete directory record'; end if;
  if p_resource='finance' and not p_record ?& array['reference','description','kind','category','amount','date','status'] then raise exception 'Incomplete transaction'; end if;
  if p_resource='roles' and not p_record ?& array['name','role','permissions'] then raise exception 'Incomplete role'; end if;
  if p_resource='settings' and not p_record ?& array['name','academicYear','logoPath','senderNumber','financeRole','overrideEnabled','requireMfa','sessionMinutes','privacyEmail','retentionDays'] then raise exception 'Incomplete settings'; end if;
  if p_resource='templates' and not p_record ?& array['name','category','body','status'] then raise exception 'Incomplete template'; end if;
  rid:=(p_record->>'id')::uuid; sid:=(p_record->>'schoolId')::uuid; bid:=nullif(p_record->>'branchId','')::uuid;
  if actor.role='owner' then
    if sid<>actor.school_id or not private.school_active(sid) or p_resource='schools' then raise exception 'School access denied'; end if;
  elsif not (p_resource='schools' or (p_resource='roles' and sid='00000000-0000-0000-0000-000000000000'::uuid)) then raise exception 'Platform resource required'; end if;
  if p_resource='schools' and (rid<>sid or p_record->>'status' not in ('Active','Suspended','Deleted') or (p_record->>'monthlyFee')::numeric<0) then raise exception 'Invalid school record'; end if;
  if p_resource='branches' and (length(p_record->>'name')<2 or (p_record->>'capacity')::int<1 or bid<>rid) then raise exception 'Invalid campus record'; end if;
  if p_resource='users' and (p_record->>'role' not in ('principal','teacher','parent','student','accountant') or p_record->>'status' not in ('Active','Inactive') or p_record->>'email' not like '%@%') then raise exception 'Invalid directory record'; end if;
  if p_resource='finance' and ((p_record->>'amount')::numeric<=0 or p_record->>'kind' not in ('Income','Expense') or p_record->>'status' not in ('Paid','Pending','Overdue')) then raise exception 'Invalid financial record'; end if;
  if p_resource='roles' and (p_record->>'role' not in ('principal','teacher','parent','student','accountant') or p_record->'permissions' ? 'master.manage' or not p_record->'permissions' ? 'workspace.read') then raise exception 'Protected role or permission'; end if;
  if p_resource='settings' and ((p_record->>'sessionMinutes')::int not between 15 and 480 or (p_record->>'retentionDays')::int not between 30 and 3650 or p_record->>'senderNumber' !~ '^\+[1-9][0-9]{7,14}$') then raise exception 'Invalid school configuration'; end if;
  if p_resource='templates' then p_record:=jsonb_set(p_record,'{status}','"Draft"'::jsonb); end if;
  if bid is not null and p_resource<>'branches' and not exists(select 1 from public.admin_records where resource='branches' and school_id=sid and id=bid) then raise exception 'Campus is outside this school'; end if;
  select * into existing from public.admin_records where id=rid for update;
  if existing.id is not null and (existing.school_id<>sid or existing.resource<>p_resource or existing.version<>(p_record->>'version')::int) then raise exception 'Record changed; refresh before saving'; end if;
  if existing.id is not null and p_resource='schools' and (existing.payload->>'ownerEmail'<>p_record->>'ownerEmail' or existing.payload->>'code'<>p_record->>'code') then raise exception 'Login identity changes require trusted Auth administration'; end if;
  if existing.id is null and p_resource='schools' then raise exception 'Use trusted school provisioning'; end if;
  next_version:=coalesce(existing.version,0)+1; result:=p_record||jsonb_build_object('version',next_version);
  insert into public.admin_records(id,school_id,branch_id,resource,payload,version) values(rid,sid,bid,p_resource,result,next_version)
    on conflict(id) do update set payload=excluded.payload,version=excluded.version,branch_id=excluded.branch_id,updated_at=now();
  if p_resource='branches' then
    insert into public.branches(id,school_id,name,city,short_name,active) values(rid,sid,p_record->>'name',p_record->>'city',p_record->>'name',p_record->>'status'='Active')
      on conflict(id) do update set name=excluded.name,city=excluded.city,short_name=excluded.short_name,active=excluded.active;
    update public.profiles set branch_ids=array(select distinct unnest(branch_ids||array[rid])) where school_id=sid and role='owner';
  end if;
  if p_resource='users' then
    if nullif(p_record->>'policyId','') is not null and not exists(select 1 from public.admin_records where id=(p_record->>'policyId')::uuid and resource='roles' and school_id=sid and payload->>'role'=p_record->>'role') then raise exception 'Role policy is outside this school or base role'; end if;
    update public.profiles set name=p_record->>'name',role=p_record->>'role',branch_ids=array[bid],active=p_record->>'status'='Active',policy_id=nullif(p_record->>'policyId','')::uuid where school_id=sid and lower(email)=lower(p_record->>'email') and role<>'owner';
    update auth.users u set raw_app_meta_data=coalesce(u.raw_app_meta_data,'{}'::jsonb)||jsonb_build_object('role',p_record->>'role','policy_id',nullif(p_record->>'policyId','')) where exists(select 1 from public.profiles p where p.id=u.id and p.school_id=sid and lower(p.email)=lower(p_record->>'email') and p.role<>'owner');
  end if;
  return result;
end $$;
revoke all on function private.admin_save_checked(text,jsonb) from public,anon;
grant execute on function private.admin_save_checked(text,jsonb) to authenticated;
create or replace function public.admin_save(p_resource text,p_record jsonb) returns jsonb language sql security invoker set search_path='' as $$ select private.admin_save_checked(p_resource,p_record); $$;

create or replace function private.admin_delete_checked(p_resource text,p_id uuid,p_scope jsonb,p_version int) returns jsonb language plpgsql security definer set search_path='' as $$
declare actor public.profiles; existing public.admin_records; sid uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into actor from public.profiles where id=auth.uid() and active and role=auth.jwt()->'app_metadata'->>'role';
  sid:=(p_scope->>'schoolId')::uuid;
  if actor.id is null or actor.role<>'owner' or actor.school_id<>sid or not private.school_active(sid) then raise exception 'School owner access required'; end if;
  if p_resource not in ('branches','users','finance','templates') then raise exception 'Protected resource'; end if;
  select * into existing from public.admin_records where id=p_id and school_id=sid and resource=p_resource for update;
  if existing.id is null or existing.version<>p_version then raise exception 'Record changed; refresh before deleting'; end if;
  if p_resource='branches' and exists(select 1 from public.admin_records where resource='users' and school_id=sid and branch_id=p_id) then raise exception 'Move assigned people before deleting this campus'; end if;
  if p_resource='users' then update public.profiles set active=false where school_id=sid and lower(email)=lower(existing.payload->>'email') and role<>'owner'; end if;
  if p_resource='branches' then
    delete from public.branches where id=p_id and school_id=sid;
    update public.profiles set branch_ids=array_remove(branch_ids,p_id) where school_id=sid;
  end if;
  delete from public.admin_records where id=p_id;
  return jsonb_build_object('deleted',true);
end $$;
revoke all on function private.admin_delete_checked(text,uuid,jsonb,int) from public,anon;
grant execute on function private.admin_delete_checked(text,uuid,jsonb,int) to authenticated;
create or replace function public.admin_delete(p_resource text,p_id text,p_scope jsonb,p_version int) returns jsonb language sql security invoker set search_path='' as $$ select private.admin_delete_checked(p_resource,p_id::uuid,p_scope,p_version); $$;

create or replace function public.admin_summary(p_scope jsonb) returns jsonb language sql stable security invoker set search_path='' as $$
 with scoped as (select resource,payload from public.admin_records where school_id=(p_scope->>'schoolId')::uuid and (coalesce(p_scope->>'branchId','')='' or branch_id=(p_scope->>'branchId')::uuid)),
 finances as (select payload from scoped where resource='finance'), people as (select payload from scoped where resource='users' and payload->>'status'='Active'), schools as (select payload from public.admin_records where resource='schools' and (coalesce(p_scope->>'from','')='' or left(payload->>'createdAt',10)>=p_scope->>'from') and (coalesce(p_scope->>'to','')='' or left(payload->>'createdAt',10)<=p_scope->>'to')),
 months as (select generate_series(date_trunc('month',now())-interval '5 months',date_trunc('month',now()),interval '1 month') as month),
 revenue as (select to_char(month,'Mon') as label,month,coalesce(sum((payload->>'amount')::numeric) filter(where payload->>'kind'='Income'),0) as income,coalesce(sum((payload->>'amount')::numeric) filter(where payload->>'kind'='Expense'),0) as expense from months left join finances on left(payload->>'date',7)=to_char(month,'YYYY-MM') and payload->>'status'='Paid' group by month)
 select jsonb_build_object(
 'students',(select count(*) from people where payload->>'role'='student'),'staff',(select count(*) from people where payload->>'role' in ('teacher','principal','accountant')),
 'attendance',coalesce((select jsonb_agg(jsonb_build_object('label',to_char(month::date,'Mon'),'value',rate) order by month) from (select left(payload->>'date',7)||'-01' as month,round(100.0*sum((payload->>'present')::numeric)/nullif(sum((payload->>'total')::numeric),0),1) as rate from scoped where resource='analytics' group by left(payload->>'date',7)) monthly where rate is not null),'[]'::jsonb),
 'income',coalesce((select sum((payload->>'amount')::numeric) from finances where payload->>'kind'='Income' and payload->>'status'='Paid'),0),
 'expenses',coalesce((select sum((payload->>'amount')::numeric) from finances where payload->>'kind'='Expense' and payload->>'status'='Paid'),0),
 'outstanding',coalesce((select sum((payload->>'amount')::numeric) from finances where payload->>'kind'='Income' and payload->>'status'<>'Paid'),0),
 'schools',(select count(*) from schools),'active',(select count(*) from schools where payload->>'status'='Active'),'suspended',(select count(*) from schools where payload->>'status'<>'Active'),
 'mrr',coalesce((select sum((payload->>'monthlyFee')::numeric) from schools where payload->>'status'='Active'),0),
 'revenue',case when (select auth.jwt()->'app_metadata'->>'role')='master' then coalesce((select jsonb_agg(jsonb_build_object('label',payload->>'code','value',case when payload->>'status'='Active' then (payload->>'monthlyFee')::numeric else 0 end)) from (select payload from schools order by (payload->>'monthlyFee')::numeric desc limit 10) top_schools),'[]'::jsonb) else coalesce((select jsonb_agg(jsonb_build_object('label',label,'value',income,'secondary',expense) order by month) from revenue),'[]'::jsonb) end,
 'enrollment',case when (select auth.jwt()->'app_metadata'->>'role')='master' then coalesce((select jsonb_agg(jsonb_build_object('label',plan,'value',(select count(*) from schools where payload->>'plan'=plan and payload->>'status'='Active'))) from unnest(array['Starter','Growth','Enterprise']) plan),'[]'::jsonb) else coalesce((select jsonb_agg(jsonb_build_object('label',b.payload->>'code','value',(select count(*) from people p where p.payload->>'branchId'=b.payload->>'id' and p.payload->>'role'='student'))) from scoped b where b.resource='branches'),'[]'::jsonb) end
 );
$$;

-- Only the trusted Edge Function can finalize Auth + school provisioning.
create or replace function public.provision_school_record(p_school jsonb,p_owner_id uuid,p_actor uuid) returns jsonb language plpgsql security invoker set search_path='' as $$
declare sid uuid; bid uuid; rid uuid; item jsonb;
begin
 if not exists(select 1 from public.profiles where id=p_actor and role='master' and active) then raise exception 'Platform administrator required'; end if;
 sid:=(p_school->>'id')::uuid; bid:=gen_random_uuid(); perform set_config('app.provision_actor',p_actor::text,true);
 insert into public.admin_records(id,school_id,resource,payload) values(sid,sid,'schools',p_school);
 insert into public.branches(id,school_id,name,city,short_name) values(bid,sid,'Main Campus','Unassigned','Main Campus');
 insert into public.admin_records(id,school_id,branch_id,resource,payload) values(bid,sid,bid,'branches',jsonb_build_object('id',bid,'schoolId',sid,'branchId',bid,'version',1,'name','Main Campus','city','Unassigned','code',p_school->>'code'||'-MAIN','principal','','capacity',1000,'status','Active'));
 insert into public.profiles(id,school_id,name,email,role,branch_ids) values(p_owner_id,sid,p_school->>'name'||' Owner',p_school->>'ownerEmail','owner',array[bid]);
 for item in select payload from public.admin_records where resource='roles' and school_id='00000000-0000-0000-0000-000000000000'::uuid loop
  rid:=gen_random_uuid(); insert into public.admin_records(id,school_id,resource,payload) values(rid,sid,'roles',item||jsonb_build_object('id',rid,'schoolId',sid,'version',1));
 end loop;
 return p_school;
end $$;
revoke all on function public.provision_school_record(jsonb,uuid,uuid) from public,anon,authenticated;
grant execute on function public.provision_school_record(jsonb,uuid,uuid) to service_role;
revoke all on function public.admin_list(text,jsonb,jsonb),public.admin_save(text,jsonb),public.admin_delete(text,text,jsonb,int),public.admin_summary(jsonb) from public,anon;
grant execute on function public.admin_list(text,jsonb,jsonb),public.admin_save(text,jsonb),public.admin_delete(text,text,jsonb,int),public.admin_summary(jsonb) to authenticated;

-- Bootstrap existing Phase 1 tenants and campuses without replacing any configured records.
insert into public.admin_records(id,school_id,resource,payload)
select school_id,school_id,'schools',jsonb_build_object('id',school_id,'schoolId',school_id,'branchId',null,'version',1,'name',max(name)||' School','code','SCH-'||left(school_id::text,8),'ownerEmail',max(email),'plan','Starter','status','Active','monthlyFee',0,'createdAt',current_date)
from public.profiles where role='owner' group by school_id on conflict do nothing;
insert into public.admin_records(id,school_id,branch_id,resource,payload)
select id,school_id,id,'branches',jsonb_build_object('id',id,'schoolId',school_id,'branchId',id,'version',1,'name',short_name,'city',city,'code',left(id::text,8),'principal','','capacity',1000,'status',case when active then 'Active' else 'Inactive' end)
from public.branches on conflict do nothing;
insert into public.admin_records(id,school_id,resource,payload)
select gen_random_uuid(),scope,'roles',jsonb_build_object('id',rid,'schoolId',scope,'branchId',null,'version',1,'name',role_name,'role',role_name,'permissions',grants)
from (select distinct school_id as scope from public.profiles where role='owner' union select '00000000-0000-0000-0000-000000000000'::uuid) schools
cross join (values
 ('owner','["workspace.read","users.manage","branches.manage","academics.read","attendance.manage","finance.manage","child.read","whatsapp.manage","system.manage"]'::jsonb),
 ('principal','["workspace.read","users.manage","academics.read","attendance.manage"]'::jsonb),
 ('teacher','["workspace.read","academics.read","attendance.manage"]'::jsonb),
 ('parent','["workspace.read","child.read"]'::jsonb),
 ('student','["workspace.read","child.read"]'::jsonb),
 ('accountant','["workspace.read","finance.manage"]'::jsonb)
) defaults(role_name,grants)
cross join lateral (select gen_random_uuid() as rid) ids on conflict do nothing;
-- Keep document IDs aligned with their relational keys, including seeded role policies.
update public.admin_records set payload=jsonb_set(payload,'{id}',to_jsonb(id::text)) where payload->>'id'<>id::text;

````

## database/phase2.test.ts

````ts
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { PGlite } from "@electric-sql/pglite";
import { readFile } from "node:fs/promises";
const db = new PGlite();
const owner = "11111111-1111-1111-1111-111111111111";
const master = "22222222-2222-2222-2222-222222222222";
const school = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa";
const branch = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb";
const recordId = "cccccccc-cccc-cccc-cccc-cccccccccccc";
async function asUser(id: string, role: string) {
  await db.exec("reset role");
  await db.query(
    "select set_config('request.jwt.claim.sub',$1,false),set_config('request.jwt.claims',$2,false)",
    [id, JSON.stringify({ app_metadata: { role } })],
  );
  await db.exec("set role authenticated");
}
beforeAll(async () => {
  await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
  create schema auth; create schema storage;
  create table auth.users(id uuid primary key,raw_app_meta_data jsonb default '{}');
  create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
  create function auth.jwt() returns jsonb language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb $$;
  grant usage on schema auth,storage to authenticated;
  create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
  create table storage.objects(id uuid default gen_random_uuid(),bucket_id text,name text);
  alter table storage.objects enable row level security;
  create function storage.foldername(text) returns text[] language sql immutable as $$ select (string_to_array($1,'/'))[1:array_length(string_to_array($1,'/'),1)-1] $$;
  create publication supabase_realtime;
  `);
  await db.exec(await readFile("database/phase1.sql", "utf8"));
  await db.query("insert into auth.users(id) values($1),($2)", [owner, master]);
  await db.query(
    "insert into public.profiles(id,school_id,name,email,role,branch_ids) values($1,$3,'School Owner','owner@test.edu','owner',array[$4::uuid]),($2,$3,'Platform Admin','master@test.edu','master',array[$4::uuid])",
    [owner, master, school, branch],
  );
  await db.query(
    "insert into public.branches(id,school_id,name,city,short_name) values($1,$2,'North Campus','Bengaluru','North')",
    [branch, school],
  );
  await db.exec(await readFile("database/phase2.sql", "utf8"));
}, 60000);
afterAll(async () => {
  await db.close();
});
describe("Phase 2 SQL authorization", () => {
  it("allows a scoped owner write and produces an append-only audit event", async () => {
    await asUser(owner, "owner");
    const record = {
      id: recordId,
      schoolId: school,
      branchId: branch,
      version: 1,
      reference: "REC-01",
      description: "Tuition collection",
      kind: "Income",
      category: "Tuition",
      amount: 5000,
      date: "2026-10-31",
      status: "Paid",
    };
    const saved = await db.query<{ result: { version: number } }>(
      "select public.admin_save($1,$2::jsonb) as result",
      ["finance", JSON.stringify(record)],
    );
    expect(saved.rows[0]?.result.version).toBe(1);
    const summary = await db.query<{ result: { income: number } }>(
      "select public.admin_summary($1::jsonb) as result",
      [JSON.stringify({ schoolId: school })],
    );
    expect(summary.rows[0]?.result.income).toBe(5000);
    await expect(
      db.exec("delete from public.admin_records where resource='audit'"),
    ).rejects.toThrow();
  });
  it("rejects cross-tenant writes and stale versions", async () => {
    await asUser(owner, "owner");
    const base = {
      id: recordId,
      schoolId: school,
      branchId: branch,
      version: 1,
      reference: "REC-01",
      description: "Tuition collection",
      kind: "Income",
      category: "Tuition",
      amount: 6000,
      date: "2026-10-31",
      status: "Paid",
    };
    await expect(
      db.query("select public.admin_save($1,$2::jsonb)", [
        "finance",
        JSON.stringify({
          ...base,
          schoolId: "dddddddd-dddd-dddd-dddd-dddddddddddd",
        }),
      ]),
    ).rejects.toThrow("School access denied");
    await db.query("select public.admin_save($1,$2::jsonb)", [
      "finance",
      JSON.stringify(base),
    ]);
    await expect(
      db.query("select public.admin_save($1,$2::jsonb)", [
        "finance",
        JSON.stringify(base),
      ]),
    ).rejects.toThrow("Record changed");
  });
  it("fails closed when no trusted actor exists", async () => {
    await asUser("", "owner");
    await expect(
      db.query("select public.admin_delete($1,$2,$3::jsonb,$4)", [
        "finance",
        recordId,
        JSON.stringify({ schoolId: school }),
        2,
      ]),
    ).rejects.toThrow("Authentication required");
  });
  it("revokes school data immediately when the platform suspends it", async () => {
    await asUser(master, "master");
    const list = await db.query<{
      result: { rows: { id: string; version: number; status: string }[] };
    }>("select public.admin_list($1,$2::jsonb,$3::jsonb) as result", [
      "schools",
      JSON.stringify({ schoolId: school }),
      "{}",
    ]);
    const existing = list.rows[0]?.result.rows[0];
    expect(existing).toBeDefined();
    await db.query("select public.admin_save($1,$2::jsonb)", [
      "schools",
      JSON.stringify({ ...existing, status: "Suspended" }),
    ]);
    await asUser(owner, "owner");
    const profiles = await db.query("select id from public.profiles");
    expect(profiles.rows).toHaveLength(0);
    await expect(
      db.query("select public.admin_delete($1,$2,$3::jsonb,$4)", [
        "finance",
        recordId,
        JSON.stringify({ schoolId: school }),
        2,
      ]),
    ).rejects.toThrow("School owner access required");
  });
});

````

## docs/PHASE_1_VERIFICATION.md

````md
# Phase 1 verification

Verified on 31 October 2026. The build and test commands require execution outside this machine's restrictive filesystem sandbox because esbuild reads parent directories during module resolution.

## Automated checks

- Strict TypeScript compilation and Vite production build pass.
- 8 tests pass: master-role separation, finance/academics separation, signed-out denial, role redirects, rejected credentials, campus isolation, notification account isolation, and remember-me restoration/sign-out.
- The production build includes a separate budget checker for the initial login and mock-auth dependency graph. Its build output reports compressed JavaScript and fails at 200 KiB.

## Browser checks completed

- Light and dark sign-in screens rendered.
- Empty-field login validation appeared inline and focused the email/code input.
- Demo Owner signed in successfully and reached the Owner workspace.
- Owner switched to Central Campus; notification drawer displayed the Central Campus scope.
- Marking a notification as read reduced the unread count optimistically.
- A 390px mobile layout showed bottom navigation and no horizontal overflow (document width 375px with the 15px scrollbar inside the 390px viewport).
- Mobile component confirmation disabled the confirm action until the exact phrase matched. Escape dismissed the dialog, restored focus to its trigger, and removed background inertness.
- A 250-record table rendered 13 mobile cards, confirming virtualization rather than rendering the entire list.
- The mobile More drawer displayed account identity and the sign-out action.

## Verification limits

The in-app browser transport closed during the final account-switch check. Reconnection attempts failed, so the final mobile sign-out/Teacher-login sequence, a tablet-width pass, and screenshot file export were not verified. Role and campus restrictions are covered by the automated tests above. The temporary browser viewport could not be reset after transport loss.

No Supabase project or credentials were supplied. Live Auth recovery, RLS behavior, Realtime delivery, Storage, and database-generated types require integration verification against a provisioned development project. `src/types/database.ts` is a schema-compatible contract, not a claim that remote type generation was performed. No Lighthouse score is claimed.

````

## docs/PHASE_2_VERIFICATION.md

````md
# Phase 2 — implementation and verification

Implemented on 31 October 2026. Phase 3 has not started.

## Delivered

- Hidden Master workspace: dashboard, school creation with generated credentials, school list/search/status filters, typed confirmation for suspend/restore/remove access, contracted school-wise subscription revenue with creation-date filters, global role defaults, and platform audit history.
- Owner dashboard: server-aggregated directory counts and finance totals, lazily loaded income/expense, enrollment and attendance-summary charts, campus scope, recent activity and shortcuts.
- Campuses, community directory, finance entries and WhatsApp template editors: validated forms, sorting, paging, search/status filters, role filters, financial date filters, exports, destructive confirmations, and mobile card actions.
- Community CSV import: quoted-field parser, schema and campus validation, duplicate checks, preview, bounded batches and explicit partial-failure feedback. Bulk activate/deactivate works on selected visible records.
- Role matrix with custom roles based on standard roles. Custom policies can be assigned to directory members. Existing linked live accounts receive trusted metadata/profile updates and require token refresh. The navigation and Can hook consume saved policies. Owner/platform boundaries remain protected.
- Branding name and logo, academic year, sender-number configuration, template editing, default financial responsibility, idle timeout, privacy contact, retention preference and a warned Owner override setting. WhatsApp connectivity/approval/delivery remains Phase 5.
- Read-only role previews using existing Owner summary data. Full role business screens remain in Phases 3 and 4.
- Mock data persists locally, including generated demo owner accounts with salted password hashes. A newly provisioned school's owner can log in and sees only that school's main campus and records.
- SQL RLS contract, checked/versioned write functions, append-only audit trigger, relational campus synchronization, linked-account role/campus/status updates, school suspension boundary and server-side aggregates. A TypeScript Edge Function handles privileged Auth provisioning without exposing a service key to the browser.

## Automated verification

`npm test`: **17 tests pass** across five suites. These cover basic role separation, mock campus and account isolation, custom-role persistence, optimistic-concurrency rejection, usable generated credentials, suspended-school denial, CSV quoting and malformed input, and local PostgreSQL RLS/write behavior.

`npm run build`: strict frontend compilation, Vite production build and bundle-budget check pass. The measured login + mock-auth dependency graph is **155.4 KiB gzip**, below the 200 KiB budget. Charts and administrative tables/forms remain separate lazy chunks. No Lighthouse score is claimed.

`npm run typecheck:edge` checks the Edge Function against the installed Supabase/Zod types and a narrow local Deno API declaration. Deployment/integration still requires a Supabase development project.

SQL was executed in PGlite with minimal Supabase Auth/Storage stubs. Tests verify actual PostgreSQL policies and functions, while hosted Auth, Storage, Realtime and Edge integration remain unverified until a project is configured. Schema-compatible types are included; they must be regenerated from the deployed database before release.

## Browser verification

- Owner dashboard rendered with real mock aggregates and lazy charts.
- A campus was created; its record and switcher option both appeared.
- A custom finance role was created, confirmed, saved, and appeared in the directory assignment selector.
- Mobile sign-out completed, followed by the separate Master login.
- The Master created a new school; its entry appeared in the school list and the one-time credentials dialog opened. Generated-credential sign-in is covered by the automated adapter test.
- Phase 1 already verified a 390px layout without horizontal overflow, dialog gating/Escape/focus restoration and table virtualization.
- The final Owner attendance-summary chart rendered with monthly data. A 768px check confirmed the 80px tablet rail and no horizontal overflow; a 1280px check confirmed the 244px desktop sidebar and no horizontal overflow. The Owner navigation contains no Master link. Viewport overrides were reset after verification.

Review screenshots: [Desktop dashboard](phase2-dashboard-desktop.jpg), [mobile dashboard](phase2-dashboard.jpg).

The demo browser contains the fictional records created during these checks. No live school or Auth account was changed.

## Run and review

```powershell
npm ci
Copy-Item .env.example .env.local
npm run dev
npm test
npm run build
npm run typecheck:edge
npm run delivery
```

Owner demo: `owner@greenwood.edu` / `Campus@2026`. Master demo: open `/sys-master`, then `master@greenwood.edu` / `Campus@2026`.

Review the Owner dashboard, create/edit a campus or person, filter the financial register, import a small CSV, create and assign a custom role, edit school settings, inspect audit events, and use the Master school-access confirmations. Every enabled Phase 2 route is listed in the role's navigation.

## Live setup

Review and apply `database/phase1.sql`, then `database/phase2.sql` in a development Supabase project. The second file bootstraps existing Owner schools/campuses and standard role defaults. Provision a trusted Master Auth user with matching `app_metadata.role` and `profiles.role`. Deploy the `provision-school` function through Supabase, setting its `APP_ORIGIN` secret to the exact frontend origin. Supabase's server-only service-role secret must never enter frontend environment variables.

School removal is a retained, reversible access status. Directory deletion is permanent within the app and requires typed confirmation. New directory rows do not automatically create Auth users or send invitations; only the Master school-provisioning workflow creates an owner login. Existing linked Auth accounts are updated by checked SQL. Sender numbers and templates are saved configuration, rather than a claim of a connected WhatsApp service. Retention days are a preference, rather than an automatic deletion schedule.

````

## index.html

````html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, viewport-fit=cover"
    />
    <meta name="theme-color" content="#E9EDF3" />
    <meta
      name="description"
      content="School Management System v3.0. One connected workspace for your entire school community."
    />
    <title>Campus · School Management</title>
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>

````

## package.json

````json
{
  "name": "campus-school-management",
  "version": "3.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite --host 127.0.0.1",
    "build": "tsc -b && tsc -p tsconfig.edge.json && vite build && node --experimental-strip-types scripts/check-bundle.ts",
    "preview": "vite preview --host 127.0.0.1",
    "test": "vitest run",
    "typecheck": "tsc --noEmit",
    "delivery": "node --experimental-strip-types scripts/delivery.ts",
    "typecheck:edge": "tsc -p tsconfig.edge.json"
  },
  "dependencies": {
    "@fontsource/inter": "5.2.5",
    "@hookform/resolvers": "3.10.0",
    "@supabase/supabase-js": "2.118.0",
    "@tanstack/react-query": "5.90.5",
    "@tanstack/react-table": "8.21.3",
    "@tanstack/react-virtual": "3.13.12",
    "date-fns": "4.1.0",
    "framer-motion": "11.18.2",
    "lucide-react": "0.468.0",
    "react": "18.3.1",
    "react-dom": "18.3.1",
    "react-hook-form": "7.62.0",
    "react-router-dom": "6.30.1",
    "recharts": "2.15.4",
    "sonner": "2.0.7",
    "zod": "3.25.76",
    "zustand": "5.0.3"
  },
  "devDependencies": {
    "@electric-sql/pglite": "0.5.13",
    "@types/node": "22.13.4",
    "@types/react": "18.3.18",
    "@types/react-dom": "18.3.5",
    "@vitejs/plugin-react": "4.3.4",
    "autoprefixer": "10.4.20",
    "postcss": "8.5.3",
    "prettier": "3.5.3",
    "tailwindcss": "3.4.17",
    "typescript": "5.7.3",
    "vite": "6.1.0",
    "vitest": "3.0.7"
  }
}

````

## postcss.config.ts

````ts
export default { plugins: { tailwindcss: {}, autoprefixer: {} } };

````

## public/favicon.svg

````svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="18" fill="#E9EDF3"/><path d="m12 26 20-12 20 12-20 11zM19 32v13q13 10 26 0V32M52 26v19" fill="none" stroke="#6480B8" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>

````

## scripts/check-bundle.ts

````ts
import { readFile } from "node:fs/promises";
import { gzipSync } from "node:zlib";
import { join } from "node:path";
type Chunk = {
  file: string;
  isEntry?: boolean;
  imports?: string[];
  dynamicImports?: string[];
};
const manifest = JSON.parse(
  await readFile("dist/.vite/manifest.json", "utf8"),
) as Record<string, Chunk>;
const entry = Object.entries(manifest).find(([, chunk]) => chunk.isEntry)?.[0];
if (!entry) throw new Error("No build entry found.");
const dependencies = new Set<string>();
function collect(key: string) {
  if (dependencies.has(key)) return;
  dependencies.add(key);
  manifest[key]?.imports?.forEach(collect);
}
collect(entry);
// Count entry dependencies plus the initial login route and mock auth adapter.
for (const key of Object.keys(manifest))
  if (key.endsWith("/Login.tsx") || key.endsWith("/adapter.ts")) collect(key);
let total = 0;
for (const key of dependencies) {
  const file = manifest[key]?.file;
  if (file?.endsWith(".js"))
    total += gzipSync(await readFile(join("dist", file))).byteLength;
}
const kib = total / 1024;
console.log(
  `Initial login + mock auth JavaScript: ${kib.toFixed(1)} KiB gzip (budget: <200 KiB).`,
);
if (kib >= 200)
  throw new Error("Initial JavaScript exceeds the requested size budget.");

````

## scripts/delivery.ts

````ts
import { readdir, readFile, writeFile, mkdir } from "node:fs/promises";
import { join, relative } from "node:path";
const root = process.cwd();
const files: string[] = [];
async function walk(directory: string): Promise<void> {
  for (const item of await readdir(directory, { withFileTypes: true })) {
    if (
      ["node_modules", ".git", ".npm-cache", "dist", "docs"].includes(item.name)
    )
      continue;
    const path = join(directory, item.name);
    if (item.isDirectory()) await walk(path);
    else if (
      !item.name.endsWith(".tsbuildinfo") &&
      item.name !== "package-lock.json" &&
      (!item.name.startsWith(".env") || item.name === ".env.example")
    )
      files.push(path);
  }
}
await walk(root);
files.push(join(root, "docs", "PHASE_1_VERIFICATION.md"));
files.push(join(root, "docs", "PHASE_2_VERIFICATION.md"));
const phase = process.argv[2] === "1" ? "1" : "2";
const fence = "````";
const output: string[] = [
  `# Phase ${phase} complete source`,
  "",
  "All authored files are included below. Install reproducible dependencies from package-lock.json in the project folder.",
  "",
];
for (const file of files.sort()) {
  const name = relative(root, file).replaceAll("\\", "/");
  const extension = name.split(".").at(-1) ?? "";
  const language =
    extension === "tsx"
      ? "tsx"
      : ["ts", "css", "sql", "json", "html", "svg", "md"].includes(extension)
        ? extension
        : "text";
  output.push(
    `## ${name}`,
    "",
    `${fence}${language}`,
    await readFile(file, "utf8"),
    fence,
    "",
  );
}
await mkdir(join(root, "docs"), { recursive: true });
await writeFile(
  join(root, "docs", `PHASE_${phase}_SOURCE.md`),
  output.join("\n"),
);
console.log(
  `Wrote complete contents of ${files.length} files to docs/PHASE_${phase}_SOURCE.md`,
);

````

## src/app/AuthProvider.tsx

````tsx
import { useEffect, useState, type ReactNode } from "react";
import { useAuth } from "../store/auth";
import { getRepository } from "../services";
import { ErrorState, NeuButton } from "../components/ui/primitives";
import { NeuModal } from "../components/ui/overlays";
export function AuthProvider({ children }: { children: ReactNode }) {
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  const expired = useAuth((s) => s.expired);
  useEffect(() => {
    let active = true;
    let unsubscribe: (() => void) | undefined;
    let revision = 0;
    setError("");
    void getRepository()
      .then(async (repository) => {
        if (!active) return;
        unsubscribe = repository.auth.onChange((profile) => {
          revision++;
          if (!active) return;
          const previous = useAuth.getState().profile;
          if (previous && !profile) useAuth.getState().setExpired(true);
          useAuth.getState().setProfile(profile);
        });
        const initialRevision = revision;
        const profile = await repository.auth.getProfile();
        if (active && initialRevision === revision)
          useAuth.getState().setProfile(profile);
      })
      .catch((reason) => {
        if (active)
          setError(
            reason instanceof Error
              ? reason.message
              : "Unable to restore your session.",
          );
      });
    return () => {
      active = false;
      unsubscribe?.();
    };
  }, [attempt]);
  if (error)
    return (
      <main className="full-screen">
        <ErrorState
          title="We couldn’t start your workspace"
          description={error}
          onRetry={() => setAttempt((n) => n + 1)}
        />
      </main>
    );
  return (
    <>
      {children}
      <NeuModal
        open={expired}
        onClose={() => useAuth.getState().setExpired(false)}
        title="Your session has ended"
        description="Sign in again to securely return to your workspace."
      >
        <NeuButton
          variant="primary"
          onClick={() => {
            useAuth.getState().setExpired(false);
            window.location.assign("/login");
          }}
        >
          Back to sign in
        </NeuButton>
      </NeuModal>
    </>
  );
}

````

## src/app/ErrorBoundary.tsx

````tsx
import { Component, type ErrorInfo, type ReactNode } from "react";
import { ErrorState } from "../components/ui/primitives";
export class ErrorBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error(
      "Workspace rendering failed",
      error.message,
      info.componentStack,
    );
  }
  render() {
    return this.state.failed ? (
      <ErrorState
        title="This view needs a fresh start"
        description="Your saved preferences are safe. Reload to try again."
        onRetry={() => window.location.reload()}
      />
    ) : (
      this.props.children
    );
  }
}

````

## src/app/router.tsx

````tsx
import { lazy, Suspense } from "react";
import {
  createBrowserRouter,
  Navigate,
  Outlet,
  useLocation,
} from "react-router-dom";
import { useAuth } from "../store/auth";
import { hasPermission, homeFor, type Permission } from "../lib/permissions";
import { Skeleton } from "../components/ui/primitives";
import { ErrorBoundary } from "./ErrorBoundary";
import type { Role } from "../types/domain";
const Login = lazy(() => import("../features/auth/Login"));
const ResetPassword = lazy(() => import("../features/auth/ResetPassword"));
const Shell = lazy(() => import("../components/layout/AppShell"));
const Overview = lazy(() => import("../features/workspace/Overview"));
const Directory = lazy(() => import("../features/workspace/Directory"));
const Components = lazy(() => import("../features/system/ComponentLibrary"));
const Preferences = lazy(() => import("../features/system/Preferences"));
const StatusPage = lazy(() => import("../features/workspace/StatusPage"));
const Dashboard = lazy(() => import("../features/owner/Dashboard"));
const Records = lazy(() => import("../features/owner/Records"));
const Permissions = lazy(() => import("../features/owner/Permissions"));
const Settings = lazy(() => import("../features/owner/Settings"));
const Audit = lazy(() => import("../features/owner/Audit"));
const ViewAs = lazy(() => import("../features/owner/ViewAs"));
const Revenue = lazy(() => import("../features/master/Revenue"));
export function RouteLoading() {
  return (
    <div className="route-loading">
      <Skeleton className="title-skeleton" />
      <Skeleton className="hero-skeleton" />
      <div className="loading-grid">
        {[1, 2, 3].map((n) => (
          <Skeleton key={n} className="card-skeleton" />
        ))}
      </div>
    </div>
  );
}
function Root() {
  return (
    <ErrorBoundary>
      <Suspense fallback={<RouteLoading />}>
        <Outlet />
      </Suspense>
    </ErrorBoundary>
  );
}
function RoleGate({
  role,
  permission,
}: {
  role: Role;
  permission: Permission;
}) {
  const { profile, initialized } = useAuth();
  const location = useLocation();
  if (!initialized) return <RouteLoading />;
  if (!profile)
    return (
      <Navigate
        to={role === "master" ? "/sys-master" : "/login"}
        state={{ from: location.pathname }}
        replace
      />
    );
  if (profile.role !== role || !hasPermission(profile.role, permission))
    return <StatusPage status="403" />;
  return <Shell />;
}
function HomeRedirect() {
  const { profile, initialized } = useAuth();
  return initialized ? (
    <Navigate to={profile ? homeFor(profile.role) : "/login"} replace />
  ) : (
    <RouteLoading />
  );
}
const roleRoutes = (
  [
    "owner",
    "principal",
    "teacher",
    "parent",
    "student",
    "accountant",
    "master",
  ] as const
).map((role) => ({
  path: role === "master" ? "/sys-master/workspace" : `/${role}`,
  element: (
    <RoleGate
      role={role}
      permission={role === "master" ? "master.manage" : "workspace.read"}
    />
  ),
  children: [
    {
      index: true,
      element:
        role === "owner" || role === "master" ? (
          <Dashboard master={role === "master"} />
        ) : (
          <Overview />
        ),
    },
    ...(role === "owner"
      ? [
          { path: "people", element: <Records resource="users" /> },
          { path: "branches", element: <Records resource="branches" /> },
          { path: "finance", element: <Records resource="finance" /> },
          { path: "roles", element: <Permissions /> },
          { path: "settings", element: <Settings /> },
          { path: "security", element: <Settings security /> },
          { path: "templates", element: <Records resource="templates" /> },
          { path: "audit", element: <Audit /> },
          { path: "view-as", element: <ViewAs /> },
        ]
      : role === "master"
        ? [
            { path: "schools", element: <Records resource="schools" /> },
            { path: "revenue", element: <Revenue /> },
            { path: "roles", element: <Permissions master /> },
            { path: "audit", element: <Audit /> },
          ]
        : []),
    { path: "directory", element: <Directory /> },
    { path: "components", element: <Components /> },
    { path: "preferences", element: <Preferences /> },
    { path: "*", element: <StatusPage status="404" /> },
  ],
}));
// The master URL is intentionally absent from navigation. Its real boundary is trusted claims + database RLS.
export const router = createBrowserRouter([
  {
    element: <Root />,
    children: [
      { path: "/", element: <HomeRedirect /> },
      { path: "/login", element: <Login /> },
      { path: "/sys-master", element: <Login master /> },
      { path: "/reset-password", element: <ResetPassword /> },
      { path: "/401", element: <StatusPage status="401" /> },
      { path: "/403", element: <StatusPage status="403" /> },
      ...roleRoutes,
      { path: "*", element: <StatusPage status="404" /> },
    ],
  },
]);

````

## src/components/layout/AppShell.tsx

````tsx
import { useEffect, useState } from "react";
import {
  Link,
  NavLink,
  Outlet,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import {
  NeuAvatar,
  NeuBadge,
  NeuButton,
  NeuSelect,
  SearchBar,
  Skeleton,
  ThemeToggle,
  ErrorState,
} from "../ui/primitives";
import { NeuDrawer, NeuModal } from "../ui/overlays";
import { Icon } from "../ui/Icon";
import { useAuth } from "../../store/auth";
import { useUI } from "../../store/ui";
import { getRepository } from "../../services";
import { homeFor, roleLabels } from "../../lib/permissions";
import { useAccess } from "../../hooks/useAccess";
import { useAdminList } from "../../hooks/useAdmin";
import { useIdleSession } from "../../hooks/useIdleSession";
import { getNavigation, moduleReady } from "../../lib/adminNavigation";
import { queryClient, queryKeys } from "../../lib/query";
import { useDebounce } from "../../hooks/useDebounce";
import { config } from "../../lib/config";
import { ErrorBoundary } from "../../app/ErrorBoundary";
import { RouteLoading } from "../../app/router";
import { Suspense } from "react";
import type { Notification } from "../../types/domain";

export default function AppShell() {
  const profile = useAuth((s) => s.profile)!;
  const { branchId, setBranch, collapsed, toggleSidebar } = useUI();
  const location = useLocation();
  const navigate = useNavigate();
  const [moreOpen, setMoreOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search);
  const base = homeFor(profile.role);
  const schoolSettings = useAdminList(
    "settings",
    { schoolId: profile.schoolId },
    {},
    profile.role === "owner",
  );
  const branding = schoolSettings.data?.rows[0];
  useIdleSession(branding?.sessionMinutes ?? 60);
  const logo = useQuery({
    queryKey: ["school-logo", profile.id, branding?.logoPath],
    queryFn: async () =>
      (await getRepository()).storage.getUrl(branding!.logoPath),
    enabled: !!branding?.logoPath,
  });
  const branches = useQuery({
    queryKey: queryKeys.branches(profile.id),
    queryFn: async () => (await getRepository()).branches.list(),
  });
  const assigned = branches.data ?? [];
  const activeBranch =
    assigned.find((branch) => branch.id === branchId) ?? assigned[0];
  const activeId = activeBranch?.id ?? "";
  useEffect(() => {
    if (activeId && branchId !== activeId) setBranch(activeId);
  }, [activeId, branchId, setBranch]);
  const key = queryKeys.notifications(profile.id, activeId);
  const notifications = useQuery({
    queryKey: key,
    queryFn: async () => (await getRepository()).notifications.list(activeId),
    enabled: !!activeId,
  });
  useEffect(() => {
    if (!activeId) return;
    let active = true;
    let cleanup: (() => void) | undefined;
    void getRepository()
      .then((repository) => {
        if (active)
          cleanup = repository.notifications.subscribe(activeId, () => {
            void queryClient.invalidateQueries({
              queryKey: queryKeys.notifications(profile.id, activeId),
            });
          });
      })
      .catch(() => undefined);
    return () => {
      active = false;
      cleanup?.();
    };
  }, [activeId, profile.id]);
  const markRead = useMutation({
    mutationFn: async (id: string) =>
      (await getRepository()).notifications.markRead(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: key });
      const previous = queryClient.getQueryData<Notification[]>(key);
      queryClient.setQueryData<Notification[]>(key, (old) =>
        old?.map((n) => (n.id === id ? { ...n, read: true } : n)),
      );
      return { previous, key };
    },
    onError: (_error, _id, context) => {
      if (context) queryClient.setQueryData(context.key, context.previous);
      toast.error("Could not update this notification. Please try again.");
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: key }),
  });
  const unread = notifications.data?.filter((item) => !item.read).length ?? 0;
  const showHighlights = useUI((s) => s.inAppUpdates);
  const access = useAccess();
  const availableNav = getNavigation(profile.role).filter((item) =>
    access.can(item.permission),
  );
  const activeLabel =
    availableNav.find((item) =>
      item.path
        ? location.pathname === `${base}${item.path}`
        : location.pathname === base,
    )?.label ?? "Workspace";
  const prefetch = (path: string) => {
    if (path === "/directory")
      void import("../../features/workspace/Directory");
    if (path === "/components")
      void import("../../features/system/ComponentLibrary");
    if (path === "/preferences")
      void import("../../features/system/Preferences");
  };
  const navContent = (
    <>
      {(["Workspace", "Management", "System"] as const).map((section) => (
        <div className="nav-section" key={section}>
          <div className="nav-section-label">{section}</div>
          {availableNav
            .filter((item) => item.section === section)
            .map((item) =>
              !moduleReady(profile.role, item.phase) ? (
                <div
                  className="nav-item unavailable"
                  key={item.label}
                  aria-disabled="true"
                  title={`Available in Phase ${item.phase}`}
                >
                  <Icon name={item.icon} />
                  <span>{item.label}</span>
                  <Icon name="lock" size={13} />
                </div>
              ) : (
                <NavLink
                  key={item.label}
                  aria-label={item.label}
                  title={item.label}
                  to={`${base}${item.path}`}
                  end={!item.path}
                  onClick={() => setMoreOpen(false)}
                  onMouseEnter={() => prefetch(item.path)}
                  onFocus={() => prefetch(item.path)}
                  className={({ isActive }) =>
                    `nav-item ${isActive ? "active" : ""}`
                  }
                >
                  <Icon name={item.icon} />
                  <span>{item.label}</span>
                  {item.label === "Overview" && (
                    <span className="nav-active-dot" />
                  )}
                </NavLink>
              ),
            )}
        </div>
      ))}
    </>
  );
  const signOut = async () => {
    try {
      const repository = await getRepository();
      await repository.auth.signOut();
      useAuth.getState().setExpired(false);
      useAuth.getState().setProfile(null);
      queryClient.clear();
      navigate(profile.role === "master" ? "/sys-master" : "/login", {
        replace: true,
      });
    } catch {
      toast.error("Sign out failed. Please try again.");
    }
  };
  return (
    <div className={`app-shell ${collapsed ? "sidebar-collapsed" : ""}`}>
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      <aside className="sidebar">
        <Link className="brand" to={base}>
          <span className="brand-mark">
            <Icon name="graduation" size={27} />
          </span>
          <span>
            campus<span className="brand-dot">.</span>
          </span>
        </Link>
        <div className="school-identity">
          <span className="school-monogram">
            {logo.data ? (
              <img
                src={logo.data}
                width="28"
                height="28"
                loading="lazy"
                alt="School logo"
              />
            ) : (
              "G"
            )}
          </span>
          <div>
            <b>
              {profile.role === "master"
                ? "Campus Platform"
                : (branding?.name ??
                  (config.mock ? "Greenwood School" : "Your school"))}
            </b>
            <small>School Management v3.0</small>
          </div>
          <Icon name="shield" size={16} />
        </div>
        <nav aria-label="Main navigation">{navContent}</nav>
        <div className="sidebar-bottom">
          <div className="help-card">
            <span className="icon-tile small">
              <Icon name="help" />
            </span>
            <b>A little help?</b>
            <p>
              Your school workspace,
              <br />
              made a little simpler.
            </p>
            <NeuButton variant="ghost" onClick={() => setHelpOpen(true)}>
              Help & getting started
              <Icon name="arrow-up-right" size={15} />
            </NeuButton>
          </div>
          <button
            className="sidebar-account"
            onClick={() => setProfileOpen(true)}
          >
            <NeuAvatar name={profile.name} size="sm" />
            <span>
              <b>{profile.name}</b>
              <small>{roleLabels[profile.role]}</small>
            </span>
            <Icon name="more" size={18} />
          </button>
        </div>
        <NeuButton
          className="sidebar-collapse"
          variant="icon"
          icon={collapsed ? "right" : "collapse"}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          onClick={toggleSidebar}
        />
      </aside>
      <div className="app-main">
        <header className="top-header">
          <div className="header-branch">
            <span className="icon-tile small">
              <Icon name="building" />
            </span>
            {profile.role === "master" ? (
              <b className="platform-label">Platform administration</b>
            ) : branches.isPending ? (
              <Skeleton className="branch-skeleton" />
            ) : branches.isError ? (
              <button
                className="text-button"
                onClick={() => void branches.refetch()}
              >
                Retry campuses
              </button>
            ) : assigned.length ? (
              <NeuSelect
                aria-label="Active campus"
                value={activeId}
                onChange={(event) => {
                  setBranch(event.target.value);
                  toast.success("Campus switched");
                }}
              >
                {assigned.map((branch) => (
                  <option key={branch.id} value={branch.id}>
                    {branch.short_name}
                  </option>
                ))}
              </NeuSelect>
            ) : (
              <span>No campus assigned</span>
            )}
            <NeuBadge>{config.mock ? "Demo" : "Live"}</NeuBadge>
          </div>
          <div className="header-actions">
            <button
              className="global-search-trigger"
              aria-label="Search your workspace"
              onClick={() => setSearchOpen(true)}
            >
              <Icon name="search" size={18} />
              <span>Search your workspace</span>
              <kbd>⌕</kbd>
            </button>
            <ThemeToggle />
            <div className="notification-trigger">
              <NeuButton
                variant="ghost"
                icon="bell"
                aria-label={`Notifications, ${unread} unread`}
                onClick={() => setNotificationOpen(true)}
              />
              {unread > 0 && showHighlights && <span />}
            </div>
            <span className="header-divider" />
            <button
              className="header-profile"
              aria-label="Open profile menu"
              onClick={() => setProfileOpen(true)}
            >
              <NeuAvatar name={profile.name} size="sm" />
              <Icon name="down" size={14} />
            </button>
          </div>
        </header>
        <main id="main-content" className="main-content" tabIndex={-1}>
          <div className="breadcrumb">
            <span>
              <Link to={base}>Workspace</Link>
              <Icon name="right" size={13} />
              {activeLabel}
            </span>
            <NeuBadge>
              <Icon name="shield" size={12} />
              {roleLabels[profile.role]}
            </NeuBadge>
          </div>
          {branches.isError && (
            <div className="inline-error" role="alert">
              Campus access could not be loaded.{" "}
              <button
                className="text-button"
                onClick={() => void branches.refetch()}
              >
                Try again
              </button>
            </div>
          )}
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.18 }}
            >
              <ErrorBoundary key={location.pathname}>
                <Suspense fallback={<RouteLoading />}>
                  <Outlet context={{ branches: assigned, activeBranch }} />
                </Suspense>
              </ErrorBoundary>
            </motion.div>
          </AnimatePresence>
          <footer className="workspace-footer">
            <span>
              Campus v3.0 <i /> Smart · Secure · Connected
            </span>
            <span>
              <span className="status-dot" />{" "}
              {config.mock ? "Demo workspace" : "Secure workspace"}
            </span>
          </footer>
        </main>
      </div>
      <nav className="bottom-nav" aria-label="Mobile navigation">
        {[
          { label: "Home", path: "", icon: "grid" },
          { label: "Directory", path: "/directory", icon: "layers" },
          { label: "Library", path: "/components", icon: "palette" },
          { label: "You", path: "/preferences", icon: "user" },
        ].map((item) => (
          <NavLink
            key={item.label}
            to={`${base}${item.path}`}
            end={!item.path}
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            <Icon name={item.icon as "grid" | "layers" | "palette" | "user"} />
            <span>{item.label}</span>
          </NavLink>
        ))}
        <button onClick={() => setMoreOpen(true)}>
          <Icon name="menu" />
          <span>More</span>
        </button>
      </nav>
      <NeuDrawer
        open={moreOpen}
        onClose={() => setMoreOpen(false)}
        title="Your workspace"
      >
        <nav className="drawer-nav" aria-label="More navigation">
          {navContent}
        </nav>
        <NeuButton
          icon="help"
          onClick={() => {
            setMoreOpen(false);
            setHelpOpen(true);
          }}
        >
          Help & getting started
        </NeuButton>
        <div className="mobile-account-actions">
          <NeuAvatar name={profile.name} />
          <div>
            <b>{profile.name}</b>
            <small>{roleLabels[profile.role]}</small>
          </div>
        </div>
        <NeuButton
          icon="logout"
          onClick={() => {
            setMoreOpen(false);
            void signOut();
          }}
        >
          Sign out securely
        </NeuButton>
      </NeuDrawer>
      <NeuDrawer
        open={notificationOpen}
        onClose={() => setNotificationOpen(false)}
        title="Notifications"
        description={`${unread} unread · ${activeBranch?.short_name ?? "Your campus"}`}
      >
        <div className="notification-list">
          {notifications.isPending ? (
            <Skeleton className="card-skeleton" />
          ) : notifications.isError ? (
            <ErrorState
              description="Could not load notifications."
              onRetry={() => void notifications.refetch()}
            />
          ) : notifications.data?.length ? (
            notifications.data.map((item) => (
              <article
                className={item.read ? "notification read" : "notification"}
                key={item.id}
              >
                <span className="icon-tile small">
                  <Icon name={item.read ? "check-all" : "bell"} />
                </span>
                <div>
                  <b>{item.title}</b>
                  <p>{item.body}</p>
                  <small>
                    {formatDistanceToNow(new Date(item.created_at), {
                      addSuffix: true,
                    })}
                  </small>
                  {!item.read && (
                    <button
                      className="text-button"
                      onClick={() => markRead.mutate(item.id)}
                    >
                      Mark as read
                    </button>
                  )}
                </div>
              </article>
            ))
          ) : (
            <p>You’re all caught up.</p>
          )}
        </div>
      </NeuDrawer>
      <NeuModal
        open={profileOpen}
        onClose={() => setProfileOpen(false)}
        title="Your account"
      >
        <div className="profile-summary">
          <NeuAvatar name={profile.name} size="lg" />
          <h3>{profile.name}</h3>
          <p>{profile.email}</p>
          <NeuBadge>{roleLabels[profile.role]}</NeuBadge>
        </div>
        <div className="profile-menu">
          <NeuButton
            icon="settings"
            onClick={() => {
              setProfileOpen(false);
              navigate(`${base}/preferences`);
            }}
          >
            My preferences
            <Icon name="right" size={16} />
          </NeuButton>
          <NeuButton icon="logout" onClick={() => void signOut()}>
            Sign out securely
          </NeuButton>
        </div>
      </NeuModal>
      <NeuModal
        open={searchOpen}
        onClose={() => {
          setSearchOpen(false);
          setSearch("");
        }}
        title="Find your way"
      >
        <SearchBar
          value={search}
          onChange={setSearch}
          placeholder="Search pages and tools…"
          label="Search workspace pages"
        />
        <div className="search-results">
          {availableNav
            .filter(
              (item) =>
                moduleReady(profile.role, item.phase) &&
                item.label
                  .toLowerCase()
                  .includes(debouncedSearch.toLowerCase()),
            )
            .map((item) => (
              <Link
                key={item.label}
                to={`${base}${item.path}`}
                onClick={() => {
                  setSearchOpen(false);
                  setSearch("");
                }}
              >
                <Icon name={item.icon} />
                <span>{item.label}</span>
                <Icon name="arrow-up-right" size={16} />
              </Link>
            ))}
          {!availableNav.some(
            (item) =>
              moduleReady(profile.role, item.phase) &&
              item.label.toLowerCase().includes(debouncedSearch.toLowerCase()),
          ) && <p>No pages found. Try “Overview” or “Preferences”.</p>}
        </div>
      </NeuModal>
      <NeuModal
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        title="Make yourself at home"
        description="A quick guide to your school workspace."
      >
        <ol className="help-steps">
          <li>
            <b>Choose your campus</b>
            <p>
              Use the campus selector at the top. You’ll see only campuses
              assigned to your account.
            </p>
          </li>
          <li>
            <b>Find your tools</b>
            <p>
              The workspace directory explains which modules your role can
              access and their delivery phase.
            </p>
          </li>
          <li>
            <b>Make it yours</b>
            <p>
              Choose your theme and local notification preferences in My
              preferences.
            </p>
          </li>
        </ol>
        <p className="muted">
          For account changes, contact your school administrator.
        </p>
      </NeuModal>
    </div>
  );
}

````

## src/components/layout/CampusIllustration.tsx

````tsx
import { Icon } from "../ui/Icon";
export function CampusIllustration({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={`campus-illustration ${compact ? "compact" : ""}`}
      aria-hidden="true"
    >
      <div className="orbit orbit-one" />
      <div className="orbit orbit-two" />
      <div className="floating-tile tile-book">
        <Icon name="book" size={30} />
      </div>
      <div className="floating-tile tile-community">
        <Icon name="users" size={26} />
      </div>
      <div className="floating-tile tile-message">
        <Icon name="message" size={24} />
        <span className="online-dot" />
      </div>
      <div className="campus-platform">
        <div className="campus-building">
          <div className="building-roof">
            <Icon name="graduation" size={42} />
          </div>
          <div className="building-clock">
            <span />
          </div>
          <div className="building-label">CAMPUS</div>
          <div className="building-windows">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <i key={n} />
            ))}
          </div>
          <div className="building-door" />
        </div>
        <div className="campus-tree tree-left">
          <i />
          <span />
        </div>
        <div className="campus-tree tree-right">
          <i />
          <span />
        </div>
        <div className="campus-path" />
      </div>
      <div className="illustration-caption">
        <span className="status-dot" /> Everyone belongs here.
      </div>
    </div>
  );
}

````

## src/components/ui/FileUpload.tsx

````tsx
import { useRef, useState } from "react";
import { Icon } from "./Icon";
import { NeuButton } from "./primitives";
export function FileUpload({
  onUpload,
  accept = ".pdf,.csv,.png,.jpg,.jpeg",
  maxMB = 5,
  disabled = false,
}: {
  onUpload: (file: File) => Promise<void>;
  accept?: string;
  maxMB?: number;
  disabled?: boolean;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [dragging, setDragging] = useState(false);
  const upload = async (file?: File) => {
    if (!file || busy || disabled) return;
    if (file.size > maxMB * 1024 * 1024) {
      setMessage(`Choose a file smaller than ${maxMB} MB.`);
      return;
    }
    const accepted = accept
      .split(",")
      .some((type) =>
        type.trim().startsWith(".")
          ? file.name.toLowerCase().endsWith(type.trim().toLowerCase())
          : type.trim().endsWith("/*")
            ? file.type.startsWith(type.trim().slice(0, -1))
            : file.type === type.trim(),
      );
    if (!accepted) {
      setMessage("This file type is not supported.");
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      await onUpload(file);
      setMessage(`${file.name} uploaded successfully.`);
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Upload failed. Please try again.",
      );
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  };
  return (
    <div
      className={`file-upload ${dragging ? "dragging" : ""}`}
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        void upload(e.dataTransfer.files[0]);
      }}
    >
      <Icon name="upload" size={28} />
      <b>Drop a file here, or browse</b>
      <small>
        {accept.replaceAll(".", "").toUpperCase()} · up to {maxMB} MB
      </small>
      <input
        ref={input}
        type="file"
        accept={accept}
        onChange={(e) => void upload(e.target.files?.[0])}
        className="sr-only"
        tabIndex={-1}
        aria-hidden="true"
      />
      <NeuButton
        icon="plus"
        loading={busy}
        disabled={disabled}
        onClick={() => input.current?.click()}
      >
        Choose file
      </NeuButton>
      <span role="status">{message}</span>
    </div>
  );
}

````

## src/components/ui/Icon.tsx

````tsx
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bell,
  BookOpen,
  Building2,
  CalendarDays,
  CalendarCheck,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  CircleHelp,
  Clock3,
  Copy,
  CreditCard,
  Download,
  Ellipsis,
  Eye,
  EyeOff,
  FileText,
  GraduationCap,
  Heart,
  Home,
  LayoutDashboard,
  Layers,
  Loader2,
  LockKeyhole,
  LogOut,
  Mail,
  Menu,
  MessageCircle,
  Monitor,
  Moon,
  Palette,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Sun,
  Upload,
  Users,
  UserRound,
  Wallet,
  X,
  XCircle,
} from "lucide-react";
import type { CSSProperties } from "react";
const icons = {
  "arrow-down": ArrowDown,
  "arrow-left": ArrowLeft,
  "arrow-right": ArrowRight,
  "arrow-up-right": ArrowUpRight,
  bell: Bell,
  book: BookOpen,
  building: Building2,
  calendar: CalendarDays,
  "calendar-check": CalendarCheck,
  check: Check,
  "check-all": CheckCheck,
  down: ChevronDown,
  left: ChevronLeft,
  right: ChevronRight,
  collapse: ChevronsLeft,
  help: CircleHelp,
  clock: Clock3,
  copy: Copy,
  credit: CreditCard,
  download: Download,
  more: Ellipsis,
  eye: Eye,
  "eye-off": EyeOff,
  file: FileText,
  graduation: GraduationCap,
  heart: Heart,
  home: Home,
  grid: LayoutDashboard,
  layers: Layers,
  loading: Loader2,
  lock: LockKeyhole,
  logout: LogOut,
  mail: Mail,
  menu: Menu,
  message: MessageCircle,
  monitor: Monitor,
  moon: Moon,
  palette: Palette,
  plus: Plus,
  search: Search,
  settings: Settings2,
  shield: ShieldCheck,
  sparkles: Sparkles,
  sun: Sun,
  upload: Upload,
  users: Users,
  user: UserRound,
  wallet: Wallet,
  close: X,
  error: XCircle,
};
export type IconName = keyof typeof icons;
export function Icon({
  name,
  size = 20,
  className = "",
  style,
}: {
  name: IconName;
  size?: number;
  className?: string;
  style?: CSSProperties;
}) {
  const Component = icons[name];
  return (
    <Component
      size={size}
      stroke="url(#icon-gradient)"
      strokeWidth={1.8}
      className={`icon ${className}`}
      style={style}
      aria-hidden="true"
    />
  );
}
export function IconGradients() {
  return (
    <svg width="0" height="0" aria-hidden="true" className="gradient-defs">
      <defs>
        <linearGradient id="icon-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4DB8FF" />
          <stop offset="100%" stopColor="#A99BD6" />
        </linearGradient>
      </defs>
    </svg>
  );
}

````

## src/components/ui/NeuTable.tsx

````tsx
import {
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table";
import { useVirtualizer } from "@tanstack/react-virtual";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { EmptyState } from "./primitives";
type TableProps<T> = {
  data: T[];
  columns: ColumnDef<T, unknown>[];
  label: string;
  rowKey: (row: T) => string;
  renderMobile: (row: T) => ReactNode;
};
export function NeuTable<T>({
  data,
  columns,
  label,
  rowKey,
  renderMobile,
}: TableProps<T>) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const parent = useRef<HTMLDivElement>(null);
  const [mobile, setMobile] = useState(
    () => matchMedia("(max-width: 639px)").matches,
  );
  useEffect(() => {
    const media = matchMedia("(max-width: 639px)");
    const update = () => setMobile(media.matches);
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  const table = useReactTable({
    data,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getRowId: rowKey,
  });
  const rows = table.getRowModel().rows;
  const virtual = useVirtualizer({
    count: rows.length,
    getScrollElement: () => parent.current,
    estimateSize: () => (mobile ? 73 : 64),
    overscan: 6,
    enabled: rows.length > 100,
  });
  useEffect(() => {
    virtual.measure();
  }, [mobile, virtual]);
  if (!data.length)
    return (
      <EmptyState
        title="No records found"
        description="Try adjusting your search or filters."
      />
    );
  const displayed =
    rows.length > 100
      ? virtual.getVirtualItems().flatMap((item) => {
          const row = rows[item.index];
          return row ? [{ row, item }] : [];
        })
      : rows.map((row) => ({ row, item: undefined }));
  // Both mobile cards and desktop rows share one bounded virtual scroller.
  return (
    <div
      ref={parent}
      className="table-scroll"
      style={rows.length > 100 ? { height: 480, overflowY: "auto" } : undefined}
    >
      <div className="mobile-table" aria-label={label}>
        {displayed.length > 0 && rows.length > 100 && (
          <div style={{ height: displayed[0]?.item?.start ?? 0 }} />
        )}
        {displayed.map(({ row }) => (
          <article key={row.id}>{renderMobile(row.original)}</article>
        ))}
        {rows.length > 100 && (
          <div
            style={{
              height:
                virtual.getTotalSize() - (displayed.at(-1)?.item?.end ?? 0),
            }}
          />
        )}
      </div>
      <table className="neu-table" aria-label={label}>
        <thead>
          {table.getHeaderGroups().map((group) => (
            <tr key={group.id}>
              {group.headers.map((header) => (
                <th
                  key={header.id}
                  aria-sort={
                    header.column.getIsSorted() === "asc"
                      ? "ascending"
                      : header.column.getIsSorted() === "desc"
                        ? "descending"
                        : undefined
                  }
                >
                  {header.column.getCanSort() ? (
                    <button onClick={header.column.getToggleSortingHandler()}>
                      {flexRender(
                        header.column.columnDef.header,
                        header.getContext(),
                      )}
                      <span aria-hidden="true">↕</span>
                    </button>
                  ) : (
                    flexRender(
                      header.column.columnDef.header,
                      header.getContext(),
                    )
                  )}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {rows.length > 100 && (
            <tr aria-hidden="true">
              <td
                colSpan={columns.length}
                style={{ height: displayed[0]?.item?.start ?? 0, padding: 0 }}
              />
            </tr>
          )}
          {displayed.map(({ row, item }) => (
            <tr key={row.id} style={item ? { height: item.size } : undefined}>
              {row.getVisibleCells().map((cell) => (
                <td key={cell.id}>
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
          {rows.length > 100 && (
            <tr aria-hidden="true">
              <td
                colSpan={columns.length}
                style={{
                  height:
                    virtual.getTotalSize() - (displayed.at(-1)?.item?.end ?? 0),
                  padding: 0,
                }}
              />
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

````

## src/components/ui/index.ts

````ts
export * from "./primitives";
export * from "./overlays";
export * from "./Icon";
export * from "./FileUpload";
export * from "./NeuTable";

````

## src/components/ui/overlays.tsx

````tsx
import { createPortal } from "react-dom";
import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { NeuButton, NeuInput } from "./primitives";

type OverlayProps = {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
};
function Overlay({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  drawer = false,
}: OverlayProps & { drawer?: boolean }) {
  const titleId = useId();
  const descriptionId = useId();
  const panel = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const root = document.getElementById("root");
    root?.setAttribute("inert", "");
    const timer = setTimeout(() => panel.current?.focus(), 0);
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeRef.current();
      if (event.key !== "Tab") return;
      const nodes = panel.current?.querySelectorAll<HTMLElement>(
        'button:not(:disabled), [href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex="0"]',
      );
      const first = nodes?.[0];
      const last = nodes?.[nodes.length - 1];
      if (!first || !last) {
        event.preventDefault();
        return;
      }
      if (
        event.shiftKey &&
        (document.activeElement === first ||
          document.activeElement === panel.current)
      ) {
        event.preventDefault();
        last.focus();
      } else if (
        !event.shiftKey &&
        (document.activeElement === last ||
          document.activeElement === panel.current)
      ) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", keydown);
    return () => {
      clearTimeout(timer);
      document.body.style.overflow = oldOverflow;
      root?.removeAttribute("inert");
      document.removeEventListener("keydown", keydown);
      previous?.focus();
    };
  }, [open]);
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className={`overlay ${drawer ? "drawer-overlay" : ""}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
        >
          <motion.div
            ref={panel}
            className={`overlay-panel ${drawer ? "drawer-panel" : ""}`}
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            aria-describedby={description ? descriptionId : undefined}
            tabIndex={-1}
            initial={drawer ? { x: 40 } : { y: 18, scale: 0.98 }}
            animate={{ x: 0, y: 0, scale: 1 }}
            exit={drawer ? { x: 40 } : { y: 18, scale: 0.98 }}
            transition={{ duration: 0.2 }}
          >
            <div className="overlay-header">
              <div>
                <h2 id={titleId}>{title}</h2>
                {description && <p id={descriptionId}>{description}</p>}
              </div>
              <NeuButton
                variant="ghost"
                icon="close"
                aria-label="Close dialog"
                onClick={onClose}
              />
            </div>
            <div className="overlay-content">{children}</div>
            {footer && <div className="overlay-footer">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
export function NeuModal(props: OverlayProps) {
  return <Overlay {...props} />;
}
export function NeuDrawer(props: OverlayProps) {
  return <Overlay {...props} drawer />;
}
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  description,
  confirmText,
  loading,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmText?: string;
  loading?: boolean;
}) {
  const [text, setText] = useState("");
  useEffect(() => {
    if (open) setText("");
  }, [open]);
  return (
    <NeuModal
      open={open}
      onClose={loading ? () => undefined : onClose}
      title={title}
      description={description}
      footer={
        <>
          <NeuButton onClick={onClose} disabled={loading}>
            Cancel
          </NeuButton>
          <NeuButton
            className="danger"
            onClick={onConfirm}
            loading={loading}
            disabled={!!confirmText && text !== confirmText}
          >
            Confirm
          </NeuButton>
        </>
      }
    >
      {confirmText && (
        <NeuInput
          id="confirm-action"
          label={`Type “${confirmText}” to confirm`}
          autoComplete="off"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      )}
    </NeuModal>
  );
}

````

## src/components/ui/primitives.tsx

````tsx
import {
  forwardRef,
  useEffect,
  useId,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
} from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Icon, type IconName } from "./Icon";
import { useUI } from "../../store/ui";
import { useTheme } from "../../hooks/useTheme";

export const NeuButton = forwardRef<
  HTMLButtonElement,
  ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: "primary" | "secondary" | "icon" | "ghost";
    loading?: boolean;
    icon?: IconName;
  }
>(function NeuButton(
  {
    variant = "secondary",
    loading,
    icon,
    children,
    className = "",
    disabled,
    ...props
  },
  ref,
) {
  return (
    <button
      ref={ref}
      className={`neu-button ${variant} ${className}`}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...props}
    >
      {loading ? (
        <Icon name="loading" className="spin" />
      ) : icon ? (
        <Icon name={icon} />
      ) : null}
      {children}
    </button>
  );
});
export function NeuCard({
  children,
  className = "",
  ...props
}: HTMLAttributes<HTMLElement>) {
  return (
    <section className={`neu-card ${className}`} {...props}>
      {children}
    </section>
  );
}
export const NeuInput = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & {
    label?: string;
    error?: string;
    hint?: string;
    icon?: IconName;
  }
>(function NeuInput(
  { label, error, hint, icon, id, className = "", ...props },
  ref,
) {
  const inputId = id ?? props.name;
  return (
    <div className={`field ${className}`}>
      {label && <label htmlFor={inputId}>{label}</label>}
      <div className="input-wrap">
        {icon && <Icon name={icon} />}
        <input
          ref={ref}
          id={inputId}
          aria-invalid={!!error}
          aria-describedby={error || hint ? `${inputId}-help` : undefined}
          {...props}
        />
      </div>
      {(error || hint) && (
        <span
          className={error ? "field-error" : "field-hint"}
          id={`${inputId}-help`}
        >
          {error || hint}
        </span>
      )}
    </div>
  );
});
export const NeuSelect = forwardRef<
  HTMLSelectElement,
  SelectHTMLAttributes<HTMLSelectElement> & { label?: string }
>(function NeuSelect({ label, id, children, className = "", ...props }, ref) {
  return (
    <div className={`field ${className}`}>
      {label && <label htmlFor={id}>{label}</label>}
      <div className="select-wrap">
        <select ref={ref} id={id} {...props}>
          {children}
        </select>
        <Icon name="down" size={16} />
      </div>
    </div>
  );
});
export function NeuToggle({
  checked,
  onChange,
  label,
  description,
  disabled,
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  description?: string;
  disabled?: boolean;
}) {
  return (
    <label className={`toggle-row ${disabled ? "disabled" : ""}`}>
      <span>
        <span className="control-label">{label}</span>
        {description && <small>{description}</small>}
      </span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        className={`toggle ${checked ? "on" : ""}`}
        onClick={() => onChange(!checked)}
      >
        <motion.span layout transition={{ duration: 0.18 }} />
      </button>
    </label>
  );
}
export const NeuCheckbox = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & { label: string }
>(function NeuCheckbox({ label, ...props }, ref) {
  return (
    <label className="choice">
      <input ref={ref} type="checkbox" {...props} />
      <span>{label}</span>
    </label>
  );
});
export const NeuRadio = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & { label: string }
>(function NeuRadio({ label, ...props }, ref) {
  return (
    <label className="choice">
      <input ref={ref} type="radio" {...props} />
      <span>{label}</span>
    </label>
  );
});
export function NeuTabs<T extends string>({
  tabs,
  value,
  onChange,
  label = "View",
}: {
  tabs: readonly { value: T; label: string }[];
  value: T;
  onChange: (value: T) => void;
  label?: string;
}) {
  const id = useId();
  return (
    <div className="neu-tabs" role="group" aria-label={label}>
      {tabs.map((tab) => (
        <button
          type="button"
          key={tab.value}
          aria-pressed={value === tab.value}
          className={value === tab.value ? "active" : ""}
          onClick={() => onChange(tab.value)}
        >
          {value === tab.value && (
            <motion.span
              className="tab-indicator"
              layoutId={`tab-${id}`}
              transition={{ duration: 0.18 }}
            />
          )}
          <span>{tab.label}</span>
        </button>
      ))}
    </div>
  );
}
export function NeuBadge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "success" | "accent" | "warning";
}) {
  return <span className={`badge ${tone}`}>{children}</span>;
}
export function NeuAvatar({
  name,
  size = "md",
}: {
  name: string;
  size?: "sm" | "md" | "lg";
}) {
  return (
    <span className={`avatar ${size}`} aria-label={name}>
      {name
        .split(" ")
        .map((n) => n[0])
        .slice(0, 2)
        .join("")}
    </span>
  );
}
export function NeuProgress({
  value,
  label,
  showValue = true,
}: {
  value: number;
  label: string;
  showValue?: boolean;
}) {
  const safe = Math.min(100, Math.max(0, value));
  return (
    <div className="progress-block">
      <div className="progress-label">
        <span>{label}</span>
        {showValue && <b>{safe}%</b>}
      </div>
      <div
        className="progress-track"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={safe}
        aria-label={label}
      >
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: safe / 100 }}
          transition={{ duration: 0.3 }}
        />
      </div>
    </div>
  );
}
export function StatCard({
  label,
  value,
  suffix = "",
  icon,
  detail,
}: {
  label: string;
  value: number;
  suffix?: string;
  icon: IconName;
  detail?: string;
}) {
  const reduced = useReducedMotion();
  const [count, setCount] = useState(value);
  const previous = useRef(value);
  useEffect(() => {
    if (reduced) {
      setCount(value);
      return;
    }
    const start = performance.now();
    const from = previous.current;
    let frame = 0;
    const tick = (time: number) => {
      const progress = Math.min((time - start) / 350, 1);
      setCount(Math.round(from + (value - from) * progress));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    previous.current = value;
    return () => cancelAnimationFrame(frame);
  }, [value, reduced]);
  return (
    <NeuCard className="stat-card">
      <div className="stat-top">
        <span>{label}</span>
        <span className="icon-tile small">
          <Icon name={icon} />
        </span>
      </div>
      <strong>
        {count.toLocaleString()}
        {suffix}
      </strong>
      {detail && <small>{detail}</small>}
    </NeuCard>
  );
}
export function SearchBar({
  value,
  onChange,
  placeholder = "Search…",
  label = "Search",
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
}) {
  return (
    <div className="search-bar">
      <Icon name="search" size={18} />
      <input
        aria-label={label}
        placeholder={placeholder}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        type="search"
      />
      {value && (
        <NeuButton
          variant="ghost"
          aria-label="Clear search"
          onClick={() => onChange("")}
          icon="close"
        />
      )}
    </div>
  );
}
export function DatePicker({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <NeuInput
      type="date"
      id={label.replaceAll(" ", "-")}
      label={label}
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}
export function Skeleton({
  className = "",
  label = "Loading",
}: {
  className?: string;
  label?: string;
}) {
  return (
    <div className={`skeleton ${className}`} role="status" aria-label={label}>
      <span className="sr-only">{label}</span>
    </div>
  );
}
export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <span className="icon-tile">
        <Icon name="layers" size={28} />
      </span>
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  );
}
export function ErrorState({
  title = "We couldn’t load this view",
  description = "Please try again in a moment.",
  onRetry,
}: {
  title?: string;
  description?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="empty-state" role="alert">
      <Icon name="error" size={32} />
      <h3>{title}</h3>
      <p>{description}</p>
      {onRetry && <NeuButton onClick={onRetry}>Try again</NeuButton>}
    </div>
  );
}
export function ThemeToggle() {
  const theme = useTheme();
  const setTheme = useUI((s) => s.setTheme);
  return (
    <NeuButton
      variant="icon"
      icon={theme === "dark" ? "sun" : "moon"}
      title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
    />
  );
}

````

## src/features/auth/Login.tsx

````tsx
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCheckbox,
  NeuInput,
  ThemeToggle,
  NeuBadge,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { Icon } from "../../components/ui/Icon";
import { getRepository } from "../../services";
import { useAuth } from "../../store/auth";
import { config } from "../../lib/config";
import { homeFor, roleLabels } from "../../lib/permissions";
import type { Role } from "../../types/domain";
import { queryClient } from "../../lib/query";
import { CampusIllustration } from "../../components/layout/CampusIllustration";
const schema = z.object({
  identifier: z.string().trim().min(1, "Enter your school email or code."),
  password: z.string().min(1, "Enter your password."),
  remember: z.boolean(),
});
type Form = z.infer<typeof schema>;
export default function Login({ master = false }: { master?: boolean }) {
  const [visible, setVisible] = useState(false);
  const [error, setError] = useState("");
  const [reset, setReset] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [sending, setSending] = useState(false);
  const [demoRole, setDemoRole] = useState<Role>(master ? "master" : "owner");
  const profile = useAuth((s) => s.profile);
  const navigate = useNavigate();
  const location = useLocation();
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { identifier: "", password: "", remember: true },
  });
  if (
    profile &&
    (master ? profile.role === "master" : profile.role !== "master")
  )
    return <Navigate to={homeFor(profile.role)} replace />;
  const submit = handleSubmit(async (values) => {
    setError("");
    try {
      const repository = await getRepository();
      const signedIn = await repository.auth.signIn({ ...values, master });
      queryClient.clear();
      useAuth.getState().setProfile(signedIn);
      const from = (location.state as { from?: unknown } | null)?.from;
      const home = homeFor(signedIn.role);
      navigate(
        typeof from === "string" &&
          (from === home || from.startsWith(`${home}/`))
          ? from
          : home,
        { replace: true },
      );
    } catch (reason) {
      setError(
        reason instanceof Error
          ? reason.message
          : "Unable to sign in. Please try again.",
      );
    }
  });
  const fillDemo = () => {
    setValue("identifier", `${demoRole}@greenwood.edu`, {
      shouldValidate: true,
    });
    setValue("password", "Campus@2026", { shouldValidate: true });
    setError("");
  };
  const sendReset = async () => {
    const result = z.string().email().safeParse(resetEmail);
    if (!result.success) {
      toast.error("Enter a valid school email address.");
      return;
    }
    setSending(true);
    try {
      await (await getRepository()).auth.resetPassword(result.data);
      toast.success("If this email is registered, a reset link is on its way.");
      setReset(false);
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Unable to send reset email.",
      );
    } finally {
      setSending(false);
    }
  };
  return (
    <main className="login-page">
      <div className="login-top">
        <a href="/" className="brand" aria-label="Campus home">
          <span className="brand-mark">
            <Icon name="graduation" size={27} />
          </span>
          <span>
            campus<span className="brand-dot">.</span>
          </span>
        </a>
        <div className="login-top-right">
          <span className="version-label">SCHOOL MANAGEMENT v3.0</span>
          <ThemeToggle />
        </div>
      </div>
      <div className="login-layout">
        <section className="login-story">
          <NeuBadge tone="accent">
            <Icon name="sparkles" size={14} /> A little less admin. A lot more
            possibility.
          </NeuBadge>
          <h1>
            Great schools.
            <br />
            Connected <span>communities.</span>
          </h1>
          <p>
            One thoughtful workspace for the people
            <br className="desktop-break" /> who make your school extraordinary.
          </p>
          <CampusIllustration />
          <div className="story-bottom">
            <div className="avatar-stack">
              <span>SW</span>
              <span>JW</span>
              <span>PS</span>
              <span>AM</span>
            </div>
            <div>
              <b>Built around your school community</b>
              <small>Every role. Every campus. One connected place.</small>
            </div>
          </div>
        </section>
        <section className="login-form-side">
          <motion.div
            className="login-card neu-card"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="icon-tile login-symbol">
              <Icon name={master ? "shield" : "graduation"} size={30} />
            </span>
            <div className="login-heading">
              <div className="eyebrow">
                {master ? "PLATFORM ADMINISTRATION" : "YOUR SCHOOL, CONNECTED"}
              </div>
              <h2>{master ? "Creator sign in" : "Welcome back"}</h2>
              <p>
                {master
                  ? "Secure access for platform administrators."
                  : "A good day at school starts here."}
              </p>
            </div>
            <motion.form
              onSubmit={submit}
              noValidate
              animate={error ? { x: [0, -4, 4, -3, 3, 0] } : { x: 0 }}
              transition={{ duration: 0.25 }}
            >
              <NeuInput
                label={config.mock ? "School email or code" : "School email"}
                id="identifier"
                icon="mail"
                placeholder={
                  config.mock ? "you@school.edu or GW-001" : "you@school.edu"
                }
                autoComplete="username"
                error={errors.identifier?.message}
                {...register("identifier")}
              />
              <div className="password-field">
                <NeuInput
                  label="Password"
                  id="password"
                  icon="lock"
                  type={visible ? "text" : "password"}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  error={errors.password?.message}
                  {...register("password")}
                />
                <NeuButton
                  type="button"
                  variant="ghost"
                  icon={visible ? "eye-off" : "eye"}
                  aria-label={visible ? "Hide password" : "Show password"}
                  onClick={() => setVisible(!visible)}
                />
              </div>
              <div className="login-options">
                <NeuCheckbox label="Remember me" {...register("remember")} />
                <button
                  type="button"
                  className="text-button"
                  onClick={() => setReset(true)}
                >
                  Forgot password?
                </button>
              </div>
              {error && (
                <div className="form-error" role="alert">
                  <Icon name="error" size={18} />
                  {error}
                </div>
              )}
              <NeuButton
                type="submit"
                variant="primary"
                className="login-submit"
                loading={isSubmitting}
              >
                Sign in to your workspace
                <Icon name="arrow-right" size={18} />
              </NeuButton>
            </motion.form>
            <div className="secure-note">
              <Icon name="shield" size={16} /> Secure access. Just for your
              school.
            </div>
            {config.mock && (
              <div className="demo-box">
                <div>
                  <NeuBadge>DEMO WORKSPACE</NeuBadge>
                  <span>Take a look around</span>
                </div>
                <div className="demo-controls">
                  <select
                    aria-label="Demo role"
                    value={demoRole}
                    onChange={(e) => setDemoRole(e.target.value as Role)}
                  >
                    {(master
                      ? (["master"] as const)
                      : ([
                          "owner",
                          "principal",
                          "teacher",
                          "parent",
                          "student",
                          "accountant",
                        ] as const)
                    ).map((role) => (
                      <option key={role} value={role}>
                        {roleLabels[role]}
                      </option>
                    ))}
                  </select>
                  <NeuButton type="button" variant="ghost" onClick={fillDemo}>
                    Use demo
                    <Icon name="arrow-up-right" size={16} />
                  </NeuButton>
                </div>
                <small>Demo password: Campus@2026</small>
              </div>
            )}
          </motion.div>
          <p className="login-help">
            Trouble signing in?{" "}
            <button
              className="text-button"
              onClick={() =>
                toast.info(
                  "Contact your school office to check your email, role, and campus assignment.",
                )
              }
            >
              Contact your school administrator
              <Icon name="arrow-up-right" size={13} />
            </button>
          </p>
        </section>
      </div>
      <footer className="login-footer">
        <span>
          Smart <i /> Secure <i /> Connected
        </span>
        <span>Made for better school days.</span>
        <span>© {new Date().getFullYear()} Campus</span>
      </footer>
      <NeuModal
        open={reset}
        onClose={() => setReset(false)}
        title="Let’s get you back in"
        description="Enter your school email and we’ll send you a secure password reset link."
        footer={
          <NeuButton
            variant="primary"
            loading={sending}
            onClick={() => void sendReset()}
          >
            Send reset link
            <Icon name="arrow-right" size={16} />
          </NeuButton>
        }
      >
        <NeuInput
          id="reset-email"
          label="School email"
          type="email"
          value={resetEmail}
          onChange={(e) => setResetEmail(e.target.value)}
          placeholder="you@school.edu"
        />
      </NeuModal>
    </main>
  );
}

````

## src/features/auth/ResetPassword.tsx

````tsx
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useNavigate } from "react-router-dom";
import {
  NeuButton,
  NeuCard,
  NeuInput,
  ThemeToggle,
} from "../../components/ui/primitives";
import { getRepository } from "../../services";
import { useAuth } from "../../store/auth";
const schema = z
  .object({
    password: z
      .string()
      .min(12, "Use at least 12 characters.")
      .regex(/[A-Z]/, "Include an uppercase letter.")
      .regex(/[0-9]/, "Include a number."),
    confirm: z.string(),
  })
  .refine((value) => value.password === value.confirm, {
    path: ["confirm"],
    message: "The passwords do not match.",
  });
export default function ResetPassword() {
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<z.infer<typeof schema>>({ resolver: zodResolver(schema) });
  return (
    <main className="full-screen">
      <NeuCard className="reset-card">
        <div className="section-heading">
          <h1>Set a new password</h1>
          <ThemeToggle />
        </div>
        <p>Open the secure link from your reset email first.</p>
        <form
          onSubmit={handleSubmit(async (values) => {
            try {
              const repository = await getRepository();
              await repository.auth.updatePassword(values.password);
              useAuth.getState().setProfile(null);
              await repository.auth.signOut();
              navigate("/login", { replace: true });
            } catch (reason) {
              setError(
                reason instanceof Error
                  ? reason.message
                  : "Unable to reset your password.",
              );
            }
          })}
        >
          <NeuInput
            label="New password"
            id="new-password"
            autoComplete="new-password"
            type="password"
            error={errors.password?.message}
            {...register("password")}
          />
          <NeuInput
            label="Confirm password"
            id="confirm-password"
            autoComplete="new-password"
            type="password"
            error={errors.confirm?.message}
            {...register("confirm")}
          />
          {error && (
            <p role="alert" className="field-error">
              {error}
            </p>
          )}
          <NeuButton type="submit" variant="primary" loading={isSubmitting}>
            Save password
          </NeuButton>
        </form>
      </NeuCard>
    </main>
  );
}

````

## src/features/master/Revenue.tsx

````tsx
import { lazy, Suspense, useState } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { getAdminRepository } from "../../services/admin";
import { useAuth } from "../../store/auth";
import { useAdminList } from "../../hooks/useAdmin";
import { AdminHeading, QueryState, Pagination } from "../owner/shared";
import {
  DatePicker,
  NeuButton,
  NeuCard,
  StatCard,
  Skeleton,
  ErrorState,
} from "../../components/ui/primitives";
import { NeuTable } from "../../components/ui/NeuTable";
import { downloadCsv, money } from "../../lib/csv";
import type { AdminModels } from "../../types/admin";
const Chart = lazy(() => import("../owner/AnalyticsChart"));
const columns: ColumnDef<AdminModels["schools"], unknown>[] = [
  { accessorKey: "name", header: "School" },
  { accessorKey: "plan", header: "Plan" },
  {
    accessorKey: "monthlyFee",
    header: "Monthly fee",
    cell: (info) => money(Number(info.getValue())),
  },
  { accessorKey: "status", header: "Status" },
];
export default function Revenue() {
  const profile = useAuth((s) => s.profile)!;
  const [from, setFrom] = useState("2025-01-01");
  const [to, setTo] = useState("2026-12-31");
  const [page, setPage] = useState(0);
  const [exporting, setExporting] = useState(false);
  const summary = useQuery({
    queryKey: ["admin", profile.id, "revenue-summary", from, to],
    queryFn: async () =>
      (await getAdminRepository()).summary({
        schoolId: profile.schoolId,
        from,
        to,
      }),
  });
  const query = useAdminList(
    "schools",
    { schoolId: profile.schoolId },
    { from, to, page, pageSize: 12 },
  );
  const exportReport = async () => {
    setExporting(true);
    try {
      const repository = await getAdminRepository();
      const rows: AdminModels["schools"][] = [];
      let index = 0;
      let total = 1;
      while (rows.length < total) {
        const result = await repository.list(
          "schools",
          { schoolId: profile.schoolId },
          { from, to, page: index++, pageSize: 500 },
        );
        rows.push(...result.rows);
        total = result.total;
        if (!result.rows.length) break;
      }
      downloadCsv(
        "school-subscription-revenue.csv",
        ["School", "Plan", "Monthly fee", "Status"],
        rows.map((row) => [row.name, row.plan, row.monthlyFee, row.status]),
      );
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Report export failed",
      );
    } finally {
      setExporting(false);
    }
  };
  return (
    <>
      <AdminHeading
        eyebrow="PLATFORM FINANCIALS"
        title="School-wise subscription revenue"
        description="Track contracted monthly revenue for schools created in your selected period. These figures describe subscriptions, rather than settled payments."
      >
        <NeuButton
          icon="download"
          loading={exporting}
          onClick={() => void exportReport()}
        >
          Export report
        </NeuButton>
      </AdminHeading>
      <div className="revenue-filters">
        <DatePicker
          label="Schools created from"
          value={from}
          onChange={(value) => {
            setFrom(value);
            setPage(0);
          }}
        />
        <DatePicker
          label="Schools created to"
          value={to}
          onChange={(value) => {
            setTo(value);
            setPage(0);
          }}
        />
      </div>
      <QueryState query={query}>
        {(data) => (
          <>
            {summary.isPending ? (
              <Skeleton className="card-skeleton" />
            ) : summary.isError ? (
              <ErrorState
                description={summary.error.message}
                onRetry={() => void summary.refetch()}
              />
            ) : (
              <div className="admin-stat-grid">
                <StatCard
                  label="Monthly contracted revenue"
                  value={summary.data?.mrr ?? 0}
                  suffix=" INR"
                  icon="wallet"
                />
                <StatCard
                  label="Annual recurring run rate"
                  value={(summary.data?.mrr ?? 0) * 12}
                  suffix=" INR"
                  icon="calendar"
                />
                <StatCard
                  label="Active schools"
                  value={summary.data?.active ?? 0}
                  icon="building"
                />
              </div>
            )}
            <NeuCard>
              <h2>Revenue by school · top 10 subscriptions</h2>
              <Suspense fallback={<Skeleton className="chart-skeleton" />}>
                <Chart
                  data={summary.data?.revenue ?? []}
                  kind="bar"
                  valueLabel="Monthly subscription (INR)"
                />
              </Suspense>
              <NeuTable
                data={data.rows}
                columns={columns}
                rowKey={(row) => row.id}
                label="School subscription revenue"
                renderMobile={(row) => (
                  <div>
                    <b>{row.name}</b>
                    <p>
                      {row.plan} · {row.status}
                    </p>
                    <strong>{money(row.monthlyFee)} / month</strong>
                  </div>
                )}
              />
              <Pagination page={page} setPage={setPage} total={data.total} />
            </NeuCard>
          </>
        )}
      </QueryState>
    </>
  );
}

````

## src/features/owner/AnalyticsChart.tsx

````tsx
import { memo } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useReducedMotion } from "framer-motion";
export type ChartPoint = { label: string; value: number; secondary?: number };
function AnalyticsChart({
  data,
  kind = "area",
  valueLabel = "Amount",
  secondaryLabel,
}: {
  data: ChartPoint[];
  kind?: "area" | "bar";
  valueLabel?: string;
  secondaryLabel?: string;
}) {
  const reduced = useReducedMotion();
  const shared = (
    <>
      <CartesianGrid
        vertical={false}
        stroke="var(--line)"
        strokeDasharray="3 5"
      />
      <XAxis
        dataKey="label"
        tick={{ fill: "var(--muted)", fontSize: 10 }}
        axisLine={false}
        tickLine={false}
      />
      <YAxis
        tick={{ fill: "var(--muted)", fontSize: 10 }}
        axisLine={false}
        tickLine={false}
        width={45}
      />
      <Tooltip
        contentStyle={{
          background: "var(--base)",
          border: "1px solid var(--line)",
          borderRadius: 12,
          color: "var(--text)",
          fontSize: 12,
        }}
      />
    </>
  );
  return (
    <div
      className="analytics-chart"
      role="img"
      aria-label={`${valueLabel} chart. ${data.map((point) => `${point.label}: ${point.value}${point.secondary !== undefined ? `, ${secondaryLabel}: ${point.secondary}` : ""}`).join("; ")}`}
    >
      <ResponsiveContainer width="100%" height="100%">
        {kind === "bar" ? (
          <BarChart data={data}>
            {shared}
            <Bar
              dataKey="value"
              name={valueLabel}
              fill="#7BAFD9"
              radius={[4, 4, 0, 0]}
              isAnimationActive={!reduced}
              animationDuration={300}
            />
            {secondaryLabel && (
              <Bar
                dataKey="secondary"
                name={secondaryLabel}
                fill="#A99BD6"
                radius={[4, 4, 0, 0]}
                isAnimationActive={!reduced}
                animationDuration={300}
              />
            )}
          </BarChart>
        ) : (
          <AreaChart data={data}>
            {shared}
            <defs>
              <linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#7BAFD9" stopOpacity={0.3} />
                <stop offset="100%" stopColor="#7BAFD9" stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey="value"
              name={valueLabel}
              stroke="#7BAFD9"
              fill="url(#chart-fill)"
              strokeWidth={2}
              isAnimationActive={!reduced}
              animationDuration={300}
            />
            {secondaryLabel && (
              <Area
                type="monotone"
                dataKey="secondary"
                name={secondaryLabel}
                stroke="#A99BD6"
                fill="transparent"
                strokeWidth={2}
                isAnimationActive={!reduced}
                animationDuration={300}
              />
            )}
          </AreaChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
export default memo(AnalyticsChart);

````

## src/features/owner/Audit.tsx

````tsx
import { useState } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { useAuth } from "../../store/auth";
import { useAdminList } from "../../hooks/useAdmin";
import { useDebounce } from "../../hooks/useDebounce";
import { AdminHeading, Pagination, QueryState } from "./shared";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  DatePicker,
  SearchBar,
} from "../../components/ui/primitives";
import { NeuTable } from "../../components/ui/NeuTable";
import { getAdminRepository } from "../../services/admin";
import { downloadCsv } from "../../lib/csv";
import type { AdminModels } from "../../types/admin";
import { toast } from "sonner";
const columns: ColumnDef<AdminModels["audit"], unknown>[] = [
  { accessorKey: "actor", header: "User" },
  { accessorKey: "action", header: "Action" },
  {
    accessorKey: "resource",
    header: "Module",
    cell: (info) => <NeuBadge>{String(info.getValue())}</NeuBadge>,
  },
  {
    accessorKey: "createdAt",
    header: "Date",
    cell: (info) => new Date(String(info.getValue())).toLocaleString("en-IN"),
  },
];
export default function Audit() {
  const profile = useAuth((s) => s.profile)!;
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [page, setPage] = useState(0);
  const [busy, setBusy] = useState(false);
  const debounced = useDebounce(search);
  const scope = { schoolId: profile.schoolId };
  const query = useAdminList("audit", scope, {
    search: debounced,
    from,
    to,
    page,
    pageSize: 12,
  });
  const exportAll = async () => {
    setBusy(true);
    try {
      const rows: AdminModels["audit"][] = [];
      const repository = await getAdminRepository();
      let total = 1;
      let index = 0;
      while (rows.length < total) {
        const result = await repository.list("audit", scope, {
          search: debounced,
          from,
          to,
          page: index++,
          pageSize: 500,
        });
        rows.push(...result.rows);
        total = result.total;
        if (!result.rows.length) break;
      }
      downloadCsv(
        "school-audit.csv",
        ["User", "Action", "Module", "Details", "Date"],
        rows.map((row) => [
          row.actor,
          row.action,
          row.resource,
          row.details,
          row.createdAt,
        ]),
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Export failed");
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <AdminHeading
        title="Every change tells a story"
        description="An append-only record of administrative activity. Search by user, action, or module."
      >
        <NeuButton
          icon="download"
          loading={busy}
          onClick={() => void exportAll()}
        >
          Export filtered audit
        </NeuButton>
      </AdminHeading>
      <NeuCard>
        <div className="audit-filters">
          <SearchBar
            value={search}
            onChange={(value) => {
              setSearch(value);
              setPage(0);
            }}
            placeholder="User, action, or module…"
          />
          <DatePicker
            label="From date"
            value={from}
            onChange={(value) => {
              setFrom(value);
              setPage(0);
            }}
          />
          <DatePicker
            label="To date"
            value={to}
            onChange={(value) => {
              setTo(value);
              setPage(0);
            }}
          />
        </div>
        <QueryState query={query}>
          {(data) => (
            <>
              <NeuTable
                data={data.rows}
                columns={columns}
                label="Audit events"
                rowKey={(row) => row.id}
                renderMobile={(row) => (
                  <div>
                    <b>{row.action}</b>
                    <p>
                      {row.actor} · {row.resource}
                    </p>
                    <small>
                      {new Date(row.createdAt).toLocaleString("en-IN")}
                    </small>
                  </div>
                )}
              />
              <Pagination page={page} setPage={setPage} total={data.total} />
            </>
          )}
        </QueryState>
      </NeuCard>
    </>
  );
}

````

## src/features/owner/Dashboard.tsx

````tsx
import { lazy, Suspense, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useAdminList } from "../../hooks/useAdmin";
import { getAdminRepository } from "../../services/admin";
import { useAuth } from "../../store/auth";
import { useUI } from "../../store/ui";
import { AdminHeading } from "./shared";
import {
  NeuBadge,
  NeuCard,
  NeuSelect,
  Skeleton,
  StatCard,
  ErrorState,
} from "../../components/ui/primitives";
import { Icon, type IconName } from "../../components/ui/Icon";
import { money } from "../../lib/csv";
import { homeFor } from "../../lib/permissions";
const Chart = lazy(() => import("./AnalyticsChart"));
export default function Dashboard({ master = false }: { master?: boolean }) {
  const profile = useAuth((s) => s.profile)!;
  const branch = useUI((s) => s.branchId);
  const [campus, setCampus] = useState("all");
  const scope = {
    schoolId: profile.schoolId,
    ...(campus === "current" && branch ? { branchId: branch } : {}),
  };
  const query = useQuery({
    queryKey: ["admin", profile.id, "summary", scope],
    queryFn: async () => (await getAdminRepository()).summary(scope),
  });
  const audit = useAdminList(
    "audit",
    { schoolId: profile.schoolId },
    { pageSize: 5 },
  );
  const base = homeFor(profile.role);
  const data = query.data;
  const shortcuts: [string, string, IconName][] = master
    ? [
        ["schools", "Manage schools", "building"],
        ["roles", "Global role control", "shield"],
        ["revenue", "School-wise revenue", "wallet"],
      ]
    : [
        ["branches", "Manage campuses", "building"],
        ["roles", "Roles & permissions", "shield"],
        ["settings", "School settings", "settings"],
        ["view-as", "View as another role", "eye"],
      ];
  return (
    <>
      <AdminHeading
        eyebrow={master ? "PLATFORM OVERVIEW" : "YOUR SCHOOL, AT A GLANCE"}
        title={
          master
            ? "A bigger picture. A better platform."
            : `Welcome back, ${profile.name.split(" ")[0]}`
        }
        description={
          master
            ? "School subscriptions and platform health, in one place."
            : "A clear view of your school community and financial performance."
        }
      >
        {!master && (
          <NeuSelect
            aria-label="Dashboard campus scope"
            value={campus}
            onChange={(e) => setCampus(e.target.value)}
          >
            <option value="all">All assigned campuses</option>
            <option value="current">Selected campus</option>
          </NeuSelect>
        )}
        <Link
          className="neu-button primary"
          to={`${base}/${master ? "schools" : "people"}`}
        >
          <Icon name="plus" />
          {master ? "Manage schools" : "Manage community"}
        </Link>
      </AdminHeading>
      {query.isPending ? (
        <Skeleton className="hero-skeleton" />
      ) : query.isError || !data ? (
        <ErrorState
          description={query.error?.message}
          onRetry={() => void query.refetch()}
        />
      ) : (
        <>
          <div className="admin-stat-grid">
            {master ? (
              <>
                <StatCard
                  label="Schools on platform"
                  value={data.schools}
                  icon="building"
                  detail="Registered schools"
                />
                <StatCard
                  label="Active subscriptions"
                  value={data.active}
                  icon="shield"
                  detail="Schools with active access"
                />
                <StatCard
                  label="Monthly recurring revenue"
                  value={data.mrr}
                  suffix=" INR"
                  icon="wallet"
                  detail="Contracted subscriptions"
                />
                <StatCard
                  label="Access suspended"
                  value={data.suspended}
                  icon="lock"
                  detail="Retained for audit history"
                />
              </>
            ) : (
              <>
                <StatCard
                  label="Students enrolled"
                  value={data.students}
                  icon="graduation"
                  detail="Active directory records"
                />
                <StatCard
                  label="Staff & faculty"
                  value={data.staff}
                  icon="users"
                  detail="Your connected school community"
                />
                <StatCard
                  label="Fees collected"
                  value={data.income}
                  suffix=" INR"
                  icon="wallet"
                  detail="Paid income entries"
                />
                <StatCard
                  label="Outstanding fees"
                  value={data.outstanding}
                  suffix=" INR"
                  icon="clock"
                  detail="Pending and overdue income"
                />
              </>
            )}
          </div>
          <div className="dashboard-main-grid">
            <NeuCard>
              <div className="section-heading">
                <div>
                  <h2>{master ? "Revenue by school" : "Income & expenses"}</h2>
                  <p>
                    {master
                      ? "Top 10 monthly subscription commitments"
                      : "Last six months · paid transactions"}
                  </p>
                </div>
                <NeuBadge>INR</NeuBadge>
              </div>
              <Suspense fallback={<Skeleton className="chart-skeleton" />}>
                <Chart
                  data={data.revenue}
                  valueLabel={master ? "Subscription" : "Income"}
                  secondaryLabel={master ? undefined : "Expenses"}
                  kind={master ? "bar" : "area"}
                />
              </Suspense>
              {!master && (
                <div className="chart-summary">
                  <span>
                    Net income <b>{money(data.income - data.expenses)}</b>
                  </span>
                  <span>
                    Expenses <b>{money(data.expenses)}</b>
                  </span>
                </div>
              )}
            </NeuCard>
            <NeuCard>
              <div className="section-heading">
                <div>
                  <h2>{master ? "Subscription mix" : "Campus enrollment"}</h2>
                  <p>
                    {master
                      ? "Active plans across your platform"
                      : "Active students from your directory"}
                  </p>
                </div>
                <Icon name="building" />
              </div>
              <Suspense fallback={<Skeleton className="chart-skeleton" />}>
                <Chart
                  kind="bar"
                  data={data.enrollment}
                  valueLabel={master ? "Schools" : "Students"}
                />
              </Suspense>
            </NeuCard>
          </div>
          {!master && (
            <NeuCard>
              <div className="section-heading">
                <div>
                  <h2>Attendance at a glance</h2>
                  <p>
                    Monthly recorded attendance summaries · percentage present
                  </p>
                </div>
                <NeuBadge>%</NeuBadge>
              </div>
              {data.attendance.length ? (
                <Suspense fallback={<Skeleton className="chart-skeleton" />}>
                  <Chart data={data.attendance} valueLabel="Attendance (%)" />
                </Suspense>
              ) : (
                <p className="module-footnote">
                  No attendance summaries have been recorded for this campus.
                </p>
              )}
            </NeuCard>
          )}
          <div className="dashboard-main-grid">
            <NeuCard>
              <div className="section-heading">
                <div>
                  <h2>Recent activity</h2>
                  <p>A clear trail of changes across your workspace.</p>
                </div>
                <Link className="text-button" to={`${base}/audit`}>
                  View audit trail
                  <Icon name="arrow-right" size={15} />
                </Link>
              </div>
              {audit.isPending ? (
                <Skeleton className="card-skeleton" />
              ) : audit.isError ? (
                <ErrorState
                  description="Activity could not be loaded."
                  onRetry={() => void audit.refetch()}
                />
              ) : (
                audit.data?.rows.map((item) => (
                  <div className="activity-row" key={item.id}>
                    <span className="icon-tile small">
                      <Icon name="shield" />
                    </span>
                    <div>
                      <b>{item.action}</b>
                      <small>
                        {item.actor} · {item.resource}
                      </small>
                    </div>
                    <time>
                      {new Date(item.createdAt).toLocaleDateString("en-IN")}
                    </time>
                  </div>
                ))
              )}
            </NeuCard>
            <NeuCard className="owner-shortcuts">
              <h2>A few useful shortcuts</h2>
              <p>Keep your school moving.</p>
              {shortcuts.map(([path, label, icon]) => (
                <Link key={path} to={`${base}/${path}`}>
                  <Icon name={icon} />
                  <span>{label}</span>
                  <Icon name="arrow-up-right" size={16} />
                </Link>
              ))}
            </NeuCard>
          </div>
        </>
      )}
    </>
  );
}

````

## src/features/owner/Permissions.tsx

````tsx
import { useEffect, useState } from "react";
import { useAdminList, refreshAdmin } from "../../hooks/useAdmin";
import { useAuth } from "../../store/auth";
import { getAdminRepository } from "../../services/admin";
import {
  permissions,
  roleLabels,
  rolePermissions,
  type Permission,
} from "../../lib/permissions";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuCheckbox,
  NeuInput,
  NeuSelect,
} from "../../components/ui/primitives";
import { ConfirmDialog, NeuModal } from "../../components/ui/overlays";
import { AdminHeading, QueryState } from "./shared";
import type { AdminModels } from "../../types/admin";
import { toast } from "sonner";
export const platformScope = "00000000-0000-0000-0000-000000000000";
export default function Permissions({ master = false }: { master?: boolean }) {
  const profile = useAuth((s) => s.profile)!;
  const schoolId = master ? platformScope : profile.schoolId;
  const query = useAdminList("roles", { schoolId }, { pageSize: 50 });
  const [draft, setDraft] = useState<AdminModels["roles"][]>([]);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [roleName, setRoleName] = useState("");
  const [baseRole, setBaseRole] = useState<
    "teacher" | "principal" | "parent" | "student" | "accountant"
  >("teacher");
  const [dirty, setDirty] = useState(false);
  useEffect(() => {
    if (query.data && !dirty)
      setDraft(
        query.data.rows.length
          ? query.data.rows
          : (
              [
                "owner",
                "principal",
                "teacher",
                "parent",
                "student",
                "accountant",
              ] as const
            ).map((role) => ({
              id: crypto.randomUUID(),
              schoolId,
              branchId: null,
              version: 1,
              name: roleLabels[role],
              custom: false,
              role,
              permissions: [...rolePermissions[role]],
            })),
      );
  }, [query.data, dirty, schoolId]);
  const toggle = (id: string, permission: Permission) => {
    setDirty(true);
    setDraft((old) =>
      old.map((row) =>
        row.id === id
          ? {
              ...row,
              permissions: row.permissions.includes(permission)
                ? row.permissions.filter((p) => p !== permission)
                : [...row.permissions, permission],
            }
          : row,
      ),
    );
  };
  const save = async () => {
    setBusy(true);
    const records = draft.filter((row) => row.role !== "owner");
    const results = await Promise.allSettled(
      records.map(async (row) =>
        (await getAdminRepository()).save("roles", row),
      ),
    );
    const failed = results.filter((r) => r.status === "rejected").length;
    setBusy(false);
    setConfirm(false);
    setDirty(false);
    await refreshAdmin();
    toast[failed ? "error" : "success"](
      failed
        ? `${failed} role policies could not be saved. Refresh before retrying.`
        : "Role policies saved",
    );
  };
  return (
    <>
      <AdminHeading
        eyebrow={master ? "GLOBAL ROLE CONTROL" : "ACCESS, WITH INTENTION"}
        title={
          master
            ? "Set the platform’s role defaults"
            : "The right access, for every role"
        }
        description="School data always remains scoped to assigned campuses. Owner and platform privileges cannot be granted through this editor."
      >
        <NeuButton icon="plus" onClick={() => setCreateOpen(true)}>
          Create role
        </NeuButton>
        <NeuButton
          disabled={!dirty}
          variant="primary"
          icon="shield"
          onClick={() => setConfirm(true)}
        >
          Review & save
        </NeuButton>
      </AdminHeading>
      <QueryState query={query}>
        {() => (
          <NeuCard>
            <div
              className="permission-matrix"
              role="group"
              aria-label="Role permission matrix"
            >
              {draft.map((row) => (
                <section key={row.id} className="permission-role">
                  <div className="section-heading">
                    <h2>{row.name}</h2>
                    {row.role === "owner" && (
                      <NeuBadge>Full access · protected</NeuBadge>
                    )}
                  </div>
                  {permissions
                    .filter((p) => p !== "master.manage")
                    .map((permission) => (
                      <NeuCheckbox
                        key={permission}
                        label={permission.replaceAll(".", " · ")}
                        checked={row.permissions.includes(permission)}
                        disabled={
                          row.role === "owner" ||
                          permission === "workspace.read"
                        }
                        onChange={() => toggle(row.id, permission)}
                      />
                    ))}
                </section>
              ))}
            </div>
          </NeuCard>
        )}
      </QueryState>
      <p className="module-footnote">
        These policies configure school module access. Database RLS remains
        authoritative; future modules must use these policies in their data
        authorization. Platform defaults apply when provisioning new schools.
      </p>
      <NeuModal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Create a school role"
        description="Use a standard role as the foundation, then choose its permissions."
        footer={
          <NeuButton
            variant="primary"
            disabled={roleName.trim().length < 2}
            onClick={() => {
              setDraft((old) => [
                ...old,
                {
                  id: crypto.randomUUID(),
                  schoolId,
                  branchId: null,
                  version: 1,
                  name: roleName.trim(),
                  role: baseRole,
                  custom: true,
                  permissions: [...rolePermissions[baseRole]],
                },
              ]);
              setDirty(true);
              setCreateOpen(false);
              setRoleName("");
            }}
          >
            Add role to matrix
          </NeuButton>
        }
      >
        <div className="admin-form">
          <NeuInput
            id="custom-role-name"
            label="Role name"
            value={roleName}
            onChange={(e) => setRoleName(e.target.value)}
          />
          <NeuSelect
            id="custom-role-base"
            label="Base role"
            value={baseRole}
            onChange={(e) => setBaseRole(e.target.value as typeof baseRole)}
          >
            {(
              [
                "teacher",
                "principal",
                "parent",
                "student",
                "accountant",
              ] as const
            ).map((role) => (
              <option value={role} key={role}>
                {roleLabels[role]}
              </option>
            ))}
          </NeuSelect>
        </div>
      </NeuModal>
      <ConfirmDialog
        open={confirm}
        onClose={() => setConfirm(false)}
        title="Save role policies?"
        description="Review the permissions before saving. These changes affect this school’s access policy and are recorded in the audit trail."
        confirmText="SAVE ACCESS"
        loading={busy}
        onConfirm={() => void save()}
      />
    </>
  );
}

````

## src/features/owner/Records.tsx

````tsx
import { useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import type { ColumnDef } from "@tanstack/react-table";
import { toast } from "sonner";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuCheckbox,
  NeuInput,
  NeuSelect,
  SearchBar,
  DatePicker,
} from "../../components/ui/primitives";
import { NeuModal, ConfirmDialog } from "../../components/ui/overlays";
import { NeuTable } from "../../components/ui/NeuTable";
import { FileUpload } from "../../components/ui/FileUpload";
import { Icon } from "../../components/ui/Icon";
import { useAuth } from "../../store/auth";
import { useDebounce } from "../../hooks/useDebounce";
import { useAdminList, refreshAdmin } from "../../hooks/useAdmin";
import { getAdminRepository } from "../../services/admin";
import { parseRecord, type AdminModels } from "../../types/admin";
import { downloadCsv, money, parseCsv } from "../../lib/csv";
import { AdminHeading, Pagination, QueryState } from "./shared";
type Resource = "branches" | "users" | "finance" | "templates" | "schools";
type Field = {
  key: string;
  label: string;
  type?: "number" | "date" | "email";
  options?: readonly string[];
  required?: boolean;
};
const fields: Record<Resource, Field[]> = {
  branches: [
    { key: "name", label: "Campus name", required: true },
    { key: "city", label: "City", required: true },
    { key: "code", label: "Campus code", required: true },
    { key: "principal", label: "Principal" },
    { key: "capacity", label: "Capacity", type: "number", required: true },
    { key: "status", label: "Status", options: ["Active", "Inactive"] },
  ],
  users: [
    { key: "name", label: "Full name", required: true },
    { key: "email", label: "School email", type: "email", required: true },
    {
      key: "role",
      label: "Role",
      options: ["student", "teacher", "parent", "principal", "accountant"],
    },
    { key: "branchId", label: "Campus", required: true },
    { key: "policyId", label: "Custom role policy" },
    { key: "phone", label: "Phone" },
    { key: "status", label: "Status", options: ["Active", "Inactive"] },
  ],
  finance: [
    { key: "reference", label: "Reference", required: true },
    { key: "description", label: "Description", required: true },
    { key: "kind", label: "Transaction type", options: ["Income", "Expense"] },
    { key: "category", label: "Category", required: true },
    { key: "amount", label: "Amount (INR)", type: "number", required: true },
    { key: "date", label: "Transaction date", type: "date", required: true },
    { key: "branchId", label: "Campus", required: true },
    {
      key: "status",
      label: "Payment status",
      options: ["Paid", "Pending", "Overdue"],
    },
  ],
  templates: [
    { key: "name", label: "Template name", required: true },
    {
      key: "category",
      label: "Category",
      options: ["Attendance", "Fees", "Announcements"],
    },
    { key: "body", label: "Message body", required: true },
  ],
  schools: [
    { key: "name", label: "School name", required: true },
    { key: "code", label: "School code", required: true },
    {
      key: "ownerEmail",
      label: "Owner login email",
      type: "email",
      required: true,
    },
    {
      key: "plan",
      label: "Plan",
      options: ["Starter", "Growth", "Enterprise"],
    },
    {
      key: "monthlyFee",
      label: "Monthly subscription (INR)",
      type: "number",
      required: true,
    },
  ],
};
const titles: Record<Resource, [string, string, string]> = {
  branches: [
    "Every campus, connected",
    "Manage campus details and capacity across your school.",
    "Add campus",
  ],
  users: [
    "Your school community",
    "Manage directory records, campus assignments, and financial roles.",
    "Add person",
  ],
  finance: [
    "Clarity in every transaction",
    "Review income, expenses, outstanding balances, and financial reports.",
    "Add transaction",
  ],
  templates: [
    "Words that keep you connected",
    "Edit your school’s WhatsApp templates. Modified templates return to Draft for approval.",
    "New template",
  ],
  schools: [
    "Schools, connected at scale",
    "Manage subscriptions and access across your platform.",
    "Create school",
  ],
};
function getValue(record: object, key: string): string {
  const value = Object.entries(record).find(([name]) => name === key)?.[1];
  return typeof value === "string" || typeof value === "number"
    ? String(value)
    : "";
}
export default function Records({ resource }: { resource: Resource }) {
  const profile = useAuth((s) => s.profile)!;
  const scope = { schoolId: profile.schoolId };
  const [search, setSearch] = useState("");
  const debounced = useDebounce(search);
  const [page, setPage] = useState(0);
  const [editing, setEditing] = useState<AdminModels[Resource] | "new" | null>(
    null,
  );
  const [pendingDelete, setPendingDelete] = useState<
    AdminModels[Resource] | null
  >(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [importRows, setImportRows] = useState<AdminModels["users"][]>([]);
  const [receipt, setReceipt] = useState<{
    email: string;
    password: string;
  } | null>(null);
  const [action, setAction] = useState<{
    school: AdminModels["schools"];
    status: AdminModels["schools"]["status"];
  } | null>(null);
  const [statusFilter, setStatusFilter] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const filters = {
    ...(statusFilter ? { status: statusFilter } : {}),
    ...(roleFilter ? { role: roleFilter } : {}),
  };
  const query = useAdminList(resource, scope, {
    search: debounced,
    page,
    pageSize: 12,
    filters,
    from,
    to,
  });
  const campuses = useAdminList(
    "branches",
    scope,
    { pageSize: 500 },
    resource !== "schools",
  );
  const policies = useAdminList(
    "roles",
    scope,
    { pageSize: 500 },
    resource === "users",
  );
  const formSchema = useMemo(
    () =>
      z.record(z.string()).superRefine((values, context) => {
        for (const field of fields[resource]) {
          const value = values[field.key]?.trim() ?? "";
          if (field.required && !value)
            context.addIssue({
              code: "custom",
              path: [field.key],
              message: `${field.label} is required.`,
            });
          if (field.key === "body" && value.length < 10)
            context.addIssue({
              code: "custom",
              path: [field.key],
              message: "Enter a message with at least 10 characters.",
            });
          if (
            field.type === "email" &&
            !z.string().email().safeParse(value).success
          )
            context.addIssue({
              code: "custom",
              path: [field.key],
              message: "Enter a valid email address.",
            });
          if (
            field.type === "number" &&
            (!Number.isFinite(Number(value)) ||
              Number(value) < (field.key === "monthlyFee" ? 0 : 1))
          )
            context.addIssue({
              code: "custom",
              path: [field.key],
              message: "Enter a valid positive amount.",
            });
        }
      }),
    [resource],
  );
  const {
    register,
    reset,
    setValue,
    watch,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<Record<string, string>>({ resolver: zodResolver(formSchema) });
  const openEditor = (record: AdminModels[Resource] | "new") => {
    const defaults: Record<string, string> = {};
    for (const field of fields[resource])
      defaults[field.key] =
        record === "new"
          ? (field.options?.[0] ??
            (field.key === "branchId"
              ? (campuses.data?.rows[0]?.id ?? "")
              : field.key === "date"
                ? new Date().toISOString().slice(0, 10)
                : ""))
          : getValue(record, field.key);
    reset(defaults);
    setEditing(record);
  };
  const submit = handleSubmit(async (values) => {
    try {
      const repository = await getAdminRepository();
      if (resource === "schools" && editing === "new") {
        const result = await repository.provisionSchool({
          name: values.name!,
          code: values.code!,
          ownerEmail: values.ownerEmail!,
          plan: z.enum(["Starter", "Growth", "Enterprise"]).parse(values.plan),
          monthlyFee: Number(values.monthlyFee),
        });
        setReceipt({ email: result.email, password: result.password });
      } else {
        const numeric = Object.fromEntries(
          fields[resource]
            .filter((field) => field.type === "number")
            .map((field) => [field.key, Number(values[field.key])]),
        );
        const existing =
          editing !== "new" && editing
            ? editing
            : {
                id: crypto.randomUUID(),
                schoolId: profile.schoolId,
                branchId: null,
                version: 1,
                joinedAt: new Date().toISOString().slice(0, 10),
                createdAt: new Date().toISOString().slice(0, 10),
              };
        const record = parseRecord(resource, {
          ...existing,
          ...values,
          ...numeric,
          ...(resource === "users"
            ? { policyId: values.policyId || null }
            : {}),
          ...(resource === "templates" ? { status: "Draft" } : {}),
          ...(resource === "branches" ? { branchId: existing.id } : {}),
        });
        await repository.save(resource, record);
      }
      toast.success(
        resource === "schools" && editing === "new"
          ? "School and owner login created"
          : "Record saved",
      );
      setEditing(null);
      await refreshAdmin();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Unable to save this record",
      );
    }
  });
  const remove = async () => {
    if (!pendingDelete || resource === "schools") return;
    setBusy(true);
    try {
      await (
        await getAdminRepository()
      ).remove(
        resource,
        pendingDelete.id,
        { schoolId: pendingDelete.schoolId },
        pendingDelete.version,
      );
      setPendingDelete(null);
      setSelected([]);
      await refreshAdmin();
      toast.success("Record deleted");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Unable to delete this record",
      );
    } finally {
      setBusy(false);
    }
  };
  const bulkStatus = async (status: "Active" | "Inactive") => {
    setBusy(true);
    const records =
      query.data?.rows.filter((row) => selected.includes(row.id)) ?? [];
    const results = await Promise.allSettled(
      records.map(async (row) =>
        (await getAdminRepository()).save(
          "users",
          parseRecord("users", { ...row, status }),
        ),
      ),
    );
    const failed = results.filter((r) => r.status === "rejected").length;
    toast[failed ? "error" : "success"](
      `${results.length - failed} records updated${failed ? `; ${failed} failed. Refresh and retry.` : ""}`,
    );
    setSelected([]);
    setBusy(false);
    await refreshAdmin();
  };
  const exportAll = async () => {
    setBusy(true);
    try {
      const rows: AdminModels[Resource][] = [];
      const repo = await getAdminRepository();
      let index = 0;
      let total = 1;
      while (rows.length < total) {
        const result = await repo.list(resource, scope, {
          search: debounced,
          page: index++,
          pageSize: 500,
          filters,
          from,
          to,
        });
        rows.push(...result.rows);
        total = result.total;
        if (!result.rows.length) break;
      }
      downloadCsv(
        `campus-${resource}.csv`,
        fields[resource].map((f) => f.label),
        rows.map((row) => fields[resource].map((f) => getValue(row, f.key))),
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Export failed");
    } finally {
      setBusy(false);
    }
  };
  const importCsv = async (file: File) => {
    const parsed = parseCsv(await file.text());
    const header =
      parsed.shift()?.map((h) => h.replace(/^\uFEFF/, "").trim()) ?? [];
    for (const required of ["name", "email", "role", "branchId"])
      if (!header.includes(required))
        throw new Error(`Missing CSV column: ${required}`);
    if (parsed.length > 250)
      throw new Error("Import at most 250 records per file.");
    const seen = new Set<string>();
    const records = parsed.map((row, index) => {
      const values = Object.fromEntries(
        header.map((key, i) => [key, row[i] ?? ""]),
      );
      try {
        const record = parseRecord("users", {
          id: crypto.randomUUID(),
          schoolId: profile.schoolId,
          branchId: null,
          version: 1,
          phone: "",
          status: "Active",
          joinedAt: new Date().toISOString().slice(0, 10),
          ...values,
        });
        if (!campuses.data?.rows.some((b) => b.id === record.branchId))
          throw new Error("Campus is not part of this school.");
        if (seen.has(record.email.toLowerCase()))
          throw new Error("Duplicate email in this file.");
        seen.add(record.email.toLowerCase());
        return record;
      } catch (error) {
        throw new Error(
          `Row ${index + 2}: ${error instanceof Error ? error.message : "Invalid record"}`,
        );
      }
    });
    setImportRows(records);
  };
  const confirmImport = async () => {
    setBusy(true);
    let success = 0;
    const failures: string[] = [];
    const repository = await getAdminRepository();
    for (let i = 0; i < importRows.length; i += 5) {
      const results = await Promise.allSettled(
        importRows
          .slice(i, i + 5)
          .map((record) => repository.save("users", record)),
      );
      results.forEach((result) => {
        if (result.status === "fulfilled") success++;
        else
          failures.push(
            result.reason instanceof Error
              ? result.reason.message
              : "Unknown error",
          );
      });
    }
    await refreshAdmin();
    setBusy(false);
    setImportRows([]);
    setImportOpen(false);
    toast[failures.length ? "error" : "success"](
      `${success} imported. ${failures.length ? `${failures.length} failed: ${failures[0]}` : "All records saved."}`,
    );
  };
  const columns = useMemo<ColumnDef<AdminModels[Resource], unknown>[]>(() => {
    const result: ColumnDef<AdminModels[Resource], unknown>[] = [];
    if (resource === "users")
      result.push({
        id: "select",
        header: () => (
          <NeuCheckbox
            label="All"
            checked={
              !!query.data?.rows.length &&
              query.data.rows.every((row) => selected.includes(row.id))
            }
            onChange={(e) =>
              setSelected(
                e.target.checked
                  ? (query.data?.rows.map((row) => row.id) ?? [])
                  : [],
              )
            }
          />
        ),
        cell: ({ row }) => (
          <NeuCheckbox
            label=""
            aria-label={`Select ${getValue(row.original, "name")}`}
            checked={selected.includes(row.original.id)}
            onChange={(e) =>
              setSelected((old) =>
                e.target.checked
                  ? [...old, row.original.id]
                  : old.filter((id) => id !== row.original.id),
              )
            }
          />
        ),
      });
    const visible =
      resource === "finance"
        ? ["description", "amount", "status"]
        : resource === "schools"
          ? ["name", "plan", "status"]
          : resource === "users"
            ? ["name", "role", "status"]
            : resource === "branches"
              ? ["name", "city", "status"]
              : ["name", "category", "status"];
    visible.forEach((key) =>
      result.push({
        id: key,
        accessorFn: (row) => getValue(row, key),
        header: key[0]!.toUpperCase() + key.slice(1),
        cell: ({ row }) =>
          key === "status" ? (
            <NeuBadge
              tone={
                getValue(row.original, key) === "Active" ||
                getValue(row.original, key) === "Paid" ||
                getValue(row.original, key) === "Approved"
                  ? "success"
                  : "warning"
              }
            >
              {getValue(row.original, key)}
            </NeuBadge>
          ) : key === "amount" ? (
            money(Number(getValue(row.original, key)))
          ) : (
            <span className="record-cell">
              <b>{getValue(row.original, key)}</b>
              {key === "name" && (
                <small>
                  {getValue(
                    row.original,
                    resource === "users" ? "email" : "code",
                  )}
                </small>
              )}
            </span>
          ),
      }),
    );
    result.push({
      id: "actions",
      header: "Actions",
      cell: ({ row }) => (
        <div className="table-actions">
          <NeuButton
            variant="ghost"
            aria-label={`Edit ${getValue(row.original, "name") || getValue(row.original, "reference")}`}
            onClick={() => openEditor(row.original)}
          >
            Edit
          </NeuButton>
          {resource === "schools" ? (
            <>
              <NeuButton
                variant="ghost"
                onClick={() =>
                  setAction({
                    school: parseRecord("schools", row.original),
                    status:
                      getValue(row.original, "status") === "Active"
                        ? "Suspended"
                        : "Active",
                  })
                }
              >
                {getValue(row.original, "status") === "Active"
                  ? "Revoke"
                  : "Restore"}
              </NeuButton>
              <NeuButton
                variant="ghost"
                onClick={() =>
                  setAction({
                    school: parseRecord("schools", row.original),
                    status: "Deleted",
                  })
                }
              >
                Remove access
              </NeuButton>
            </>
          ) : (
            <NeuButton
              variant="ghost"
              icon="close"
              aria-label="Delete record"
              onClick={() => setPendingDelete(row.original)}
            />
          )}
        </div>
      ),
    });
    return result;
  }, [resource, query.data, selected, campuses.data]);
  return (
    <>
      <AdminHeading
        eyebrow={
          resource === "schools"
            ? "PLATFORM ADMINISTRATION"
            : "YOUR SCHOOL, CONNECTED"
        }
        title={titles[resource][0]}
        description={titles[resource][1]}
      >
        <NeuButton
          icon="download"
          loading={busy}
          onClick={() => void exportAll()}
        >
          Export
        </NeuButton>
        {resource === "users" && (
          <NeuButton icon="upload" onClick={() => setImportOpen(true)}>
            Import CSV
          </NeuButton>
        )}
        <NeuButton
          variant="primary"
          icon="plus"
          onClick={() => openEditor("new")}
        >
          {titles[resource][2]}
        </NeuButton>
      </AdminHeading>
      <NeuCard className={resource === "users" ? "people-table" : ""}>
        <div className="records-toolbar">
          <SearchBar
            value={search}
            onChange={(value) => {
              setSearch(value);
              setPage(0);
              setSelected([]);
            }}
            placeholder={`Search ${resource}…`}
            label={`Search ${resource}`}
          />
          <NeuSelect
            aria-label="Filter status"
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setPage(0);
              setSelected([]);
            }}
          >
            <option value="">All statuses</option>
            {(resource === "finance"
              ? ["Paid", "Pending", "Overdue"]
              : resource === "schools"
                ? ["Active", "Suspended", "Deleted"]
                : resource === "templates"
                  ? ["Draft", "Pending", "Approved"]
                  : ["Active", "Inactive"]
            ).map((status) => (
              <option key={status} value={status}>
                {status}
              </option>
            ))}
          </NeuSelect>
          {resource === "users" && (
            <NeuSelect
              aria-label="Filter role"
              value={roleFilter}
              onChange={(e) => {
                setRoleFilter(e.target.value);
                setPage(0);
                setSelected([]);
              }}
            >
              <option value="">All roles</option>
              {["student", "teacher", "parent", "principal", "accountant"].map(
                (role) => (
                  <option key={role} value={role}>
                    {role}
                  </option>
                ),
              )}
            </NeuSelect>
          )}
          {resource === "finance" && (
            <>
              <DatePicker
                label="From date"
                value={from}
                onChange={(value) => {
                  setFrom(value);
                  setPage(0);
                }}
              />
              <DatePicker
                label="To date"
                value={to}
                onChange={(value) => {
                  setTo(value);
                  setPage(0);
                }}
              />
            </>
          )}
          <NeuBadge>{query.data?.total ?? 0} records</NeuBadge>
          {selected.length > 0 && (
            <div className="bulk-actions">
              <span>{selected.length} selected</span>
              <NeuButton
                disabled={busy}
                onClick={() => void bulkStatus("Active")}
              >
                Activate
              </NeuButton>
              <NeuButton
                disabled={busy}
                onClick={() => void bulkStatus("Inactive")}
              >
                Deactivate
              </NeuButton>
            </div>
          )}
        </div>
        <QueryState query={query}>
          {(data) => (
            <>
              <NeuTable
                data={data.rows}
                columns={columns}
                label={titles[resource][0]}
                rowKey={(row) => row.id}
                renderMobile={(row) => (
                  <div className="record-mobile">
                    <div>
                      <b>
                        {getValue(row, "name") || getValue(row, "description")}
                      </b>
                      <small>
                        {getValue(row, "email") ||
                          getValue(row, "city") ||
                          getValue(row, "category")}
                      </small>
                    </div>
                    <NeuBadge>{getValue(row, "status")}</NeuBadge>
                    <NeuButton variant="ghost" onClick={() => openEditor(row)}>
                      Edit
                    </NeuButton>
                    {resource === "schools" ? (
                      <>
                        <NeuButton
                          variant="ghost"
                          onClick={() =>
                            setAction({
                              school: parseRecord("schools", row),
                              status:
                                getValue(row, "status") === "Active"
                                  ? "Suspended"
                                  : "Active",
                            })
                          }
                        >
                          {getValue(row, "status") === "Active"
                            ? "Revoke"
                            : "Restore"}
                        </NeuButton>
                        <NeuButton
                          variant="ghost"
                          onClick={() =>
                            setAction({
                              school: parseRecord("schools", row),
                              status: "Deleted",
                            })
                          }
                        >
                          Remove access
                        </NeuButton>
                      </>
                    ) : (
                      <NeuButton
                        variant="ghost"
                        aria-label="Delete record"
                        icon="close"
                        onClick={() => setPendingDelete(row)}
                      />
                    )}
                    {resource === "users" && (
                      <NeuCheckbox
                        label="Select"
                        checked={selected.includes(row.id)}
                        onChange={(e) =>
                          setSelected((old) =>
                            e.target.checked
                              ? [...old, row.id]
                              : old.filter((id) => id !== row.id),
                          )
                        }
                      />
                    )}
                  </div>
                )}
              />
              <Pagination page={page} setPage={setPage} total={data.total} />
            </>
          )}
        </QueryState>
      </NeuCard>
      {resource === "users" && (
        <p className="module-footnote">
          Directory records describe your community. Existing linked accounts
          receive role and campus changes on their next token refresh. New login
          invitations require your school’s trusted Auth provisioning process.
        </p>
      )}
      <NeuModal
        open={!!editing}
        onClose={() => !isSubmitting && setEditing(null)}
        title={`${editing === "new" ? "Create" : "Edit"} ${resource === "users" ? "directory record" : resource === "branches" ? "campus" : resource === "finance" ? "transaction" : resource === "schools" ? "school" : "template"}`}
        description={
          resource === "schools" && editing === "new"
            ? "Create a school and a dedicated owner login. Save the generated credentials securely."
            : "Changes are recorded in your audit history."
        }
        footer={
          <>
            <NeuButton onClick={() => setEditing(null)} disabled={isSubmitting}>
              Cancel
            </NeuButton>
            <NeuButton
              variant="primary"
              loading={isSubmitting}
              onClick={() => void submit()}
            >
              Save changes
            </NeuButton>
          </>
        }
      >
        <form className="admin-form" onSubmit={submit}>
          {fields[resource].map((field) =>
            field.options ||
            field.key === "branchId" ||
            field.key === "policyId" ? (
              <NeuSelect
                key={field.key}
                id={`edit-${field.key}`}
                label={field.label}
                {...register(
                  field.key,
                  field.key === "role"
                    ? { onChange: () => setValue("policyId", "") }
                    : undefined,
                )}
              >
                {(field.key === "policyId"
                  ? [
                      { value: "", label: "Standard role policy" },
                      ...(policies.data?.rows
                        .filter(
                          (policy) =>
                            policy.custom && policy.role === watch("role"),
                        )
                        .map((policy) => ({
                          value: policy.id,
                          label: policy.name,
                        })) ?? []),
                    ]
                  : field.key === "branchId"
                    ? (campuses.data?.rows.map((b) => ({
                        value: b.id,
                        label: b.name,
                      })) ?? [])
                    : field.options!.map((value) => ({ value, label: value }))
                ).map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </NeuSelect>
            ) : field.key === "body" ? (
              <div className="field" key={field.key}>
                <label htmlFor="edit-body">Message body</label>
                <textarea
                  id="edit-body"
                  rows={6}
                  aria-invalid={!!errors.body}
                  {...register("body")}
                />
                {errors.body?.message && (
                  <span className="field-error">{errors.body.message}</span>
                )}
              </div>
            ) : (
              <NeuInput
                key={field.key}
                id={`edit-${field.key}`}
                label={field.label}
                type={field.type ?? "text"}
                error={errors[field.key]?.message}
                readOnly={
                  resource === "schools" &&
                  editing !== "new" &&
                  ["code", "ownerEmail"].includes(field.key)
                }
                {...register(field.key)}
              />
            ),
          )}
          <button type="submit" className="sr-only" tabIndex={-1}>
            Save
          </button>
        </form>
      </NeuModal>
      <ConfirmDialog
        open={!!pendingDelete}
        onClose={() => setPendingDelete(null)}
        onConfirm={() => void remove()}
        title="Delete this record?"
        description="This removes the record and writes an audit event. This action cannot be undone in the app."
        confirmText={
          pendingDelete
            ? getValue(pendingDelete, "name") ||
              getValue(pendingDelete, "reference")
            : ""
        }
        loading={busy}
      />
      <ConfirmDialog
        open={!!action}
        onClose={() => setAction(null)}
        title={
          action?.status === "Suspended"
            ? "Revoke school access?"
            : action?.status === "Deleted"
              ? "Remove school access?"
              : "Restore school access?"
        }
        description="The school’s records are retained. Suspended schools cannot sign in or read protected data."
        confirmText={action?.school.code}
        loading={busy}
        onConfirm={() => {
          if (!action) return;
          setBusy(true);
          void getAdminRepository()
            .then((repo) =>
              repo.save("schools", { ...action.school, status: action.status }),
            )
            .then(async () => {
              setAction(null);
              await refreshAdmin();
              toast.success("School access updated");
            })
            .catch((error) =>
              toast.error(
                error instanceof Error ? error.message : "Update failed",
              ),
            )
            .finally(() => setBusy(false));
        }}
      />
      <NeuModal
        open={importOpen}
        onClose={() => !busy && setImportOpen(false)}
        title="Import your school community"
        description="CSV columns: name,email,role,branchId,phone,status. Required: name,email,role,branchId. Up to 250 rows."
        footer={
          importRows.length > 0 && (
            <NeuButton
              variant="primary"
              loading={busy}
              onClick={() => void confirmImport()}
            >
              Import {importRows.length} validated records
            </NeuButton>
          )
        }
      >
        <NeuButton
          variant="ghost"
          onClick={() =>
            downloadCsv(
              "people-import-template.csv",
              ["name", "email", "role", "branchId", "phone", "status"],
              [
                [
                  "Sample Student",
                  "student@example.edu",
                  "student",
                  campuses.data?.rows[0]?.id ?? "",
                  "",
                  "Active",
                ],
              ],
            )
          }
        >
          Download CSV template
          <Icon name="download" size={16} />
        </NeuButton>
        <FileUpload accept=".csv" onUpload={importCsv} />
        {importRows.length > 0 && (
          <div className="import-preview">
            <b>{importRows.length} records validated</b>
            {importRows.slice(0, 5).map((row) => (
              <p key={row.id}>
                {row.name} · {row.email}
              </p>
            ))}
          </div>
        )}
      </NeuModal>
      <NeuModal
        open={!!receipt}
        onClose={() => setReceipt(null)}
        title="Your school is ready"
        description="These credentials are shown once. Copy them before closing."
      >
        {receipt && (
          <div className="credentials">
            <NeuInput
              label="Owner login"
              id="new-owner-email"
              readOnly
              value={receipt.email}
            />
            <NeuInput
              label="Generated password"
              id="new-owner-password"
              readOnly
              value={receipt.password}
            />
            <NeuButton
              icon="copy"
              onClick={() => {
                void navigator.clipboard
                  .writeText(
                    `Email: ${receipt.email}\nPassword: ${receipt.password}`,
                  )
                  .then(() => toast.success("Credentials copied"))
                  .catch(() =>
                    toast.error("Select and copy the credentials manually."),
                  );
              }}
            >
              Copy credentials
            </NeuButton>
          </div>
        )}
      </NeuModal>
    </>
  );
}

````

## src/features/owner/Settings.tsx

````tsx
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "react-router-dom";
import { useAuth } from "../../store/auth";
import { useUI } from "../../store/ui";
import { useAdminList, useAdminSave } from "../../hooks/useAdmin";
import { AdminHeading, QueryState } from "./shared";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuInput,
  NeuSelect,
  NeuToggle,
} from "../../components/ui/primitives";
import { ConfirmDialog } from "../../components/ui/overlays";
import { FileUpload } from "../../components/ui/FileUpload";
import { Icon } from "../../components/ui/Icon";
import { getRepository } from "../../services";
import { adminSchemas, type AdminModels } from "../../types/admin";
import { config } from "../../lib/config";
const schema = adminSchemas.settings.extend({
  senderNumber: z
    .string()
    .regex(
      /^\+[1-9]\d{7,14}$/,
      "Use an international number, such as +919845001234.",
    ),
  academicYear: z.string().min(4, "Enter an academic year."),
});
export default function Settings({ security = false }: { security?: boolean }) {
  const profile = useAuth((s) => s.profile)!;
  const branchId = useUI((s) => s.branchId);
  const query = useAdminList("settings", { schoolId: profile.schoolId });
  const save = useAdminSave("settings");
  const [overrideConfirm, setOverrideConfirm] = useState(false);
  const {
    register,
    reset,
    watch,
    setValue,
    handleSubmit,
    formState: { errors, isDirty },
  } = useForm<AdminModels["settings"]>({ resolver: zodResolver(schema) });
  useEffect(() => {
    if (query.data && !isDirty)
      reset(
        query.data.rows[0] ?? {
          id: crypto.randomUUID(),
          schoolId: profile.schoolId,
          branchId: null,
          version: 1,
          name: "Your school",
          academicYear: "2026–2027",
          logoPath: "",
          senderNumber: "+919000000000",
          financeRole: "accountant",
          overrideEnabled: false,
          requireMfa: false,
          sessionMinutes: 60,
          privacyEmail: profile.email,
          retentionDays: 365,
        },
      );
  }, [query.data, profile, reset, isDirty]);
  const submit = handleSubmit(async (record) => {
    const result = await save.mutateAsync(record);
    reset(result);
  });
  return (
    <>
      <AdminHeading
        title={
          security
            ? "Security, with peace of mind"
            : "Make your school’s workspace its own"
        }
        description={
          security
            ? "Manage session policy, privacy contacts, and access overrides."
            : "Branding, academic year, communication, and financial responsibilities."
        }
      >
        <NeuButton
          variant="primary"
          icon="check"
          loading={save.isPending}
          disabled={!isDirty}
          onClick={() => void submit().catch(() => undefined)}
        >
          Save settings
        </NeuButton>
      </AdminHeading>
      <QueryState query={query}>
        {() => (
          <form className="settings-grid" onSubmit={submit}>
            {!security ? (
              <>
                <NeuCard>
                  <div className="section-heading">
                    <h2>School identity</h2>
                    <Icon name="building" />
                  </div>
                  <div className="admin-form">
                    <NeuInput
                      id="school-name"
                      label="School name"
                      error={errors.name?.message}
                      {...register("name")}
                    />
                    <NeuInput
                      id="academic-year"
                      label="Academic year"
                      error={errors.academicYear?.message}
                      {...register("academicYear")}
                    />
                    <FileUpload
                      accept=".png,.jpg,.jpeg"
                      onUpload={async (file) => {
                        const path = await (
                          await getRepository()
                        ).storage.upload(file, branchId);
                        setValue("logoPath", path, { shouldDirty: true });
                      }}
                    />
                    {watch("logoPath") && (
                      <small>
                        Logo uploaded: {watch("logoPath")?.split("/").at(-1)}
                      </small>
                    )}
                  </div>
                </NeuCard>
                <NeuCard>
                  <div className="section-heading">
                    <h2>School communication</h2>
                    <NeuBadge>Owner access</NeuBadge>
                  </div>
                  <div className="admin-form">
                    <NeuInput
                      id="sender-number"
                      label="WhatsApp sender number"
                      hint="Changing this configuration does not connect or verify a WhatsApp account. Connection is delivered in Phase 5."
                      error={errors.senderNumber?.message}
                      {...register("senderNumber")}
                    />
                    <Link className="neu-button" to="/owner/templates">
                      <Icon name="message" />
                      Manage WhatsApp templates
                    </Link>
                    <NeuSelect
                      id="finance-role"
                      label="Default financial role"
                      {...register("financeRole")}
                    >
                      <option value="accountant">Office / Accountant</option>
                      <option value="owner">Owner only</option>
                    </NeuSelect>
                    <Link className="text-button" to="/owner/people">
                      Assign financial roles in People & access
                      <Icon name="arrow-up-right" size={16} />
                    </Link>
                  </div>
                </NeuCard>
              </>
            ) : (
              <>
                <NeuCard>
                  <div className="section-heading">
                    <h2>Session & access policy</h2>
                    <Icon name="shield" />
                  </div>
                  <div className="admin-form">
                    <NeuSelect
                      id="session-timeout"
                      label="Idle session timeout"
                      {...register("sessionMinutes", { valueAsNumber: true })}
                    >
                      {[15, 30, 60, 120, 240, 480].map((n) => (
                        <option value={n} key={n}>
                          {n} minutes
                        </option>
                      ))}
                    </NeuSelect>
                    <NeuToggle
                      label="Owner permission override"
                      description="Allow the Owner to bypass school module restrictions. Tenant and platform boundaries always apply."
                      checked={watch("overrideEnabled") ?? false}
                      onChange={(value) =>
                        value
                          ? setOverrideConfirm(true)
                          : setValue("overrideEnabled", false, {
                              shouldDirty: true,
                            })
                      }
                    />
                    <div className="info-note">
                      <Icon name="lock" size={18} />
                      <p>
                        Roles come from trusted Auth metadata and provisioned
                        profiles. This screen cannot grant platform
                        administration or access to another school.
                      </p>
                    </div>
                  </div>
                </NeuCard>
                <NeuCard>
                  <div className="section-heading">
                    <h2>Privacy preferences</h2>
                    <Icon name="heart" />
                  </div>
                  <div className="admin-form">
                    <NeuInput
                      label="Privacy contact email"
                      id="privacy-email"
                      type="email"
                      error={errors.privacyEmail?.message}
                      {...register("privacyEmail")}
                    />
                    <NeuInput
                      label="Requested retention period (days)"
                      id="retention-days"
                      type="number"
                      hint="Records are retained until your administrator applies the retention policy. This preference does not schedule deletion."
                      error={errors.retentionDays?.message}
                      {...register("retentionDays", { valueAsNumber: true })}
                    />
                    <NeuBadge tone="success">
                      Private storage · tenant-scoped data
                    </NeuBadge>
                    <p className="module-footnote">
                      {config.mock
                        ? "You are in a local demonstration workspace. Use fictional data only."
                        : "Use the audit trail to review access and configuration changes."}
                    </p>
                  </div>
                </NeuCard>
              </>
            )}
            <button type="submit" className="sr-only" tabIndex={-1}>
              Save settings
            </button>
          </form>
        )}
      </QueryState>
      <ConfirmDialog
        open={overrideConfirm}
        onClose={() => setOverrideConfirm(false)}
        title="Enable the Owner override?"
        description="This setting grants broad access within your school. It does not bypass database tenancy or platform restrictions. Save the settings to apply it."
        confirmText="ENABLE OVERRIDE"
        onConfirm={() => {
          setValue("overrideEnabled", true, { shouldDirty: true });
          setOverrideConfirm(false);
        }}
      />
    </>
  );
}

````

## src/features/owner/ViewAs.tsx

````tsx
import { useState } from "react";
import { useAuth } from "../../store/auth";
import { useUI } from "../../store/ui";
import { useAdminList } from "../../hooks/useAdmin";
import { AdminHeading } from "./shared";
import {
  NeuBadge,
  NeuCard,
  NeuSelect,
  StatCard,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { roleLabels } from "../../lib/permissions";
import { workspaces } from "../../mocks/data";
import { hasPermission } from "../../lib/permissions";
import type { Role } from "../../types/domain";
export default function ViewAs() {
  const profile = useAuth((s) => s.profile)!;
  const branchId = useUI((s) => s.branchId);
  const [role, setRole] = useState<Role>("principal");
  const [child, setChild] = useState("");
  const users = useAdminList(
    "users",
    { schoolId: profile.schoolId, branchId },
    { pageSize: 500 },
  );
  const finance = useAdminList(
    "finance",
    { schoolId: profile.schoolId, branchId },
    { pageSize: 500 },
  );
  const students = users.data?.rows.filter((u) => u.role === "student") ?? [];
  const selectedChild = students.find((u) => u.id === child) ?? students[0];
  return (
    <>
      <AdminHeading
        title="A different view. The same community."
        description="Inspect a role’s workspace foundation without changing your account or permissions."
      >
        <NeuSelect
          aria-label="Preview role"
          value={role}
          onChange={(e) => setRole(e.target.value as Role)}
        >
          {(["principal", "teacher", "parent", "accountant"] as const).map(
            (value) => (
              <option key={value} value={value}>
                {roleLabels[value]}
              </option>
            ),
          )}
        </NeuSelect>
      </AdminHeading>
      <div className="readonly-banner">
        <Icon name="eye" />
        <div>
          <b>Read-only role preview · {roleLabels[role]}</b>
          <p>
            Your Owner session stays active. No mutations or messages can be
            made from this preview.
          </p>
        </div>
        <NeuBadge>READ ONLY</NeuBadge>
      </div>
      <NeuCard className="role-preview-heading">
        <span className="icon-tile">
          <Icon
            name={
              role === "accountant"
                ? "wallet"
                : role === "parent"
                  ? "heart"
                  : "graduation"
            }
            size={28}
          />
        </span>
        <div>
          <h2>{roleLabels[role]} workspace</h2>
          <p>Selected campus · role-scoped workflow preview</p>
        </div>
        {role === "parent" && (
          <NeuSelect
            aria-label="Preview child"
            value={selectedChild?.id ?? ""}
            onChange={(e) => setChild(e.target.value)}
          >
            {students.map((student) => (
              <option key={student.id} value={student.id}>
                {student.name}
              </option>
            ))}
          </NeuSelect>
        )}
      </NeuCard>
      <div className="admin-stat-grid">
        {role === "accountant" ? (
          <>
            <StatCard
              label="Paid income"
              value={
                finance.data?.rows
                  .filter((r) => r.kind === "Income" && r.status === "Paid")
                  .reduce((n, r) => n + r.amount, 0) ?? 0
              }
              suffix=" INR"
              icon="wallet"
            />
            <StatCard
              label="Pending transactions"
              value={
                finance.data?.rows.filter((r) => r.status !== "Paid").length ??
                0
              }
              icon="clock"
            />
          </>
        ) : (
          <>
            <StatCard
              label={
                role === "parent" ? "Selected child" : "Students at this campus"
              }
              value={
                role === "parent" ? (selectedChild ? 1 : 0) : students.length
              }
              icon="graduation"
              detail={
                role === "parent"
                  ? (selectedChild?.name ?? "No student records")
                  : "Directory records only"
              }
            />
            <StatCard
              label="Teaching faculty"
              value={
                users.data?.rows.filter((u) => u.role === "teacher").length ?? 0
              }
              icon="users"
            />
          </>
        )}
      </div>
      <div className="directory-grid">
        {workspaces
          .filter((tool) => hasPermission(role, tool.permission))
          .map((tool) => (
            <NeuCard key={tool.id}>
              <div className="section-heading">
                <Icon name={tool.icon} />
                <NeuBadge>Phase {tool.phase}</NeuBadge>
              </div>
              <h3>{tool.name}</h3>
              <p>{tool.description}</p>
            </NeuCard>
          ))}
      </div>
      <p className="module-footnote">
        Principal and Teacher modules arrive in Phase 3; Parent and Accountant
        modules in Phase 4. This preview exposes only the Phase 1 foundation and
        existing Owner summary data.
      </p>
    </>
  );
}

````

## src/features/owner/shared.tsx

````tsx
import type { ReactNode } from "react";
import {
  NeuBadge,
  NeuButton,
  Skeleton,
  ErrorState,
} from "../../components/ui/primitives";
import type { UseQueryResult } from "@tanstack/react-query";
import type { AdminPage } from "../../types/admin";
export function AdminHeading({
  eyebrow = "SCHOOL MANAGEMENT",
  title,
  description,
  children,
}: {
  eyebrow?: string;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      <div className="admin-heading-actions">{children}</div>
    </div>
  );
}
export function QueryState<T>({
  query,
  children,
}: {
  query: UseQueryResult<AdminPage<T>, Error>;
  children: (data: AdminPage<T>) => ReactNode;
}) {
  if (query.isPending)
    return (
      <div className="admin-loading">
        <Skeleton className="title-skeleton" />
        <Skeleton className="hero-skeleton" />
      </div>
    );
  if (query.isError)
    return (
      <ErrorState
        description={query.error.message}
        onRetry={() => void query.refetch()}
      />
    );
  return children(query.data);
}
export function Pagination({
  page,
  setPage,
  total,
  size = 12,
}: {
  page: number;
  setPage: (page: number) => void;
  total: number;
  size?: number;
}) {
  return (
    <div className="pagination">
      <span>
        {total ? page * size + 1 : 0}–{Math.min((page + 1) * size, total)} of{" "}
        {total}
      </span>
      <NeuButton
        variant="ghost"
        icon="left"
        aria-label="Previous page"
        disabled={page === 0}
        onClick={() => setPage(page - 1)}
      />
      <NeuBadge>Page {page + 1}</NeuBadge>
      <NeuButton
        variant="ghost"
        icon="right"
        aria-label="Next page"
        disabled={(page + 1) * size >= total}
        onClick={() => setPage(page + 1)}
      />
    </div>
  );
}

````

## src/features/system/ComponentLibrary.tsx

````tsx
import { useMemo, useState } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { toast } from "sonner";
import {
  NeuAvatar,
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuCheckbox,
  NeuInput,
  NeuProgress,
  NeuRadio,
  NeuSelect,
  NeuTabs,
  NeuToggle,
  SearchBar,
  DatePicker,
  StatCard,
  EmptyState,
  ErrorState,
  Skeleton,
  ThemeToggle,
} from "../../components/ui/primitives";
import {
  NeuModal,
  NeuDrawer,
  ConfirmDialog,
} from "../../components/ui/overlays";
import { NeuTable } from "../../components/ui/NeuTable";
import { FileUpload } from "../../components/ui/FileUpload";
import { Icon } from "../../components/ui/Icon";
type Sample = {
  id: string;
  name: string;
  email: string;
  role: string;
  status: string;
};
const initialRows: Sample[] = [
  {
    id: "1",
    name: "Sarah Williams",
    email: "sarah@greenwood.edu",
    role: "Principal",
    status: "Active",
  },
  {
    id: "2",
    name: "James Wilson",
    email: "james@greenwood.edu",
    role: "Teacher",
    status: "Active",
  },
  {
    id: "3",
    name: "Priya Sharma",
    email: "priya@greenwood.edu",
    role: "Parent",
    status: "Invited",
  },
];
const tabs = [
  { value: "controls", label: "Controls" },
  { value: "data", label: "Data & feedback" },
  { value: "overlays", label: "Overlays" },
] as const;
export default function ComponentLibrary() {
  const [tab, setTab] = useState<(typeof tabs)[number]["value"]>("controls");
  const [toggle, setToggle] = useState(true);
  const [checked, setChecked] = useState(true);
  const [radio, setRadio] = useState("daily");
  const [date, setDate] = useState("2026-10-31");
  const [search, setSearch] = useState("");
  const [overlay, setOverlay] = useState<"modal" | "drawer" | "confirm" | null>(
    null,
  );
  const [rows, setRows] = useState(initialRows);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(64);
  const columns = useMemo<ColumnDef<Sample, unknown>[]>(
    () => [
      {
        accessorKey: "name",
        header: "Name",
        cell: (info) => (
          <div className="table-person">
            <NeuAvatar name={String(info.getValue())} size="sm" />
            <span>
              <b>{String(info.getValue())}</b>
              <small>{info.row.original.email}</small>
            </span>
          </div>
        ),
      },
      { accessorKey: "role", header: "Role" },
      {
        accessorKey: "status",
        header: "Status",
        cell: (info) => (
          <NeuBadge tone={info.getValue() === "Active" ? "success" : "warning"}>
            {String(info.getValue())}
          </NeuBadge>
        ),
      },
    ],
    [],
  );
  const previewLoading = async () => {
    setLoading(true);
    await new Promise<void>((resolve) => setTimeout(resolve, 1000));
    setLoading(false);
    toast.success("All set. A little feedback goes a long way.");
  };
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">THE CAMPUS DESIGN LANGUAGE</div>
          <h1>Thoughtful by design</h1>
          <p>Soft surfaces. Clear interactions. One consistent experience.</p>
        </div>
        <ThemeToggle />
      </div>
      <div className="library-header">
        <NeuTabs
          tabs={tabs}
          value={tab}
          onChange={setTab}
          label="Component group"
        />
        <NeuBadge>Interactive component library</NeuBadge>
      </div>
      {tab === "controls" && (
        <div className="library-grid">
          <NeuCard>
            <div className="section-heading">
              <h2>Buttons</h2>
              <NeuBadge>01</NeuBadge>
            </div>
            <p className="muted">A clear action, with a reassuring press.</p>
            <div className="component-row">
              <NeuButton
                variant="primary"
                icon="plus"
                onClick={() => toast.success("Primary action selected")}
              >
                Primary action
              </NeuButton>
              <NeuButton
                onClick={() => toast.info("Secondary action selected")}
              >
                Secondary
              </NeuButton>
              <NeuButton
                variant="ghost"
                onClick={() => toast.info("Ghost action selected")}
              >
                Ghost action
              </NeuButton>
              <NeuButton
                variant="icon"
                icon="heart"
                aria-label="Like this design"
                onClick={() =>
                  toast.success("A little love for thoughtful design")
                }
              />
              <NeuButton disabled>Disabled</NeuButton>
              <NeuButton
                loading={loading}
                onClick={() => void previewLoading()}
              >
                Try loading
              </NeuButton>
            </div>
          </NeuCard>
          <NeuCard>
            <div className="section-heading">
              <h2>Inputs & selection</h2>
              <NeuBadge>02</NeuBadge>
            </div>
            <div className="component-form">
              <NeuInput
                label="School email"
                id="sample-email"
                type="email"
                placeholder="you@school.edu"
                icon="mail"
                hint="Use the email your school assigned you."
              />
              <NeuSelect label="Campus" id="sample-campus" defaultValue="north">
                <option value="north">North Campus</option>
                <option value="central">Central Campus</option>
              </NeuSelect>
              <DatePicker
                label="Selected date"
                value={date}
                onChange={setDate}
              />
              <NeuInput
                label="Validation feedback"
                id="sample-invalid"
                defaultValue="sarah@"
                error="Enter a complete email address."
              />
            </div>
          </NeuCard>
          <NeuCard>
            <div className="section-heading">
              <h2>Choices & toggles</h2>
              <NeuBadge>03</NeuBadge>
            </div>
            <NeuToggle
              checked={toggle}
              onChange={setToggle}
              label="School updates"
              description="A switch with a clear on and off state."
            />
            <div className="component-row">
              <NeuCheckbox
                label="Remember this device"
                checked={checked}
                onChange={(e) => setChecked(e.target.checked)}
              />
              <NeuRadio
                name="sample-frequency"
                label="Daily"
                checked={radio === "daily"}
                onChange={() => setRadio("daily")}
              />
              <NeuRadio
                name="sample-frequency"
                label="Weekly"
                checked={radio === "weekly"}
                onChange={() => setRadio("weekly")}
              />
            </div>
          </NeuCard>
          <NeuCard>
            <div className="section-heading">
              <h2>People & status</h2>
              <NeuBadge>04</NeuBadge>
            </div>
            <div className="component-row">
              <NeuAvatar name="Sarah Williams" size="lg" />
              <NeuAvatar name="James Wilson" />
              <NeuAvatar name="Priya Sharma" size="sm" />
            </div>
            <div className="component-row">
              <NeuBadge tone="success">Active</NeuBadge>
              <NeuBadge tone="warning">Pending</NeuBadge>
              <NeuBadge tone="accent">School admin</NeuBadge>
              <NeuBadge>Default</NeuBadge>
            </div>
            <NeuProgress value={progress} label="Your progress" />
            <NeuButton
              variant="ghost"
              onClick={() =>
                setProgress((v) => (v >= 100 ? 0 : Math.min(v + 12, 100)))
              }
            >
              Advance progress
              <Icon name="arrow-right" size={15} />
            </NeuButton>
          </NeuCard>
        </div>
      )}
      {tab === "data" && (
        <div className="library-data">
          <div className="stat-grid">
            <StatCard
              label="Sample records"
              value={rows.length}
              icon="users"
              detail="Component demonstration data"
            />
            <StatCard
              label="Workspace readiness"
              value={100}
              suffix="%"
              icon="shield"
              detail="Phase 1 foundation"
            />
          </div>
          <NeuCard>
            <div className="section-heading">
              <div>
                <h2>A clearer view of your data</h2>
                <p>
                  Sortable columns. Cards on mobile. Virtualized above 100 rows.
                </p>
              </div>
              <NeuButton
                variant="ghost"
                onClick={() =>
                  setRows(
                    rows.length > 100
                      ? initialRows
                      : Array.from({ length: 250 }, (_, i) => ({
                          ...initialRows[i % 3]!,
                          id: String(i),
                          name: `${initialRows[i % 3]!.name} ${i + 1}`,
                        })),
                  )
                }
              >
                {rows.length > 100 ? "Use 3 rows" : "Try 250 rows"}
              </NeuButton>
            </div>
            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search demo people…"
              label="Search sample records"
            />
            <NeuTable
              data={rows.filter((row) =>
                `${row.name} ${row.role}`
                  .toLowerCase()
                  .includes(search.toLowerCase()),
              )}
              columns={columns}
              label="Demo school community"
              rowKey={(row) => row.id}
              renderMobile={(row) => (
                <div className="mobile-person">
                  <NeuAvatar name={row.name} />
                  <span>
                    <b>{row.name}</b>
                    <small>{row.role}</small>
                  </span>
                  <NeuBadge tone="success">{row.status}</NeuBadge>
                </div>
              )}
            />
          </NeuCard>
          <div className="library-grid">
            <NeuCard>
              <h2>Loading gracefully</h2>
              <div className="skeleton-demo">
                <Skeleton className="line-skeleton" />
                <Skeleton className="card-skeleton" />
                <Skeleton className="line-skeleton short" />
              </div>
            </NeuCard>
            <NeuCard>
              <EmptyState
                title="A fresh start"
                description="New records will appear here when they’re added."
              />
            </NeuCard>
            <NeuCard>
              <ErrorState
                description="This is a sample recoverable error state."
                onRetry={() => toast.success("Retry action received")}
              />
            </NeuCard>
            <NeuCard>
              <h2>Files, made simple</h2>
              <p className="muted">
                Demo only: validates your file locally without storing it.
              </p>
              <FileUpload
                onUpload={async (file) => {
                  await new Promise<void>((resolve) =>
                    setTimeout(resolve, 400),
                  );
                  toast.success(
                    `${file.name} passed local validation. No file was stored.`,
                  );
                }}
              />
            </NeuCard>
          </div>
        </div>
      )}
      {tab === "overlays" && (
        <div className="library-grid">
          <NeuCard>
            <span className="icon-tile">
              <Icon name="layers" size={26} />
            </span>
            <h2>A focused conversation</h2>
            <p className="muted">
              A modal with focus trapping, Escape dismissal, and focus
              restoration.
            </p>
            <NeuButton onClick={() => setOverlay("modal")}>
              Open modal
            </NeuButton>
          </NeuCard>
          <NeuCard>
            <span className="icon-tile">
              <Icon name="menu" size={26} />
            </span>
            <h2>A little more space</h2>
            <p className="muted">
              A drawer that stays close to your current task.
            </p>
            <NeuButton onClick={() => setOverlay("drawer")}>
              Open drawer
            </NeuButton>
          </NeuCard>
          <NeuCard>
            <span className="icon-tile">
              <Icon name="shield" size={26} />
            </span>
            <h2>A considered decision</h2>
            <p className="muted">
              Type to confirm a destructive action. This demo removes no data.
            </p>
            <NeuButton onClick={() => setOverlay("confirm")}>
              Try confirmation
            </NeuButton>
          </NeuCard>
        </div>
      )}
      <NeuModal
        open={overlay === "modal"}
        onClose={() => setOverlay(null)}
        title="A little focus goes a long way"
        description="Everything you need, right where you are."
        footer={
          <NeuButton
            variant="primary"
            onClick={() => {
              setOverlay(null);
              toast.success("Changes confirmed");
            }}
          >
            Looks good
            <Icon name="check" size={16} />
          </NeuButton>
        }
      >
        <NeuInput
          label="A note for your school"
          id="modal-note"
          placeholder="What’s on your mind?"
        />
      </NeuModal>
      <NeuDrawer
        open={overlay === "drawer"}
        onClose={() => setOverlay(null)}
        title="Details, close at hand"
        description="A companion to your main workspace."
      >
        <NeuInput
          label="Quick note"
          id="drawer-note"
          placeholder="Add a thought…"
        />
        <NeuButton
          variant="primary"
          onClick={() => {
            setOverlay(null);
            toast.success("Note demo completed");
          }}
        >
          Done
        </NeuButton>
      </NeuDrawer>
      <ConfirmDialog
        open={overlay === "confirm"}
        onClose={() => setOverlay(null)}
        onConfirm={() => {
          setOverlay(null);
          toast.success("Confirmation matched. No records were removed.");
        }}
        title="Try a careful confirmation"
        description="This is a safe demonstration. Type the phrase below to confirm."
        confirmText="CONFIRM"
      />
    </>
  );
}

````

## src/features/system/Preferences.tsx

````tsx
import {
  NeuAvatar,
  NeuBadge,
  NeuCard,
  NeuRadio,
  NeuToggle,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { useUI, type ThemeChoice } from "../../store/ui";
import { useAuth } from "../../store/auth";
import { roleLabels } from "../../lib/permissions";
import { toast } from "sonner";
export default function Preferences() {
  const { theme, setTheme, emailUpdates, inAppUpdates, setPreference } =
    useUI();
  const profile = useAuth((s) => s.profile)!;
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">MAKE IT YOURS</div>
          <h1>A workspace that feels like you</h1>
          <p>A few thoughtful preferences for your everyday.</p>
        </div>
        <NeuBadge tone="success">
          <Icon name="check" size={13} />
          Saved automatically
        </NeuBadge>
      </div>
      <div className="preferences-grid">
        <NeuCard>
          <div className="section-heading">
            <h2>Your profile</h2>
            <Icon name="user" />
          </div>
          <div className="profile-summary">
            <NeuAvatar name={profile.name} size="lg" />
            <h3>{profile.name}</h3>
            <p>{profile.email}</p>
            <NeuBadge>{roleLabels[profile.role]}</NeuBadge>
          </div>
          <div className="info-note">
            <Icon name="lock" size={17} />
            <p>
              Your school manages your profile, role, and campus assignments.
              Contact your administrator to request a change.
            </p>
          </div>
        </NeuCard>
        <div className="preference-stack">
          <NeuCard>
            <div className="section-heading">
              <div>
                <h2>A familiar look</h2>
                <p>Choose the light that works for you.</p>
              </div>
              <Icon name="palette" />
            </div>
            <div className="theme-options">
              {(
                [
                  { value: "light", label: "Light", icon: "sun" },
                  { value: "dark", label: "Dark", icon: "moon" },
                  { value: "system", label: "Use system", icon: "monitor" },
                ] as const
              ).map((option) => (
                <div
                  className={`theme-option ${theme === option.value ? "selected" : ""}`}
                  key={option.value}
                >
                  <Icon name={option.icon} size={26} />
                  <NeuRadio
                    name="theme"
                    label={option.label}
                    checked={theme === option.value}
                    onChange={() => setTheme(option.value as ThemeChoice)}
                  />
                </div>
              ))}
            </div>
          </NeuCard>
          <NeuCard>
            <div className="section-heading">
              <div>
                <h2>Your notification preferences</h2>
                <p>Saved on this device for your next visit.</p>
              </div>
              <Icon name="bell" />
            </div>
            <NeuToggle
              checked={inAppUpdates}
              onChange={(value) => {
                setPreference("inAppUpdates", value);
                toast.success("Preference saved on this device");
              }}
              label="In-app notification highlights"
              description="Show unread highlights in your workspace."
            />
            <NeuToggle
              checked={emailUpdates}
              onChange={(value) => {
                setPreference("emailUpdates", value);
                toast.success("Preference saved on this device");
              }}
              label="Email update preference"
              description="Your preference is saved locally; email delivery settings arrive with system controls."
            />
          </NeuCard>
        </div>
      </div>
    </>
  );
}

````

## src/features/workspace/Directory.tsx

````tsx
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuTabs,
  SearchBar,
  EmptyState,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { Icon } from "../../components/ui/Icon";
import { workspaces } from "../../mocks/data";
import { useAccess } from "../../hooks/useAccess";
import { useAuth } from "../../store/auth";
import { useDebounce } from "../../hooks/useDebounce";
import type { Workspace } from "../../types/domain";
const tabs = [
  { value: "All", label: "All tools" },
  { value: "Community", label: "Community" },
  { value: "Academics", label: "Academics" },
  { value: "Operations", label: "Operations" },
  { value: "System", label: "System" },
] as const;
export default function Directory() {
  const profile = useAuth((s) => s.profile)!;
  const navigate = useNavigate();
  const { can } = useAccess();
  const modulePaths: Record<string, string> = {
    people: "people",
    branches: "branches",
    finance: "finance",
    system: "settings",
  };
  const [filter, setFilter] = useState<(typeof tabs)[number]["value"]>("All");
  const [search, setSearch] = useState("");
  const query = useDebounce(search);
  const [selected, setSelected] = useState<Workspace | null>(null);
  const filtered = useMemo(
    () =>
      workspaces.filter(
        (tool) =>
          (filter === "All" || filter === tool.category) &&
          `${tool.name} ${tool.description}`
            .toLowerCase()
            .includes(query.toLowerCase()),
      ),
    [filter, query],
  );
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">FIND YOUR WAY</div>
          <h1>Your workspace directory</h1>
          <p>A place for every part of your school day.</p>
        </div>
        <NeuBadge>
          Phase {profile.role === "owner" || profile.role === "master" ? 2 : 1}{" "}
          workspace
        </NeuBadge>
      </div>
      <div className="directory-toolbar">
        <NeuTabs
          tabs={tabs}
          value={filter}
          onChange={setFilter}
          label="Module category"
        />
        <SearchBar
          value={search}
          onChange={setSearch}
          placeholder="Find a tool…"
          label="Search workspace tools"
        />
      </div>
      <p className="directory-note">
        <Icon name="help" size={17} />
        Modules are delivered in phases. Your role determines which tools you
        can access.
      </p>
      <div className="directory-grid">
        {filtered.map((tool) => {
          const allowed = can(tool.permission);
          const ready =
            allowed && profile.role === "owner" && !!modulePaths[tool.id];
          return (
            <NeuCard
              key={tool.id}
              className={`workspace-tool ${allowed ? "" : "restricted-tool"}`}
            >
              <div className="tool-top">
                <span className="icon-tile">
                  <Icon name={tool.icon} size={26} />
                </span>
                <NeuBadge tone={allowed ? "accent" : "neutral"}>
                  {allowed ? (
                    ready ? (
                      "Available"
                    ) : (
                      `Phase ${tool.phase}`
                    )
                  ) : (
                    <>
                      <Icon name="lock" size={12} />
                      Restricted
                    </>
                  )}
                </NeuBadge>
              </div>
              <small className="eyebrow">{tool.category}</small>
              <h3>{tool.name}</h3>
              <p>{tool.description}</p>
              <NeuButton
                variant="ghost"
                onClick={() =>
                  ready
                    ? navigate(`/owner/${modulePaths[tool.id]}`)
                    : setSelected(tool)
                }
              >
                {ready
                  ? "Open module"
                  : allowed
                    ? "View module details"
                    : "View access details"}
                <Icon name={allowed ? "arrow-up-right" : "lock"} size={16} />
              </NeuButton>
            </NeuCard>
          );
        })}
      </div>
      {!filtered.length && (
        <EmptyState
          title="No tools found"
          description="Try a different category or search term."
          action={
            <NeuButton
              onClick={() => {
                setFilter("All");
                setSearch("");
              }}
            >
              Clear filters
            </NeuButton>
          }
        />
      )}
      <NeuModal
        open={!!selected}
        onClose={() => setSelected(null)}
        title={selected?.name ?? "Module details"}
        description={selected?.description}
      >
        {selected && (
          <div className="module-details">
            <NeuBadge tone="accent">Phase {selected.phase}</NeuBadge>
            <h3>
              {can(selected.permission)
                ? "Included in your role"
                : "Your role doesn’t have access"}
            </h3>
            <p>
              {can(selected.permission)
                ? `This module will be implemented in Phase ${selected.phase}. Its foundation and permission boundary are ready.`
                : "This area contains information outside your assigned responsibilities. Contact your school administrator if your role needs to change."}
            </p>
            <p className="muted">
              Permissions are enforced by the live database. The directory
              describes access without exposing protected records.
            </p>
          </div>
        )}
      </NeuModal>
    </>
  );
}

````

## src/features/workspace/Overview.tsx

````tsx
import { Link, useOutletContext } from "react-router-dom";
import { format } from "date-fns";
import { motion } from "framer-motion";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuProgress,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { CampusIllustration } from "../../components/layout/CampusIllustration";
import { useAuth } from "../../store/auth";
import { hasPermission, homeFor, roleLabels } from "../../lib/permissions";
import { workspaces } from "../../mocks/data";
import type { Branch } from "../../types/domain";
import { useState } from "react";
import { NeuModal } from "../../components/ui/overlays";
export default function Overview() {
  const profile = useAuth((s) => s.profile)!;
  const { activeBranch, branches } = useOutletContext<{
    activeBranch?: Branch;
    branches: Branch[];
  }>();
  const [introOpen, setIntroOpen] = useState(false);
  const base = homeFor(profile.role);
  const tools = workspaces
    .filter((item) => hasPermission(profile.role, item.permission))
    .slice(0, 4);
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">YOUR WORKSPACE, AT A GLANCE</div>
          <h1>
            Hello, {profile.name.split(" ")[0]}{" "}
            <span className="greeting-dot">✦</span>
          </h1>
          <p>Good things happen when your school comes together.</p>
        </div>
        <div className="date-chip">
          <Icon name="calendar" size={17} />
          {format(new Date(), "EEE, dd MMM yyyy")}
        </div>
      </div>
      <NeuCard className="welcome-hero">
        <div className="welcome-copy">
          <NeuBadge tone="accent">
            <span className="status-dot" /> YOUR CONNECTED CAMPUS
          </NeuBadge>
          <h2>
            A place for everyone.
            <br />
            <span>Everything in its place.</span>
          </h2>
          <p>
            Less time finding things. More time moving your school
            <br className="desktop-break" /> forward. Welcome to your new
            everyday.
          </p>
          <Link to={`${base}/directory`} className="neu-button primary">
            Explore your workspace
            <Icon name="arrow-right" size={18} />
          </Link>
        </div>
        <CampusIllustration compact />
        <span className="hero-edition">SCHOOL MANAGEMENT SYSTEM · v3.0</span>
      </NeuCard>
      <div className="workspace-summary">
        <div>
          <span className="icon-tile small">
            <Icon name="building" />
          </span>
          <span>
            <small>YOUR CAMPUS</small>
            <b>{activeBranch?.short_name ?? "Campus not assigned"}</b>
          </span>
          <NeuBadge>{branches.length} assigned</NeuBadge>
        </div>
        <div>
          <span className="icon-tile small">
            <Icon name="shield" />
          </span>
          <span>
            <small>YOUR ACCESS</small>
            <b>{roleLabels[profile.role]}</b>
          </span>
        </div>
        <div>
          <span className="icon-tile small">
            <Icon name="layers" />
          </span>
          <span>
            <small>YOUR FOUNDATION</small>
            <b>Personalized & connected</b>
          </span>
          <span className="status-dot" />
        </div>
      </div>
      <div className="overview-columns">
        <section className="tools-section">
          <div className="section-heading">
            <div>
              <h2>Around your workspace</h2>
              <p>The right tools, for the way you work.</p>
            </div>
            <Link to={`${base}/directory`} className="text-button">
              View all
              <Icon name="arrow-right" size={15} />
            </Link>
          </div>
          <div className="workspace-grid">
            {tools.map((tool, i) => (
              <motion.div
                key={tool.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04, duration: 0.2 }}
              >
                <NeuCard className="workspace-tool">
                  <div className="tool-top">
                    <span className="icon-tile">
                      <Icon name={tool.icon} size={24} />
                    </span>
                    <NeuBadge>Phase {tool.phase}</NeuBadge>
                  </div>
                  <h3>{tool.name}</h3>
                  <p>{tool.description}</p>
                  <Link className="tool-link" to={`${base}/directory`}>
                    See what’s inside
                    <Icon name="arrow-up-right" size={16} />
                  </Link>
                </NeuCard>
              </motion.div>
            ))}
            {tools.length === 0 && (
              <NeuCard className="workspace-tool">
                <span className="icon-tile">
                  <Icon name="shield" size={24} />
                </span>
                <h3>Platform administration</h3>
                <p>
                  Your platform foundation is ready. School management and
                  revenue tools arrive in Phase 2.
                </p>
                <NeuBadge>Phase 2</NeuBadge>
              </NeuCard>
            )}
          </div>
        </section>
        <aside className="overview-right">
          <NeuCard className="getting-started">
            <div className="section-heading">
              <span className="icon-tile small">
                <Icon name="sparkles" />
              </span>
              <NeuBadge tone="success">LET’S BEGIN</NeuBadge>
            </div>
            <h2>Make yourself at home</h2>
            <p>Small steps. A smoother school day.</p>
            <NeuProgress value={33} label="Your workspace journey" />
            <div className="onboarding-list">
              <div className="completed">
                <span>
                  <Icon name="check" size={15} />
                </span>
                <div>
                  <b>Sign in to your workspace</b>
                  <small>You’re right where you belong.</small>
                </div>
              </div>
              <Link to={`${base}/preferences`}>
                <span>2</span>
                <div>
                  <b>Make it feel like you</b>
                  <small>Set your theme & preferences.</small>
                </div>
                <Icon name="right" size={14} />
              </Link>
              <Link to={`${base}/directory`}>
                <span>3</span>
                <div>
                  <b>Get to know your tools</b>
                  <small>Find your way around.</small>
                </div>
                <Icon name="right" size={14} />
              </Link>
            </div>
            <NeuButton variant="ghost" onClick={() => setIntroOpen(true)}>
              A quick introduction
              <Icon name="arrow-right" size={16} />
            </NeuButton>
          </NeuCard>
          <div className="privacy-note">
            <span className="icon-tile small">
              <Icon name="shield" />
            </span>
            <div>
              <b>A little peace of mind</b>
              <p>
                Your workspace is tailored to your role. Your school’s data
                stays in the right hands.
              </p>
            </div>
          </div>
        </aside>
      </div>
      <div className="community-strip">
        <span className="icon-tile">
          <Icon name="heart" size={24} />
        </span>
        <div>
          <b>Behind every great school, there’s a connected community.</b>
          <p>You’re part of something that makes a difference, every day.</p>
        </div>
        <span>
          Let’s make it a good one. <Icon name="sparkles" size={18} />
        </span>
      </div>
      <NeuModal
        open={introOpen}
        onClose={() => setIntroOpen(false)}
        title="One workspace. Your whole school."
        description="Start with the essentials, then grow together."
      >
        <div className="intro-list">
          <p>
            <b>Smart.</b> Find tools from the directory or global search.
          </p>
          <p>
            <b>Secure.</b> Role permissions and campus assignments define your
            access.
          </p>
          <p>
            <b>Connected.</b> Stay up to date through your notification center.
          </p>
          <p className="muted">
            This is Phase 1. Each module in the directory shows the phase in
            which it will become available.
          </p>
        </div>
      </NeuModal>
    </>
  );
}

````

## src/features/workspace/StatusPage.tsx

````tsx
import { Link } from "react-router-dom";
import { Icon } from "../../components/ui/Icon";
import { useAuth } from "../../store/auth";
import { homeFor } from "../../lib/permissions";
export default function StatusPage({
  status,
}: {
  status: "401" | "403" | "404";
}) {
  const profile = useAuth((s) => s.profile);
  const content = {
    "401": [
      "Let’s get you signed in",
      "Sign in securely to access your school workspace.",
    ],
    "403": [
      "This space is restricted",
      "Your role or campus assignment doesn’t grant access to this workspace.",
    ],
    "404": [
      "A little off the timetable",
      "We couldn’t find this page. Your workspace is just a click away.",
    ],
  }[status];
  return (
    <div className="status-page">
      <span className="icon-tile">
        <Icon name={status === "404" ? "search" : "lock"} size={32} />
      </span>
      <span className="eyebrow">{status}</span>
      <h1>{content[0]}</h1>
      <p>{content[1]}</p>
      <Link
        className="neu-button primary"
        to={profile ? homeFor(profile.role) : "/login"}
      >
        <Icon name="arrow-left" size={18} />
        {profile ? "Back to my workspace" : "Go to sign in"}
      </Link>
    </div>
  );
}

````

## src/hooks/useAccess.ts

````ts
import { useAuth } from "../store/auth";
import { useAdminList } from "./useAdmin";
import { hasPermission, type Permission } from "../lib/permissions";
export function useAccess() {
  const profile = useAuth((s) => s.profile);
  const query = useAdminList(
    "roles",
    { schoolId: profile?.schoolId ?? "" },
    { pageSize: 500 },
    !!profile && profile.role !== "master",
  );
  const policy = query.data?.rows.find((row) =>
    profile?.policyId
      ? row.id === profile.policyId
      : row.role === profile?.role && !row.custom,
  );
  return {
    can: (permission: Permission) => {
      if (!profile) return false;
      if (profile.role === "owner" || profile.role === "master")
        return hasPermission(profile.role, permission);
      if (profile.policyId && !policy) return permission === "workspace.read";
      return policy
        ? policy.permissions.includes(permission)
        : hasPermission(profile.role, permission);
    },
  };
}

````

## src/hooks/useAdmin.ts

````ts
import { useMutation, useQuery } from "@tanstack/react-query";
import { getAdminRepository } from "../services/admin";
import { useAuth } from "../store/auth";
import { queryClient } from "../lib/query";
import { toast } from "sonner";
import type {
  AdminModels,
  AdminResource,
  AdminScope,
  ListOptions,
} from "../types/admin";
export function useAdminList<K extends AdminResource>(
  resource: K,
  scope: AdminScope,
  options: ListOptions = {},
  enabled = true,
) {
  const user = useAuth((s) => s.profile?.id);
  return useQuery({
    queryKey: [
      "admin",
      user,
      resource,
      scope.schoolId,
      scope.branchId ?? "all",
      options,
    ],
    queryFn: async () =>
      (await getAdminRepository()).list(resource, scope, options),
    enabled: !!user && enabled,
  });
}
export async function refreshAdmin() {
  await Promise.all([
    queryClient.invalidateQueries({ queryKey: ["admin"] }),
    queryClient.invalidateQueries({ queryKey: ["branches"] }),
  ]);
}
export function useAdminSave<
  K extends Exclude<AdminResource, "audit" | "analytics">,
>(resource: K) {
  return useMutation({
    mutationFn: async (record: AdminModels[K]) =>
      (await getAdminRepository()).save(resource, record),
    onSuccess: () => {
      void refreshAdmin();
      toast.success("Changes saved");
    },
    onError: (error) =>
      toast.error(
        error instanceof Error ? error.message : "Unable to save changes",
      ),
  });
}

````

## src/hooks/useDebounce.ts

````ts
import { useEffect, useState } from "react";
export function useDebounce<T>(value: T, delay = 300): T {
  const [result, setResult] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setResult(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return result;
}

````

## src/hooks/useIdleSession.ts

````ts
import { useEffect } from "react";
import { useAuth } from "../store/auth";
import { getRepository } from "../services";
import { queryClient } from "../lib/query";
export function useIdleSession(minutes: number) {
  const id = useAuth((s) => s.profile?.id);
  useEffect(() => {
    if (!id) return;
    let lastActivity = Date.now();
    let ending = false;
    const activity = () => {
      lastActivity = Date.now();
    };
    const expire = async () => {
      if (ending || Date.now() - lastActivity < minutes * 60000) return;
      ending = true;
      try {
        await (await getRepository()).auth.signOut();
        useAuth.getState().setProfile(null);
        useAuth.getState().setExpired(true);
        queryClient.clear();
      } catch {
        ending = false;
      }
    };
    const interval = setInterval(() => {
      void expire();
    }, 15000);
    window.addEventListener("pointerdown", activity, { passive: true });
    window.addEventListener("keydown", activity);
    return () => {
      clearInterval(interval);
      window.removeEventListener("pointerdown", activity);
      window.removeEventListener("keydown", activity);
    };
  }, [id, minutes]);
}

````

## src/hooks/usePermission.tsx

````tsx
import type { ReactNode } from "react";
import { type Permission } from "../lib/permissions";
import { useAccess } from "./useAccess";
export function usePermission(permission: Permission) {
  return useAccess().can(permission);
}
export function Can({
  permission,
  children,
  fallback = null,
}: {
  permission: Permission;
  children: ReactNode;
  fallback?: ReactNode;
}) {
  return usePermission(permission) ? children : fallback;
}

````

## src/hooks/useTheme.ts

````ts
import { useEffect, useState } from "react";
import { useUI } from "../store/ui";
export function useTheme() {
  const choice = useUI((s) => s.theme);
  const [systemDark, setSystemDark] = useState(
    () => matchMedia("(prefers-color-scheme: dark)").matches,
  );
  useEffect(() => {
    const media = matchMedia("(prefers-color-scheme: dark)");
    const update = () => setSystemDark(media.matches);
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  const resolved =
    choice === "system" ? (systemDark ? "dark" : "light") : choice;
  useEffect(() => {
    document.documentElement.dataset.theme = resolved;
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", resolved === "dark" ? "#1B1E24" : "#E9EDF3");
  }, [resolved]);
  return resolved;
}

````

## src/lib/adminNavigation.ts

````ts
import { navigation, type Permission } from "./permissions";
import type { IconName } from "../components/ui/Icon";
import type { Role } from "../types/domain";
type Item = {
  label: string;
  path: string;
  icon: IconName;
  permission: Permission;
  phase: number;
  section: "Workspace" | "Management" | "System";
};
export function getNavigation(role: Role): Item[] {
  const common: Item[] = [...navigation];
  if (role === "master")
    return [
      ...common.filter((item) => item.phase === 1),
      {
        label: "Schools",
        path: "/schools",
        icon: "building",
        permission: "master.manage",
        phase: 2,
        section: "Workspace",
      },
      {
        label: "Revenue",
        path: "/revenue",
        icon: "wallet",
        permission: "master.manage",
        phase: 2,
        section: "Management",
      },
      {
        label: "Global role control",
        path: "/roles",
        icon: "shield",
        permission: "master.manage",
        phase: 2,
        section: "Management",
      },
      {
        label: "Audit trail",
        path: "/audit",
        icon: "file",
        permission: "master.manage",
        phase: 2,
        section: "System",
      },
    ];
  return role !== "owner"
    ? common
    : [
        ...common,
        {
          label: "Roles & permissions",
          path: "/roles",
          icon: "shield",
          permission: "system.manage",
          phase: 2,
          section: "Workspace",
        },
        {
          label: "View as",
          path: "/view-as",
          icon: "eye",
          permission: "system.manage",
          phase: 2,
          section: "Management",
        },
        {
          label: "School settings",
          path: "/settings",
          icon: "settings",
          permission: "system.manage",
          phase: 2,
          section: "System",
        },
        {
          label: "Security & privacy",
          path: "/security",
          icon: "lock",
          permission: "system.manage",
          phase: 2,
          section: "System",
        },
        {
          label: "Audit trail",
          path: "/audit",
          icon: "file",
          permission: "system.manage",
          phase: 2,
          section: "System",
        },
      ];
}
export function moduleReady(role: Role, phase: number) {
  return phase <= (role === "owner" || role === "master" ? 2 : 1);
}

````

## src/lib/config.ts

````ts
export const config = {
  mock: import.meta.env.VITE_USE_MOCK !== "false",
  appUrl: import.meta.env.VITE_APP_URL || window.location.origin,
};

````

## src/lib/csv.test.ts

````ts
import { describe, expect, it } from "vitest";
import { parseCsv } from "./csv";
describe("CSV import parser", () => {
  it("handles quoted commas, newlines, and escaped quotes", () => {
    expect(
      parseCsv(
        'name,email\r\n"Morgan, Alex",alex@test.edu\r\n"A ""quoted"" name",name@test.edu',
      ),
    ).toEqual([
      ["name", "email"],
      ["Morgan, Alex", "alex@test.edu"],
      ['A "quoted" name', "name@test.edu"],
    ]);
  });
  it("rejects a malformed quoted field", () => {
    expect(() => parseCsv('name\n"unfinished')).toThrow("unclosed quote");
  });
});

````

## src/lib/csv.ts

````ts
export function downloadCsv(
  filename: string,
  headers: string[],
  rows: (string | number)[][],
) {
  const cell = (value: string | number) => {
    const text = String(value);
    const safe = /^[=+@\-\t\r]/.test(text) ? `'${text}` : text;
    return `"${safe.replaceAll('"', '""')}"`;
  };
  const csv =
    "\uFEFF" +
    [headers, ...rows].map((row) => row.map(cell).join(",")).join("\r\n");
  const url = URL.createObjectURL(
    new Blob([csv], { type: "text/csv;charset=utf-8" }),
  );
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let value = "";
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i]!;
    if (char === '"') {
      if (quoted && text[i + 1] === '"') {
        value += '"';
        i++;
      } else quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(value.trim());
      value = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && text[i + 1] === "\n") i++;
      row.push(value.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      value = "";
    } else value += char;
  }
  if (quoted) throw new Error("CSV contains an unclosed quote.");
  row.push(value.trim());
  if (row.some(Boolean)) rows.push(row);
  return rows;
}
export const money = (value: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);

````

## src/lib/permissions.test.ts

````ts
import { describe, expect, it } from "vitest";
import { hasPermission, homeFor, rolePermissions } from "./permissions";
import { roles } from "../types/domain";
describe("role boundaries", () => {
  it("does not grant master access to owners or other school roles", () => {
    for (const role of roles.filter((r) => r !== "master"))
      expect(hasPermission(role, "master.manage")).toBe(false);
    expect(hasPermission("master", "master.manage")).toBe(true);
  });
  it("keeps financial and academic responsibilities separate", () => {
    expect(hasPermission("teacher", "finance.manage")).toBe(false);
    expect(hasPermission("accountant", "academics.read")).toBe(false);
    expect(hasPermission("principal", "system.manage")).toBe(false);
    expect(hasPermission("parent", "users.manage")).toBe(false);
  });
  it("fails closed for signed-out users", () => {
    for (const permission of rolePermissions.owner)
      expect(hasPermission(undefined, permission)).toBe(false);
  });
  it("redirects every role to its own workspace", () => {
    expect(homeFor("master")).toBe("/sys-master/workspace");
    for (const role of roles.filter((r) => r !== "master"))
      expect(homeFor(role)).toBe(`/${role}`);
  });
});

````

## src/lib/permissions.ts

````ts
import type { Role } from "../types/domain";
export const permissions = [
  "workspace.read",
  "users.manage",
  "branches.manage",
  "academics.read",
  "attendance.manage",
  "finance.manage",
  "child.read",
  "whatsapp.manage",
  "system.manage",
  "master.manage",
] as const;
export type Permission = (typeof permissions)[number];
export const roleLabels: Record<Role, string> = {
  owner: "Owner / Super Admin",
  principal: "Principal",
  teacher: "Teacher",
  parent: "Parent",
  student: "Student",
  accountant: "Office / Accountant",
  master: "SaaS Creator",
};
export const rolePermissions: Record<Role, readonly Permission[]> = {
  owner: permissions.filter((p) => p !== "master.manage"),
  principal: [
    "workspace.read",
    "users.manage",
    "academics.read",
    "attendance.manage",
  ],
  teacher: ["workspace.read", "academics.read", "attendance.manage"],
  parent: ["workspace.read", "child.read"],
  student: ["workspace.read", "child.read"],
  accountant: ["workspace.read", "finance.manage"],
  master: ["workspace.read", "master.manage"],
};
export function hasPermission(
  role: Role | undefined,
  permission: Permission,
): boolean {
  return role ? rolePermissions[role].includes(permission) : false;
}
export function homeFor(role: Role) {
  return role === "master" ? "/sys-master/workspace" : `/${role}`;
}
export const navigation = [
  {
    label: "Overview",
    path: "",
    icon: "grid",
    permission: "workspace.read",
    phase: 1,
    section: "Workspace",
  },
  {
    label: "Workspace directory",
    path: "/directory",
    icon: "layers",
    permission: "workspace.read",
    phase: 1,
    section: "Workspace",
  },
  {
    label: "People & access",
    path: "/people",
    icon: "users",
    permission: "users.manage",
    phase: 2,
    section: "Workspace",
  },
  {
    label: "Branches",
    path: "/branches",
    icon: "building",
    permission: "branches.manage",
    phase: 2,
    section: "Workspace",
  },
  {
    label: "Academics",
    path: "/academics",
    icon: "book",
    permission: "academics.read",
    phase: 3,
    section: "Management",
  },
  {
    label: "Attendance",
    path: "/attendance",
    icon: "calendar-check",
    permission: "attendance.manage",
    phase: 3,
    section: "Management",
  },
  {
    label: "My child",
    path: "/child",
    icon: "heart",
    permission: "child.read",
    phase: 4,
    section: "Management",
  },
  {
    label: "Finance",
    path: "/finance",
    icon: "wallet",
    permission: "finance.manage",
    phase: 2,
    section: "Management",
  },
  {
    label: "WhatsApp",
    path: "/whatsapp",
    icon: "message",
    permission: "whatsapp.manage",
    phase: 5,
    section: "Management",
  },
  {
    label: "Component library",
    path: "/components",
    icon: "palette",
    permission: "workspace.read",
    phase: 1,
    section: "System",
  },
  {
    label: "My preferences",
    path: "/preferences",
    icon: "settings",
    permission: "workspace.read",
    phase: 1,
    section: "System",
  },
] as const;

````

## src/lib/query.ts

````ts
import { QueryClient } from "@tanstack/react-query";
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60_000,
      gcTime: 300_000,
      retry: 1,
      refetchOnWindowFocus: false,
    },
    mutations: { retry: 0 },
  },
});
export const queryKeys = {
  branches: (user: string) => ["branches", user] as const,
  notifications: (user: string, branch: string) =>
    ["notifications", user, branch] as const,
};

````

## src/main.tsx

````tsx
import React from "react";
import ReactDOM from "react-dom/client";
import { RouterProvider } from "react-router-dom";
import { QueryClientProvider } from "@tanstack/react-query";
import { MotionConfig } from "framer-motion";
import { Toaster } from "sonner";
import "@fontsource/inter/latin-400.css";
import "@fontsource/inter/latin-500.css";
import "@fontsource/inter/latin-600.css";
import "@fontsource/inter/latin-700.css";
import "../src/styles/tokens.css";
import "../src/styles/global.css";
import "../src/styles/admin.css";
import { queryClient } from "./lib/query";
import { router } from "./app/router";
import { AuthProvider } from "./app/AuthProvider";
import { IconGradients } from "./components/ui/Icon";
function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <MotionConfig
        reducedMotion="user"
        transition={{ duration: 0.2, ease: [0.22, 0.61, 0.36, 1] }}
      >
        <IconGradients />
        <AuthProvider>
          <RouterProvider router={router} />
        </AuthProvider>
        <Toaster position="bottom-right" richColors closeButton />
      </MotionConfig>
    </QueryClientProvider>
  );
}
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);

````

## src/mocks/adapter.test.ts

````ts
// These tests exercise the adapter's isolation contract with a small Web Storage implementation.
import { beforeEach, describe, expect, it } from "vitest";
import { mockRepository } from "./adapter";
function memoryStorage(): Storage {
  const map = new Map<string, string>();
  return {
    get length() {
      return map.size;
    },
    clear: () => map.clear(),
    getItem: (key) => map.get(key) ?? null,
    key: (index) => [...map.keys()][index] ?? null,
    removeItem: (key) => {
      map.delete(key);
    },
    setItem: (key, value) => {
      map.set(key, value);
    },
  };
}
beforeEach(() => {
  globalThis.localStorage = memoryStorage();
  globalThis.sessionStorage = memoryStorage();
});
describe("mock repository security contract", () => {
  it("rejects incorrect credentials and master accounts on the normal login", async () => {
    await expect(
      mockRepository.auth.signIn({
        identifier: "owner@greenwood.edu",
        password: "wrong",
        remember: true,
      }),
    ).rejects.toThrow();
    await expect(
      mockRepository.auth.signIn({
        identifier: "master@greenwood.edu",
        password: "Campus@2026",
        remember: true,
      }),
    ).rejects.toThrow();
  });
  it("isolates an assigned teacher from other campuses", async () => {
    await mockRepository.auth.signIn({
      identifier: "teacher@greenwood.edu",
      password: "Campus@2026",
      remember: false,
    });
    expect((await mockRepository.branches.list()).map((b) => b.id)).toEqual([
      "north",
    ]);
    await expect(mockRepository.notifications.list("central")).rejects.toThrow(
      "access",
    );
    expect(localStorage.getItem("campus-demo-session")).toBeNull();
  });
  it("does not expose one account’s notifications to another", async () => {
    await mockRepository.auth.signIn({
      identifier: "owner@greenwood.edu",
      password: "Campus@2026",
      remember: true,
    });
    const owner = await mockRepository.notifications.list("north");
    await mockRepository.auth.signIn({
      identifier: "parent@greenwood.edu",
      password: "Campus@2026",
      remember: false,
    });
    const parent = await mockRepository.notifications.list("north");
    expect(parent.every((n) => n.user_id === "demo-parent")).toBe(true);
    expect(parent.some((n) => n.id === owner[0]?.id)).toBe(false);
  });
  it("restores a remembered session and clears it on sign out", async () => {
    const signedIn = await mockRepository.auth.signIn({
      identifier: "GW-001",
      password: "Campus@2026",
      remember: true,
    });
    expect(await mockRepository.auth.getProfile()).toEqual(signedIn);
    await mockRepository.auth.signOut();
    expect(await mockRepository.auth.getProfile()).toBeNull();
  });
});

````

## src/mocks/adapter.ts

````ts
import { z } from "zod";
import type { Notification, Profile, Role } from "../types/domain";
import { roles } from "../types/domain";
import type { Repository } from "../services/contracts";
import { demoProfile } from "./data";
import {
  readRecords as readAdminRecords,
  readProvisionedAccounts,
  hashPassword,
} from "./adminStorage";
const key = "campus-demo-session";
const profileSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string().email(),
  role: z.enum(roles),
  schoolId: z.string(),
  branchIds: z.array(z.string()),
  policyId: z.string().nullable().optional(),
});
const pause = () => new Promise<void>((resolve) => setTimeout(resolve, 280));
export function readProfile(): Profile | null {
  try {
    const raw = localStorage.getItem(key) ?? sessionStorage.getItem(key);
    const profile = raw ? profileSchema.parse(JSON.parse(raw)) : null;
    if (profile && profile.role !== "master") {
      const records = readAdminRecords();
      if (
        records.schools.find((s) => s.id === profile.schoolId)?.status !==
        "Active"
      )
        return null;
      if (profile.role !== "owner") {
        const linked = records.users.find(
          (u) =>
            u.email.toLowerCase() === profile.email.toLowerCase() &&
            u.schoolId === profile.schoolId,
        );
        if (linked) {
          if (linked.status !== "Active") return null;
          return {
            ...profile,
            role: linked.role,
            policyId: linked.policyId,
            branchIds: linked.branchId ? [linked.branchId] : [],
          };
        }
      }
    }
    return profile;
  } catch {
    localStorage.removeItem(key);
    sessionStorage.removeItem(key);
    return null;
  }
}
const listeners = new Set<(profile: Profile | null) => void>();
const events = new Set<() => void>();
const notifications = new Map<string, Notification[]>();
function current() {
  const profile = readProfile();
  if (!profile) throw new Error("Please sign in to continue.");
  return profile;
}
export const mockRepository: Repository = {
  auth: {
    async getProfile() {
      await pause();
      const profile = readProfile();
      if (profile && profile.role !== "master") {
        if (
          readAdminRecords().schools.find((s) => s.id === profile.schoolId)
            ?.status !== "Active"
        )
          return null;
      }
      return profile;
    },
    async signIn({ identifier, password, remember, master }) {
      await pause();
      const normalized = identifier.toLowerCase().trim();
      const role =
        normalized === "gw-001" ? "owner" : (normalized.split("@")[0] as Role);
      const account = readProvisionedAccounts().find(
        (a) => a.email === normalized,
      );
      const validProvisioned =
        account &&
        !master &&
        (await hashPassword(password, account.salt)) === account.hash;
      if (
        !validProvisioned &&
        (!roles.includes(role) ||
          (normalized !== "gw-001" && normalized !== `${role}@greenwood.edu`) ||
          password !== "Campus@2026" ||
          (master ? role !== "master" : role === "master"))
      )
        throw new Error("The email, school code, or password is incorrect.");
      const profile = validProvisioned ? account.profile : demoProfile(role);
      if (
        profile.role !== "master" &&
        readAdminRecords().schools.find((s) => s.id === profile.schoolId)
          ?.status !== "Active"
      )
        throw new Error(
          "Access to this school has been suspended. Contact your platform administrator.",
        );
      if (profile.role === "owner")
        profile.branchIds = readAdminRecords()
          .branches.filter(
            (b) => b.schoolId === profile.schoolId && b.status === "Active",
          )
          .map((b) => b.id);
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
      (remember ? localStorage : sessionStorage).setItem(
        key,
        JSON.stringify(profile),
      );
      listeners.forEach((fn) => fn(profile));
      return profile;
    },
    async signOut() {
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
      listeners.forEach((fn) => fn(null));
    },
    async resetPassword() {
      await pause();
      throw new Error(
        "Demo accounts use Campus@2026. Password emails are available in Supabase mode.",
      );
    },
    async updatePassword() {
      await pause();
      throw new Error("Demo passwords cannot be changed.");
    },
    onChange(callback) {
      listeners.add(callback);
      const sync = (event: StorageEvent) => {
        if (event.key === key || event.key === "campus-admin-v2")
          callback(readProfile());
      };
      window.addEventListener("storage", sync);
      return () => {
        listeners.delete(callback);
        window.removeEventListener("storage", sync);
      };
    },
  },
  branches: {
    async list() {
      await pause();
      const profile = current();
      return readAdminRecords()
        .branches.filter(
          (b) =>
            b.schoolId === profile.schoolId &&
            b.status === "Active" &&
            (profile.role === "owner" ||
              profile.role === "master" ||
              profile.branchIds.includes(b.id)),
        )
        .map((b) => ({
          id: b.id,
          school_id: b.schoolId,
          name: b.name,
          short_name: b.name,
          city: b.city,
        }));
    },
  },
  notifications: {
    async list(branchId) {
      await pause();
      const profile = current();
      if (
        !profile.branchIds.includes(branchId) &&
        !(
          profile.role === "owner" &&
          readAdminRecords().branches.some(
            (b) => b.id === branchId && b.schoolId === profile.schoolId,
          )
        )
      )
        throw new Error("You do not have access to this campus.");
      const scoped = `${profile.id}:${branchId}`;
      if (!notifications.has(scoped))
        notifications.set(scoped, [
          {
            id: `${scoped}-welcome`,
            user_id: profile.id,
            branch_id: branchId,
            title: "Your workspace is ready",
            body: "Explore your workspace, personalize your theme, and find everything in one place.",
            created_at: new Date().toISOString(),
            read: false,
          },
          {
            id: `${scoped}-access`,
            user_id: profile.id,
            branch_id: branchId,
            title: "Access tailored to your role",
            body: "Your assigned campuses and permissions keep school information in the right hands.",
            created_at: new Date(Date.now() - 3_600_000).toISOString(),
            read: false,
          },
        ]);
      return structuredClone(notifications.get(scoped) ?? []);
    },
    async markRead(id) {
      await pause();
      const profile = current();
      for (const list of notifications.values()) {
        const item = list.find((n) => n.id === id && n.user_id === profile.id);
        if (item) item.read = true;
      }
      events.forEach((fn) => fn());
    },
    subscribe(_branchId, callback) {
      events.add(callback);
      return () => {
        events.delete(callback);
      };
    },
  },
  storage: {
    async getUrl(path) {
      const value = localStorage.getItem(`campus-demo-file:${path}`);
      if (!value)
        throw new Error(
          "This demo file is no longer available. Upload it again.",
        );
      return value;
    },
    async upload(file, branchId) {
      await pause();
      const user = current();
      if (
        !user.branchIds.includes(branchId) &&
        !(
          user.role === "owner" &&
          readAdminRecords().branches.some(
            (b) => b.schoolId === user.schoolId && b.id === branchId,
          )
        )
      )
        throw new Error("Campus access denied.");
      if (file.size > 5 * 1024 * 1024)
        throw new Error("File exceeds the 5 MB limit.");
      const bytes = new Uint8Array(await file.arrayBuffer());
      let binary = "";
      for (let i = 0; i < bytes.length; i += 16384)
        binary += String.fromCharCode(...bytes.slice(i, i + 16384));
      const path = `demo://${branchId}/${crypto.randomUUID()}/${encodeURIComponent(file.name)}`;
      localStorage.setItem(
        `campus-demo-file:${path}`,
        `data:${file.type};base64,${btoa(binary)}`,
      );
      return path;
    },
  },
};

````

## src/mocks/adminAdapter.test.ts

````ts
import { beforeEach, describe, expect, it } from "vitest";
import { mockRepository } from "./adapter";
import { mockAdminRepository } from "./adminAdapter";
function storage(): Storage {
  const values = new Map<string, string>();
  return {
    get length() {
      return values.size;
    },
    clear: () => values.clear(),
    getItem: (key) => values.get(key) ?? null,
    key: (index) => [...values.keys()][index] ?? null,
    removeItem: (key) => {
      values.delete(key);
    },
    setItem: (key, value) => {
      values.set(key, value);
    },
  };
}
beforeEach(() => {
  globalThis.localStorage = storage();
  globalThis.sessionStorage = storage();
});
async function signIn(role: string) {
  return mockRepository.auth.signIn({
    identifier: `${role}@greenwood.edu`,
    password: "Campus@2026",
    remember: false,
    master: role === "master",
  });
}
describe("Phase 2 mock administration", () => {
  it("denies school administration to teachers and cross-school writes to owners", async () => {
    await signIn("teacher");
    await expect(
      mockAdminRepository.list("finance", { schoolId: "greenwood" }),
    ).rejects.toThrow("permission");
    await signIn("owner");
    await expect(
      mockAdminRepository.save("branches", {
        id: crypto.randomUUID(),
        schoolId: "oakridge",
        branchId: null,
        version: 1,
        name: "Foreign campus",
        city: "Delhi",
        code: "OA-X",
        principal: "",
        capacity: 100,
        status: "Active",
      }),
    ).rejects.toThrow("permission");
  });
  it("persists a custom role and rejects a stale update", async () => {
    await signIn("owner");
    const created = await mockAdminRepository.save("roles", {
      id: crypto.randomUUID(),
      schoolId: "greenwood",
      branchId: null,
      version: 1,
      name: "Finance Coordinator",
      role: "accountant",
      custom: true,
      permissions: ["workspace.read", "finance.manage"],
    });
    const updated = await mockAdminRepository.save("roles", {
      ...created,
      name: "Senior Finance Coordinator",
    });
    expect(updated.version).toBe(2);
    await expect(mockAdminRepository.save("roles", created)).rejects.toThrow(
      "changed",
    );
    expect(
      (
        await mockAdminRepository.list("audit", { schoolId: "greenwood" })
      ).rows.some((row) => row.resource === "roles"),
    ).toBe(true);
  });
  it("creates usable owner credentials and blocks a suspended school", async () => {
    await signIn("master");
    const provisioned = await mockAdminRepository.provisionSchool({
      name: "Test Valley School",
      code: "TV-QA",
      ownerEmail: "owner@testvalley.edu",
      plan: "Growth",
      monthlyFee: 12900,
    });
    await mockRepository.auth.signOut();
    const owner = await mockRepository.auth.signIn({
      identifier: provisioned.email,
      password: provisioned.password,
      remember: false,
    });
    expect(owner.schoolId).toBe(provisioned.school.id);
    expect(await mockRepository.branches.list()).toHaveLength(1);
    expect(
      (await mockAdminRepository.list("settings", { schoolId: owner.schoolId }))
        .rows[0]?.name,
    ).toBe("Test Valley School");
    await signIn("master");
    await mockAdminRepository.save("schools", {
      ...provisioned.school,
      status: "Suspended",
    });
    await mockRepository.auth.signOut();
    await expect(
      mockRepository.auth.signIn({
        identifier: provisioned.email,
        password: provisioned.password,
        remember: false,
      }),
    ).rejects.toThrow("suspended");
  });
});

````

## src/mocks/adminAdapter.ts

````ts
import type {
  AdminModels,
  AdminRepository,
  AdminResource,
  AdminScope,
} from "../types/admin";
import { parseRecord } from "../types/admin";
import {
  readRecords,
  writeRecords,
  hashPassword,
  readProvisionedAccounts,
} from "./adminStorage";
import { readProfile } from "./adapter";
const pause = () => new Promise<void>((resolve) => setTimeout(resolve, 180));
function actor() {
  const profile = readProfile();
  if (!profile) throw new Error("Sign in to continue.");
  if (
    profile.role !== "master" &&
    readRecords().schools.find((s) => s.id === profile.schoolId)?.status !==
      "Active"
  )
    throw new Error("School access is suspended.");
  return profile;
}
function authorize(resource: AdminResource, scope: AdminScope, write = false) {
  const user = actor();
  if (resource === "schools") {
    if (user.role !== "master") throw new Error("Platform access is required.");
  } else if (user.role === "master") {
    if (
      (resource !== "roles" && resource !== "audit") ||
      (resource === "roles" &&
        scope.schoolId !== "00000000-0000-0000-0000-000000000000")
    )
      throw new Error("Open a school account to manage school operations.");
  } else if (
    user.schoolId !== scope.schoolId ||
    (user.role !== "owner" &&
      (write || !["roles", "branches"].includes(resource)))
  )
    throw new Error("You do not have permission for this school operation.");
  if (
    scope.branchId &&
    user.role !== "owner" &&
    user.role !== "master" &&
    !user.branchIds.includes(scope.branchId)
  )
    throw new Error("Campus access denied.");
  return user;
}
function audit(
  resource: string,
  action: string,
  schoolId: string,
  detail: string,
) {
  const user = actor();
  const records = readRecords();
  records.audit.unshift({
    id: crypto.randomUUID(),
    schoolId,
    branchId: null,
    version: 1,
    actor: user.name,
    action,
    resource,
    details: detail,
    createdAt: new Date().toISOString(),
  });
  writeRecords(records);
}
export const mockAdminRepository: AdminRepository = {
  async summary(scope) {
    await pause();
    const user = actor();
    if (user.role !== "owner" && user.role !== "master")
      throw new Error("Administrative access required.");
    if (user.role === "owner" && user.schoolId !== scope.schoolId)
      throw new Error("School access denied.");
    const all = readRecords();
    const subscriptionSchools = all.schools.filter(
      (s) =>
        (!scope.from || s.createdAt.slice(0, 10) >= scope.from) &&
        (!scope.to || s.createdAt.slice(0, 10) <= scope.to),
    );
    const financial = all.finance.filter(
      (r) =>
        r.schoolId === scope.schoolId &&
        (!scope.branchId || r.branchId === scope.branchId),
    );
    const people = all.users.filter(
      (r) =>
        r.schoolId === scope.schoolId &&
        (!scope.branchId || r.branchId === scope.branchId) &&
        r.status === "Active",
    );
    const total = (kind: string, paid: boolean) =>
      financial
        .filter(
          (r) =>
            r.kind === kind &&
            (paid ? r.status === "Paid" : r.status !== "Paid"),
        )
        .reduce((n, r) => n + r.amount, 0);
    return {
      students: people.filter((r) => r.role === "student").length,
      attendance:
        user.role === "master"
          ? []
          : [
              ...new Set(
                all.analytics
                  .filter(
                    (r) =>
                      r.schoolId === scope.schoolId &&
                      (!scope.branchId || r.branchId === scope.branchId),
                  )
                  .map((r) => r.date),
              ),
            ]
              .sort()
              .map((date) => {
                const entries = all.analytics.filter(
                  (r) =>
                    r.schoolId === scope.schoolId &&
                    r.date === date &&
                    (!scope.branchId || r.branchId === scope.branchId),
                );
                const present = entries.reduce((n, r) => n + r.present, 0);
                const count = entries.reduce((n, r) => n + r.total, 0);
                return {
                  label: new Date(date).toLocaleString("en", {
                    month: "short",
                  }),
                  value: count ? Math.round((present / count) * 1000) / 10 : 0,
                };
              }),
      staff: people.filter((r) =>
        ["teacher", "principal", "accountant"].includes(r.role),
      ).length,
      income: total("Income", true),
      expenses: total("Expense", true),
      outstanding: total("Income", false),
      schools: subscriptionSchools.length,
      active: subscriptionSchools.filter((s) => s.status === "Active").length,
      mrr: subscriptionSchools
        .filter((s) => s.status === "Active")
        .reduce((n, s) => n + s.monthlyFee, 0),
      suspended: subscriptionSchools.filter((s) => s.status !== "Active")
        .length,
      revenue:
        user.role === "master"
          ? [...subscriptionSchools]
              .sort((a, b) => b.monthlyFee - a.monthlyFee)
              .slice(0, 10)
              .map((s) => ({
                label: s.code,
                value: s.status === "Active" ? s.monthlyFee : 0,
              }))
          : Array.from({ length: 6 }, (_, i) => {
              const date = new Date();
              date.setDate(1);
              date.setMonth(date.getMonth() - 5 + i);
              const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
              const matching = financial.filter(
                (r) => r.date.startsWith(key) && r.status === "Paid",
              );
              return {
                label: date.toLocaleString("en", { month: "short" }),
                value: matching
                  .filter((r) => r.kind === "Income")
                  .reduce((n, r) => n + r.amount, 0),
                secondary: matching
                  .filter((r) => r.kind === "Expense")
                  .reduce((n, r) => n + r.amount, 0),
              };
            }),
      enrollment:
        user.role === "master"
          ? ["Starter", "Growth", "Enterprise"].map((plan) => ({
              label: plan,
              value: subscriptionSchools.filter(
                (s) => s.plan === plan && s.status === "Active",
              ).length,
            }))
          : all.branches
              .filter(
                (b) =>
                  b.schoolId === scope.schoolId &&
                  (!scope.branchId || b.id === scope.branchId),
              )
              .map((b) => ({
                label: b.code,
                value: people.filter(
                  (p) => p.branchId === b.id && p.role === "student",
                ).length,
              })),
    };
  },
  async list(resource, scope, options = {}) {
    await pause();
    const user = authorize(resource, scope);
    let rows = readRecords()[resource].filter(
      (row) =>
        resource === "schools" ||
        (user.role === "master" && resource === "audit") ||
        row.schoolId === scope.schoolId,
    );
    if (scope.branchId && resource !== "roles" && resource !== "settings")
      rows = rows.filter((row) => row.branchId === scope.branchId);
    if (options.filters)
      rows = rows.filter((row) =>
        Object.entries(options.filters ?? {}).every(([key, value]) =>
          Object.entries(row).some(
            ([field, fieldValue]) => field === key && fieldValue === value,
          ),
        ),
      );
    if (options.search)
      rows = rows.filter((row) =>
        JSON.stringify(row)
          .toLowerCase()
          .includes(options.search!.toLowerCase()),
      );
    if (options.from)
      rows = rows.filter((row) => {
        const date =
          "date" in row ? row.date : "createdAt" in row ? row.createdAt : "";
        return date.slice(0, 10) >= options.from!;
      });
    if (options.to)
      rows = rows.filter((row) => {
        const date =
          "date" in row ? row.date : "createdAt" in row ? row.createdAt : "";
        return date.slice(0, 10) <= options.to!;
      });
    const page = options.page ?? 0;
    const size = Math.min(options.pageSize ?? 50, 500);
    return {
      rows: rows.slice(page * size, (page + 1) * size),
      total: rows.length,
    };
  },
  async save(resource, input) {
    await pause();
    authorize(resource, { schoolId: input.schoolId }, true);
    const record = parseRecord(resource, input);
    if (resource === "roles" && "role" in record && record.role === "owner")
      throw new Error("Owner access cannot be reduced by a school policy.");
    if (
      resource === "roles" &&
      "permissions" in record &&
      record.permissions.includes("master.manage") &&
      actor().role !== "master"
    )
      throw new Error("Schools cannot grant platform access.");
    const records = readRecords();
    if (
      record.branchId &&
      resource !== "branches" &&
      !records.branches.some(
        (b) => b.id === record.branchId && b.schoolId === record.schoolId,
      )
    )
      throw new Error("Campus is outside this school.");
    if (
      resource === "users" &&
      "policyId" in record &&
      record.policyId &&
      !records.roles.some(
        (p) =>
          p.id === record.policyId &&
          p.schoolId === record.schoolId &&
          p.role === record.role,
      )
    )
      throw new Error("Role policy is outside this school or base role.");
    const list = records[resource];
    const index = list.findIndex((row) => row.id === record.id);
    const previous = list[index];
    if (
      resource === "schools" &&
      previous &&
      "ownerEmail" in record &&
      "ownerEmail" in previous &&
      (record.ownerEmail !== previous.ownerEmail ||
        record.code !== previous.code)
    )
      throw new Error(
        "Login identity changes require trusted Auth administration.",
      );
    if (
      previous &&
      (previous.schoolId !== record.schoolId ||
        previous.version !== record.version)
    )
      throw new Error("This record changed. Refresh before saving again.");
    if (
      resource === "users" &&
      "email" in record &&
      records.users.some(
        (u) =>
          u.email.toLowerCase() === record.email.toLowerCase() &&
          u.id !== record.id &&
          u.schoolId === record.schoolId,
      )
    )
      throw new Error("This email already exists in the school directory.");
    const saved = { ...record, version: previous ? previous.version + 1 : 1 };
    if (index >= 0) list.splice(index, 1, saved);
    else list.unshift(saved);
    writeRecords(records);
    audit(
      resource,
      previous ? "Updated" : "Created",
      record.schoolId,
      `${resource} record ${record.id}`,
    );
    return saved as AdminModels[typeof resource];
  },
  async remove(resource, id, scope, version) {
    await pause();
    authorize(resource, scope, true);
    const records = readRecords();
    const record = records[resource].find(
      (item) => item.id === id && item.schoolId === scope.schoolId,
    );
    if (!record || record.version !== version)
      throw new Error("This record changed. Refresh and try again.");
    if (resource === "branches" && records.users.some((u) => u.branchId === id))
      throw new Error(
        "Move the people assigned to this campus before deleting it.",
      );
    if (resource === "roles" && "role" in record && record.role === "owner")
      throw new Error("Owner access cannot be deleted.");
    Object.assign(records, {
      [resource]: records[resource].filter((item) => item.id !== id),
    });
    writeRecords(records);
    audit(
      resource,
      "Deleted",
      scope.schoolId,
      `Deleted ${resource} record ${id}`,
    );
  },
  async provisionSchool(input) {
    await pause();
    authorize("schools", { schoolId: "platform" }, true);
    const records = readRecords();
    if (
      records.schools.some(
        (s) =>
          s.code.toLowerCase() === input.code.toLowerCase() ||
          s.ownerEmail.toLowerCase() === input.ownerEmail.toLowerCase(),
      )
    )
      throw new Error("This school code or owner email is already registered.");
    const id = crypto.randomUUID();
    const branch = crypto.randomUUID();
    const profile = {
      id: crypto.randomUUID(),
      name: `${input.name} Owner`,
      email: input.ownerEmail,
      role: "owner" as const,
      schoolId: id,
      branchIds: [branch],
    };
    const password = `Campus!${crypto.randomUUID().replaceAll("-", "").slice(0, 16)}`;
    const salt = crypto.randomUUID();
    const accounts = readProvisionedAccounts();
    accounts.push({
      email: input.ownerEmail.toLowerCase(),
      hash: await hashPassword(password, salt),
      salt,
      profile,
    });
    localStorage.setItem("campus-demo-accounts", JSON.stringify(accounts));
    const school = parseRecord("schools", {
      ...input,
      id,
      schoolId: id,
      branchId: null,
      version: 1,
      status: "Active",
      createdAt: new Date().toISOString().slice(0, 10),
    });
    records.schools.unshift(school);
    records.branches.push({
      id: branch,
      schoolId: id,
      branchId: branch,
      version: 1,
      name: "Main Campus",
      city: "Unassigned",
      code: `${input.code}-MAIN`,
      principal: "",
      capacity: 1000,
      status: "Active",
    });
    const roleDefaults = records.roles.filter(
      (r) => r.schoolId === "00000000-0000-0000-0000-000000000000",
    );
    records.roles.push(
      ...(roleDefaults.length
        ? roleDefaults
        : records.roles.filter((r) => r.schoolId === "greenwood" && !r.custom)
      ).map((r) => ({
        ...r,
        id: crypto.randomUUID(),
        schoolId: id,
        version: 1,
      })),
    );
    records.settings.push({
      id: crypto.randomUUID(),
      schoolId: id,
      branchId: null,
      version: 1,
      name: input.name,
      academicYear: "2026–2027",
      logoPath: "",
      senderNumber: "+919000000000",
      financeRole: "accountant",
      overrideEnabled: false,
      requireMfa: false,
      sessionMinutes: 60,
      privacyEmail: input.ownerEmail,
      retentionDays: 365,
    });
    writeRecords(records);
    audit("schools", "Provisioned school", id, input.name);
    return { school, email: input.ownerEmail, password };
  },
};

````

## src/mocks/adminStorage.ts

````ts
import type { AdminModels, AdminResource } from "../types/admin";
import { parseRecord } from "../types/admin";
import { branches } from "./data";
import { roleLabels, rolePermissions } from "../lib/permissions";
import { z } from "zod";
const key = "campus-admin-v2";
type RecordSet = { [K in AdminResource]: AdminModels[K][] };
function seed(): RecordSet {
  const core = { schoolId: "greenwood", branchId: null, version: 1 };
  return {
    analytics: branches.flatMap((branch) =>
      Array.from({ length: 6 }, (_, i) => ({
        ...core,
        id: `attendance-${branch.id}-${i}`,
        branchId: branch.id,
        date: `2026-${String(i + 5).padStart(2, "0")}-01`,
        present: [182, 190, 186, 194, 188, 196][i]!,
        total: 200,
      })),
    ),
    schools: [
      {
        ...core,
        id: "greenwood",
        name: "Greenwood International School",
        code: "GW-001",
        ownerEmail: "owner@greenwood.edu",
        plan: "Enterprise",
        status: "Active",
        monthlyFee: 24900,
        createdAt: "2025-04-01",
      },
      {
        ...core,
        schoolId: "oakridge",
        id: "oakridge",
        name: "Oakridge Academy",
        code: "OA-002",
        ownerEmail: "admin@oakridge.edu",
        plan: "Growth",
        status: "Active",
        monthlyFee: 12900,
        createdAt: "2026-02-15",
      },
      {
        ...core,
        schoolId: "riverside",
        id: "riverside",
        name: "Riverside Public School",
        code: "RP-003",
        ownerEmail: "admin@riverside.edu",
        plan: "Starter",
        status: "Suspended",
        monthlyFee: 5900,
        createdAt: "2026-06-01",
      },
    ],
    branches: branches.map((branch, i) => ({
      ...core,
      id: branch.id,
      branchId: branch.id,
      name: branch.short_name,
      city: branch.city,
      code: ["GW-N", "GW-C", "GW-E"][i]!,
      principal: ["Sarah Williams", "Daniel Brown", "Emma Taylor"][i]!,
      capacity: [1200, 900, 600][i]!,
      status: "Active",
    })),
    users: Array.from({ length: 36 }, (_, i) => {
      const role = (
        [
          "student",
          "teacher",
          "parent",
          "student",
          "accountant",
          "principal",
        ] as const
      )[i % 6]!;
      const names = [
        "Aarav Sharma",
        "James Wilson",
        "Priya Sharma",
        "Maya Patel",
        "Olivia Davis",
        "Sarah Williams",
        "Noah Carter",
        "Amelia Chen",
        "Ethan Brooks",
        "Isla Thomas",
        "Liam Harris",
        "Sofia Lewis",
      ];
      const name = `${names[i % names.length]}${i >= names.length ? ` ${Math.floor(i / names.length) + 1}` : ""}`;
      return {
        ...core,
        id: `person-${i}`,
        branchId: ["north", "central", "east"][i % 3]!,
        name,
        policyId: null,
        email: `${name.toLowerCase().replaceAll(" ", ".")}@greenwood.edu`,
        role,
        status: i % 11 === 0 ? "Inactive" : "Active",
        phone: `+91 98${String(31000000 + i)}`,
        joinedAt: `2026-0${(i % 9) + 1}-12`,
      };
    }),
    finance: Array.from({ length: 30 }, (_, i) => ({
      ...core,
      id: `entry-${i}`,
      branchId: ["north", "central", "east"][i % 3]!,
      reference: `GW-2026-${String(i + 1).padStart(4, "0")}`,
      description:
        i % 4 === 0
          ? "Campus maintenance"
          : i % 4 === 1
            ? "Tuition fee collection"
            : i % 4 === 2
              ? "Term fee collection"
              : "Learning resources",
      kind: i % 4 === 0 || i % 4 === 3 ? "Expense" : "Income",
      category:
        i % 4 === 0 ? "Maintenance" : i % 4 === 3 ? "Supplies" : "Tuition",
      amount: [18000, 75000, 62000, 8500][i % 4]!,
      date: `2026-${String(5 + (i % 6)).padStart(2, "0")}-${String(1 + (i % 25)).padStart(2, "0")}`,
      status: i % 9 === 0 ? "Overdue" : i % 7 === 0 ? "Pending" : "Paid",
    })),
    roles: (Object.keys(rolePermissions) as (keyof typeof rolePermissions)[])
      .filter((role) => role !== "master")
      .map((role) => ({
        ...core,
        id: `role-${role}`,
        name: roleLabels[role],
        custom: false,
        role,
        permissions: [...rolePermissions[role]],
      })),
    settings: [
      {
        ...core,
        id: "settings-greenwood",
        name: "Greenwood International School",
        academicYear: "2026–2027",
        logoPath: "",
        senderNumber: "+919845001234",
        financeRole: "accountant",
        overrideEnabled: false,
        requireMfa: false,
        sessionMinutes: 60,
        privacyEmail: "privacy@greenwood.edu",
        retentionDays: 365,
      },
    ],
    templates: [
      {
        ...core,
        id: "template-fees",
        name: "Gentle fee reminder",
        category: "Fees",
        body: "Hello {{parent_name}}, a friendly reminder that {{amount}} is due for {{student_name}} on {{due_date}}. Thank you, Greenwood School.",
        status: "Approved",
      },
      {
        ...core,
        id: "template-attendance",
        name: "Daily absence update",
        category: "Attendance",
        body: "Hello {{parent_name}}, {{student_name}} was marked absent today. Please contact the school office if you have any questions.",
        status: "Approved",
      },
    ],
    audit: [
      {
        ...core,
        id: "audit-welcome",
        actor: "System",
        action: "Workspace initialized",
        resource: "system",
        details: "Phase 2 demonstration workspace initialized.",
        createdAt: "2026-10-31T08:00:00Z",
      },
    ],
  };
}
export function readRecords(): RecordSet {
  const raw = localStorage.getItem(key);
  if (!raw) {
    const initial = seed();
    writeRecords(initial);
    return initial;
  }
  const parsed: unknown = JSON.parse(raw);
  const object = z.record(z.array(z.unknown())).parse(parsed);
  const result = seed();
  for (const resource of Object.keys(result) as AdminResource[]) {
    const records = (object[resource] ?? result[resource]).map((row) =>
      parseRecord(resource, row),
    );
    Object.assign(result, { [resource]: records });
  }
  return result;
}
export function writeRecords(records: RecordSet) {
  localStorage.setItem(key, JSON.stringify(records));
}
export const provisionedAccountSchema = z.object({
  email: z.string().email(),
  hash: z.string(),
  salt: z.string(),
  profile: z.object({
    id: z.string(),
    name: z.string(),
    email: z.string().email(),
    role: z.literal("owner"),
    schoolId: z.string(),
    branchIds: z.array(z.string()),
  }),
});
export async function hashPassword(password: string, salt: string) {
  const hash = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`${salt}:${password}`),
  );
  return Array.from(new Uint8Array(hash))
    .map((n) => n.toString(16).padStart(2, "0"))
    .join("");
}
export function readProvisionedAccounts() {
  return z
    .array(provisionedAccountSchema)
    .parse(JSON.parse(localStorage.getItem("campus-demo-accounts") ?? "[]"));
}

````

## src/mocks/data.ts

````ts
import type { Branch, Profile, Role, Workspace } from "../types/domain";
export const branches: Branch[] = [
  {
    id: "north",
    school_id: "greenwood",
    name: "Greenwood · North Campus",
    short_name: "North Campus",
    city: "Bengaluru",
  },
  {
    id: "central",
    school_id: "greenwood",
    name: "Greenwood · Central Campus",
    short_name: "Central Campus",
    city: "Bengaluru",
  },
  {
    id: "east",
    school_id: "greenwood",
    name: "Greenwood · East Campus",
    short_name: "East Campus",
    city: "Whitefield",
  },
];
const names: Record<Role, string> = {
  owner: "Alex Morgan",
  principal: "Sarah Williams",
  teacher: "James Wilson",
  parent: "Priya Sharma",
  student: "Aarav Sharma",
  accountant: "Olivia Davis",
  master: "Jordan Lee",
};
export function demoProfile(role: Role): Profile {
  return {
    id: `demo-${role}`,
    name: names[role],
    email: `${role}@greenwood.edu`,
    role,
    schoolId: "greenwood",
    branchIds:
      role === "owner" || role === "master"
        ? branches.map((b) => b.id)
        : ["north"],
  };
}
export const workspaces: Workspace[] = [
  {
    id: "people",
    name: "People & access",
    description: "A connected directory of students, families, and staff.",
    category: "Community",
    permission: "users.manage",
    phase: 2,
    icon: "users",
  },
  {
    id: "branches",
    name: "Branches & campuses",
    description: "Every campus, connected through one workspace.",
    category: "Operations",
    permission: "branches.manage",
    phase: 2,
    icon: "building",
  },
  {
    id: "academics",
    name: "Learning & academics",
    description: "Classes, subjects, timetables, and learning journeys.",
    category: "Academics",
    permission: "academics.read",
    phase: 3,
    icon: "book",
  },
  {
    id: "attendance",
    name: "Attendance",
    description: "Stay close to your school community, every day.",
    category: "Academics",
    permission: "attendance.manage",
    phase: 3,
    icon: "calendar-check",
  },
  {
    id: "finance",
    name: "Fees & finance",
    description: "Bring clarity to fees, expenses, and school accounts.",
    category: "Operations",
    permission: "finance.manage",
    phase: 2,
    icon: "wallet",
  },
  {
    id: "child",
    name: "My child’s journey",
    description: "Follow learning, attendance, and important milestones.",
    category: "Community",
    permission: "child.read",
    phase: 4,
    icon: "heart",
  },
  {
    id: "whatsapp",
    name: "Communication",
    description: "Keep families in the loop with thoughtful messaging.",
    category: "Community",
    permission: "whatsapp.manage",
    phase: 5,
    icon: "message",
  },
  {
    id: "system",
    name: "School settings",
    description: "Make your school’s workspace feel like your own.",
    category: "System",
    permission: "system.manage",
    phase: 5,
    icon: "settings",
  },
];

````

## src/services/admin.ts

````ts
import { config } from "../lib/config";
import type { AdminRepository } from "../types/admin";
let repository: Promise<AdminRepository> | undefined;
export function getAdminRepository(): Promise<AdminRepository> {
  repository ??= config.mock
    ? import("../mocks/adminAdapter").then((m) => m.mockAdminRepository)
    : import("./adminSupabase").then((m) => m.adminSupabaseRepository);
  return repository;
}

````

## src/services/adminSupabase.ts

````ts
import { z } from "zod";
import { client } from "./supabase";
import type { AdminRepository } from "../types/admin";
import { parseRecord, summarySchema } from "../types/admin";
import type { Json } from "../types/database";
const json = (value: unknown): Json =>
  JSON.parse(JSON.stringify(value)) as Json;
export const adminSupabaseRepository: AdminRepository = {
  async summary(scope) {
    const { data, error } = await client.rpc("admin_summary", {
      p_scope: json(scope),
    });
    if (error) throw error;
    return summarySchema.parse(data);
  },
  async list(resource, scope, options = {}) {
    const { data, error } = await client.rpc("admin_list", {
      p_resource: resource,
      p_scope: json(scope),
      p_options: json(options),
    });
    if (error) throw error;
    const page = z
      .object({ rows: z.array(z.unknown()), total: z.number() })
      .parse(data);
    return {
      rows: page.rows.map((value) => parseRecord(resource, value)),
      total: page.total,
    };
  },
  async save(resource, record) {
    const { data, error } = await client.rpc("admin_save", {
      p_resource: resource,
      p_record: json(record),
    });
    if (error) throw error;
    return parseRecord(resource, data);
  },
  async remove(resource, id, scope, version) {
    const { error } = await client.rpc("admin_delete", {
      p_resource: resource,
      p_id: id,
      p_scope: json(scope),
      p_version: version,
    });
    if (error) throw error;
  },
  async provisionSchool(input) {
    const { data, error } = await client.functions.invoke("provision-school", {
      body: input,
    });
    if (error) throw error;
    const result = z
      .object({
        school: z.unknown(),
        email: z.string().email(),
        password: z.string(),
      })
      .parse(data);
    return { ...result, school: parseRecord("schools", result.school) };
  },
};

````

## src/services/contracts.ts

````ts
import type {
  Branch,
  Notification,
  Profile,
  SignInInput,
  Unsubscribe,
} from "../types/domain";
export interface Repository {
  auth: {
    getProfile(): Promise<Profile | null>;
    signIn(input: SignInInput): Promise<Profile>;
    signOut(): Promise<void>;
    resetPassword(email: string): Promise<void>;
    updatePassword(password: string): Promise<void>;
    onChange(callback: (profile: Profile | null) => void): Unsubscribe;
  };
  branches: { list(): Promise<Branch[]> };
  notifications: {
    list(branchId: string): Promise<Notification[]>;
    markRead(id: string): Promise<void>;
    subscribe(branchId: string, callback: () => void): Unsubscribe;
  };
  storage: {
    upload(file: File, branchId: string): Promise<string>;
    getUrl(path: string): Promise<string>;
  };
}

````

## src/services/index.ts

````ts
import { config } from "../lib/config";
import type { Repository } from "./contracts";
let adapter: Promise<Repository> | undefined;
export function getRepository(): Promise<Repository> {
  adapter ??= config.mock
    ? import("../mocks/adapter").then((m) => m.mockRepository)
    : import("./supabase").then((m) => m.supabaseRepository);
  return adapter;
}

````

## src/services/supabase.ts

````ts
import { createClient } from "@supabase/supabase-js";
import type { Database } from "../types/database";
import { roles, type Profile } from "../types/domain";
import type { Repository } from "./contracts";
import { config } from "../lib/config";
const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  import.meta.env.VITE_SUPABASE_ANON_KEY) as string | undefined;
if (!url || !key)
  throw new Error(
    "Supabase is not configured. Set the URL and publishable key in .env.local, or enable VITE_USE_MOCK=true.",
  );
const storageKey = "campus.auth.remember";
// Session-only mode never writes access tokens to persistent storage.
const authStorage = {
  getItem: (name: string) =>
    localStorage.getItem(storageKey) === "true"
      ? localStorage.getItem(name)
      : sessionStorage.getItem(name),
  setItem: (name: string, value: string) => {
    (localStorage.getItem(storageKey) === "true"
      ? localStorage
      : sessionStorage
    ).setItem(name, value);
  },
  removeItem: (name: string) => {
    localStorage.removeItem(name);
    sessionStorage.removeItem(name);
  },
};
export const client = createClient<Database>(url, key, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: authStorage,
  },
});
async function getProfile(): Promise<Profile | null> {
  const { data: sessionData, error: sessionError } =
    await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) return null;
  const {
    data: { user },
    error: userError,
  } = await client.auth.getUser();
  if (userError) throw userError;
  if (!user) return null;
  const { data, error } = await client
    .from("profiles")
    .select("id,school_id,name,email,role,branch_ids,policy_id")
    .eq("id", user.id)
    .single();
  if (error) throw error;
  const role = roles.find((r) => r === data.role);
  // app_metadata is provisioned by a trusted administrator; user_metadata is never authorization input.
  if (!role || user.app_metadata.role !== role)
    throw new Error(
      "Your school access is not provisioned. Contact your school administrator.",
    );
  return {
    id: data.id,
    schoolId: data.school_id,
    name: data.name,
    email: data.email,
    role,
    branchIds: data.branch_ids,
    policyId: data.policy_id,
  };
}
export const supabaseRepository: Repository = {
  auth: {
    getProfile,
    async signIn({ identifier, password, remember, master }) {
      if (!identifier.includes("@"))
        throw new Error(
          "Please use your school email address when signing in to the live service.",
        );
      localStorage.setItem(storageKey, String(remember));
      const { error } = await client.auth.signInWithPassword({
        email: identifier,
        password,
      });
      if (error) throw error;
      try {
        const profile = await getProfile();
        if (
          !profile ||
          (master ? profile.role !== "master" : profile.role === "master")
        )
          throw new Error("This account cannot access this sign-in page.");
        return profile;
      } catch (error) {
        await client.auth.signOut();
        throw error;
      }
    },
    async signOut() {
      const { error } = await client.auth.signOut();
      if (error) throw error;
    },
    async resetPassword(email) {
      const { error } = await client.auth.resetPasswordForEmail(email, {
        redirectTo: `${config.appUrl}/reset-password`,
      });
      if (error) throw error;
    },
    async updatePassword(password) {
      const { error } = await client.auth.updateUser({ password });
      if (error) throw error;
    },
    onChange(callback) {
      let active = true;
      const timers = new Set<ReturnType<typeof setTimeout>>();
      const {
        data: { subscription },
      } = client.auth.onAuthStateChange((event) => {
        if (event === "SIGNED_OUT") callback(null);
        if (
          event === "SIGNED_IN" ||
          event === "USER_UPDATED" ||
          event === "TOKEN_REFRESHED"
        ) {
          // Keep Supabase calls outside the auth callback to avoid its session lock.
          const timer = setTimeout(() => {
            timers.delete(timer);
            void getProfile()
              .then((profile) => {
                if (active) callback(profile);
              })
              .catch(() => {
                if (active) callback(null);
              });
          }, 0);
          timers.add(timer);
        }
      });
      return () => {
        active = false;
        timers.forEach(clearTimeout);
        subscription.unsubscribe();
      };
    },
  },
  branches: {
    async list() {
      const { data, error } = await client
        .from("branches")
        .select("id,school_id,name,city,short_name")
        .order("name");
      if (error) throw error;
      return data;
    },
  },
  notifications: {
    async list(branchId) {
      const { data, error } = await client
        .from("notifications")
        .select("id,user_id,branch_id,title,body,created_at,read")
        .or(`branch_id.eq.${branchId},branch_id.is.null`)
        .order("created_at", { ascending: false })
        .range(0, 49);
      if (error) throw error;
      return data;
    },
    async markRead(id) {
      const { error } = await client
        .from("notifications")
        .update({ read: true })
        .eq("id", id);
      if (error) throw error;
    },
    subscribe(_branchId, callback) {
      const channel = client
        .channel("my-notifications")
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "notifications" },
          callback,
        )
        .subscribe();
      return () => {
        void client.removeChannel(channel);
      };
    },
  },
  storage: {
    async getUrl(path) {
      const { data, error } = await client.storage
        .from("school-files")
        .createSignedUrl(path, 3600);
      if (error) throw error;
      return data.signedUrl;
    },
    async upload(file, branchId) {
      const profile = await getProfile();
      if (!profile) throw new Error("Sign in to upload files.");
      const path = `${profile.schoolId}/${branchId}/${profile.id}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error } = await client.storage
        .from("school-files")
        .upload(path, file, { upsert: false });
      if (error) throw error;
      return path;
    },
  },
};

````

## src/store/auth.ts

````ts
import { create } from "zustand";
import type { Profile } from "../types/domain";
type AuthState = {
  profile: Profile | null;
  initialized: boolean;
  expired: boolean;
  setProfile: (profile: Profile | null) => void;
  setExpired: (expired: boolean) => void;
};
export const useAuth = create<AuthState>((set) => ({
  profile: null,
  initialized: false,
  expired: false,
  setProfile: (profile) => set({ profile, initialized: true }),
  setExpired: (expired) => set({ expired }),
}));

````

## src/store/ui.ts

````ts
import { create } from "zustand";
import { persist } from "zustand/middleware";
export type ThemeChoice = "light" | "dark" | "system";
type UIState = {
  theme: ThemeChoice;
  branchId: string;
  collapsed: boolean;
  emailUpdates: boolean;
  inAppUpdates: boolean;
  setTheme: (theme: ThemeChoice) => void;
  setBranch: (branchId: string) => void;
  toggleSidebar: () => void;
  setPreference: (key: "emailUpdates" | "inAppUpdates", value: boolean) => void;
};
export const useUI = create<UIState>()(
  persist(
    (set) => ({
      theme: "system",
      branchId: "",
      collapsed: false,
      emailUpdates: true,
      inAppUpdates: true,
      setTheme: (theme) => set({ theme }),
      setBranch: (branchId) => set({ branchId }),
      toggleSidebar: () => set((s) => ({ collapsed: !s.collapsed })),
      setPreference: (key, value) => set({ [key]: value }),
    }),
    { name: "campus-ui-v3" },
  ),
);

````

## src/styles/admin.css

````css
.admin-heading-actions {
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}
.admin-stat-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 24px;
  margin: 28px 0;
}
.admin-stat-grid .stat-card > strong {
  font-size: 26px;
  overflow-wrap: anywhere;
}
.dashboard-main-grid {
  display: grid;
  grid-template-columns: 1.4fr 1fr;
  gap: 28px;
  margin: 28px 0;
}
.analytics-chart {
  height: 270px;
  min-width: 0;
  width: 100%;
  margin-top: 20px;
}
.chart-skeleton {
  height: 270px;
}
.chart-summary {
  display: flex;
  gap: 30px;
  border-top: 1px solid var(--line);
  padding-top: 20px;
  font-size: 11px;
  color: var(--muted);
}
.chart-summary b {
  display: block;
  font-size: 15px;
  color: var(--text);
  margin-top: 4px;
}
.activity-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px 0;
  border-top: 1px solid var(--line);
}
.activity-row > div {
  flex: 1;
  min-width: 0;
}
.activity-row b {
  font-size: 12px;
  font-weight: 500;
  display: block;
}
.activity-row small {
  font-size: 10px;
  display: block;
}
.activity-row time {
  font-size: 9px;
  color: var(--muted);
}
.owner-shortcuts > p {
  font-size: 12px;
  margin: 8px 0 20px;
}
.owner-shortcuts > a {
  display: flex;
  align-items: center;
  gap: 14px;
  min-height: 52px;
  border-top: 1px solid var(--line);
  font-size: 12px;
}
.owner-shortcuts > a > span {
  flex: 1;
}
.records-toolbar {
  display: flex;
  align-items: center;
  gap: 14px;
  flex-wrap: wrap;
  margin-bottom: 24px;
}
.records-toolbar > .search-bar {
  flex: 1;
  min-width: 170px;
}
.records-toolbar > .field {
  flex: 0 1 150px;
}
.records-toolbar .select-wrap select {
  min-height: 44px;
}
.record-cell {
  display: flex;
  flex-direction: column;
  gap: 4px;
  overflow-wrap: anywhere;
}
.record-cell b {
  font-size: 11px;
  font-weight: 500;
}
.record-cell small {
  font-size: 9px;
  overflow-wrap: anywhere;
}
.table-actions {
  display: flex;
  gap: 0;
  flex-wrap: wrap;
  justify-content: flex-start;
}
.table-actions .neu-button {
  padding: 8px;
  min-width: 44px;
  font-size: 10px;
}
.records-toolbar .bulk-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  padding-top: 16px;
  border-top: 1px solid var(--line);
  font-size: 12px;
}
.pagination {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 12px;
  padding-top: 20px;
  color: var(--muted);
  font-size: 11px;
}
.pagination > span:first-child {
  margin-right: auto;
}
.admin-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.credentials {
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.module-footnote {
  font-size: 11px;
  color: var(--muted);
  line-height: 1.9;
  margin: 20px 0 28px;
}
.import-preview {
  padding: 16px 0;
}
.import-preview p {
  font-size: 11px;
  margin-top: 8px;
}
.permission-matrix {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 28px;
}
.permission-role {
  min-width: 0;
  padding: 8px 0 20px;
  border-bottom: 1px solid var(--line);
}
.permission-role .section-heading {
  flex-wrap: wrap;
  gap: 8px;
}
.permission-role h2 {
  font-size: 15px;
}
.permission-role > .choice {
  display: flex;
  font-size: 11px;
}
.settings-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 28px;
  margin: 28px 0;
}
.audit-filters,
.revenue-filters {
  display: flex;
  align-items: flex-end;
  gap: 20px;
  margin-bottom: 28px;
  flex-wrap: wrap;
}
.audit-filters > .search-bar {
  flex: 1;
  min-width: 200px;
}
.audit-filters > .field,
.revenue-filters > .field {
  min-width: 180px;
}
.readonly-banner {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px 24px;
  border: 1px solid var(--line);
  border-radius: 16px;
  margin-bottom: 28px;
  background: var(--accent-soft);
}
.readonly-banner > div {
  flex: 1;
}
.readonly-banner b {
  font-size: 12px;
}
.readonly-banner p {
  font-size: 11px;
  margin-top: 5px;
}
.role-preview-heading {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 28px;
}
.role-preview-heading > div {
  flex: 1;
}
.role-preview-heading p {
  font-size: 12px;
  margin-top: 8px;
}
.record-mobile {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}
.record-mobile > div:first-child {
  flex: 1;
  min-width: 0;
}
.record-mobile b {
  font-size: 12px;
  display: block;
}
.record-mobile small {
  font-size: 10px;
  display: block;
  overflow-wrap: anywhere;
}
.neu-tabs button,
.tool-link,
.login-help .text-button,
.help-card .neu-button,
.welcome-copy > .neu-button {
  min-height: 44px;
}
.sidebar-collapse {
  min-height: 44px !important;
  width: 44px !important;
  right: -22px;
}
.search-bar .neu-button {
  min-height: 44px;
  min-width: 44px;
}
@media (max-width: 1200px) {
  .admin-stat-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 20px;
  }
  .dashboard-main-grid {
    grid-template-columns: 1fr;
    gap: 24px;
  }
  .permission-matrix {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .admin-heading-actions {
    gap: 10px;
  }
  .admin-heading-actions > .neu-button {
    font-size: 10px;
    padding: 9px 12px;
  }
}
@media (max-width: 639px) {
  .admin-heading-actions {
    width: 100%;
  }
  .page-heading:has(.admin-heading-actions) {
    flex-wrap: wrap;
  }
  .admin-heading-actions > .neu-button {
    flex: 1;
  }
  .admin-stat-grid {
    grid-template-columns: 1fr;
    gap: 20px;
    margin: 24px 0;
  }
  .admin-stat-grid .stat-card > strong {
    font-size: 32px;
  }
  .admin-stat-grid .stat-top {
    font-size: 12px;
  }
  .admin-stat-grid .stat-top .icon-tile {
    display: flex;
  }
  .settings-grid,
  .permission-matrix {
    grid-template-columns: 1fr;
    gap: 24px;
  }
  .dashboard-main-grid > .neu-card {
    padding: 22px;
  }
  .analytics-chart {
    height: 230px;
  }
  .audit-filters {
    align-items: stretch;
    gap: 16px;
  }
  .audit-filters > .field {
    flex: 1;
    min-width: 120px;
  }
  .audit-filters > .search-bar {
    width: 100%;
    flex: none;
  }
  .revenue-filters > .field {
    flex: 1;
    min-width: 120px;
  }
  .readonly-banner {
    align-items: flex-start;
    padding: 20px;
    flex-wrap: wrap;
  }
  .readonly-banner > .badge {
    margin-left: 36px;
  }
  .role-preview-heading {
    flex-wrap: wrap;
    padding: 22px;
  }
  .role-preview-heading > .field {
    flex-basis: 100%;
  }
  .records-toolbar > .field {
    flex: 1;
    min-width: 120px;
  }
  .records-toolbar > .search-bar {
    flex-basis: 100%;
  }
  .pagination {
    gap: 6px;
    font-size: 10px;
  }
  .permission-role > .choice {
    font-size: 12px;
  }
  .record-mobile {
    align-items: flex-start;
  }
  .record-mobile > .choice {
    flex-basis: 100%;
  }
  .mobile-table article:has(.record-mobile) {
    height: auto;
    min-height: 90px;
    padding: 18px 0;
  }
  .records-toolbar .bulk-actions {
    flex-wrap: wrap;
  }
  .activity-row time {
    font-size: 8px;
  }
  .chart-summary {
    gap: 20px;
  }
  .permission-role .choice {
    min-height: 46px;
  }
}
.people-table .neu-table th:first-child {
  width: 56px;
}
.people-table .neu-table th:nth-child(2) {
  width: 34%;
}
.table-actions .neu-button {
  white-space: normal;
}
.school-monogram > img {
  object-fit: contain;
  aspect-ratio: 1;
  border-radius: 6px;
}
.school-identity b {
  overflow-wrap: anywhere;
}
.field textarea {
  width: 100%;
  background: var(--base);
  color: var(--text);
  border: 1px solid var(--line);
  border-radius: 12px;
  box-shadow: var(--inset-pressed);
  padding: 14px;
  font-size: 12px;
  resize: vertical;
  min-height: 120px;
}
.platform-label {
  font-size: 12px;
  font-weight: 500;
}
.table-actions .neu-button {
  min-width: 44px;
}

````

## src/styles/global.css

````css
@tailwind base;
@tailwind components;
@tailwind utilities;

* {
  box-sizing: border-box;
}
body {
  margin: 0;
  background: var(--base);
  color: var(--text);
  font-size: 14px;
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
}
button,
input,
select,
textarea {
  font: inherit;
}
button,
a,
input,
select {
  touch-action: manipulation;
}
button {
  cursor: pointer;
  color: inherit;
}
button:disabled {
  cursor: not-allowed;
}
a {
  color: inherit;
  text-decoration: none;
}
button {
  border: 0;
}
h1,
h2,
h3,
p {
  margin: 0;
}
h1,
h2,
h3 {
  line-height: 1.3;
  font-weight: 600;
  letter-spacing: -0.04em;
}
h1 {
  font-size: clamp(25px, 3vw, 34px);
}
h2 {
  font-size: 19px;
}
h3 {
  font-size: 16px;
}
p {
  color: var(--muted);
}
small {
  font-size: 11px;
  color: var(--muted);
}
svg {
  flex-shrink: 0;
}
::selection {
  background: #a99bd666;
}
:focus-visible {
  outline: 2px solid var(--accent-text);
  outline-offset: 4px;
  border-radius: 8px;
  box-shadow: 0 0 0 4px var(--accent-soft);
}
input:focus-visible,
select:focus-visible {
  outline-offset: 2px;
}
button:disabled {
  opacity: 0.5;
}
.gradient-defs {
  position: absolute;
  pointer-events: none;
}
.muted {
  color: var(--muted);
}
.eyebrow {
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.14em;
  color: var(--muted);
}
.text-button {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: transparent;
  color: var(--accent-text);
  font-size: 12px;
  font-weight: 600;
  min-height: 44px;
  padding: 0;
}
.text-button:hover {
  text-decoration: underline;
}
.icon {
  vertical-align: middle;
}
.neu-card {
  background: var(--surface);
  border-radius: var(--radius);
  box-shadow: var(--raised-sm);
  padding: 24px;
  min-width: 0;
}
.neu-button {
  min-height: 44px;
  border: 1px solid transparent;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 10px 18px;
  border-radius: 12px;
  background: var(--base);
  box-shadow: var(--raised-sm);
  font-size: 12px;
  font-weight: 600;
  transition:
    transform 0.15s,
    opacity 0.15s;
  white-space: normal;
}
.neu-button:hover:not(:disabled) {
  transform: translateY(-1px);
}
.neu-button:active:not(:disabled) {
  box-shadow: var(--inset-pressed);
  transform: translateY(1px);
}
.neu-button.primary {
  background: var(--text);
  color: var(--base);
  box-shadow: var(--raised-sm);
}
.neu-button.icon {
  width: 44px;
  padding: 10px;
}
.neu-button.ghost {
  box-shadow: none;
  background: transparent;
  padding: 8px 12px;
}
.neu-button.danger {
  color: var(--danger);
  border-color: var(--danger);
}
.icon-tile {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  background: var(--base);
  box-shadow: var(--raised-sm);
  border-radius: 14px;
  flex-shrink: 0;
}
.icon-tile.small {
  width: 36px;
  height: 36px;
  border-radius: 11px;
  box-shadow: none;
  background: var(--accent-soft);
}
.badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  border: 1px solid var(--line);
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.01em;
  white-space: nowrap;
  color: var(--muted);
  line-height: 1.6;
}
.badge.accent {
  background: var(--accent-soft);
  color: var(--accent-text);
  border-color: transparent;
}
.badge.success {
  color: var(--success);
  background: var(--success-bg);
  border-color: transparent;
}
.badge.warning {
  color: var(--warning);
  background: var(--warning-bg);
  border-color: transparent;
}
.avatar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #d9e9f5, #ddd8ec);
  color: #455376;
  font-size: 12px;
  font-weight: 600;
  flex-shrink: 0;
}
.avatar.sm {
  width: 34px;
  height: 34px;
  font-size: 10px;
}
.avatar.lg {
  width: 64px;
  height: 64px;
  font-size: 21px;
}
.field {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
}
.field label {
  font-size: 12px;
  font-weight: 500;
}
.input-wrap {
  position: relative;
  display: flex;
  align-items: center;
}
.input-wrap > .icon {
  position: absolute;
  left: 15px;
  pointer-events: none;
}
.input-wrap input,
.select-wrap select {
  width: 100%;
  min-width: 0;
  min-height: 48px;
  background: var(--base);
  border: 1px solid var(--line);
  box-shadow: var(--inset-pressed);
  border-radius: 12px;
  padding: 12px 14px;
  color: var(--text);
  font-size: 12px;
}
.input-wrap > .icon + input {
  padding-left: 44px;
}
.input-wrap input::placeholder {
  color: var(--muted);
  opacity: 0.85;
}
.field-error {
  font-size: 11px;
  color: var(--danger);
}
.field-hint {
  font-size: 11px;
  color: var(--muted);
}
.select-wrap {
  position: relative;
}
.select-wrap select {
  appearance: none;
  padding-right: 34px;
}
.select-wrap > .icon {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
}
.choice {
  display: inline-flex;
  gap: 8px;
  align-items: center;
  min-height: 44px;
  font-size: 12px;
  cursor: pointer;
}
.choice input {
  width: 17px;
  height: 17px;
  accent-color: #667dad;
  cursor: pointer;
}
.toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  min-height: 64px;
  padding: 12px 0;
}
.toggle-row > span {
  display: flex;
  flex-direction: column;
}
.control-label {
  font-size: 13px;
  font-weight: 500;
}
.toggle {
  padding: 5px;
  width: 46px;
  min-width: 46px;
  height: 44px;
  border-radius: 22px;
  display: flex;
  align-items: center;
  background: transparent;
  position: relative;
}
.toggle::before {
  position: absolute;
  content: "";
  inset: 8px 0;
  border-radius: 18px;
  background: var(--base);
  box-shadow: var(--inset-pressed);
}
.toggle span {
  width: 20px;
  height: 20px;
  background: var(--muted);
  border-radius: 50%;
  position: relative;
}
.toggle.on {
  justify-content: flex-end;
}
.toggle.on::before {
  background: var(--gradient);
  box-shadow: none;
}
.toggle.on span {
  background: #f3f5f8;
}
.neu-tabs {
  display: inline-flex;
  gap: 4px;
  padding: 5px;
  box-shadow: var(--inset-pressed);
  border-radius: 12px;
  max-width: 100%;
  flex-wrap: wrap;
}
.neu-tabs button {
  min-height: 38px;
  padding: 8px 14px;
  border-radius: 8px;
  background: transparent;
  color: var(--muted);
  font-size: 12px;
  position: relative;
}
.neu-tabs button.active {
  background: var(--base);
  color: var(--text);
  box-shadow: var(--raised-sm);
}
.neu-tabs button.active::after {
  content: "";
  position: absolute;
  bottom: 3px;
  left: 35%;
  right: 35%;
  height: 2px;
  border-radius: 2px;
  background: var(--gradient);
}
.progress-block {
  padding: 16px 0;
}
.progress-label {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  font-size: 11px;
  color: var(--muted);
  margin-bottom: 10px;
}
.progress-label b {
  font-weight: 500;
}
.progress-track {
  height: 7px;
  overflow: hidden;
  border-radius: 6px;
  box-shadow: var(--inset-pressed);
}
.progress-track > div {
  height: 100%;
  width: 100%;
  background: var(--gradient);
  transform-origin: left;
  border-radius: 6px;
}
.search-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  border: 1px solid var(--line);
  box-shadow: var(--inset-pressed);
  border-radius: 12px;
  min-height: 44px;
  padding: 0 14px;
  min-width: 0;
}
.search-bar input {
  min-width: 0;
  width: 100%;
  background: transparent;
  border: 0;
  color: var(--text);
  font-size: 12px;
  padding: 12px 0;
}
.search-bar input:focus-visible {
  outline: 0;
  box-shadow: none;
}
.search-bar:focus-within {
  outline: 2px solid var(--accent-text);
  outline-offset: 2px;
}
.search-bar .neu-button {
  padding: 0;
  min-width: 28px;
  min-height: 32px;
}
.skeleton {
  background: var(--line);
  border-radius: 12px;
  position: relative;
  overflow: hidden;
}
.skeleton::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
    90deg,
    transparent,
    rgba(255, 255, 255, 0.17),
    transparent
  );
  transform: translateX(-100%);
  animation: shimmer 1.4s infinite;
}
.spin {
  animation: spin 0.8s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes shimmer {
  to {
    transform: translateX(100%);
  }
}
.empty-state {
  text-align: center;
  padding: 36px 20px;
  display: flex;
  align-items: center;
  flex-direction: column;
  gap: 12px;
}
.empty-state p {
  max-width: 340px;
  font-size: 13px;
}
.overlay {
  position: fixed;
  inset: 0;
  z-index: 100;
  background: rgba(13, 20, 32, 0.35);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}
.overlay-panel {
  background: var(--base);
  border: 1px solid var(--line);
  border-radius: 24px;
  width: 100%;
  max-width: 520px;
  max-height: 90dvh;
  display: flex;
  flex-direction: column;
  outline: none;
}
.overlay-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  padding: 28px 28px 16px;
}
.overlay-header h2 {
  font-size: 21px;
}
.overlay-header p {
  font-size: 12px;
  margin-top: 8px;
}
.overlay-content {
  padding: 8px 28px 28px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.overlay-footer {
  padding: 16px 28px 24px;
  border-top: 1px solid var(--line);
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}
.drawer-overlay {
  justify-content: flex-end;
  padding: 12px;
}
.drawer-panel {
  height: calc(100dvh - 24px);
  max-height: none;
  max-width: 420px;
}
.drawer-panel .overlay-content {
  flex: 1;
}
.file-upload {
  border: 1px dashed var(--line);
  border-radius: 16px;
  text-align: center;
  padding: 24px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  margin-top: 16px;
}
.file-upload.dragging {
  outline: 2px solid var(--accent-text);
}
.file-upload b {
  font-size: 12px;
}
.file-upload [role="status"] {
  font-size: 11px;
  color: var(--muted);
}
.table-scroll {
  margin-top: 20px;
  max-width: 100%;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.neu-table {
  width: 100%;
  table-layout: fixed;
  border-collapse: collapse;
  font-size: 12px;
}
.neu-table th {
  text-align: left;
  font-size: 10px;
  font-weight: 500;
  color: var(--muted);
  border-bottom: 1px solid var(--line);
  position: sticky;
  top: 0;
  background: var(--base);
  z-index: 1;
}
.neu-table th button {
  background: transparent;
  padding: 10px 4px;
  min-height: 44px;
  width: 100%;
  text-align: left;
  display: flex;
  gap: 12px;
  align-items: center;
}
.neu-table th:first-child {
  width: 52%;
}
.neu-table td {
  padding: 14px 4px;
  border-bottom: 1px solid var(--line);
  overflow-wrap: anywhere;
}
.table-person {
  display: flex;
  align-items: center;
  gap: 10px;
}
.table-person span:last-child {
  display: flex;
  flex-direction: column;
}
.table-person b {
  font-weight: 500;
}
.table-person small {
  font-size: 10px;
}
.mobile-table {
  display: none;
}
.stat-top {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  align-items: center;
  color: var(--muted);
  font-size: 12px;
}
.stat-card > strong {
  display: block;
  font-size: 32px;
  font-weight: 600;
  letter-spacing: -0.06em;
  margin: 10px 0;
}
.stat-card > small {
  display: block;
}
.brand {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  font-size: 28px;
  font-weight: 700;
  letter-spacing: -0.08em;
  line-height: 1;
}
.brand-dot {
  color: #8099c9;
}
.brand-mark {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  box-shadow: var(--raised-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.brand > span:last-child {
  padding-bottom: 4px;
}
.login-page {
  padding: 28px clamp(24px, 4vw, 72px) 0;
  min-height: 100dvh;
  display: flex;
  flex-direction: column;
  max-width: 1800px;
  margin: auto;
}
.login-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.login-top-right {
  display: flex;
  align-items: center;
  gap: 28px;
}
.version-label {
  color: var(--muted);
  font-size: 9px;
  letter-spacing: 0.14em;
  font-weight: 500;
}
.login-layout {
  display: grid;
  grid-template-columns: 1.1fr 1fr;
  gap: clamp(24px, 6vw, 100px);
  align-items: center;
  flex: 1;
  max-width: 1180px;
  width: 100%;
  margin: 48px auto;
}
.login-story > .badge {
  font-size: 10px;
  padding: 7px 10px;
  margin-bottom: 24px;
}
.login-story h1 {
  font-size: clamp(34px, 3.5vw, 53px);
  line-height: 1.18;
  font-weight: 600;
  letter-spacing: -0.06em;
}
.login-story h1 > span {
  color: var(--accent-text);
}
.login-story > p {
  margin-top: 20px;
  font-size: 14px;
  line-height: 1.9;
}
.login-form-side {
  max-width: 440px;
  width: 100%;
  justify-self: end;
}
.login-card {
  padding: 36px 36px 24px;
  box-shadow: var(--raised-md);
  border: 1px solid var(--white);
  border-radius: 26px;
}
.login-symbol {
  margin-bottom: 26px;
  width: 56px;
  height: 56px;
  border-radius: 18px;
}
.login-heading .eyebrow {
  font-size: 9px;
}
.login-heading h2 {
  font-size: 29px;
  margin: 8px 0 8px;
  letter-spacing: -0.05em;
}
.login-heading > p {
  font-size: 12px;
}
.login-card form {
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-top: 28px;
}
.password-field {
  position: relative;
}
.password-field > .neu-button {
  position: absolute;
  right: 5px;
  top: 29px;
  width: 42px;
  padding: 8px;
}
.password-field input {
  padding-right: 48px;
}
.login-options {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: -9px;
  gap: 8px;
}
.login-options .text-button {
  font-size: 11px;
}
.login-options .choice {
  font-size: 11px;
}
.login-submit {
  width: 100%;
  min-height: 48px;
  margin-top: -5px;
}
.login-submit > .icon {
  margin-left: auto;
}
.secure-note {
  display: flex;
  gap: 7px;
  justify-content: center;
  align-items: center;
  margin: 19px 0 22px;
  font-size: 10px;
  color: var(--muted);
}
.demo-box {
  border-top: 1px solid var(--line);
  padding-top: 20px;
}
.demo-box > div:first-child {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  align-items: center;
}
.demo-box > div:first-child > span:last-child {
  font-size: 10px;
  color: var(--muted);
}
.demo-box .badge {
  font-size: 8px;
  letter-spacing: 0.06em;
}
.demo-controls {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 8px;
}
.demo-controls select {
  min-width: 0;
  flex: 1;
  min-height: 44px;
  background: transparent;
  border: 0;
  color: var(--text);
  font-size: 12px;
  padding: 0;
}
.demo-controls .neu-button {
  padding: 8px 0;
  font-size: 11px;
}
.demo-box > small {
  font-size: 9px;
}
.login-help {
  text-align: center;
  font-size: 10px;
  margin: 20px -20px 0;
}
.login-help .text-button {
  font-size: 10px;
  min-height: 32px;
  font-weight: 500;
}
.login-footer {
  border-top: 1px solid var(--line);
  padding: 22px 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 10px;
  color: var(--muted);
}
.login-footer > span:first-child {
  display: flex;
  align-items: center;
  gap: 10px;
}
.login-footer i {
  width: 3px;
  height: 3px;
  background: #94a4c1;
  border-radius: 50%;
}
.story-bottom {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-top: 8px;
}
.story-bottom > div:last-child {
  display: flex;
  flex-direction: column;
}
.story-bottom b {
  font-size: 10px;
  font-weight: 500;
}
.story-bottom small {
  font-size: 9px;
  margin-top: 3px;
}
.avatar-stack {
  display: flex;
  padding-left: 6px;
}
.avatar-stack > span {
  margin-left: -6px;
  width: 29px;
  height: 29px;
  display: flex;
  justify-content: center;
  align-items: center;
  border: 2px solid var(--base);
  border-radius: 50%;
  font-size: 8px;
  font-weight: 600;
  background: #ccd9e9;
  color: #3e5576;
}
.avatar-stack > span:nth-child(2) {
  background: #d9d4e7;
}
.avatar-stack > span:nth-child(3) {
  background: #d5e2dd;
}
.avatar-stack > span:nth-child(4) {
  background: #e4d9cb;
}
.form-error {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: 11px;
  color: var(--danger);
  padding: 10px 12px;
  border-radius: 10px;
  border: 1px solid var(--danger);
}
.campus-illustration {
  height: 290px;
  position: relative;
  width: 100%;
  max-width: 500px;
  isolation: isolate;
  margin: 6px auto 0;
}
.orbit {
  position: absolute;
  border: 1px dashed var(--line);
  border-radius: 50%;
  width: 300px;
  height: 220px;
  left: 50%;
  top: 25px;
  transform: translateX(-50%) rotate(-16deg);
}
.orbit-two {
  width: 390px;
  height: 165px;
  top: 60px;
  transform: translateX(-50%) rotate(16deg);
  border-style: solid;
  border-color: var(--line);
  opacity: 0.6;
}
.campus-platform {
  position: absolute;
  width: 286px;
  height: 105px;
  border-radius: 50%;
  left: 50%;
  bottom: 32px;
  transform: translateX(-50%);
  background: var(--base);
  box-shadow: var(--raised-md);
}
.campus-building {
  width: 166px;
  height: 140px;
  position: absolute;
  bottom: 47px;
  left: 60px;
  background: var(--base);
  border: 1px solid var(--white);
  border-radius: 12px 12px 6px 6px;
  box-shadow: var(--raised-md);
}
.building-roof {
  height: 54px;
  position: absolute;
  top: -33px;
  left: 16px;
  right: 16px;
  background: var(--base);
  border-radius: 32px 32px 8px 8px;
  box-shadow: var(--raised-sm);
  display: flex;
  align-items: center;
  justify-content: center;
}
.building-clock {
  position: absolute;
  width: 17px;
  height: 17px;
  top: 34px;
  left: 74px;
  border: 2px solid #93a6c3;
  border-radius: 50%;
}
.building-clock::after {
  content: "";
  position: absolute;
  width: 4px;
  height: 5px;
  border-left: 1px solid #8196b6;
  border-bottom: 1px solid #8196b6;
  left: 6px;
  top: 3px;
}
.building-label {
  font-size: 6px;
  font-weight: 600;
  letter-spacing: 0.22em;
  position: absolute;
  top: 25px;
  width: 100%;
  text-align: center;
  color: var(--accent-text);
}
.building-windows {
  display: grid;
  grid-template-columns: repeat(3, 15px);
  gap: 13px 33px;
  position: absolute;
  top: 61px;
  left: 27px;
}
.building-windows i {
  height: 21px;
  background: linear-gradient(135deg, #b2d4e8, #c3bcde);
  border-radius: 4px;
  box-shadow: var(--inset-pressed);
}
.building-door {
  position: absolute;
  bottom: 0;
  left: 67px;
  width: 33px;
  height: 46px;
  background: var(--base);
  border-radius: 18px 18px 0 0;
  box-shadow: var(--inset-pressed);
}
.campus-path {
  position: absolute;
  width: 66px;
  height: 23px;
  border-radius: 50%;
  bottom: 7px;
  left: 110px;
  background: var(--base);
  box-shadow: var(--inset-pressed);
}
.campus-tree {
  position: absolute;
  bottom: 28px;
  width: 34px;
  height: 60px;
}
.campus-tree > i {
  position: absolute;
  width: 4px;
  height: 35px;
  left: 15px;
  bottom: 0;
  background: #a6b6b3;
  border-radius: 4px;
}
.campus-tree > span {
  position: absolute;
  width: 32px;
  height: 40px;
  top: 0;
  left: 1px;
  background: #cfded9;
  border-radius: 50% 50% 45% 45%;
  box-shadow: var(--raised-sm);
}
.tree-left {
  left: 15px;
}
.tree-right {
  right: 12px;
  transform: scale(0.85);
}
.floating-tile {
  position: absolute;
  width: 54px;
  height: 54px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: var(--raised-sm);
  background: var(--base);
  border-radius: 16px;
  z-index: 2;
}
.tile-book {
  left: 15%;
  top: 48px;
  transform: rotate(-10deg);
}
.tile-community {
  right: 9%;
  top: 16px;
  transform: rotate(10deg);
}
.tile-message {
  right: 7%;
  bottom: 62px;
  transform: rotate(-6deg);
  width: 46px;
  height: 46px;
}
.online-dot {
  position: absolute;
  width: 8px;
  height: 8px;
  top: 9px;
  right: 9px;
  background: #80ab9c;
  border: 2px solid var(--base);
  border-radius: 50%;
}
.illustration-caption {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 7px;
  white-space: nowrap;
  font-size: 9px;
  letter-spacing: 0.01em;
  color: var(--muted);
}
.status-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--success);
  display: inline-block;
  flex-shrink: 0;
}
[data-theme="dark"] .campus-tree > span {
  background: #334d45;
}
[data-theme="dark"] .building-windows i {
  background: linear-gradient(135deg, #405d70, #54506a);
}
.app-shell {
  min-height: 100dvh;
}
.sidebar {
  width: var(--sidebar);
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  padding: 30px 20px 16px;
  border-right: 1px solid var(--line);
  display: flex;
  flex-direction: column;
  z-index: 30;
  background: var(--base);
}
.sidebar > .brand {
  padding-left: 8px;
  margin-bottom: 32px;
}
.sidebar .brand {
  font-size: 27px;
}
.school-identity {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 12px 4px 22px;
  border-bottom: 1px solid var(--line);
  margin-bottom: 15px;
}
.school-monogram {
  width: 28px;
  height: 32px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--accent-soft);
  font-family: Georgia, serif;
  color: var(--accent-text);
  font-weight: bold;
}
.school-identity > div {
  flex: 1;
  min-width: 0;
}
.school-identity b {
  display: block;
  font-size: 10px;
  letter-spacing: -0.01em;
}
.school-identity small {
  font-size: 8px;
  display: block;
  margin-top: 2px;
}
.sidebar > nav {
  flex: 1;
  overflow-y: auto;
  scrollbar-width: none;
}
.nav-section {
  margin: 12px 0 18px;
}
.nav-section-label {
  font-size: 9px;
  letter-spacing: 0.12em;
  color: var(--muted);
  padding: 0 12px 9px;
}
.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  min-height: 44px;
  border-radius: 11px;
  font-size: 11px;
  color: var(--muted);
  margin: 4px 0;
  position: relative;
}
.nav-item > .icon:first-child {
  width: 18px;
  height: 18px;
}
.nav-item > span:nth-child(2) {
  flex: 1;
}
.nav-item.active {
  background: var(--base);
  box-shadow: var(--inset-pressed);
  color: var(--text);
  font-weight: 500;
}
.nav-item.active::before {
  position: absolute;
  content: "";
  left: 0;
  top: 13px;
  bottom: 13px;
  width: 3px;
  border-radius: 3px;
  background: var(--gradient);
}
.nav-active-dot {
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: #81a3d0;
  display: none;
}
.nav-item.active .nav-active-dot {
  display: block;
}
.nav-item.unavailable {
  color: var(--muted);
}
.nav-item.unavailable > .icon:first-child {
  opacity: 0.75;
}
.nav-item.unavailable > .icon:last-child {
  opacity: 0.65;
}
.sidebar-bottom {
  padding-top: 10px;
}
.help-card {
  padding: 16px 14px;
  border: 1px solid var(--line);
  border-radius: 14px;
}
.help-card .icon-tile {
  float: right;
  width: 28px;
  height: 28px;
}
.help-card b {
  font-size: 11px;
  font-weight: 500;
}
.help-card p {
  font-size: 10px;
  line-height: 1.8;
  margin-top: 5px;
}
.help-card .neu-button {
  font-size: 9px;
  padding: 8px 0;
  min-height: 36px;
  color: var(--accent-text);
  justify-content: space-between;
  width: 100%;
  margin-top: 8px;
}
.sidebar-account {
  display: flex;
  align-items: center;
  width: 100%;
  text-align: left;
  gap: 10px;
  background: transparent;
  border-top: 1px solid var(--line);
  margin-top: 20px;
  padding: 18px 0 0;
}
.sidebar-account > span:nth-child(2) {
  flex: 1;
  min-width: 0;
}
.sidebar-account b {
  font-size: 10px;
  font-weight: 500;
  display: block;
}
.sidebar-account small {
  font-size: 8px;
  display: block;
}
.sidebar-collapse {
  position: absolute;
  right: -15px;
  top: 84px;
  min-height: 28px !important;
  width: 28px !important;
  border-radius: 50%;
  padding: 5px !important;
  background: var(--base);
  border: 1px solid var(--line);
}
.sidebar-collapse .icon {
  width: 13px;
  height: 13px;
}
.app-main {
  margin-left: var(--sidebar);
  min-width: 0;
}
.top-header {
  height: 85px;
  padding: 0 36px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid var(--line);
  gap: 16px;
}
.header-branch,
.header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}
.header-branch .select-wrap select {
  background: transparent;
  box-shadow: none;
  border: 0;
  padding-left: 0;
  font-size: 12px;
  font-weight: 500;
  max-width: 200px;
}
.header-branch .badge {
  font-size: 8px;
  padding: 1px 5px;
}
.header-actions {
  gap: 14px;
}
.global-search-trigger {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 44px;
  background: transparent;
  color: var(--muted);
  font-size: 10px;
  min-width: 210px;
}
.global-search-trigger kbd {
  margin-left: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  border: 1px solid var(--line);
  border-radius: 5px;
  font-size: 14px;
}
.header-actions .neu-button {
  box-shadow: none;
  background: transparent;
}
.notification-trigger {
  position: relative;
}
.notification-trigger > span {
  position: absolute;
  right: 12px;
  top: 9px;
  border: 2px solid var(--base);
  background: #889fd1;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  pointer-events: none;
}
.header-divider {
  width: 1px;
  height: 26px;
  background: var(--line);
  margin: 0 3px;
}
.header-profile {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 44px;
  background: transparent;
}
.main-content {
  max-width: 1520px;
  margin: 0 auto;
  padding: 24px 36px 0;
  outline: none;
}
.breadcrumb {
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: var(--muted);
  font-size: 10px;
  margin-bottom: 30px;
  gap: 12px;
}
.breadcrumb > span {
  display: flex;
  align-items: center;
  gap: 10px;
}
.breadcrumb > .badge {
  font-size: 8px;
}
.page-heading {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  align-items: center;
  margin-bottom: 28px;
}
.page-heading .eyebrow {
  margin-bottom: 9px;
  font-size: 9px;
}
.page-heading p {
  font-size: 12px;
  margin-top: 9px;
}
.page-heading h1 {
  font-size: 29px;
}
.greeting-dot {
  font-size: 22px;
  color: #97aac8;
  padding-left: 5px;
}
.date-chip {
  display: flex;
  align-items: center;
  gap: 9px;
  white-space: nowrap;
  font-size: 10px;
  color: var(--muted);
  padding-top: 20px;
}
.welcome-hero {
  position: relative;
  padding: 32px 36px;
  display: flex;
  overflow: hidden;
  min-height: 270px;
  box-shadow: var(--raised-sm);
  border: 1px solid var(--white);
}
.welcome-copy {
  position: relative;
  z-index: 2;
}
.welcome-copy > .badge {
  font-size: 8px;
  letter-spacing: 0.09em;
  padding: 4px 8px;
}
.welcome-copy h2 {
  font-size: 32px;
  line-height: 1.3;
  margin-top: 16px;
  letter-spacing: -0.05em;
}
.welcome-copy h2 > span {
  color: var(--accent-text);
}
.welcome-copy p {
  font-size: 11px;
  line-height: 1.9;
  margin-top: 12px;
}
.welcome-copy > .neu-button {
  margin-top: 20px;
  font-size: 10px;
  min-height: 40px;
  padding: 9px 14px;
  gap: 22px;
}
.welcome-hero .campus-illustration {
  position: absolute;
  right: 10px;
  top: 0;
  width: 40%;
  height: 270px;
  margin: 0;
  max-width: 420px;
}
.welcome-hero .campus-platform {
  transform: translateX(-50%) scale(0.8);
  bottom: 28px;
}
.welcome-hero .orbit-one {
  width: 260px;
  height: 200px;
  top: 30px;
}
.welcome-hero .orbit-two {
  width: 330px;
  height: 150px;
  top: 50px;
}
.welcome-hero .tile-book {
  width: 42px;
  height: 42px;
  top: 70px;
  left: 10%;
}
.welcome-hero .tile-community {
  width: 42px;
  height: 42px;
  top: 30px;
  right: 16%;
}
.welcome-hero .tile-message {
  bottom: 62px;
  right: 9%;
  width: 36px;
  height: 36px;
}
.welcome-hero .floating-tile .icon {
  width: 23px;
  height: 23px;
}
.welcome-hero .illustration-caption {
  bottom: 20px;
  font-size: 8px;
}
.hero-edition {
  position: absolute;
  bottom: 10px;
  right: 20px;
  font-size: 6px;
  color: var(--muted);
  letter-spacing: 0.12em;
  opacity: 0.8;
}
.workspace-summary {
  display: grid;
  grid-template-columns: 1.1fr 1fr 1.1fr;
  margin: 26px 0 38px;
  padding: 14px 0;
  border-top: 1px solid var(--line);
  border-bottom: 1px solid var(--line);
}
.workspace-summary > div {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 0 16px;
  border-right: 1px solid var(--line);
  min-width: 0;
}
.workspace-summary > div:first-child {
  padding-left: 0;
}
.workspace-summary > div:last-child {
  border: 0;
  padding-right: 0;
}
.workspace-summary small {
  display: block;
  font-size: 7px;
  letter-spacing: 0.11em;
}
.workspace-summary b {
  display: block;
  font-size: 10px;
  font-weight: 500;
  line-height: 1.8;
}
.workspace-summary .badge {
  font-size: 7px;
  padding: 1px 4px;
}
.workspace-summary .icon-tile {
  width: 30px;
  height: 30px;
  background: transparent;
}
.workspace-summary .icon-tile .icon {
  width: 20px;
}
.workspace-summary .status-dot {
  margin-left: auto;
}
.overview-columns {
  display: grid;
  grid-template-columns: 1fr 310px;
  gap: 28px;
}
.section-heading {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  align-items: center;
  margin-bottom: 20px;
}
.section-heading h2 {
  font-size: 16px;
}
.section-heading p {
  font-size: 10px;
  margin-top: 6px;
}
.section-heading > .text-button {
  font-size: 10px;
  white-space: nowrap;
}
.workspace-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 20px;
}
.workspace-tool {
  padding: 22px;
  display: flex;
  flex-direction: column;
  height: 100%;
}
.tool-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  gap: 12px;
}
.tool-top .badge {
  font-size: 8px;
  padding: 2px 6px;
}
.workspace-tool h3 {
  font-size: 13px;
  margin-bottom: 8px;
}
.workspace-tool p {
  font-size: 10px;
  line-height: 1.8;
  flex: 1;
  margin-bottom: 16px;
}
.tool-link {
  font-size: 9px;
  color: var(--accent-text);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 36px;
}
.workspace-tool .icon-tile {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  box-shadow: none;
  background: var(--accent-soft);
}
.workspace-tool .neu-button {
  font-size: 10px;
  justify-content: space-between;
  padding: 8px 0;
}
.workspace-tool .eyebrow {
  margin-bottom: 12px;
  font-size: 7px;
}
.getting-started {
  padding: 24px;
}
.getting-started .section-heading {
  margin-bottom: 18px;
}
.getting-started h2 {
  font-size: 16px;
}
.getting-started > p {
  font-size: 10px;
  margin-top: 7px;
}
.getting-started > .neu-button {
  font-size: 10px;
  width: 100%;
  justify-content: space-between;
  color: var(--accent-text);
  border-top: 1px solid var(--line);
  border-radius: 0;
  margin-top: 14px;
  padding: 12px 0 0;
}
.getting-started .progress-label {
  font-size: 9px;
  margin-top: 8px;
}
.onboarding-list {
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding-top: 10px;
}
.onboarding-list > a,
.onboarding-list > div {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 44px;
}
.onboarding-list > a > span,
.onboarding-list > div > span {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 23px;
  height: 23px;
  box-shadow: var(--inset-pressed);
  border-radius: 50%;
  font-size: 9px;
  color: var(--muted);
  flex-shrink: 0;
}
.onboarding-list .completed > span {
  background: var(--accent-soft);
  box-shadow: none;
}
.onboarding-list b {
  font-size: 10px;
  font-weight: 500;
  display: block;
}
.onboarding-list small {
  font-size: 8px;
  display: block;
  margin-top: 3px;
}
.onboarding-list a > .icon {
  margin-left: auto;
}
.privacy-note {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 24px 12px;
}
.privacy-note .icon-tile {
  width: 28px;
  height: 28px;
  background: transparent;
}
.privacy-note b {
  font-size: 10px;
  font-weight: 500;
}
.privacy-note p {
  font-size: 9px;
  margin-top: 5px;
  line-height: 1.8;
}
.community-strip {
  display: flex;
  align-items: center;
  gap: 16px;
  border-top: 1px solid var(--line);
  margin-top: 34px;
  padding: 24px 0;
}
.community-strip > .icon-tile {
  box-shadow: none;
  background: var(--accent-soft);
  width: 40px;
  height: 40px;
}
.community-strip b {
  font-size: 10px;
  font-weight: 500;
}
.community-strip p {
  font-size: 9px;
  margin-top: 4px;
}
.community-strip > span:last-child {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-left: auto;
  font-size: 9px;
  color: var(--muted);
}
.workspace-footer {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  border-top: 1px solid var(--line);
  padding: 20px 0;
  font-size: 8px;
  color: var(--muted);
}
.workspace-footer > span {
  display: flex;
  align-items: center;
  gap: 8px;
}
.workspace-footer i {
  width: 3px;
  height: 3px;
  background: var(--muted);
  border-radius: 50%;
}
.bottom-nav {
  display: none;
}
.skip-link {
  position: fixed;
  top: -80px;
  left: 20px;
  z-index: 999;
  padding: 12px;
  background: var(--base);
}
.skip-link:focus {
  top: 20px;
}
.branch-skeleton {
  width: 140px;
  height: 26px;
}
.notification {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  padding: 20px 0;
  border-bottom: 1px solid var(--line);
}
.notification b {
  font-size: 13px;
  font-weight: 500;
}
.notification p {
  font-size: 12px;
  margin: 6px 0;
}
.notification small {
  font-size: 10px;
  display: block;
}
.notification .text-button {
  font-size: 10px;
}
.notification.read {
  opacity: 0.75;
}
.profile-summary {
  text-align: center;
  margin: 10px 0 28px;
}
.profile-summary h3 {
  margin-top: 12px;
}
.profile-summary p {
  font-size: 12px;
  margin: 6px 0 12px;
}
.profile-menu {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.profile-menu .neu-button {
  justify-content: flex-start;
}
.profile-menu .neu-button > .icon:last-child {
  margin-left: auto;
}
.search-results {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-top: 16px;
}
.search-results a {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  min-height: 48px;
  border-radius: 10px;
}
.search-results a:hover {
  box-shadow: var(--inset-pressed);
}
.search-results a > span {
  flex: 1;
}
.help-steps {
  margin: 0;
  padding-left: 20px;
}
.help-steps li {
  padding: 8px;
}
.help-steps b {
  font-size: 13px;
}
.help-steps p {
  font-size: 12px;
  margin-top: 6px;
}
.help-steps ~ p {
  font-size: 11px;
  margin-top: 20px;
}
.directory-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 20px;
}
.directory-toolbar > .search-bar {
  max-width: 240px;
  width: 100%;
}
.directory-note {
  font-size: 11px;
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 20px 0;
}
.directory-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 24px;
  margin-bottom: 40px;
}
.restricted-tool .icon-tile {
  background: transparent;
}
.module-details h3 {
  margin: 20px 0 12px;
}
.module-details p {
  font-size: 13px;
  margin: 12px 0;
}
.preferences-grid {
  display: grid;
  grid-template-columns: 320px 1fr;
  gap: 28px;
  margin: 36px 0 48px;
}
.preference-stack {
  display: flex;
  flex-direction: column;
  gap: 28px;
}
.info-note {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  border-top: 1px solid var(--line);
  padding-top: 20px;
}
.info-note p {
  font-size: 10px;
}
.theme-options {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 16px;
}
.theme-option {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  border: 1px solid var(--line);
  border-radius: 12px;
  padding: 20px 8px 6px;
}
.theme-option.selected {
  box-shadow: var(--inset-pressed);
  border-color: #8b9db9;
}
.theme-option .choice {
  font-size: 10px;
}
.preferences-grid .toggle-row + .toggle-row {
  border-top: 1px solid var(--line);
}
.library-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin: 30px 0;
}
.library-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 28px;
  margin-bottom: 40px;
}
.library-grid > .neu-card > .icon-tile {
  margin-bottom: 24px;
}
.library-grid > .neu-card > h2 {
  margin-bottom: 12px;
}
.library-grid > .neu-card > .muted {
  font-size: 12px;
  margin-bottom: 20px;
}
.component-row {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
  align-items: center;
  margin: 20px 0;
}
.component-form {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 20px;
}
.library-data {
  display: flex;
  flex-direction: column;
  gap: 28px;
}
.stat-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 28px;
}
.skeleton-demo {
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-top: 24px;
}
.line-skeleton {
  height: 16px;
}
.line-skeleton.short {
  width: 65%;
}
.title-skeleton {
  height: 30px;
  width: 50%;
  max-width: 330px;
}
.hero-skeleton {
  height: 270px;
  margin: 32px 0;
}
.card-skeleton {
  height: 180px;
}
.route-loading {
  padding: 40px;
  max-width: 1400px;
  margin: auto;
}
.loading-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 24px;
}
.status-page,
.full-screen {
  min-height: 75dvh;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 20px;
  padding: 32px;
  text-align: center;
}
.status-page p {
  max-width: 430px;
}
.status-page h1 {
  font-size: 30px;
}
.reset-card {
  max-width: 480px;
  width: 100%;
  text-align: left;
}
.reset-card form {
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-top: 24px;
}
.reset-card h1 {
  font-size: 23px;
}
.reset-card p {
  font-size: 12px;
}
.intro-list p {
  margin: 16px 0;
  font-size: 13px;
}
.inline-error {
  padding: 12px 16px;
  border: 1px solid var(--danger);
  border-radius: 12px;
  font-size: 12px;
  margin-bottom: 20px;
}
.sidebar-collapsed {
  --sidebar: 84px;
}
.sidebar-collapsed .sidebar {
  padding-left: 16px;
  padding-right: 16px;
}
.sidebar-collapsed .sidebar > .brand {
  padding-left: 4px;
}
.sidebar-collapsed .brand > span:last-child,
.sidebar-collapsed .school-identity,
.sidebar-collapsed .nav-section-label,
.sidebar-collapsed .nav-item > span,
.sidebar-collapsed .nav-item > .icon:last-child:not(:first-child),
.sidebar-collapsed .help-card,
.sidebar-collapsed .sidebar-account > span:last-of-type,
.sidebar-collapsed .sidebar-account > .icon {
  display: none;
}
.sidebar-collapsed .sidebar > .brand {
  margin-bottom: 30px;
}
.sidebar-collapsed .nav-item {
  justify-content: center;
  padding: 10px;
}
.sidebar-collapsed .sidebar-account {
  justify-content: center;
}
.drawer-nav .nav-section-label {
  margin-top: 20px;
}
@media (min-width: 1600px) {
  .overview-columns {
    grid-template-columns: 1fr 340px;
  }
  .workspace-tool p {
    font-size: 12px;
  }
  .workspace-tool h3 {
    font-size: 15px;
  }
  .getting-started h2 {
    font-size: 19px;
  }
  .welcome-hero {
    min-height: 300px;
  }
  .welcome-hero .campus-illustration {
    height: 290px;
  }
  .welcome-copy h2 {
    font-size: 36px;
  }
  .main-content {
    padding-left: 48px;
    padding-right: 48px;
  }
  .page-heading h1 {
    font-size: 33px;
  }
}
@media (max-width: 1200px) {
  .overview-columns {
    grid-template-columns: 1fr 280px;
    gap: 20px;
  }
  .main-content {
    padding-left: 24px;
    padding-right: 24px;
  }
  .top-header {
    padding: 0 24px;
  }
  .global-search-trigger {
    min-width: 44px;
    justify-content: center;
  }
  .global-search-trigger span,
  .global-search-trigger kbd {
    display: none;
  }
  .header-actions {
    gap: 6px;
  }
  .workspace-summary {
    grid-template-columns: 1fr 1fr;
  }
  .workspace-summary > div:last-child {
    display: none;
  }
  .workspace-summary > div:nth-child(2) {
    border: 0;
  }
  .workspace-summary .badge {
    display: none;
  }
  .workspace-tool {
    padding: 18px;
  }
  .getting-started {
    padding: 20px;
  }
  .community-strip > span:last-child {
    display: none;
  }
  .directory-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .directory-toolbar {
    align-items: flex-start;
  }
  .directory-toolbar .neu-tabs {
    flex: 1;
  }
  .preferences-grid {
    grid-template-columns: 260px 1fr;
    gap: 20px;
  }
  .theme-options {
    gap: 8px;
  }
  .component-form {
    grid-template-columns: 1fr;
  }
  .welcome-hero {
    padding: 28px;
  }
  .welcome-copy h2 {
    font-size: 28px;
  }
  .welcome-hero .campus-illustration {
    right: -22px;
    width: 43%;
  }
  .welcome-copy p {
    max-width: 310px;
  }
  .welcome-copy .desktop-break {
    display: none;
  }
}
@media (min-width: 640px) and (max-width: 1024px) {
  .app-shell {
    --sidebar: 80px;
  }
  .sidebar {
    padding: 25px 14px 16px;
  }
  .sidebar > .brand {
    padding-left: 3px;
    margin-bottom: 30px;
  }
  .sidebar .brand > span:last-child,
  .sidebar .school-identity,
  .sidebar .nav-section-label,
  .sidebar .nav-item > span,
  .sidebar .nav-item > .icon:last-child:not(:first-child),
  .sidebar .help-card,
  .sidebar .sidebar-account > span:last-of-type,
  .sidebar .sidebar-account > .icon,
  .sidebar-collapse {
    display: none;
  }
  .sidebar .nav-item {
    justify-content: center;
    padding: 10px;
  }
  .sidebar .sidebar-account {
    justify-content: center;
  }
  .sidebar .nav-section {
    margin-bottom: 24px;
  }
  .nav-item {
    min-height: 48px;
  }
  .overview-columns {
    grid-template-columns: 1fr 260px;
  }
  .page-heading h1 {
    font-size: 25px;
  }
  .workspace-tool p {
    font-size: 10px;
  }
  .workspace-grid {
    gap: 14px;
  }
  .getting-started {
    padding: 18px;
  }
  .workspace-tool h3 {
    font-size: 12px;
  }
  .workspace-tool {
    padding: 16px;
  }
  .overview-columns {
    gap: 20px;
  }
  .privacy-note {
    padding: 20px 0;
  }
  .welcome-copy h2 {
    font-size: 28px;
  }
  .welcome-copy p {
    max-width: 260px;
  }
  .welcome-hero .campus-illustration {
    right: -5%;
    width: 45%;
  }
  .login-story h1 {
    font-size: 37px;
  }
  .login-layout {
    gap: 36px;
  }
  .login-card {
    padding: 28px;
  }
  .login-story .badge {
    font-size: 8px;
  }
  .campus-illustration {
    max-width: 380px;
  }
  .orbit-two {
    width: 310px;
  }
  .login-layout .campus-illustration {
    transform: scale(0.9);
  }
  .story-bottom {
    gap: 8px;
  }
  .story-bottom b {
    font-size: 9px;
  }
  .story-bottom small {
    font-size: 8px;
  }
  .date-chip {
    font-size: 9px;
  }
  .preferences-grid {
    grid-template-columns: 1fr;
  }
  .preferences-grid > .neu-card .profile-summary {
    margin: 10px 0 20px;
  }
  .library-grid {
    gap: 20px;
  }
  .directory-toolbar {
    flex-direction: column;
  }
  .directory-toolbar > .search-bar {
    max-width: 100%;
  }
}
@media (min-width: 640px) and (max-width: 850px) {
  .overview-columns {
    grid-template-columns: 1fr;
  }
  .overview-right {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
  }
  .privacy-note {
    padding: 20px 12px;
  }
  .login-story {
    display: none;
  }
  .login-layout {
    grid-template-columns: 1fr;
    margin: 48px auto;
    max-width: 440px;
  }
  .login-form-side {
    justify-self: center;
  }
  .welcome-hero .campus-illustration {
    right: -5%;
    width: 48%;
    opacity: 0.8;
  }
  .welcome-copy h2 {
    font-size: 26px;
  }
  .welcome-copy p {
    max-width: 240px;
  }
}
@media (max-width: 639px) {
  .login-page {
    padding: 22px 22px 0;
  }
  .version-label {
    display: none;
  }
  .login-story {
    display: none;
  }
  .login-layout {
    display: block;
    margin: 40px auto 24px;
    max-width: 420px;
  }
  .login-form-side {
    max-width: 100%;
  }
  .login-card {
    padding: 28px 24px 22px;
    border-radius: 24px;
  }
  .login-heading h2 {
    font-size: 28px;
  }
  .login-symbol {
    margin-bottom: 24px;
  }
  .login-top .brand {
    font-size: 26px;
  }
  .login-help {
    margin-left: 0;
    margin-right: 0;
    line-height: 1.8;
  }
  .login-footer {
    font-size: 8px;
    flex-wrap: wrap;
    gap: 12px;
    justify-content: center;
    margin-top: auto;
    padding: 20px 0;
  }
  .login-footer > span:nth-child(2) {
    display: none;
  }
  .login-footer > span:last-child {
    margin-left: auto;
  }
  .login-options {
    gap: 4px;
  }
  .login-options .choice,
  .login-options .text-button {
    font-size: 10px;
  }
  .neu-button {
    font-size: 11px;
  }
  .overlay {
    align-items: flex-end;
    padding: 0;
  }
  .overlay-panel {
    border-radius: 24px 24px 0 0;
    max-height: 94dvh;
    padding-bottom: env(safe-area-inset-bottom);
  }
  .overlay-header {
    padding: 24px 22px 16px;
  }
  .overlay-header h2 {
    font-size: 20px;
  }
  .overlay-content {
    padding: 8px 22px 28px;
  }
  .overlay-footer {
    padding: 16px 22px 24px;
  }
  .drawer-panel {
    height: 94dvh;
  }
  .drawer-overlay {
    padding: 0;
  }
  .sidebar {
    display: none;
  }
  .app-main {
    margin-left: 0;
  }
  .top-header {
    height: 76px;
    padding: 0 16px;
    gap: 8px;
  }
  .header-branch {
    gap: 6px;
    flex: 1;
  }
  .header-branch > .icon-tile {
    width: 28px;
    height: 28px;
    background: transparent;
  }
  .header-branch .select-wrap select {
    font-size: 11px;
    max-width: 150px;
  }
  .header-branch > .badge {
    display: none;
  }
  .header-actions {
    gap: 0;
  }
  .header-actions .neu-button {
    width: 40px;
    min-height: 44px;
    padding: 10px;
  }
  .header-actions .header-divider,
  .header-profile {
    display: none;
  }
  .global-search-trigger {
    min-width: 36px;
    padding: 5px;
  }
  .main-content {
    padding: 20px 20px calc(80px + env(safe-area-inset-bottom));
  }
  .breadcrumb {
    margin-bottom: 25px;
    font-size: 9px;
  }
  .breadcrumb > .badge {
    font-size: 7px;
    max-width: 50%;
    white-space: normal;
  }
  .page-heading {
    margin-bottom: 24px;
    gap: 12px;
    align-items: flex-start;
  }
  .page-heading .eyebrow {
    font-size: 8px;
  }
  .page-heading h1 {
    font-size: 26px;
  }
  .page-heading p {
    font-size: 11px;
    line-height: 1.9;
  }
  .date-chip {
    display: none;
  }
  .welcome-hero {
    min-height: 340px;
    padding: 24px;
  }
  .welcome-copy h2 {
    font-size: 27px;
  }
  .welcome-copy p {
    max-width: 215px;
    font-size: 10px;
    margin-top: 12px;
  }
  .welcome-copy .neu-button {
    margin-top: 18px;
    font-size: 10px;
    gap: 16px;
  }
  .welcome-hero .campus-illustration {
    right: -60px;
    top: 125px;
    width: 220px;
    height: 220px;
    opacity: 0.65;
    pointer-events: none;
    z-index: 0;
  }
  .welcome-hero .campus-platform {
    transform: translateX(-50%) scale(0.58);
    bottom: 13px;
  }
  .welcome-hero .orbit {
    display: none;
  }
  .welcome-hero .tile-book {
    top: 85px;
    left: 9px;
    width: 32px;
    height: 32px;
  }
  .welcome-hero .tile-community {
    top: 58px;
    right: 35px;
    width: 32px;
    height: 32px;
  }
  .welcome-hero .tile-message {
    display: none;
  }
  .welcome-hero .illustration-caption {
    display: none;
  }
  .hero-edition {
    font-size: 5px;
    left: 24px;
    bottom: 15px;
    right: auto;
  }
  .welcome-copy > .badge {
    font-size: 6px;
  }
  .workspace-summary {
    grid-template-columns: 1fr 1fr;
    margin: 22px 0 30px;
    padding: 14px 0;
    gap: 8px;
  }
  .workspace-summary > div {
    padding: 0 6px;
    gap: 6px;
  }
  .workspace-summary > div:last-child {
    display: none;
  }
  .workspace-summary > div:nth-child(2) {
    border: 0;
  }
  .workspace-summary b {
    font-size: 9px;
  }
  .workspace-summary small {
    font-size: 6px;
  }
  .workspace-summary .icon-tile {
    width: 24px;
    height: 24px;
  }
  .workspace-summary .icon-tile > .icon {
    width: 17px;
  }
  .overview-columns {
    grid-template-columns: 1fr;
    gap: 30px;
  }
  .workspace-grid {
    gap: 16px;
  }
  .workspace-tool {
    padding: 18px;
  }
  .workspace-tool h3 {
    font-size: 12px;
  }
  .workspace-tool p {
    font-size: 10px;
    line-height: 1.8;
  }
  .tool-top {
    margin-bottom: 18px;
  }
  .tool-top .badge {
    font-size: 7px;
  }
  .workspace-tool .icon-tile {
    width: 35px;
    height: 35px;
  }
  .tool-link {
    font-size: 8px;
    min-height: 44px;
  }
  .section-heading h2 {
    font-size: 16px;
  }
  .section-heading p {
    font-size: 10px;
  }
  .getting-started {
    padding: 24px;
  }
  .getting-started h2 {
    font-size: 19px;
  }
  .onboarding-list b {
    font-size: 12px;
  }
  .onboarding-list small {
    font-size: 10px;
  }
  .getting-started > p {
    font-size: 12px;
  }
  .getting-started .progress-label {
    font-size: 11px;
  }
  .onboarding-list {
    gap: 14px;
  }
  .privacy-note {
    padding: 28px 8px 0;
  }
  .privacy-note b {
    font-size: 11px;
  }
  .privacy-note p {
    font-size: 10px;
  }
  .community-strip {
    margin-top: 28px;
    align-items: flex-start;
    padding: 24px 0;
  }
  .community-strip b {
    font-size: 10px;
  }
  .community-strip p {
    font-size: 9px;
  }
  .workspace-footer {
    font-size: 7px;
    flex-wrap: wrap;
  }
  .workspace-footer > span:last-child {
    display: none;
  }
  .bottom-nav {
    display: flex;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: calc(68px + env(safe-area-inset-bottom));
    padding: 5px 8px calc(5px + env(safe-area-inset-bottom));
    background: var(--base);
    border-top: 1px solid var(--line);
    z-index: 40;
    align-items: center;
    justify-content: space-around;
  }
  .bottom-nav > a,
  .bottom-nav > button {
    display: flex;
    flex-direction: column;
    gap: 3px;
    align-items: center;
    justify-content: center;
    background: transparent;
    min-width: 52px;
    min-height: 50px;
    color: var(--muted);
    font-size: 9px;
    border-radius: 12px;
    position: relative;
  }
  .bottom-nav > a.active {
    box-shadow: var(--inset-pressed);
    color: var(--text);
  }
  .bottom-nav > a.active::before {
    content: "";
    position: absolute;
    top: 4px;
    height: 2px;
    width: 14px;
    border-radius: 2px;
    background: var(--gradient);
  }
  .bottom-nav .icon {
    width: 19px;
    height: 19px;
  }
  .directory-toolbar {
    flex-direction: column;
    align-items: stretch;
  }
  .directory-toolbar .neu-tabs {
    width: 100%;
    justify-content: flex-start;
  }
  .directory-toolbar .neu-tabs button {
    font-size: 10px;
    padding: 8px 10px;
  }
  .directory-toolbar > .search-bar {
    max-width: none;
  }
  .directory-grid {
    grid-template-columns: 1fr;
    gap: 20px;
  }
  .directory-grid .workspace-tool h3 {
    font-size: 15px;
  }
  .directory-grid .workspace-tool p {
    font-size: 12px;
  }
  .directory-note {
    font-size: 10px;
    align-items: flex-start;
  }
  .directory-grid .workspace-tool {
    padding: 24px;
  }
  .preferences-grid {
    grid-template-columns: 1fr;
    gap: 24px;
  }
  .theme-options {
    gap: 8px;
  }
  .theme-option .choice {
    font-size: 9px;
    gap: 5px;
  }
  .theme-option .choice input {
    width: 14px;
    height: 14px;
  }
  .library-grid {
    grid-template-columns: 1fr;
    gap: 24px;
  }
  .library-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 18px;
  }
  .library-header .neu-tabs button {
    font-size: 10px;
    padding: 8px 12px;
  }
  .component-form {
    grid-template-columns: 1fr;
  }
  .library-data > .neu-card {
    padding: 20px;
  }
  .stat-grid {
    gap: 16px;
  }
  .stat-card {
    padding: 20px;
  }
  .stat-top {
    font-size: 10px;
  }
  .stat-top .icon-tile {
    display: none;
  }
  .stat-card > strong {
    font-size: 28px;
  }
  .stat-card small {
    font-size: 9px;
  }
  .mobile-table {
    display: block;
  }
  .neu-table {
    display: none;
  }
  .mobile-table article {
    padding: 16px 0;
    border-bottom: 1px solid var(--line);
    min-height: 64px;
  }
  .mobile-person {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .mobile-person > span:nth-child(2) {
    flex: 1;
    min-width: 0;
  }
  .mobile-person b {
    font-size: 11px;
    font-weight: 500;
    display: block;
  }
  .mobile-person small {
    display: block;
    font-size: 9px;
  }
  .mobile-person .badge {
    font-size: 8px;
  }
  .route-loading {
    padding: 24px;
  }
  .loading-grid {
    grid-template-columns: 1fr;
  }
  .control-label {
    font-size: 12px;
  }
  .toggle-row small {
    font-size: 10px;
  }
  .full-screen {
    padding: 24px;
  }
  .status-page h1 {
    font-size: 26px;
  }
}
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation: none !important;
    transition: none !important;
    scroll-behavior: auto !important;
  }
  .skeleton::after {
    display: none;
  }
}
.neu-tabs button.active::after {
  display: none;
}
.neu-tabs button > span {
  position: relative;
}
.neu-tabs button > .tab-indicator {
  position: absolute;
  inset: 3px;
  border-bottom: 2px solid #8ca5d3;
  border-radius: 7px;
  pointer-events: none;
}
@media (max-width: 639px) {
  .mobile-table article {
    height: 73px;
    min-height: 73px;
    padding: 16px 0;
  }
  .mobile-person b {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
}
@media (max-width: 639px) {
  .workspace-grid {
    grid-template-columns: 1fr;
  }
  .workspace-grid .workspace-tool {
    padding: 24px;
  }
  .workspace-grid .workspace-tool h3 {
    font-size: 15px;
  }
  .workspace-grid .workspace-tool p {
    font-size: 12px;
  }
  .workspace-grid .tool-link {
    font-size: 11px;
  }
  .workspace-grid .workspace-tool .icon-tile {
    width: 40px;
    height: 40px;
  }
}
.mobile-account-actions {
  display: flex;
  align-items: center;
  gap: 14px;
  margin: 28px 0 16px;
  padding-top: 24px;
  border-top: 1px solid var(--line);
}
.mobile-account-actions b,
.mobile-account-actions small {
  display: block;
}
.mobile-account-actions b {
  font-size: 12px;
  font-weight: 500;
}

````

## src/styles/tokens.css

````css
:root {
  color-scheme: light;
  --base: #e9edf3;
  --surface: #e9edf3;
  --text: #14181f;
  --muted: #5b6577;
  --subtle: #6a7485;
  --sky: #4db8ff;
  --purple: #a99bd6;
  --accent-text: #42618f;
  --accent-soft: #dfe8f3;
  --line: rgba(84, 103, 132, 0.16);
  --white: rgba(255, 255, 255, 0.9);
  --shadow: rgba(163, 177, 198, 0.5);
  --raised-sm: 3px 3px 6px var(--shadow), -3px -3px 6px var(--white);
  --raised-md: 5px 5px 12px var(--shadow), -5px -5px 12px var(--white);
  --inset-pressed:
    inset 3px 3px 6px var(--shadow), inset -3px -3px 6px var(--white);
  --gradient: linear-gradient(135deg, #4db8ff, #a99bd6);
  --success: #2d6959;
  --success-bg: #dcece6;
  --warning: #7e5d24;
  --warning-bg: #ede5d4;
  --danger: #a23446;
  --radius: 20px;
  --sidebar: 244px;
  font-family: Inter, ui-sans-serif, system-ui, sans-serif;
}
[data-theme="dark"] {
  color-scheme: dark;
  --base: #1b1e24;
  --surface: #1b1e24;
  --text: #f2f4f8;
  --muted: #9aa3b2;
  --subtle: #9aa3b2;
  --accent-text: #acbeea;
  --accent-soft: #242f40;
  --line: rgba(164, 179, 202, 0.17);
  --white: rgba(255, 255, 255, 0.04);
  --shadow: rgba(0, 0, 0, 0.5);
  --success: #9cd0ba;
  --success-bg: #263c35;
  --warning: #d8be88;
  --warning-bg: #3b3426;
  --danger: #f59aaa;
}

````

## src/types/admin.ts

````ts
import { z } from "zod";
import { permissions } from "../lib/permissions";
const base = {
  id: z.string(),
  schoolId: z.string(),
  branchId: z.string().nullable(),
  version: z.number().int().positive(),
};
export const adminSchemas = {
  analytics: z.object({
    ...base,
    date: z.string(),
    present: z.number().nonnegative(),
    total: z.number().nonnegative(),
  }),
  schools: z.object({
    ...base,
    name: z.string().min(2),
    code: z.string().min(2),
    ownerEmail: z.string().email(),
    plan: z.enum(["Starter", "Growth", "Enterprise"]),
    status: z.enum(["Active", "Suspended", "Deleted"]),
    monthlyFee: z.number().nonnegative(),
    createdAt: z.string(),
  }),
  branches: z.object({
    ...base,
    name: z.string().min(2),
    city: z.string().min(2),
    code: z.string().min(2),
    principal: z.string(),
    capacity: z.number().int().positive(),
    status: z.enum(["Active", "Inactive"]),
  }),
  users: z.object({
    ...base,
    name: z.string().min(2),
    email: z.string().email(),
    role: z.enum(["principal", "teacher", "parent", "student", "accountant"]),
    policyId: z.string().nullable().default(null),
    status: z.enum(["Active", "Inactive"]),
    phone: z.string(),
    joinedAt: z.string(),
  }),
  finance: z.object({
    ...base,
    reference: z.string().min(2),
    description: z.string().min(2),
    kind: z.enum(["Income", "Expense"]),
    category: z.string().min(2),
    amount: z.number().positive(),
    date: z.string(),
    status: z.enum(["Paid", "Pending", "Overdue"]),
  }),
  roles: z.object({
    ...base,
    name: z.string(),
    custom: z.boolean().default(false),
    role: z.enum([
      "owner",
      "principal",
      "teacher",
      "parent",
      "student",
      "accountant",
      "master",
    ]),
    permissions: z.array(z.enum(permissions)),
  }),
  settings: z.object({
    ...base,
    name: z.string().min(2),
    academicYear: z.string(),
    logoPath: z.string(),
    senderNumber: z.string(),
    financeRole: z.enum(["owner", "accountant"]),
    overrideEnabled: z.boolean(),
    requireMfa: z.boolean(),
    sessionMinutes: z.number().min(15).max(480),
    privacyEmail: z.string().email(),
    retentionDays: z.number().min(30).max(3650),
  }),
  templates: z.object({
    ...base,
    name: z.string().min(2),
    category: z.enum(["Attendance", "Fees", "Announcements"]),
    body: z.string().min(10),
    status: z.enum(["Draft", "Pending", "Approved"]),
  }),
  audit: z.object({
    ...base,
    actor: z.string(),
    action: z.string(),
    resource: z.string(),
    details: z.string(),
    createdAt: z.string(),
  }),
};
export type AdminModels = {
  [K in keyof typeof adminSchemas]: z.infer<(typeof adminSchemas)[K]>;
};
export type AdminResource = keyof AdminModels;
export type AdminScope = {
  schoolId: string;
  branchId?: string;
  from?: string;
  to?: string;
};
export type ListOptions = {
  search?: string;
  page?: number;
  pageSize?: number;
  from?: string;
  to?: string;
  filters?: Record<string, string>;
};
export type AdminPage<T> = { rows: T[]; total: number };
export const summarySchema = z.object({
  students: z.number(),
  staff: z.number(),
  income: z.number(),
  expenses: z.number(),
  outstanding: z.number(),
  schools: z.number(),
  active: z.number(),
  mrr: z.number(),
  suspended: z.number(),
  revenue: z.array(
    z.object({
      label: z.string(),
      value: z.number(),
      secondary: z.number().optional(),
    }),
  ),
  enrollment: z.array(z.object({ label: z.string(), value: z.number() })),
  attendance: z
    .array(z.object({ label: z.string(), value: z.number() }))
    .default([]),
});
export type AdminSummary = z.infer<typeof summarySchema>;
export type SchoolInput = {
  name: string;
  code: string;
  ownerEmail: string;
  plan: AdminModels["schools"]["plan"];
  monthlyFee: number;
};
export type ProvisionedSchool = {
  school: AdminModels["schools"];
  email: string;
  password: string;
};
export interface AdminRepository {
  summary(scope: AdminScope): Promise<AdminSummary>;
  list<K extends AdminResource>(
    resource: K,
    scope: AdminScope,
    options?: ListOptions,
  ): Promise<AdminPage<AdminModels[K]>>;
  save<K extends Exclude<AdminResource, "audit" | "analytics">>(
    resource: K,
    record: AdminModels[K],
  ): Promise<AdminModels[K]>;
  remove<K extends Exclude<AdminResource, "audit" | "schools" | "analytics">>(
    resource: K,
    id: string,
    scope: AdminScope,
    version: number,
  ): Promise<void>;
  provisionSchool(input: SchoolInput): Promise<ProvisionedSchool>;
}
export function parseRecord<K extends AdminResource>(
  resource: K,
  value: unknown,
): AdminModels[K] {
  return adminSchemas[resource].parse(value) as AdminModels[K];
}

````

## src/types/database.ts

````ts
// Schema contract for database/phase1.sql and phase2.sql, using the Supabase generator's shape.
// Regenerate from the connected database before releasing live schema changes.
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];
export type Database = {
  public: {
    Tables: {
      admin_records: {
        Row: {
          id: string;
          school_id: string;
          branch_id: string | null;
          resource: string;
          payload: Json;
          version: number;
          updated_at: string;
        };
        Insert: {
          id: string;
          school_id: string;
          branch_id?: string | null;
          resource: string;
          payload: Json;
          version?: number;
          updated_at?: string;
        };
        Update: {
          payload?: Json;
          branch_id?: string | null;
          version?: number;
          updated_at?: string;
        };
        Relationships: [];
      };
      profiles: {
        Row: {
          id: string;
          school_id: string;
          name: string;
          email: string;
          role: string;
          branch_ids: string[];
          policy_id: string | null;
          active: boolean;
        };
        Insert: {
          id: string;
          school_id: string;
          name: string;
          email: string;
          role: string;
          branch_ids: string[];
        };
        Update: { name?: string };
        Relationships: [];
      };
      branches: {
        Row: {
          id: string;
          school_id: string;
          name: string;
          city: string;
          short_name: string;
          active: boolean;
        };
        Insert: {
          id?: string;
          school_id: string;
          name: string;
          city: string;
          short_name: string;
        };
        Update: { name?: string; city?: string; short_name?: string };
        Relationships: [];
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          branch_id: string | null;
          title: string;
          body: string;
          created_at: string;
          read: boolean;
        };
        Insert: {
          id?: string;
          user_id: string;
          branch_id?: string | null;
          title: string;
          body: string;
          created_at?: string;
          read?: boolean;
        };
        Update: { read?: boolean };
        Relationships: [];
      };
    };
    Views: { [_ in never]: never };
    Functions: {
      admin_summary: { Args: { p_scope: Json }; Returns: Json };
      provision_school_record: {
        Args: { p_school: Json; p_owner_id: string; p_actor: string };
        Returns: Json;
      };
      admin_list: {
        Args: { p_resource: string; p_scope: Json; p_options: Json };
        Returns: Json;
      };
      admin_save: {
        Args: { p_resource: string; p_record: Json };
        Returns: Json;
      };
      admin_delete: {
        Args: {
          p_resource: string;
          p_id: string;
          p_scope: Json;
          p_version: number;
        };
        Returns: Json;
      };
    };
    Enums: { [_ in never]: never };
    CompositeTypes: { [_ in never]: never };
  };
};

````

## src/types/domain.ts

````ts
export const roles = [
  "owner",
  "principal",
  "teacher",
  "parent",
  "student",
  "accountant",
  "master",
] as const;
export type Role = (typeof roles)[number];
export type Profile = {
  policyId?: string | null;
  id: string;
  name: string;
  email: string;
  role: Role;
  schoolId: string;
  branchIds: string[];
};
export type Branch = {
  id: string;
  school_id: string;
  name: string;
  city: string;
  short_name: string;
};
export type Notification = {
  id: string;
  user_id: string;
  branch_id: string | null;
  title: string;
  body: string;
  created_at: string;
  read: boolean;
};
export type Workspace = {
  id: string;
  name: string;
  description: string;
  category: "Community" | "Academics" | "Operations" | "System";
  permission: import("../lib/permissions").Permission;
  phase: number;
  icon: import("../components/ui/Icon").IconName;
};
export type SignInInput = {
  identifier: string;
  password: string;
  remember: boolean;
  master?: boolean;
};
export type Unsubscribe = () => void;

````

## supabase/functions/deno.d.ts

````ts
// Local compile-time surface for the Deno APIs used by the deployed Edge Function.
declare const Deno: {
  env: { get(name: string): string | undefined };
  serve(handler: (request: Request) => Response | Promise<Response>): void;
};

````

## supabase/functions/provision-school/index.ts

````ts
import { createClient } from "npm:@supabase/supabase-js@2.118.0";
import { z } from "npm:zod@3.25.76";
import type { Database } from "../../../src/types/database.ts";
const inputSchema = z.object({
  name: z.string().trim().min(2).max(120),
  code: z
    .string()
    .trim()
    .min(2)
    .max(30)
    .regex(/^[A-Za-z0-9-]+$/),
  ownerEmail: z.string().email(),
  plan: z.enum(["Starter", "Growth", "Enterprise"]),
  monthlyFee: z.number().nonnegative().max(10000000),
});
Deno.serve(async (request) => {
  const allowed = Deno.env.get("APP_ORIGIN");
  const origin = request.headers.get("origin");
  const cors = {
    "Access-Control-Allow-Origin": allowed ?? "",
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    Vary: "Origin",
  };
  const respond = (body: unknown, status: number) =>
    Response.json(body, { status, headers: cors });
  if (!allowed || origin !== allowed)
    return respond({ error: "Origin not permitted" }, 403);
  if (request.method === "OPTIONS")
    return new Response(null, { status: 204, headers: cors });
  if (request.method !== "POST")
    return respond({ error: "Method not allowed" }, 405);
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const publicKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const secret = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const authorization = request.headers.get("Authorization");
    if (!authorization?.startsWith("Bearer "))
      return respond({ error: "Authentication required" }, 401);
    const caller = createClient<Database>(url, publicKey, {
      global: { headers: { Authorization: authorization } },
      auth: { persistSession: false },
    });
    const {
      data: { user },
      error: userError,
    } = await caller.auth.getUser();
    if (userError || !user || user.app_metadata.role !== "master")
      return respond({ error: "Platform access required" }, 403);
    const { data: profile, error: profileError } = await caller
      .from("profiles")
      .select("id,role,active")
      .eq("id", user.id)
      .single();
    if (profileError || !profile?.active || profile.role !== "master")
      return respond({ error: "Platform profile required" }, 403);
    const input = inputSchema.parse(await request.json());
    const admin = createClient<Database>(url, secret, {
      auth: { persistSession: false },
    });
    const password = `Campus!${crypto.randomUUID().replaceAll("-", "")}${crypto.randomUUID().slice(0, 8)}`;
    const { data: account, error: accountError } =
      await admin.auth.admin.createUser({
        email: input.ownerEmail,
        password,
        email_confirm: true,
        app_metadata: { role: "owner" },
      });
    if (accountError || !account.user)
      return respond(
        { error: accountError?.message ?? "Account creation failed" },
        400,
      );
    const id = crypto.randomUUID();
    const school = {
      ...input,
      id,
      schoolId: id,
      branchId: null,
      version: 1,
      status: "Active",
      createdAt: new Date().toISOString().slice(0, 10),
    };
    const { data, error } = await admin.rpc("provision_school_record", {
      p_school: school,
      p_owner_id: account.user.id,
      p_actor: user.id,
    });
    if (error) {
      const cleanup = await admin.auth.admin.deleteUser(account.user.id);
      if (cleanup.error)
        console.error(
          "Provisioning cleanup required for user",
          account.user.id,
        );
      return respond(
        {
          error:
            "School provisioning failed. Contact your platform administrator.",
        },
        400,
      );
    }
    return respond({ school: data, email: input.ownerEmail, password }, 201);
  } catch (error) {
    return respond(
      {
        error:
          error instanceof z.ZodError
            ? "Invalid school details"
            : "Unable to provision this school",
      },
      400,
    );
  }
});

````

## tailwind.config.ts

````ts
import type { Config } from "tailwindcss";
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: ["class", '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        base: "var(--base)",
        ink: "var(--text)",
        muted: "var(--muted)",
        accent: "var(--sky)",
      },
      borderRadius: { neu: "20px" },
      boxShadow: {
        "raised-sm": "var(--raised-sm)",
        "raised-md": "var(--raised-md)",
        "inset-pressed": "var(--inset-pressed)",
      },
    },
  },
  plugins: [],
} satisfies Config;

````

## tsconfig.edge.json

````json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2022", "DOM"],
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noEmit": true,
    "skipLibCheck": true,
    "allowImportingTsExtensions": true,
    "types": [],
    "paths": {
      "npm:@supabase/supabase-js@2.118.0": [
        "./node_modules/@supabase/supabase-js/dist/index.d.mts"
      ],
      "npm:zod@3.25.76": ["./node_modules/zod/index.d.ts"]
    }
  },
  "include": ["supabase/functions/**/*.ts", "src/types/database.ts"]
}

````

## tsconfig.json

````json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "noUncheckedIndexedAccess": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "types": ["vite/client"]
  },
  "include": [
    "src",
    "vite.config.ts",
    "tailwind.config.ts",
    "postcss.config.ts"
  ]
}

````

## vite.config.ts

````ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  build: { target: "es2022", sourcemap: false, manifest: true },
});

````
