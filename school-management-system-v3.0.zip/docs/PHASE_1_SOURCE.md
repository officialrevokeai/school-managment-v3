# Phase 1 complete source

All authored files are included below. Install reproducible dependencies from package-lock.json in the project folder.

## .env.example

````text
VITE_USE_MOCK=true
# For live mode, apply database/phase1.sql and configure your Supabase project.
VITE_SUPABASE_URL=
VITE_SUPABASE_PUBLISHABLE_KEY=
# Optional compatibility with existing projects:
VITE_SUPABASE_ANON_KEY=
# Set to your deployed origin; password reset redirects to /reset-password.
VITE_APP_URL=http://127.0.0.1:5173

````

## .gitignore

````text
node_modules/
dist/
.env
.env.local
.env.*.local
*.tsbuildinfo
test-results/
.npm-cache/

````

## README.md

````md
# Campus · School Management System v3.0

Smart • Secure • Connected

Phase 1 is a complete, local frontend foundation using React 18, strict TypeScript, Vite, Supabase, Tailwind tokens, Framer Motion, TanStack Query v5, Zustand, React Router v6, React Hook Form, Zod, TanStack Table/Virtual, date-fns, lucide-react, and sonner. Recharts is installed for the chart modules in later phases; no chart code is loaded by Phase 1.

## Run

Node 22.13+ (Node 24 recommended) and npm are required. From this folder:

```powershell
npm ci
Copy-Item .env.example .env.local
npm run dev
```

Open the URL printed by Vite, normally http://127.0.0.1:5173. The shipped defaults enable mock mode without a backend. Build with `npm run build`, run boundary tests with `npm test`, and preview the production build with `npm run preview`. `npm run delivery` writes the complete authored file contents with paths to `docs/PHASE_1_SOURCE.md`.

## Demo sign-in

Use the role selector and **Use demo** to fill the form, then sign in. Every demo account uses **Campus@2026**.

| Role       | Email                           | Campus access        |
| ---------- | ------------------------------- | -------------------- |
| Owner      | owner@greenwood.edu (or GW-001) | North, Central, East |
| Principal  | principal@greenwood.edu         | North                |
| Teacher    | teacher@greenwood.edu           | North                |
| Parent     | parent@greenwood.edu            | North                |
| Student    | student@greenwood.edu           | North                |
| Accountant | accountant@greenwood.edu        | North                |

The separate, non-linked `/sys-master` sign-in accepts `master@greenwood.edu`, with the same demo password. It does not appear in any navigation. Mock mode simulates access in browser storage and is explicitly labeled Demo. It is not a security boundary for real school data.

## Phase 1 delivered

- Responsive shell, full desktop sidebar, tablet icon rail, mobile bottom navigation and More drawer; breadcrumbs, profile menu, school/campus selection, search, theme, and notifications.
- Login validation, password visibility, remember-me storage selection, error feedback, recovery email flow and reset page, role redirects, 401/403/404 views, protected routes, and session-expired dialog.
- Light/dark/system preference with persistence and reduced-motion support. Reusable library of all requested Phase 1 components, including accessible focus-trapped dialogs, type-to-confirm, file validation, virtualized sortable table/card views, and loading/empty/error states.
- A workspace overview and module directory that clearly explain role access and the delivery roadmap. Functional local preferences and interactive component gallery.
- Adapter interface for auth, assigned campuses, notification reads/updates/subscriptions, and private file uploads. Supabase implementation is dynamically loaded only in live mode. Query keys isolate user + campus. Notification read updates are optimistic with rollback; subscriptions are cleaned up.
- SQL schema/RLS/storage contract and compatible database types. Live generation and validation require a real Supabase project; the included types describe the supplied schema, and are **not represented as generated from a deployed database**.

Business modules are intentionally deferred to the phases in the brief: Phase 2 Master/Owner; Phase 3 Principal/Teacher; Phase 4 Parent/Student/Accountant; Phase 5 WhatsApp and system controls. Locked navigation explains the phase instead of opening unfinished pages. No messages, payments, invitation emails, or uploaded study materials are sent by this phase.

## Live Supabase setup

1. Use a development Supabase project. Review and apply `database/phase1.sql` in its SQL editor. This is a schema contract, not an executed or generated migration. It grants only the operations implemented in Phase 1.
2. Provision Auth users through trusted administration. Set `app_metadata.role` to one of the roles, and insert a matching `profiles` row with the same role, school UUID, and assigned campus UUID array. Insert the assigned campus rows. The frontend has no privilege to assign roles, tenants, or campuses. Changing authorization claims requires refreshing/revoking sessions as appropriate.
3. Configure your Auth site URL and allow `${your-origin}/reset-password` as a redirect URL. Use HTTPS for production. Real mode accepts email addresses; demo school codes do not resolve live email identities.
4. Enable the tables in your project's Data API settings if required. Review the Realtime publication and create a test notification for the user to verify realtime delivery.
5. Set `VITE_USE_MOCK=false`, the Supabase URL, public publishable key, and app URL in `.env.local`, then restart Vite. Never use a service-role or secret key in a VITE variable.
6. Generate `src/types/database.ts` from that database using the Supabase dashboard or the CLI command documented in [Supabase type generation](https://supabase.com/docs/guides/api/rest/generating-types). Run the build, and test role/campus/RLS isolation with separate users before going live.

The repository implementations follow the documented [Supabase auth subscription lifecycle](https://supabase.com/docs/reference/javascript/auth-onauthstatechange). All authorization comes from trusted app metadata plus read-only provisioned profiles and RLS. The hidden route adds no security by itself. No live Supabase calls have been verified without a configured project.

Private uploads are stored as `school/campus/user/random-name`. The UI gallery validates files locally and does not upload them; the real storage adapter is provided for future module forms. Client-side validation complements server bucket limits.

## Structure

```text
src/
  app/                  Router, auth bootstrap, error boundaries
  components/layout/    Shell and code-native campus illustration
  components/ui/        Complete reusable component library
  features/auth/        Sign-in and password recovery
  features/workspace/   Overview, directory, status pages
  features/system/      Component gallery and local preferences
  hooks/                Theme, permission, debounce
  lib/                  Permissions, query keys, configuration
  services/             Typed repository contract and Supabase adapter
  store/                Auth and persisted UI state
  types/                Domain and database contract
  styles/               Tailwind + CSS-variable neumorphism tokens
  mocks/                Scoped mock adapter and fixture data
database/phase1.sql      Live schema/RLS/storage contract
```

Later role feature folders are introduced when their phase is authorized. No empty implementation files are shipped.

## What to verify

1. Sign in as Owner, switch campus, and confirm branch-specific notifications change. Read a notification and check the unread count updates. Sign out and try Teacher: only North Campus is available.
2. Try incorrect credentials and empty fields; check the error and keyboard focus. Try the master credentials on the normal sign-in: access is rejected. Open an Owner URL as Teacher: a 403 view appears.
3. Toggle light/dark; choose Use system in preferences and change the OS preference. Refresh to confirm local persistence.
4. Exercise global search, profile menu, More drawer, component dialogs, confirmation, and 250-row virtualized table. Check tab focus stays inside dialogs and returns to the trigger on close.
5. At 390px, 768px, and laptop widths, check the bottom navigation/icon rail/full sidebar. Tables become cards on mobile. Test reduced-motion preference.
6. In live mode, verify forgot-password and reset with an actual email. Test failed API requests, expired sessions, storage restrictions, and Realtime with your provisioned users.

Production hosting needs an SPA fallback to `index.html` for deep links. The initial JS budget is measured from built entry dependencies; chart/table/form screens are lazy routes. Lighthouse >=90 is a target and is not claimed without a measured audit.

````

## database/phase1.sql

````sql
-- Phase 1 schema contract. Run in a development Supabase project before live mode.
-- No users, authorization claims, or tenants are created by this file.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  school_id uuid not null,
  name text not null,
  email text not null,
  role text not null check (role in ('owner','principal','teacher','parent','student','accountant','master')),
  branch_ids uuid[] not null default '{}'
);
create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null,
  name text not null,
  city text not null,
  short_name text not null
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  branch_id uuid references public.branches(id) on delete cascade,
  title text not null,
  body text not null,
  created_at timestamptz not null default now(),
  read boolean not null default false
);
create index if not exists branches_school_id_idx on public.branches(school_id);
create index if not exists notifications_user_branch_created_idx on public.notifications(user_id,branch_id,created_at desc);
create index if not exists notifications_branch_id_idx on public.notifications(branch_id);
alter table public.profiles enable row level security;
alter table public.branches enable row level security;
alter table public.notifications enable row level security;
revoke all on public.profiles, public.branches, public.notifications from anon, authenticated;
grant select on public.profiles, public.branches, public.notifications to authenticated;
grant update(read) on public.notifications to authenticated;
drop policy if exists "Read own provisioned profile" on public.profiles;
create policy "Read own provisioned profile" on public.profiles for select to authenticated
  using (id = (select auth.uid()) and role = (select auth.jwt()->'app_metadata'->>'role'));
-- A trusted provisioning process maintains school_id, role, and branch_ids.
-- Client users cannot promote themselves or assign additional campuses.
drop policy if exists "Assigned campuses in own school" on public.branches;
create policy "Assigned campuses in own school" on public.branches for select to authenticated
  using (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.school_id = branches.school_id and branches.id = any(p.branch_ids)));
drop policy if exists "Read own scoped notifications" on public.notifications;
create policy "Read own scoped notifications" on public.notifications for select to authenticated
  using (user_id = (select auth.uid()) and (branch_id is null or exists (select 1 from public.branches b where b.id = notifications.branch_id)));
drop policy if exists "Mark own scoped notifications read" on public.notifications;
create policy "Mark own scoped notifications read" on public.notifications for update to authenticated
  using (user_id = (select auth.uid()) and (branch_id is null or exists (select 1 from public.branches b where b.id = notifications.branch_id)))
  with check (user_id = (select auth.uid()) and (branch_id is null or exists (select 1 from public.branches b where b.id = notifications.branch_id)));
insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('school-files','school-files',false,5242880,array['application/pdf','text/csv','image/png','image/jpeg'])
on conflict(id) do nothing;
-- Files are private and confined to school/campus/user folders.
drop policy if exists "Upload own campus files" on storage.objects;
create policy "Upload own campus files" on storage.objects for insert to authenticated
with check (bucket_id = 'school-files' and (storage.foldername(name))[3] = (select auth.uid())::text and exists (
  select 1 from public.profiles p join public.branches b on b.school_id = p.school_id
  where p.id = (select auth.uid()) and p.school_id::text = (storage.foldername(name))[1]
  and b.id::text = (storage.foldername(name))[2] and b.id = any(p.branch_ids)
));
drop policy if exists "Read own campus files" on storage.objects;
create policy "Read own campus files" on storage.objects for select to authenticated
using (bucket_id = 'school-files' and (storage.foldername(name))[3] = (select auth.uid())::text and exists (
  select 1 from public.profiles p join public.branches b on b.school_id = p.school_id
  where p.id = (select auth.uid()) and p.school_id::text = (storage.foldername(name))[1]
  and b.id::text = (storage.foldername(name))[2] and b.id = any(p.branch_ids)
));
-- Publish notifications for Realtime if not already enabled in this project.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'notifications') then
    alter publication supabase_realtime add table public.notifications;
  end if;
end $$;

````

## docs/PHASE_1_VERIFICATION.md

````md
# Phase 1 verification

Verified on 31 October 2026. The build and test commands require execution outside this machine's restrictive filesystem sandbox because esbuild reads parent directories during module resolution.

## Automated checks

- Strict TypeScript compilation and Vite production build pass.
- 8 tests pass: master-role separation, finance/academics separation, signed-out denial, role redirects, rejected credentials, campus isolation, notification account isolation, and remember-me restoration/sign-out.
- The production build includes a separate budget checker for the initial login and mock-auth dependency graph. Its build output reports compressed JavaScript and fails at 200 KiB.

## Browser checks completed

- Light and dark sign-in screens rendered.
- Empty-field login validation appeared inline and focused the email/code input.
- Demo Owner signed in successfully and reached the Owner workspace.
- Owner switched to Central Campus; notification drawer displayed the Central Campus scope.
- Marking a notification as read reduced the unread count optimistically.
- A 390px mobile layout showed bottom navigation and no horizontal overflow (document width 375px with the 15px scrollbar inside the 390px viewport).
- Mobile component confirmation disabled the confirm action until the exact phrase matched. Escape dismissed the dialog, restored focus to its trigger, and removed background inertness.
- A 250-record table rendered 13 mobile cards, confirming virtualization rather than rendering the entire list.
- The mobile More drawer displayed account identity and the sign-out action.

## Verification limits

The in-app browser transport closed during the final account-switch check. Reconnection attempts failed, so the final mobile sign-out/Teacher-login sequence, a tablet-width pass, and screenshot file export were not verified. Role and campus restrictions are covered by the automated tests above. The temporary browser viewport could not be reset after transport loss.

No Supabase project or credentials were supplied. Live Auth recovery, RLS behavior, Realtime delivery, Storage, and database-generated types require integration verification against a provisioned development project. `src/types/database.ts` is a schema-compatible contract, not a claim that remote type generation was performed. No Lighthouse score is claimed.

````

## index.html

````html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, viewport-fit=cover"
    />
    <meta name="theme-color" content="#E9EDF3" />
    <meta
      name="description"
      content="School Management System v3.0. One connected workspace for your entire school community."
    />
    <title>Campus · School Management</title>
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>

````

## package.json

````json
{
  "name": "campus-school-management",
  "version": "3.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite --host 127.0.0.1",
    "build": "tsc -b && vite build && node --experimental-strip-types scripts/check-bundle.ts",
    "preview": "vite preview --host 127.0.0.1",
    "test": "vitest run",
    "typecheck": "tsc --noEmit",
    "delivery": "node --experimental-strip-types scripts/delivery.ts"
  },
  "dependencies": {
    "@fontsource/inter": "5.2.5",
    "@hookform/resolvers": "3.10.0",
    "@supabase/supabase-js": "2.118.0",
    "@tanstack/react-query": "5.90.5",
    "@tanstack/react-table": "8.21.3",
    "@tanstack/react-virtual": "3.13.12",
    "date-fns": "4.1.0",
    "framer-motion": "11.18.2",
    "lucide-react": "0.468.0",
    "react": "18.3.1",
    "react-dom": "18.3.1",
    "react-hook-form": "7.62.0",
    "react-router-dom": "6.30.1",
    "recharts": "2.15.4",
    "sonner": "2.0.7",
    "zod": "3.25.76",
    "zustand": "5.0.3"
  },
  "devDependencies": {
    "@types/node": "22.13.4",
    "@types/react": "18.3.18",
    "@types/react-dom": "18.3.5",
    "@vitejs/plugin-react": "4.3.4",
    "autoprefixer": "10.4.20",
    "postcss": "8.5.3",
    "prettier": "3.5.3",
    "tailwindcss": "3.4.17",
    "typescript": "5.7.3",
    "vite": "6.1.0",
    "vitest": "3.0.7"
  }
}

````

## postcss.config.ts

````ts
export default { plugins: { tailwindcss: {}, autoprefixer: {} } };

````

## public/favicon.svg

````svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="18" fill="#E9EDF3"/><path d="m12 26 20-12 20 12-20 11zM19 32v13q13 10 26 0V32M52 26v19" fill="none" stroke="#6480B8" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>

````

## scripts/check-bundle.ts

````ts
import { readFile } from "node:fs/promises";
import { gzipSync } from "node:zlib";
import { join } from "node:path";
type Chunk = {
  file: string;
  isEntry?: boolean;
  imports?: string[];
  dynamicImports?: string[];
};
const manifest = JSON.parse(
  await readFile("dist/.vite/manifest.json", "utf8"),
) as Record<string, Chunk>;
const entry = Object.entries(manifest).find(([, chunk]) => chunk.isEntry)?.[0];
if (!entry) throw new Error("No build entry found.");
const dependencies = new Set<string>();
function collect(key: string) {
  if (dependencies.has(key)) return;
  dependencies.add(key);
  manifest[key]?.imports?.forEach(collect);
}
collect(entry);
// Count entry dependencies plus the initial login route and mock auth adapter.
for (const key of Object.keys(manifest))
  if (key.endsWith("/Login.tsx") || key.endsWith("/adapter.ts")) collect(key);
let total = 0;
for (const key of dependencies) {
  const file = manifest[key]?.file;
  if (file?.endsWith(".js"))
    total += gzipSync(await readFile(join("dist", file))).byteLength;
}
const kib = total / 1024;
console.log(
  `Initial login + mock auth JavaScript: ${kib.toFixed(1)} KiB gzip (budget: <200 KiB).`,
);
if (kib >= 200)
  throw new Error("Initial JavaScript exceeds the requested size budget.");

````

## scripts/delivery.ts

````ts
import { readdir, readFile, writeFile, mkdir } from "node:fs/promises";
import { join, relative } from "node:path";
const root = process.cwd();
const files: string[] = [];
async function walk(directory: string): Promise<void> {
  for (const item of await readdir(directory, { withFileTypes: true })) {
    if (
      ["node_modules", ".git", ".npm-cache", "dist", "docs"].includes(item.name)
    )
      continue;
    const path = join(directory, item.name);
    if (item.isDirectory()) await walk(path);
    else if (
      !item.name.endsWith(".tsbuildinfo") &&
      item.name !== "package-lock.json" &&
      (!item.name.startsWith(".env") || item.name === ".env.example")
    )
      files.push(path);
  }
}
await walk(root);
files.push(join(root, "docs", "PHASE_1_VERIFICATION.md"));
const fence = "````";
const output: string[] = [
  "# Phase 1 complete source",
  "",
  "All authored files are included below. Install reproducible dependencies from package-lock.json in the project folder.",
  "",
];
for (const file of files.sort()) {
  const name = relative(root, file).replaceAll("\\", "/");
  const extension = name.split(".").at(-1) ?? "";
  const language =
    extension === "tsx"
      ? "tsx"
      : ["ts", "css", "sql", "json", "html", "svg", "md"].includes(extension)
        ? extension
        : "text";
  output.push(
    `## ${name}`,
    "",
    `${fence}${language}`,
    await readFile(file, "utf8"),
    fence,
    "",
  );
}
await mkdir(join(root, "docs"), { recursive: true });
await writeFile(join(root, "docs", "PHASE_1_SOURCE.md"), output.join("\n"));
console.log(
  `Wrote complete contents of ${files.length} files to docs/PHASE_1_SOURCE.md`,
);

````

## src/app/AuthProvider.tsx

````tsx
import { useEffect, useState, type ReactNode } from "react";
import { useAuth } from "../store/auth";
import { getRepository } from "../services";
import { ErrorState, NeuButton } from "../components/ui/primitives";
import { NeuModal } from "../components/ui/overlays";
export function AuthProvider({ children }: { children: ReactNode }) {
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  const expired = useAuth((s) => s.expired);
  useEffect(() => {
    let active = true;
    let unsubscribe: (() => void) | undefined;
    let revision = 0;
    setError("");
    void getRepository()
      .then(async (repository) => {
        if (!active) return;
        unsubscribe = repository.auth.onChange((profile) => {
          revision++;
          if (!active) return;
          const previous = useAuth.getState().profile;
          if (previous && !profile) useAuth.getState().setExpired(true);
          useAuth.getState().setProfile(profile);
        });
        const initialRevision = revision;
        const profile = await repository.auth.getProfile();
        if (active && initialRevision === revision)
          useAuth.getState().setProfile(profile);
      })
      .catch((reason) => {
        if (active)
          setError(
            reason instanceof Error
              ? reason.message
              : "Unable to restore your session.",
          );
      });
    return () => {
      active = false;
      unsubscribe?.();
    };
  }, [attempt]);
  if (error)
    return (
      <main className="full-screen">
        <ErrorState
          title="We couldn’t start your workspace"
          description={error}
          onRetry={() => setAttempt((n) => n + 1)}
        />
      </main>
    );
  return (
    <>
      {children}
      <NeuModal
        open={expired}
        onClose={() => useAuth.getState().setExpired(false)}
        title="Your session has ended"
        description="Sign in again to securely return to your workspace."
      >
        <NeuButton
          variant="primary"
          onClick={() => {
            useAuth.getState().setExpired(false);
            window.location.assign("/login");
          }}
        >
          Back to sign in
        </NeuButton>
      </NeuModal>
    </>
  );
}

````

## src/app/ErrorBoundary.tsx

````tsx
import { Component, type ErrorInfo, type ReactNode } from "react";
import { ErrorState } from "../components/ui/primitives";
export class ErrorBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error(
      "Workspace rendering failed",
      error.message,
      info.componentStack,
    );
  }
  render() {
    return this.state.failed ? (
      <ErrorState
        title="This view needs a fresh start"
        description="Your saved preferences are safe. Reload to try again."
        onRetry={() => window.location.reload()}
      />
    ) : (
      this.props.children
    );
  }
}

````

## src/app/router.tsx

````tsx
import { lazy, Suspense } from "react";
import {
  createBrowserRouter,
  Navigate,
  Outlet,
  useLocation,
} from "react-router-dom";
import { useAuth } from "../store/auth";
import { hasPermission, homeFor, type Permission } from "../lib/permissions";
import { Skeleton } from "../components/ui/primitives";
import { ErrorBoundary } from "./ErrorBoundary";
import type { Role } from "../types/domain";
const Login = lazy(() => import("../features/auth/Login"));
const ResetPassword = lazy(() => import("../features/auth/ResetPassword"));
const Shell = lazy(() => import("../components/layout/AppShell"));
const Overview = lazy(() => import("../features/workspace/Overview"));
const Directory = lazy(() => import("../features/workspace/Directory"));
const Components = lazy(() => import("../features/system/ComponentLibrary"));
const Preferences = lazy(() => import("../features/system/Preferences"));
const StatusPage = lazy(() => import("../features/workspace/StatusPage"));
export function RouteLoading() {
  return (
    <div className="route-loading">
      <Skeleton className="title-skeleton" />
      <Skeleton className="hero-skeleton" />
      <div className="loading-grid">
        {[1, 2, 3].map((n) => (
          <Skeleton key={n} className="card-skeleton" />
        ))}
      </div>
    </div>
  );
}
function Root() {
  return (
    <ErrorBoundary>
      <Suspense fallback={<RouteLoading />}>
        <Outlet />
      </Suspense>
    </ErrorBoundary>
  );
}
function RoleGate({
  role,
  permission,
}: {
  role: Role;
  permission: Permission;
}) {
  const { profile, initialized } = useAuth();
  const location = useLocation();
  if (!initialized) return <RouteLoading />;
  if (!profile)
    return (
      <Navigate
        to={role === "master" ? "/sys-master" : "/login"}
        state={{ from: location.pathname }}
        replace
      />
    );
  if (profile.role !== role || !hasPermission(profile.role, permission))
    return <StatusPage status="403" />;
  return <Shell />;
}
function HomeRedirect() {
  const { profile, initialized } = useAuth();
  return initialized ? (
    <Navigate to={profile ? homeFor(profile.role) : "/login"} replace />
  ) : (
    <RouteLoading />
  );
}
const roleRoutes = (
  [
    "owner",
    "principal",
    "teacher",
    "parent",
    "student",
    "accountant",
    "master",
  ] as const
).map((role) => ({
  path: role === "master" ? "/sys-master/workspace" : `/${role}`,
  element: (
    <RoleGate
      role={role}
      permission={role === "master" ? "master.manage" : "workspace.read"}
    />
  ),
  children: [
    { index: true, element: <Overview /> },
    { path: "directory", element: <Directory /> },
    { path: "components", element: <Components /> },
    { path: "preferences", element: <Preferences /> },
    { path: "*", element: <StatusPage status="404" /> },
  ],
}));
// The master URL is intentionally absent from navigation. Its real boundary is trusted claims + database RLS.
export const router = createBrowserRouter([
  {
    element: <Root />,
    children: [
      { path: "/", element: <HomeRedirect /> },
      { path: "/login", element: <Login /> },
      { path: "/sys-master", element: <Login master /> },
      { path: "/reset-password", element: <ResetPassword /> },
      { path: "/401", element: <StatusPage status="401" /> },
      { path: "/403", element: <StatusPage status="403" /> },
      ...roleRoutes,
      { path: "*", element: <StatusPage status="404" /> },
    ],
  },
]);

````

## src/components/layout/AppShell.tsx

````tsx
import { useEffect, useState } from "react";
import {
  Link,
  NavLink,
  Outlet,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import {
  NeuAvatar,
  NeuBadge,
  NeuButton,
  NeuSelect,
  SearchBar,
  Skeleton,
  ThemeToggle,
  ErrorState,
} from "../ui/primitives";
import { NeuDrawer, NeuModal } from "../ui/overlays";
import { Icon } from "../ui/Icon";
import { useAuth } from "../../store/auth";
import { useUI } from "../../store/ui";
import { getRepository } from "../../services";
import {
  hasPermission,
  homeFor,
  navigation,
  roleLabels,
} from "../../lib/permissions";
import { queryClient, queryKeys } from "../../lib/query";
import { useDebounce } from "../../hooks/useDebounce";
import { config } from "../../lib/config";
import { ErrorBoundary } from "../../app/ErrorBoundary";
import { RouteLoading } from "../../app/router";
import { Suspense } from "react";
import type { Notification } from "../../types/domain";

export default function AppShell() {
  const profile = useAuth((s) => s.profile)!;
  const { branchId, setBranch, collapsed, toggleSidebar } = useUI();
  const location = useLocation();
  const navigate = useNavigate();
  const [moreOpen, setMoreOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search);
  const base = homeFor(profile.role);
  const branches = useQuery({
    queryKey: queryKeys.branches(profile.id),
    queryFn: async () => (await getRepository()).branches.list(),
  });
  const assigned = branches.data ?? [];
  const activeBranch =
    assigned.find((branch) => branch.id === branchId) ?? assigned[0];
  const activeId = activeBranch?.id ?? "";
  useEffect(() => {
    if (activeId && branchId !== activeId) setBranch(activeId);
  }, [activeId, branchId, setBranch]);
  const key = queryKeys.notifications(profile.id, activeId);
  const notifications = useQuery({
    queryKey: key,
    queryFn: async () => (await getRepository()).notifications.list(activeId),
    enabled: !!activeId,
  });
  useEffect(() => {
    if (!activeId) return;
    let active = true;
    let cleanup: (() => void) | undefined;
    void getRepository()
      .then((repository) => {
        if (active)
          cleanup = repository.notifications.subscribe(activeId, () => {
            void queryClient.invalidateQueries({
              queryKey: queryKeys.notifications(profile.id, activeId),
            });
          });
      })
      .catch(() => undefined);
    return () => {
      active = false;
      cleanup?.();
    };
  }, [activeId, profile.id]);
  const markRead = useMutation({
    mutationFn: async (id: string) =>
      (await getRepository()).notifications.markRead(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: key });
      const previous = queryClient.getQueryData<Notification[]>(key);
      queryClient.setQueryData<Notification[]>(key, (old) =>
        old?.map((n) => (n.id === id ? { ...n, read: true } : n)),
      );
      return { previous, key };
    },
    onError: (_error, _id, context) => {
      if (context) queryClient.setQueryData(context.key, context.previous);
      toast.error("Could not update this notification. Please try again.");
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: key }),
  });
  const unread = notifications.data?.filter((item) => !item.read).length ?? 0;
  const showHighlights = useUI((s) => s.inAppUpdates);
  const availableNav = navigation.filter((item) =>
    hasPermission(profile.role, item.permission),
  );
  const activeLabel =
    availableNav.find((item) =>
      item.path
        ? location.pathname === `${base}${item.path}`
        : location.pathname === base,
    )?.label ?? "Workspace";
  const prefetch = (path: string) => {
    if (path === "/directory")
      void import("../../features/workspace/Directory");
    if (path === "/components")
      void import("../../features/system/ComponentLibrary");
    if (path === "/preferences")
      void import("../../features/system/Preferences");
  };
  const navContent = (
    <>
      {(["Workspace", "Management", "System"] as const).map((section) => (
        <div className="nav-section" key={section}>
          <div className="nav-section-label">{section}</div>
          {availableNav
            .filter((item) => item.section === section)
            .map((item) =>
              item.phase > 1 ? (
                <div
                  className="nav-item unavailable"
                  key={item.label}
                  aria-disabled="true"
                  title={`Available in Phase ${item.phase}`}
                >
                  <Icon name={item.icon} />
                  <span>{item.label}</span>
                  <Icon name="lock" size={13} />
                </div>
              ) : (
                <NavLink
                  key={item.label}
                  aria-label={item.label}
                  title={item.label}
                  to={`${base}${item.path}`}
                  end={!item.path}
                  onClick={() => setMoreOpen(false)}
                  onMouseEnter={() => prefetch(item.path)}
                  onFocus={() => prefetch(item.path)}
                  className={({ isActive }) =>
                    `nav-item ${isActive ? "active" : ""}`
                  }
                >
                  <Icon name={item.icon} />
                  <span>{item.label}</span>
                  {item.label === "Overview" && (
                    <span className="nav-active-dot" />
                  )}
                </NavLink>
              ),
            )}
        </div>
      ))}
    </>
  );
  const signOut = async () => {
    try {
      const repository = await getRepository();
      await repository.auth.signOut();
      useAuth.getState().setExpired(false);
      useAuth.getState().setProfile(null);
      queryClient.clear();
      navigate(profile.role === "master" ? "/sys-master" : "/login", {
        replace: true,
      });
    } catch {
      toast.error("Sign out failed. Please try again.");
    }
  };
  return (
    <div className={`app-shell ${collapsed ? "sidebar-collapsed" : ""}`}>
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      <aside className="sidebar">
        <Link className="brand" to={base}>
          <span className="brand-mark">
            <Icon name="graduation" size={27} />
          </span>
          <span>
            campus<span className="brand-dot">.</span>
          </span>
        </Link>
        <div className="school-identity">
          <span className="school-monogram">G</span>
          <div>
            <b>{config.mock ? "Greenwood School" : "Your school"}</b>
            <small>School Management v3.0</small>
          </div>
          <Icon name="shield" size={16} />
        </div>
        <nav aria-label="Main navigation">{navContent}</nav>
        <div className="sidebar-bottom">
          <div className="help-card">
            <span className="icon-tile small">
              <Icon name="help" />
            </span>
            <b>A little help?</b>
            <p>
              Your school workspace,
              <br />
              made a little simpler.
            </p>
            <NeuButton variant="ghost" onClick={() => setHelpOpen(true)}>
              Help & getting started
              <Icon name="arrow-up-right" size={15} />
            </NeuButton>
          </div>
          <button
            className="sidebar-account"
            onClick={() => setProfileOpen(true)}
          >
            <NeuAvatar name={profile.name} size="sm" />
            <span>
              <b>{profile.name}</b>
              <small>{roleLabels[profile.role]}</small>
            </span>
            <Icon name="more" size={18} />
          </button>
        </div>
        <NeuButton
          className="sidebar-collapse"
          variant="icon"
          icon={collapsed ? "right" : "collapse"}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          onClick={toggleSidebar}
        />
      </aside>
      <div className="app-main">
        <header className="top-header">
          <div className="header-branch">
            <span className="icon-tile small">
              <Icon name="building" />
            </span>
            {branches.isPending ? (
              <Skeleton className="branch-skeleton" />
            ) : branches.isError ? (
              <button
                className="text-button"
                onClick={() => void branches.refetch()}
              >
                Retry campuses
              </button>
            ) : assigned.length ? (
              <NeuSelect
                aria-label="Active campus"
                value={activeId}
                onChange={(event) => {
                  setBranch(event.target.value);
                  toast.success("Campus switched");
                }}
              >
                {assigned.map((branch) => (
                  <option key={branch.id} value={branch.id}>
                    {branch.short_name}
                  </option>
                ))}
              </NeuSelect>
            ) : (
              <span>No campus assigned</span>
            )}
            <NeuBadge>{config.mock ? "Demo" : "Live"}</NeuBadge>
          </div>
          <div className="header-actions">
            <button
              className="global-search-trigger"
              aria-label="Search your workspace"
              onClick={() => setSearchOpen(true)}
            >
              <Icon name="search" size={18} />
              <span>Search your workspace</span>
              <kbd>⌕</kbd>
            </button>
            <ThemeToggle />
            <div className="notification-trigger">
              <NeuButton
                variant="ghost"
                icon="bell"
                aria-label={`Notifications, ${unread} unread`}
                onClick={() => setNotificationOpen(true)}
              />
              {unread > 0 && showHighlights && <span />}
            </div>
            <span className="header-divider" />
            <button
              className="header-profile"
              aria-label="Open profile menu"
              onClick={() => setProfileOpen(true)}
            >
              <NeuAvatar name={profile.name} size="sm" />
              <Icon name="down" size={14} />
            </button>
          </div>
        </header>
        <main id="main-content" className="main-content" tabIndex={-1}>
          <div className="breadcrumb">
            <span>
              <Link to={base}>Workspace</Link>
              <Icon name="right" size={13} />
              {activeLabel}
            </span>
            <NeuBadge>
              <Icon name="shield" size={12} />
              {roleLabels[profile.role]}
            </NeuBadge>
          </div>
          {branches.isError && (
            <div className="inline-error" role="alert">
              Campus access could not be loaded.{" "}
              <button
                className="text-button"
                onClick={() => void branches.refetch()}
              >
                Try again
              </button>
            </div>
          )}
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.18 }}
            >
              <ErrorBoundary key={location.pathname}>
                <Suspense fallback={<RouteLoading />}>
                  <Outlet context={{ branches: assigned, activeBranch }} />
                </Suspense>
              </ErrorBoundary>
            </motion.div>
          </AnimatePresence>
          <footer className="workspace-footer">
            <span>
              Campus v3.0 <i /> Smart · Secure · Connected
            </span>
            <span>
              <span className="status-dot" />{" "}
              {config.mock ? "Demo workspace" : "Secure workspace"}
            </span>
          </footer>
        </main>
      </div>
      <nav className="bottom-nav" aria-label="Mobile navigation">
        {[
          { label: "Home", path: "", icon: "grid" },
          { label: "Directory", path: "/directory", icon: "layers" },
          { label: "Library", path: "/components", icon: "palette" },
          { label: "You", path: "/preferences", icon: "user" },
        ].map((item) => (
          <NavLink
            key={item.label}
            to={`${base}${item.path}`}
            end={!item.path}
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            <Icon name={item.icon as "grid" | "layers" | "palette" | "user"} />
            <span>{item.label}</span>
          </NavLink>
        ))}
        <button onClick={() => setMoreOpen(true)}>
          <Icon name="menu" />
          <span>More</span>
        </button>
      </nav>
      <NeuDrawer
        open={moreOpen}
        onClose={() => setMoreOpen(false)}
        title="Your workspace"
      >
        <nav className="drawer-nav" aria-label="More navigation">
          {navContent}
        </nav>
        <NeuButton
          icon="help"
          onClick={() => {
            setMoreOpen(false);
            setHelpOpen(true);
          }}
        >
          Help & getting started
        </NeuButton>
        <div className="mobile-account-actions">
          <NeuAvatar name={profile.name} />
          <div>
            <b>{profile.name}</b>
            <small>{roleLabels[profile.role]}</small>
          </div>
        </div>
        <NeuButton
          icon="logout"
          onClick={() => {
            setMoreOpen(false);
            void signOut();
          }}
        >
          Sign out securely
        </NeuButton>
      </NeuDrawer>
      <NeuDrawer
        open={notificationOpen}
        onClose={() => setNotificationOpen(false)}
        title="Notifications"
        description={`${unread} unread · ${activeBranch?.short_name ?? "Your campus"}`}
      >
        <div className="notification-list">
          {notifications.isPending ? (
            <Skeleton className="card-skeleton" />
          ) : notifications.isError ? (
            <ErrorState
              description="Could not load notifications."
              onRetry={() => void notifications.refetch()}
            />
          ) : notifications.data?.length ? (
            notifications.data.map((item) => (
              <article
                className={item.read ? "notification read" : "notification"}
                key={item.id}
              >
                <span className="icon-tile small">
                  <Icon name={item.read ? "check-all" : "bell"} />
                </span>
                <div>
                  <b>{item.title}</b>
                  <p>{item.body}</p>
                  <small>
                    {formatDistanceToNow(new Date(item.created_at), {
                      addSuffix: true,
                    })}
                  </small>
                  {!item.read && (
                    <button
                      className="text-button"
                      onClick={() => markRead.mutate(item.id)}
                    >
                      Mark as read
                    </button>
                  )}
                </div>
              </article>
            ))
          ) : (
            <p>You’re all caught up.</p>
          )}
        </div>
      </NeuDrawer>
      <NeuModal
        open={profileOpen}
        onClose={() => setProfileOpen(false)}
        title="Your account"
      >
        <div className="profile-summary">
          <NeuAvatar name={profile.name} size="lg" />
          <h3>{profile.name}</h3>
          <p>{profile.email}</p>
          <NeuBadge>{roleLabels[profile.role]}</NeuBadge>
        </div>
        <div className="profile-menu">
          <NeuButton
            icon="settings"
            onClick={() => {
              setProfileOpen(false);
              navigate(`${base}/preferences`);
            }}
          >
            My preferences
            <Icon name="right" size={16} />
          </NeuButton>
          <NeuButton icon="logout" onClick={() => void signOut()}>
            Sign out securely
          </NeuButton>
        </div>
      </NeuModal>
      <NeuModal
        open={searchOpen}
        onClose={() => {
          setSearchOpen(false);
          setSearch("");
        }}
        title="Find your way"
      >
        <SearchBar
          value={search}
          onChange={setSearch}
          placeholder="Search pages and tools…"
          label="Search workspace pages"
        />
        <div className="search-results">
          {availableNav
            .filter(
              (item) =>
                item.phase === 1 &&
                item.label
                  .toLowerCase()
                  .includes(debouncedSearch.toLowerCase()),
            )
            .map((item) => (
              <Link
                key={item.label}
                to={`${base}${item.path}`}
                onClick={() => {
                  setSearchOpen(false);
                  setSearch("");
                }}
              >
                <Icon name={item.icon} />
                <span>{item.label}</span>
                <Icon name="arrow-up-right" size={16} />
              </Link>
            ))}
          {!availableNav.some(
            (item) =>
              item.phase === 1 &&
              item.label.toLowerCase().includes(debouncedSearch.toLowerCase()),
          ) && <p>No pages found. Try “Overview” or “Preferences”.</p>}
        </div>
      </NeuModal>
      <NeuModal
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        title="Make yourself at home"
        description="A quick guide to your school workspace."
      >
        <ol className="help-steps">
          <li>
            <b>Choose your campus</b>
            <p>
              Use the campus selector at the top. You’ll see only campuses
              assigned to your account.
            </p>
          </li>
          <li>
            <b>Find your tools</b>
            <p>
              The workspace directory explains which modules your role can
              access and their delivery phase.
            </p>
          </li>
          <li>
            <b>Make it yours</b>
            <p>
              Choose your theme and local notification preferences in My
              preferences.
            </p>
          </li>
        </ol>
        <p className="muted">
          For account changes, contact your school administrator.
        </p>
      </NeuModal>
    </div>
  );
}

````

## src/components/layout/CampusIllustration.tsx

````tsx
import { Icon } from "../ui/Icon";
export function CampusIllustration({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={`campus-illustration ${compact ? "compact" : ""}`}
      aria-hidden="true"
    >
      <div className="orbit orbit-one" />
      <div className="orbit orbit-two" />
      <div className="floating-tile tile-book">
        <Icon name="book" size={30} />
      </div>
      <div className="floating-tile tile-community">
        <Icon name="users" size={26} />
      </div>
      <div className="floating-tile tile-message">
        <Icon name="message" size={24} />
        <span className="online-dot" />
      </div>
      <div className="campus-platform">
        <div className="campus-building">
          <div className="building-roof">
            <Icon name="graduation" size={42} />
          </div>
          <div className="building-clock">
            <span />
          </div>
          <div className="building-label">CAMPUS</div>
          <div className="building-windows">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <i key={n} />
            ))}
          </div>
          <div className="building-door" />
        </div>
        <div className="campus-tree tree-left">
          <i />
          <span />
        </div>
        <div className="campus-tree tree-right">
          <i />
          <span />
        </div>
        <div className="campus-path" />
      </div>
      <div className="illustration-caption">
        <span className="status-dot" /> Everyone belongs here.
      </div>
    </div>
  );
}

````

## src/components/ui/FileUpload.tsx

````tsx
import { useRef, useState } from "react";
import { Icon } from "./Icon";
import { NeuButton } from "./primitives";
export function FileUpload({
  onUpload,
  accept = ".pdf,.csv,.png,.jpg,.jpeg",
  maxMB = 5,
  disabled = false,
}: {
  onUpload: (file: File) => Promise<void>;
  accept?: string;
  maxMB?: number;
  disabled?: boolean;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [dragging, setDragging] = useState(false);
  const upload = async (file?: File) => {
    if (!file || busy || disabled) return;
    if (file.size > maxMB * 1024 * 1024) {
      setMessage(`Choose a file smaller than ${maxMB} MB.`);
      return;
    }
    const accepted = accept
      .split(",")
      .some((type) =>
        type.trim().startsWith(".")
          ? file.name.toLowerCase().endsWith(type.trim().toLowerCase())
          : type.trim().endsWith("/*")
            ? file.type.startsWith(type.trim().slice(0, -1))
            : file.type === type.trim(),
      );
    if (!accepted) {
      setMessage("This file type is not supported.");
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      await onUpload(file);
      setMessage(`${file.name} uploaded successfully.`);
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Upload failed. Please try again.",
      );
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  };
  return (
    <div
      className={`file-upload ${dragging ? "dragging" : ""}`}
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        void upload(e.dataTransfer.files[0]);
      }}
    >
      <Icon name="upload" size={28} />
      <b>Drop a file here, or browse</b>
      <small>
        {accept.replaceAll(".", "").toUpperCase()} · up to {maxMB} MB
      </small>
      <input
        ref={input}
        type="file"
        accept={accept}
        onChange={(e) => void upload(e.target.files?.[0])}
        className="sr-only"
        tabIndex={-1}
        aria-hidden="true"
      />
      <NeuButton
        icon="plus"
        loading={busy}
        disabled={disabled}
        onClick={() => input.current?.click()}
      >
        Choose file
      </NeuButton>
      <span role="status">{message}</span>
    </div>
  );
}

````

## src/components/ui/Icon.tsx

````tsx
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bell,
  BookOpen,
  Building2,
  CalendarDays,
  CalendarCheck,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  CircleHelp,
  Clock3,
  Copy,
  CreditCard,
  Download,
  Ellipsis,
  Eye,
  EyeOff,
  FileText,
  GraduationCap,
  Heart,
  Home,
  LayoutDashboard,
  Layers,
  Loader2,
  LockKeyhole,
  LogOut,
  Mail,
  Menu,
  MessageCircle,
  Monitor,
  Moon,
  Palette,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Sun,
  Upload,
  Users,
  UserRound,
  Wallet,
  X,
  XCircle,
} from "lucide-react";
import type { CSSProperties } from "react";
const icons = {
  "arrow-down": ArrowDown,
  "arrow-left": ArrowLeft,
  "arrow-right": ArrowRight,
  "arrow-up-right": ArrowUpRight,
  bell: Bell,
  book: BookOpen,
  building: Building2,
  calendar: CalendarDays,
  "calendar-check": CalendarCheck,
  check: Check,
  "check-all": CheckCheck,
  down: ChevronDown,
  left: ChevronLeft,
  right: ChevronRight,
  collapse: ChevronsLeft,
  help: CircleHelp,
  clock: Clock3,
  copy: Copy,
  credit: CreditCard,
  download: Download,
  more: Ellipsis,
  eye: Eye,
  "eye-off": EyeOff,
  file: FileText,
  graduation: GraduationCap,
  heart: Heart,
  home: Home,
  grid: LayoutDashboard,
  layers: Layers,
  loading: Loader2,
  lock: LockKeyhole,
  logout: LogOut,
  mail: Mail,
  menu: Menu,
  message: MessageCircle,
  monitor: Monitor,
  moon: Moon,
  palette: Palette,
  plus: Plus,
  search: Search,
  settings: Settings2,
  shield: ShieldCheck,
  sparkles: Sparkles,
  sun: Sun,
  upload: Upload,
  users: Users,
  user: UserRound,
  wallet: Wallet,
  close: X,
  error: XCircle,
};
export type IconName = keyof typeof icons;
export function Icon({
  name,
  size = 20,
  className = "",
  style,
}: {
  name: IconName;
  size?: number;
  className?: string;
  style?: CSSProperties;
}) {
  const Component = icons[name];
  return (
    <Component
      size={size}
      stroke="url(#icon-gradient)"
      strokeWidth={1.8}
      className={`icon ${className}`}
      style={style}
      aria-hidden="true"
    />
  );
}
export function IconGradients() {
  return (
    <svg width="0" height="0" aria-hidden="true" className="gradient-defs">
      <defs>
        <linearGradient id="icon-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4DB8FF" />
          <stop offset="100%" stopColor="#A99BD6" />
        </linearGradient>
      </defs>
    </svg>
  );
}

````

## src/components/ui/NeuTable.tsx

````tsx
import {
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table";
import { useVirtualizer } from "@tanstack/react-virtual";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { EmptyState } from "./primitives";
type TableProps<T> = {
  data: T[];
  columns: ColumnDef<T, unknown>[];
  label: string;
  rowKey: (row: T) => string;
  renderMobile: (row: T) => ReactNode;
};
export function NeuTable<T>({
  data,
  columns,
  label,
  rowKey,
  renderMobile,
}: TableProps<T>) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const parent = useRef<HTMLDivElement>(null);
  const [mobile, setMobile] = useState(
    () => matchMedia("(max-width: 639px)").matches,
  );
  useEffect(() => {
    const media = matchMedia("(max-width: 639px)");
    const update = () => setMobile(media.matches);
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  const table = useReactTable({
    data,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getRowId: rowKey,
  });
  const rows = table.getRowModel().rows;
  const virtual = useVirtualizer({
    count: rows.length,
    getScrollElement: () => parent.current,
    estimateSize: () => (mobile ? 73 : 64),
    overscan: 6,
    enabled: rows.length > 100,
  });
  useEffect(() => {
    virtual.measure();
  }, [mobile, virtual]);
  if (!data.length)
    return (
      <EmptyState
        title="No records found"
        description="Try adjusting your search or filters."
      />
    );
  const displayed =
    rows.length > 100
      ? virtual.getVirtualItems().flatMap((item) => {
          const row = rows[item.index];
          return row ? [{ row, item }] : [];
        })
      : rows.map((row) => ({ row, item: undefined }));
  // Both mobile cards and desktop rows share one bounded virtual scroller.
  return (
    <div
      ref={parent}
      className="table-scroll"
      style={rows.length > 100 ? { height: 480, overflowY: "auto" } : undefined}
    >
      <div className="mobile-table" aria-label={label}>
        {displayed.length > 0 && rows.length > 100 && (
          <div style={{ height: displayed[0]?.item?.start ?? 0 }} />
        )}
        {displayed.map(({ row }) => (
          <article key={row.id}>{renderMobile(row.original)}</article>
        ))}
        {rows.length > 100 && (
          <div
            style={{
              height:
                virtual.getTotalSize() - (displayed.at(-1)?.item?.end ?? 0),
            }}
          />
        )}
      </div>
      <table className="neu-table" aria-label={label}>
        <thead>
          {table.getHeaderGroups().map((group) => (
            <tr key={group.id}>
              {group.headers.map((header) => (
                <th
                  key={header.id}
                  aria-sort={
                    header.column.getIsSorted() === "asc"
                      ? "ascending"
                      : header.column.getIsSorted() === "desc"
                        ? "descending"
                        : undefined
                  }
                >
                  {header.column.getCanSort() ? (
                    <button onClick={header.column.getToggleSortingHandler()}>
                      {flexRender(
                        header.column.columnDef.header,
                        header.getContext(),
                      )}
                      <span aria-hidden="true">↕</span>
                    </button>
                  ) : (
                    flexRender(
                      header.column.columnDef.header,
                      header.getContext(),
                    )
                  )}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {rows.length > 100 && (
            <tr aria-hidden="true">
              <td
                colSpan={columns.length}
                style={{ height: displayed[0]?.item?.start ?? 0, padding: 0 }}
              />
            </tr>
          )}
          {displayed.map(({ row, item }) => (
            <tr key={row.id} style={item ? { height: item.size } : undefined}>
              {row.getVisibleCells().map((cell) => (
                <td key={cell.id}>
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
          {rows.length > 100 && (
            <tr aria-hidden="true">
              <td
                colSpan={columns.length}
                style={{
                  height:
                    virtual.getTotalSize() - (displayed.at(-1)?.item?.end ?? 0),
                  padding: 0,
                }}
              />
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

````

## src/components/ui/index.ts

````ts
export * from "./primitives";
export * from "./overlays";
export * from "./Icon";
export * from "./FileUpload";
export * from "./NeuTable";

````

## src/components/ui/overlays.tsx

````tsx
import { createPortal } from "react-dom";
import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { NeuButton, NeuInput } from "./primitives";

type OverlayProps = {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
};
function Overlay({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  drawer = false,
}: OverlayProps & { drawer?: boolean }) {
  const titleId = useId();
  const descriptionId = useId();
  const panel = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const root = document.getElementById("root");
    root?.setAttribute("inert", "");
    const timer = setTimeout(() => panel.current?.focus(), 0);
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeRef.current();
      if (event.key !== "Tab") return;
      const nodes = panel.current?.querySelectorAll<HTMLElement>(
        'button:not(:disabled), [href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex="0"]',
      );
      const first = nodes?.[0];
      const last = nodes?.[nodes.length - 1];
      if (!first || !last) {
        event.preventDefault();
        return;
      }
      if (
        event.shiftKey &&
        (document.activeElement === first ||
          document.activeElement === panel.current)
      ) {
        event.preventDefault();
        last.focus();
      } else if (
        !event.shiftKey &&
        (document.activeElement === last ||
          document.activeElement === panel.current)
      ) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", keydown);
    return () => {
      clearTimeout(timer);
      document.body.style.overflow = oldOverflow;
      root?.removeAttribute("inert");
      document.removeEventListener("keydown", keydown);
      previous?.focus();
    };
  }, [open]);
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className={`overlay ${drawer ? "drawer-overlay" : ""}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
        >
          <motion.div
            ref={panel}
            className={`overlay-panel ${drawer ? "drawer-panel" : ""}`}
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            aria-describedby={description ? descriptionId : undefined}
            tabIndex={-1}
            initial={drawer ? { x: 40 } : { y: 18, scale: 0.98 }}
            animate={{ x: 0, y: 0, scale: 1 }}
            exit={drawer ? { x: 40 } : { y: 18, scale: 0.98 }}
            transition={{ duration: 0.2 }}
          >
            <div className="overlay-header">
              <div>
                <h2 id={titleId}>{title}</h2>
                {description && <p id={descriptionId}>{description}</p>}
              </div>
              <NeuButton
                variant="ghost"
                icon="close"
                aria-label="Close dialog"
                onClick={onClose}
              />
            </div>
            <div className="overlay-content">{children}</div>
            {footer && <div className="overlay-footer">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
export function NeuModal(props: OverlayProps) {
  return <Overlay {...props} />;
}
export function NeuDrawer(props: OverlayProps) {
  return <Overlay {...props} drawer />;
}
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  description,
  confirmText,
  loading,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmText?: string;
  loading?: boolean;
}) {
  const [text, setText] = useState("");
  useEffect(() => {
    if (open) setText("");
  }, [open]);
  return (
    <NeuModal
      open={open}
      onClose={loading ? () => undefined : onClose}
      title={title}
      description={description}
      footer={
        <>
          <NeuButton onClick={onClose} disabled={loading}>
            Cancel
          </NeuButton>
          <NeuButton
            className="danger"
            onClick={onConfirm}
            loading={loading}
            disabled={!!confirmText && text !== confirmText}
          >
            Confirm
          </NeuButton>
        </>
      }
    >
      {confirmText && (
        <NeuInput
          id="confirm-action"
          label={`Type “${confirmText}” to confirm`}
          autoComplete="off"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      )}
    </NeuModal>
  );
}

````

## src/components/ui/primitives.tsx

````tsx
import {
  forwardRef,
  useEffect,
  useId,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
} from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Icon, type IconName } from "./Icon";
import { useUI } from "../../store/ui";
import { useTheme } from "../../hooks/useTheme";

export const NeuButton = forwardRef<
  HTMLButtonElement,
  ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: "primary" | "secondary" | "icon" | "ghost";
    loading?: boolean;
    icon?: IconName;
  }
>(function NeuButton(
  {
    variant = "secondary",
    loading,
    icon,
    children,
    className = "",
    disabled,
    ...props
  },
  ref,
) {
  return (
    <button
      ref={ref}
      className={`neu-button ${variant} ${className}`}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...props}
    >
      {loading ? (
        <Icon name="loading" className="spin" />
      ) : icon ? (
        <Icon name={icon} />
      ) : null}
      {children}
    </button>
  );
});
export function NeuCard({
  children,
  className = "",
  ...props
}: HTMLAttributes<HTMLElement>) {
  return (
    <section className={`neu-card ${className}`} {...props}>
      {children}
    </section>
  );
}
export const NeuInput = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & {
    label?: string;
    error?: string;
    hint?: string;
    icon?: IconName;
  }
>(function NeuInput(
  { label, error, hint, icon, id, className = "", ...props },
  ref,
) {
  const inputId = id ?? props.name;
  return (
    <div className={`field ${className}`}>
      {label && <label htmlFor={inputId}>{label}</label>}
      <div className="input-wrap">
        {icon && <Icon name={icon} />}
        <input
          ref={ref}
          id={inputId}
          aria-invalid={!!error}
          aria-describedby={error || hint ? `${inputId}-help` : undefined}
          {...props}
        />
      </div>
      {(error || hint) && (
        <span
          className={error ? "field-error" : "field-hint"}
          id={`${inputId}-help`}
        >
          {error || hint}
        </span>
      )}
    </div>
  );
});
export const NeuSelect = forwardRef<
  HTMLSelectElement,
  SelectHTMLAttributes<HTMLSelectElement> & { label?: string }
>(function NeuSelect({ label, id, children, className = "", ...props }, ref) {
  return (
    <div className={`field ${className}`}>
      {label && <label htmlFor={id}>{label}</label>}
      <div className="select-wrap">
        <select ref={ref} id={id} {...props}>
          {children}
        </select>
        <Icon name="down" size={16} />
      </div>
    </div>
  );
});
export function NeuToggle({
  checked,
  onChange,
  label,
  description,
  disabled,
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  description?: string;
  disabled?: boolean;
}) {
  return (
    <label className={`toggle-row ${disabled ? "disabled" : ""}`}>
      <span>
        <span className="control-label">{label}</span>
        {description && <small>{description}</small>}
      </span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        className={`toggle ${checked ? "on" : ""}`}
        onClick={() => onChange(!checked)}
      >
        <motion.span layout transition={{ duration: 0.18 }} />
      </button>
    </label>
  );
}
export const NeuCheckbox = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & { label: string }
>(function NeuCheckbox({ label, ...props }, ref) {
  return (
    <label className="choice">
      <input ref={ref} type="checkbox" {...props} />
      <span>{label}</span>
    </label>
  );
});
export const NeuRadio = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & { label: string }
>(function NeuRadio({ label, ...props }, ref) {
  return (
    <label className="choice">
      <input ref={ref} type="radio" {...props} />
      <span>{label}</span>
    </label>
  );
});
export function NeuTabs<T extends string>({
  tabs,
  value,
  onChange,
  label = "View",
}: {
  tabs: readonly { value: T; label: string }[];
  value: T;
  onChange: (value: T) => void;
  label?: string;
}) {
  const id = useId();
  return (
    <div className="neu-tabs" role="group" aria-label={label}>
      {tabs.map((tab) => (
        <button
          type="button"
          key={tab.value}
          aria-pressed={value === tab.value}
          className={value === tab.value ? "active" : ""}
          onClick={() => onChange(tab.value)}
        >
          {value === tab.value && (
            <motion.span
              className="tab-indicator"
              layoutId={`tab-${id}`}
              transition={{ duration: 0.18 }}
            />
          )}
          <span>{tab.label}</span>
        </button>
      ))}
    </div>
  );
}
export function NeuBadge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "success" | "accent" | "warning";
}) {
  return <span className={`badge ${tone}`}>{children}</span>;
}
export function NeuAvatar({
  name,
  size = "md",
}: {
  name: string;
  size?: "sm" | "md" | "lg";
}) {
  return (
    <span className={`avatar ${size}`} aria-label={name}>
      {name
        .split(" ")
        .map((n) => n[0])
        .slice(0, 2)
        .join("")}
    </span>
  );
}
export function NeuProgress({
  value,
  label,
  showValue = true,
}: {
  value: number;
  label: string;
  showValue?: boolean;
}) {
  const safe = Math.min(100, Math.max(0, value));
  return (
    <div className="progress-block">
      <div className="progress-label">
        <span>{label}</span>
        {showValue && <b>{safe}%</b>}
      </div>
      <div
        className="progress-track"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={safe}
        aria-label={label}
      >
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: safe / 100 }}
          transition={{ duration: 0.3 }}
        />
      </div>
    </div>
  );
}
export function StatCard({
  label,
  value,
  suffix = "",
  icon,
  detail,
}: {
  label: string;
  value: number;
  suffix?: string;
  icon: IconName;
  detail?: string;
}) {
  const reduced = useReducedMotion();
  const [count, setCount] = useState(value);
  const previous = useRef(value);
  useEffect(() => {
    if (reduced) {
      setCount(value);
      return;
    }
    const start = performance.now();
    const from = previous.current;
    let frame = 0;
    const tick = (time: number) => {
      const progress = Math.min((time - start) / 350, 1);
      setCount(Math.round(from + (value - from) * progress));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    previous.current = value;
    return () => cancelAnimationFrame(frame);
  }, [value, reduced]);
  return (
    <NeuCard className="stat-card">
      <div className="stat-top">
        <span>{label}</span>
        <span className="icon-tile small">
          <Icon name={icon} />
        </span>
      </div>
      <strong>
        {count.toLocaleString()}
        {suffix}
      </strong>
      {detail && <small>{detail}</small>}
    </NeuCard>
  );
}
export function SearchBar({
  value,
  onChange,
  placeholder = "Search…",
  label = "Search",
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
}) {
  return (
    <div className="search-bar">
      <Icon name="search" size={18} />
      <input
        aria-label={label}
        placeholder={placeholder}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        type="search"
      />
      {value && (
        <NeuButton
          variant="ghost"
          aria-label="Clear search"
          onClick={() => onChange("")}
          icon="close"
        />
      )}
    </div>
  );
}
export function DatePicker({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <NeuInput
      type="date"
      id={label.replaceAll(" ", "-")}
      label={label}
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}
export function Skeleton({
  className = "",
  label = "Loading",
}: {
  className?: string;
  label?: string;
}) {
  return (
    <div className={`skeleton ${className}`} role="status" aria-label={label}>
      <span className="sr-only">{label}</span>
    </div>
  );
}
export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <span className="icon-tile">
        <Icon name="layers" size={28} />
      </span>
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  );
}
export function ErrorState({
  title = "We couldn’t load this view",
  description = "Please try again in a moment.",
  onRetry,
}: {
  title?: string;
  description?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="empty-state" role="alert">
      <Icon name="error" size={32} />
      <h3>{title}</h3>
      <p>{description}</p>
      {onRetry && <NeuButton onClick={onRetry}>Try again</NeuButton>}
    </div>
  );
}
export function ThemeToggle() {
  const theme = useTheme();
  const setTheme = useUI((s) => s.setTheme);
  return (
    <NeuButton
      variant="icon"
      icon={theme === "dark" ? "sun" : "moon"}
      title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
    />
  );
}

````

## src/features/auth/Login.tsx

````tsx
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCheckbox,
  NeuInput,
  ThemeToggle,
  NeuBadge,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { Icon } from "../../components/ui/Icon";
import { getRepository } from "../../services";
import { useAuth } from "../../store/auth";
import { config } from "../../lib/config";
import { homeFor, roleLabels } from "../../lib/permissions";
import type { Role } from "../../types/domain";
import { queryClient } from "../../lib/query";
import { CampusIllustration } from "../../components/layout/CampusIllustration";
const schema = z.object({
  identifier: z.string().trim().min(1, "Enter your school email or code."),
  password: z.string().min(1, "Enter your password."),
  remember: z.boolean(),
});
type Form = z.infer<typeof schema>;
export default function Login({ master = false }: { master?: boolean }) {
  const [visible, setVisible] = useState(false);
  const [error, setError] = useState("");
  const [reset, setReset] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [sending, setSending] = useState(false);
  const [demoRole, setDemoRole] = useState<Role>(master ? "master" : "owner");
  const profile = useAuth((s) => s.profile);
  const navigate = useNavigate();
  const location = useLocation();
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { identifier: "", password: "", remember: true },
  });
  if (
    profile &&
    (master ? profile.role === "master" : profile.role !== "master")
  )
    return <Navigate to={homeFor(profile.role)} replace />;
  const submit = handleSubmit(async (values) => {
    setError("");
    try {
      const repository = await getRepository();
      const signedIn = await repository.auth.signIn({ ...values, master });
      queryClient.clear();
      useAuth.getState().setProfile(signedIn);
      const from = (location.state as { from?: unknown } | null)?.from;
      const home = homeFor(signedIn.role);
      navigate(
        typeof from === "string" &&
          (from === home || from.startsWith(`${home}/`))
          ? from
          : home,
        { replace: true },
      );
    } catch (reason) {
      setError(
        reason instanceof Error
          ? reason.message
          : "Unable to sign in. Please try again.",
      );
    }
  });
  const fillDemo = () => {
    setValue("identifier", `${demoRole}@greenwood.edu`, {
      shouldValidate: true,
    });
    setValue("password", "Campus@2026", { shouldValidate: true });
    setError("");
  };
  const sendReset = async () => {
    const result = z.string().email().safeParse(resetEmail);
    if (!result.success) {
      toast.error("Enter a valid school email address.");
      return;
    }
    setSending(true);
    try {
      await (await getRepository()).auth.resetPassword(result.data);
      toast.success("If this email is registered, a reset link is on its way.");
      setReset(false);
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Unable to send reset email.",
      );
    } finally {
      setSending(false);
    }
  };
  return (
    <main className="login-page">
      <div className="login-top">
        <a href="/" className="brand" aria-label="Campus home">
          <span className="brand-mark">
            <Icon name="graduation" size={27} />
          </span>
          <span>
            campus<span className="brand-dot">.</span>
          </span>
        </a>
        <div className="login-top-right">
          <span className="version-label">SCHOOL MANAGEMENT v3.0</span>
          <ThemeToggle />
        </div>
      </div>
      <div className="login-layout">
        <section className="login-story">
          <NeuBadge tone="accent">
            <Icon name="sparkles" size={14} /> A little less admin. A lot more
            possibility.
          </NeuBadge>
          <h1>
            Great schools.
            <br />
            Connected <span>communities.</span>
          </h1>
          <p>
            One thoughtful workspace for the people
            <br className="desktop-break" /> who make your school extraordinary.
          </p>
          <CampusIllustration />
          <div className="story-bottom">
            <div className="avatar-stack">
              <span>SW</span>
              <span>JW</span>
              <span>PS</span>
              <span>AM</span>
            </div>
            <div>
              <b>Built around your school community</b>
              <small>Every role. Every campus. One connected place.</small>
            </div>
          </div>
        </section>
        <section className="login-form-side">
          <motion.div
            className="login-card neu-card"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="icon-tile login-symbol">
              <Icon name={master ? "shield" : "graduation"} size={30} />
            </span>
            <div className="login-heading">
              <div className="eyebrow">
                {master ? "PLATFORM ADMINISTRATION" : "YOUR SCHOOL, CONNECTED"}
              </div>
              <h2>{master ? "Creator sign in" : "Welcome back"}</h2>
              <p>
                {master
                  ? "Secure access for platform administrators."
                  : "A good day at school starts here."}
              </p>
            </div>
            <motion.form
              onSubmit={submit}
              noValidate
              animate={error ? { x: [0, -4, 4, -3, 3, 0] } : { x: 0 }}
              transition={{ duration: 0.25 }}
            >
              <NeuInput
                label={config.mock ? "School email or code" : "School email"}
                id="identifier"
                icon="mail"
                placeholder={
                  config.mock ? "you@school.edu or GW-001" : "you@school.edu"
                }
                autoComplete="username"
                error={errors.identifier?.message}
                {...register("identifier")}
              />
              <div className="password-field">
                <NeuInput
                  label="Password"
                  id="password"
                  icon="lock"
                  type={visible ? "text" : "password"}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  error={errors.password?.message}
                  {...register("password")}
                />
                <NeuButton
                  type="button"
                  variant="ghost"
                  icon={visible ? "eye-off" : "eye"}
                  aria-label={visible ? "Hide password" : "Show password"}
                  onClick={() => setVisible(!visible)}
                />
              </div>
              <div className="login-options">
                <NeuCheckbox label="Remember me" {...register("remember")} />
                <button
                  type="button"
                  className="text-button"
                  onClick={() => setReset(true)}
                >
                  Forgot password?
                </button>
              </div>
              {error && (
                <div className="form-error" role="alert">
                  <Icon name="error" size={18} />
                  {error}
                </div>
              )}
              <NeuButton
                type="submit"
                variant="primary"
                className="login-submit"
                loading={isSubmitting}
              >
                Sign in to your workspace
                <Icon name="arrow-right" size={18} />
              </NeuButton>
            </motion.form>
            <div className="secure-note">
              <Icon name="shield" size={16} /> Secure access. Just for your
              school.
            </div>
            {config.mock && (
              <div className="demo-box">
                <div>
                  <NeuBadge>DEMO WORKSPACE</NeuBadge>
                  <span>Take a look around</span>
                </div>
                <div className="demo-controls">
                  <select
                    aria-label="Demo role"
                    value={demoRole}
                    onChange={(e) => setDemoRole(e.target.value as Role)}
                  >
                    {(master
                      ? (["master"] as const)
                      : ([
                          "owner",
                          "principal",
                          "teacher",
                          "parent",
                          "student",
                          "accountant",
                        ] as const)
                    ).map((role) => (
                      <option key={role} value={role}>
                        {roleLabels[role]}
                      </option>
                    ))}
                  </select>
                  <NeuButton type="button" variant="ghost" onClick={fillDemo}>
                    Use demo
                    <Icon name="arrow-up-right" size={16} />
                  </NeuButton>
                </div>
                <small>Demo password: Campus@2026</small>
              </div>
            )}
          </motion.div>
          <p className="login-help">
            Trouble signing in?{" "}
            <button
              className="text-button"
              onClick={() =>
                toast.info(
                  "Contact your school office to check your email, role, and campus assignment.",
                )
              }
            >
              Contact your school administrator
              <Icon name="arrow-up-right" size={13} />
            </button>
          </p>
        </section>
      </div>
      <footer className="login-footer">
        <span>
          Smart <i /> Secure <i /> Connected
        </span>
        <span>Made for better school days.</span>
        <span>© {new Date().getFullYear()} Campus</span>
      </footer>
      <NeuModal
        open={reset}
        onClose={() => setReset(false)}
        title="Let’s get you back in"
        description="Enter your school email and we’ll send you a secure password reset link."
        footer={
          <NeuButton
            variant="primary"
            loading={sending}
            onClick={() => void sendReset()}
          >
            Send reset link
            <Icon name="arrow-right" size={16} />
          </NeuButton>
        }
      >
        <NeuInput
          id="reset-email"
          label="School email"
          type="email"
          value={resetEmail}
          onChange={(e) => setResetEmail(e.target.value)}
          placeholder="you@school.edu"
        />
      </NeuModal>
    </main>
  );
}

````

## src/features/auth/ResetPassword.tsx

````tsx
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useNavigate } from "react-router-dom";
import {
  NeuButton,
  NeuCard,
  NeuInput,
  ThemeToggle,
} from "../../components/ui/primitives";
import { getRepository } from "../../services";
import { useAuth } from "../../store/auth";
const schema = z
  .object({
    password: z
      .string()
      .min(12, "Use at least 12 characters.")
      .regex(/[A-Z]/, "Include an uppercase letter.")
      .regex(/[0-9]/, "Include a number."),
    confirm: z.string(),
  })
  .refine((value) => value.password === value.confirm, {
    path: ["confirm"],
    message: "The passwords do not match.",
  });
export default function ResetPassword() {
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<z.infer<typeof schema>>({ resolver: zodResolver(schema) });
  return (
    <main className="full-screen">
      <NeuCard className="reset-card">
        <div className="section-heading">
          <h1>Set a new password</h1>
          <ThemeToggle />
        </div>
        <p>Open the secure link from your reset email first.</p>
        <form
          onSubmit={handleSubmit(async (values) => {
            try {
              const repository = await getRepository();
              await repository.auth.updatePassword(values.password);
              useAuth.getState().setProfile(null);
              await repository.auth.signOut();
              navigate("/login", { replace: true });
            } catch (reason) {
              setError(
                reason instanceof Error
                  ? reason.message
                  : "Unable to reset your password.",
              );
            }
          })}
        >
          <NeuInput
            label="New password"
            id="new-password"
            autoComplete="new-password"
            type="password"
            error={errors.password?.message}
            {...register("password")}
          />
          <NeuInput
            label="Confirm password"
            id="confirm-password"
            autoComplete="new-password"
            type="password"
            error={errors.confirm?.message}
            {...register("confirm")}
          />
          {error && (
            <p role="alert" className="field-error">
              {error}
            </p>
          )}
          <NeuButton type="submit" variant="primary" loading={isSubmitting}>
            Save password
          </NeuButton>
        </form>
      </NeuCard>
    </main>
  );
}

````

## src/features/system/ComponentLibrary.tsx

````tsx
import { useMemo, useState } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { toast } from "sonner";
import {
  NeuAvatar,
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuCheckbox,
  NeuInput,
  NeuProgress,
  NeuRadio,
  NeuSelect,
  NeuTabs,
  NeuToggle,
  SearchBar,
  DatePicker,
  StatCard,
  EmptyState,
  ErrorState,
  Skeleton,
  ThemeToggle,
} from "../../components/ui/primitives";
import {
  NeuModal,
  NeuDrawer,
  ConfirmDialog,
} from "../../components/ui/overlays";
import { NeuTable } from "../../components/ui/NeuTable";
import { FileUpload } from "../../components/ui/FileUpload";
import { Icon } from "../../components/ui/Icon";
type Sample = {
  id: string;
  name: string;
  email: string;
  role: string;
  status: string;
};
const initialRows: Sample[] = [
  {
    id: "1",
    name: "Sarah Williams",
    email: "sarah@greenwood.edu",
    role: "Principal",
    status: "Active",
  },
  {
    id: "2",
    name: "James Wilson",
    email: "james@greenwood.edu",
    role: "Teacher",
    status: "Active",
  },
  {
    id: "3",
    name: "Priya Sharma",
    email: "priya@greenwood.edu",
    role: "Parent",
    status: "Invited",
  },
];
const tabs = [
  { value: "controls", label: "Controls" },
  { value: "data", label: "Data & feedback" },
  { value: "overlays", label: "Overlays" },
] as const;
export default function ComponentLibrary() {
  const [tab, setTab] = useState<(typeof tabs)[number]["value"]>("controls");
  const [toggle, setToggle] = useState(true);
  const [checked, setChecked] = useState(true);
  const [radio, setRadio] = useState("daily");
  const [date, setDate] = useState("2026-10-31");
  const [search, setSearch] = useState("");
  const [overlay, setOverlay] = useState<"modal" | "drawer" | "confirm" | null>(
    null,
  );
  const [rows, setRows] = useState(initialRows);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(64);
  const columns = useMemo<ColumnDef<Sample, unknown>[]>(
    () => [
      {
        accessorKey: "name",
        header: "Name",
        cell: (info) => (
          <div className="table-person">
            <NeuAvatar name={String(info.getValue())} size="sm" />
            <span>
              <b>{String(info.getValue())}</b>
              <small>{info.row.original.email}</small>
            </span>
          </div>
        ),
      },
      { accessorKey: "role", header: "Role" },
      {
        accessorKey: "status",
        header: "Status",
        cell: (info) => (
          <NeuBadge tone={info.getValue() === "Active" ? "success" : "warning"}>
            {String(info.getValue())}
          </NeuBadge>
        ),
      },
    ],
    [],
  );
  const previewLoading = async () => {
    setLoading(true);
    await new Promise<void>((resolve) => setTimeout(resolve, 1000));
    setLoading(false);
    toast.success("All set. A little feedback goes a long way.");
  };
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">THE CAMPUS DESIGN LANGUAGE</div>
          <h1>Thoughtful by design</h1>
          <p>Soft surfaces. Clear interactions. One consistent experience.</p>
        </div>
        <ThemeToggle />
      </div>
      <div className="library-header">
        <NeuTabs
          tabs={tabs}
          value={tab}
          onChange={setTab}
          label="Component group"
        />
        <NeuBadge>Interactive component library</NeuBadge>
      </div>
      {tab === "controls" && (
        <div className="library-grid">
          <NeuCard>
            <div className="section-heading">
              <h2>Buttons</h2>
              <NeuBadge>01</NeuBadge>
            </div>
            <p className="muted">A clear action, with a reassuring press.</p>
            <div className="component-row">
              <NeuButton
                variant="primary"
                icon="plus"
                onClick={() => toast.success("Primary action selected")}
              >
                Primary action
              </NeuButton>
              <NeuButton
                onClick={() => toast.info("Secondary action selected")}
              >
                Secondary
              </NeuButton>
              <NeuButton
                variant="ghost"
                onClick={() => toast.info("Ghost action selected")}
              >
                Ghost action
              </NeuButton>
              <NeuButton
                variant="icon"
                icon="heart"
                aria-label="Like this design"
                onClick={() =>
                  toast.success("A little love for thoughtful design")
                }
              />
              <NeuButton disabled>Disabled</NeuButton>
              <NeuButton
                loading={loading}
                onClick={() => void previewLoading()}
              >
                Try loading
              </NeuButton>
            </div>
          </NeuCard>
          <NeuCard>
            <div className="section-heading">
              <h2>Inputs & selection</h2>
              <NeuBadge>02</NeuBadge>
            </div>
            <div className="component-form">
              <NeuInput
                label="School email"
                id="sample-email"
                type="email"
                placeholder="you@school.edu"
                icon="mail"
                hint="Use the email your school assigned you."
              />
              <NeuSelect label="Campus" id="sample-campus" defaultValue="north">
                <option value="north">North Campus</option>
                <option value="central">Central Campus</option>
              </NeuSelect>
              <DatePicker
                label="Selected date"
                value={date}
                onChange={setDate}
              />
              <NeuInput
                label="Validation feedback"
                id="sample-invalid"
                defaultValue="sarah@"
                error="Enter a complete email address."
              />
            </div>
          </NeuCard>
          <NeuCard>
            <div className="section-heading">
              <h2>Choices & toggles</h2>
              <NeuBadge>03</NeuBadge>
            </div>
            <NeuToggle
              checked={toggle}
              onChange={setToggle}
              label="School updates"
              description="A switch with a clear on and off state."
            />
            <div className="component-row">
              <NeuCheckbox
                label="Remember this device"
                checked={checked}
                onChange={(e) => setChecked(e.target.checked)}
              />
              <NeuRadio
                name="sample-frequency"
                label="Daily"
                checked={radio === "daily"}
                onChange={() => setRadio("daily")}
              />
              <NeuRadio
                name="sample-frequency"
                label="Weekly"
                checked={radio === "weekly"}
                onChange={() => setRadio("weekly")}
              />
            </div>
          </NeuCard>
          <NeuCard>
            <div className="section-heading">
              <h2>People & status</h2>
              <NeuBadge>04</NeuBadge>
            </div>
            <div className="component-row">
              <NeuAvatar name="Sarah Williams" size="lg" />
              <NeuAvatar name="James Wilson" />
              <NeuAvatar name="Priya Sharma" size="sm" />
            </div>
            <div className="component-row">
              <NeuBadge tone="success">Active</NeuBadge>
              <NeuBadge tone="warning">Pending</NeuBadge>
              <NeuBadge tone="accent">School admin</NeuBadge>
              <NeuBadge>Default</NeuBadge>
            </div>
            <NeuProgress value={progress} label="Your progress" />
            <NeuButton
              variant="ghost"
              onClick={() =>
                setProgress((v) => (v >= 100 ? 0 : Math.min(v + 12, 100)))
              }
            >
              Advance progress
              <Icon name="arrow-right" size={15} />
            </NeuButton>
          </NeuCard>
        </div>
      )}
      {tab === "data" && (
        <div className="library-data">
          <div className="stat-grid">
            <StatCard
              label="Sample records"
              value={rows.length}
              icon="users"
              detail="Component demonstration data"
            />
            <StatCard
              label="Workspace readiness"
              value={100}
              suffix="%"
              icon="shield"
              detail="Phase 1 foundation"
            />
          </div>
          <NeuCard>
            <div className="section-heading">
              <div>
                <h2>A clearer view of your data</h2>
                <p>
                  Sortable columns. Cards on mobile. Virtualized above 100 rows.
                </p>
              </div>
              <NeuButton
                variant="ghost"
                onClick={() =>
                  setRows(
                    rows.length > 100
                      ? initialRows
                      : Array.from({ length: 250 }, (_, i) => ({
                          ...initialRows[i % 3]!,
                          id: String(i),
                          name: `${initialRows[i % 3]!.name} ${i + 1}`,
                        })),
                  )
                }
              >
                {rows.length > 100 ? "Use 3 rows" : "Try 250 rows"}
              </NeuButton>
            </div>
            <SearchBar
              value={search}
              onChange={setSearch}
              placeholder="Search demo people…"
              label="Search sample records"
            />
            <NeuTable
              data={rows.filter((row) =>
                `${row.name} ${row.role}`
                  .toLowerCase()
                  .includes(search.toLowerCase()),
              )}
              columns={columns}
              label="Demo school community"
              rowKey={(row) => row.id}
              renderMobile={(row) => (
                <div className="mobile-person">
                  <NeuAvatar name={row.name} />
                  <span>
                    <b>{row.name}</b>
                    <small>{row.role}</small>
                  </span>
                  <NeuBadge tone="success">{row.status}</NeuBadge>
                </div>
              )}
            />
          </NeuCard>
          <div className="library-grid">
            <NeuCard>
              <h2>Loading gracefully</h2>
              <div className="skeleton-demo">
                <Skeleton className="line-skeleton" />
                <Skeleton className="card-skeleton" />
                <Skeleton className="line-skeleton short" />
              </div>
            </NeuCard>
            <NeuCard>
              <EmptyState
                title="A fresh start"
                description="New records will appear here when they’re added."
              />
            </NeuCard>
            <NeuCard>
              <ErrorState
                description="This is a sample recoverable error state."
                onRetry={() => toast.success("Retry action received")}
              />
            </NeuCard>
            <NeuCard>
              <h2>Files, made simple</h2>
              <p className="muted">
                Demo only: validates your file locally without storing it.
              </p>
              <FileUpload
                onUpload={async (file) => {
                  await new Promise<void>((resolve) =>
                    setTimeout(resolve, 400),
                  );
                  toast.success(
                    `${file.name} passed local validation. No file was stored.`,
                  );
                }}
              />
            </NeuCard>
          </div>
        </div>
      )}
      {tab === "overlays" && (
        <div className="library-grid">
          <NeuCard>
            <span className="icon-tile">
              <Icon name="layers" size={26} />
            </span>
            <h2>A focused conversation</h2>
            <p className="muted">
              A modal with focus trapping, Escape dismissal, and focus
              restoration.
            </p>
            <NeuButton onClick={() => setOverlay("modal")}>
              Open modal
            </NeuButton>
          </NeuCard>
          <NeuCard>
            <span className="icon-tile">
              <Icon name="menu" size={26} />
            </span>
            <h2>A little more space</h2>
            <p className="muted">
              A drawer that stays close to your current task.
            </p>
            <NeuButton onClick={() => setOverlay("drawer")}>
              Open drawer
            </NeuButton>
          </NeuCard>
          <NeuCard>
            <span className="icon-tile">
              <Icon name="shield" size={26} />
            </span>
            <h2>A considered decision</h2>
            <p className="muted">
              Type to confirm a destructive action. This demo removes no data.
            </p>
            <NeuButton onClick={() => setOverlay("confirm")}>
              Try confirmation
            </NeuButton>
          </NeuCard>
        </div>
      )}
      <NeuModal
        open={overlay === "modal"}
        onClose={() => setOverlay(null)}
        title="A little focus goes a long way"
        description="Everything you need, right where you are."
        footer={
          <NeuButton
            variant="primary"
            onClick={() => {
              setOverlay(null);
              toast.success("Changes confirmed");
            }}
          >
            Looks good
            <Icon name="check" size={16} />
          </NeuButton>
        }
      >
        <NeuInput
          label="A note for your school"
          id="modal-note"
          placeholder="What’s on your mind?"
        />
      </NeuModal>
      <NeuDrawer
        open={overlay === "drawer"}
        onClose={() => setOverlay(null)}
        title="Details, close at hand"
        description="A companion to your main workspace."
      >
        <NeuInput
          label="Quick note"
          id="drawer-note"
          placeholder="Add a thought…"
        />
        <NeuButton
          variant="primary"
          onClick={() => {
            setOverlay(null);
            toast.success("Note demo completed");
          }}
        >
          Done
        </NeuButton>
      </NeuDrawer>
      <ConfirmDialog
        open={overlay === "confirm"}
        onClose={() => setOverlay(null)}
        onConfirm={() => {
          setOverlay(null);
          toast.success("Confirmation matched. No records were removed.");
        }}
        title="Try a careful confirmation"
        description="This is a safe demonstration. Type the phrase below to confirm."
        confirmText="CONFIRM"
      />
    </>
  );
}

````

## src/features/system/Preferences.tsx

````tsx
import {
  NeuAvatar,
  NeuBadge,
  NeuCard,
  NeuRadio,
  NeuToggle,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { useUI, type ThemeChoice } from "../../store/ui";
import { useAuth } from "../../store/auth";
import { roleLabels } from "../../lib/permissions";
import { toast } from "sonner";
export default function Preferences() {
  const { theme, setTheme, emailUpdates, inAppUpdates, setPreference } =
    useUI();
  const profile = useAuth((s) => s.profile)!;
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">MAKE IT YOURS</div>
          <h1>A workspace that feels like you</h1>
          <p>A few thoughtful preferences for your everyday.</p>
        </div>
        <NeuBadge tone="success">
          <Icon name="check" size={13} />
          Saved automatically
        </NeuBadge>
      </div>
      <div className="preferences-grid">
        <NeuCard>
          <div className="section-heading">
            <h2>Your profile</h2>
            <Icon name="user" />
          </div>
          <div className="profile-summary">
            <NeuAvatar name={profile.name} size="lg" />
            <h3>{profile.name}</h3>
            <p>{profile.email}</p>
            <NeuBadge>{roleLabels[profile.role]}</NeuBadge>
          </div>
          <div className="info-note">
            <Icon name="lock" size={17} />
            <p>
              Your school manages your profile, role, and campus assignments.
              Contact your administrator to request a change.
            </p>
          </div>
        </NeuCard>
        <div className="preference-stack">
          <NeuCard>
            <div className="section-heading">
              <div>
                <h2>A familiar look</h2>
                <p>Choose the light that works for you.</p>
              </div>
              <Icon name="palette" />
            </div>
            <div className="theme-options">
              {(
                [
                  { value: "light", label: "Light", icon: "sun" },
                  { value: "dark", label: "Dark", icon: "moon" },
                  { value: "system", label: "Use system", icon: "monitor" },
                ] as const
              ).map((option) => (
                <div
                  className={`theme-option ${theme === option.value ? "selected" : ""}`}
                  key={option.value}
                >
                  <Icon name={option.icon} size={26} />
                  <NeuRadio
                    name="theme"
                    label={option.label}
                    checked={theme === option.value}
                    onChange={() => setTheme(option.value as ThemeChoice)}
                  />
                </div>
              ))}
            </div>
          </NeuCard>
          <NeuCard>
            <div className="section-heading">
              <div>
                <h2>Your notification preferences</h2>
                <p>Saved on this device for your next visit.</p>
              </div>
              <Icon name="bell" />
            </div>
            <NeuToggle
              checked={inAppUpdates}
              onChange={(value) => {
                setPreference("inAppUpdates", value);
                toast.success("Preference saved on this device");
              }}
              label="In-app notification highlights"
              description="Show unread highlights in your workspace."
            />
            <NeuToggle
              checked={emailUpdates}
              onChange={(value) => {
                setPreference("emailUpdates", value);
                toast.success("Preference saved on this device");
              }}
              label="Email update preference"
              description="Your preference is saved locally; email delivery settings arrive with system controls."
            />
          </NeuCard>
        </div>
      </div>
    </>
  );
}

````

## src/features/workspace/Directory.tsx

````tsx
import { useMemo, useState } from "react";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuTabs,
  SearchBar,
  EmptyState,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { Icon } from "../../components/ui/Icon";
import { workspaces } from "../../mocks/data";
import { hasPermission } from "../../lib/permissions";
import { useAuth } from "../../store/auth";
import { useDebounce } from "../../hooks/useDebounce";
import type { Workspace } from "../../types/domain";
const tabs = [
  { value: "All", label: "All tools" },
  { value: "Community", label: "Community" },
  { value: "Academics", label: "Academics" },
  { value: "Operations", label: "Operations" },
  { value: "System", label: "System" },
] as const;
export default function Directory() {
  const profile = useAuth((s) => s.profile)!;
  const [filter, setFilter] = useState<(typeof tabs)[number]["value"]>("All");
  const [search, setSearch] = useState("");
  const query = useDebounce(search);
  const [selected, setSelected] = useState<Workspace | null>(null);
  const filtered = useMemo(
    () =>
      workspaces.filter(
        (tool) =>
          (filter === "All" || filter === tool.category) &&
          `${tool.name} ${tool.description}`
            .toLowerCase()
            .includes(query.toLowerCase()),
      ),
    [filter, query],
  );
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">FIND YOUR WAY</div>
          <h1>Your workspace directory</h1>
          <p>A place for every part of your school day.</p>
        </div>
        <NeuBadge>Phase 1 foundation</NeuBadge>
      </div>
      <div className="directory-toolbar">
        <NeuTabs
          tabs={tabs}
          value={filter}
          onChange={setFilter}
          label="Module category"
        />
        <SearchBar
          value={search}
          onChange={setSearch}
          placeholder="Find a tool…"
          label="Search workspace tools"
        />
      </div>
      <p className="directory-note">
        <Icon name="help" size={17} />
        Modules are delivered in phases. Your role determines which tools you
        can access.
      </p>
      <div className="directory-grid">
        {filtered.map((tool) => {
          const allowed = hasPermission(profile.role, tool.permission);
          return (
            <NeuCard
              key={tool.id}
              className={`workspace-tool ${allowed ? "" : "restricted-tool"}`}
            >
              <div className="tool-top">
                <span className="icon-tile">
                  <Icon name={tool.icon} size={26} />
                </span>
                <NeuBadge tone={allowed ? "accent" : "neutral"}>
                  {allowed ? (
                    `Phase ${tool.phase}`
                  ) : (
                    <>
                      <Icon name="lock" size={12} />
                      Restricted
                    </>
                  )}
                </NeuBadge>
              </div>
              <small className="eyebrow">{tool.category}</small>
              <h3>{tool.name}</h3>
              <p>{tool.description}</p>
              <NeuButton variant="ghost" onClick={() => setSelected(tool)}>
                {allowed ? "View module details" : "View access details"}
                <Icon name={allowed ? "arrow-up-right" : "lock"} size={16} />
              </NeuButton>
            </NeuCard>
          );
        })}
      </div>
      {!filtered.length && (
        <EmptyState
          title="No tools found"
          description="Try a different category or search term."
          action={
            <NeuButton
              onClick={() => {
                setFilter("All");
                setSearch("");
              }}
            >
              Clear filters
            </NeuButton>
          }
        />
      )}
      <NeuModal
        open={!!selected}
        onClose={() => setSelected(null)}
        title={selected?.name ?? "Module details"}
        description={selected?.description}
      >
        {selected && (
          <div className="module-details">
            <NeuBadge tone="accent">Phase {selected.phase}</NeuBadge>
            <h3>
              {hasPermission(profile.role, selected.permission)
                ? "Included in your role"
                : "Your role doesn’t have access"}
            </h3>
            <p>
              {hasPermission(profile.role, selected.permission)
                ? `This module will be implemented in Phase ${selected.phase}. Its foundation and permission boundary are ready.`
                : "This area contains information outside your assigned responsibilities. Contact your school administrator if your role needs to change."}
            </p>
            <p className="muted">
              Permissions are enforced by the live database. The directory
              describes access without exposing protected records.
            </p>
          </div>
        )}
      </NeuModal>
    </>
  );
}

````

## src/features/workspace/Overview.tsx

````tsx
import { Link, useOutletContext } from "react-router-dom";
import { format } from "date-fns";
import { motion } from "framer-motion";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuProgress,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { CampusIllustration } from "../../components/layout/CampusIllustration";
import { useAuth } from "../../store/auth";
import { hasPermission, homeFor, roleLabels } from "../../lib/permissions";
import { workspaces } from "../../mocks/data";
import type { Branch } from "../../types/domain";
import { useState } from "react";
import { NeuModal } from "../../components/ui/overlays";
export default function Overview() {
  const profile = useAuth((s) => s.profile)!;
  const { activeBranch, branches } = useOutletContext<{
    activeBranch?: Branch;
    branches: Branch[];
  }>();
  const [introOpen, setIntroOpen] = useState(false);
  const base = homeFor(profile.role);
  const tools = workspaces
    .filter((item) => hasPermission(profile.role, item.permission))
    .slice(0, 4);
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">YOUR WORKSPACE, AT A GLANCE</div>
          <h1>
            Hello, {profile.name.split(" ")[0]}{" "}
            <span className="greeting-dot">✦</span>
          </h1>
          <p>Good things happen when your school comes together.</p>
        </div>
        <div className="date-chip">
          <Icon name="calendar" size={17} />
          {format(new Date(), "EEE, dd MMM yyyy")}
        </div>
      </div>
      <NeuCard className="welcome-hero">
        <div className="welcome-copy">
          <NeuBadge tone="accent">
            <span className="status-dot" /> YOUR CONNECTED CAMPUS
          </NeuBadge>
          <h2>
            A place for everyone.
            <br />
            <span>Everything in its place.</span>
          </h2>
          <p>
            Less time finding things. More time moving your school
            <br className="desktop-break" /> forward. Welcome to your new
            everyday.
          </p>
          <Link to={`${base}/directory`} className="neu-button primary">
            Explore your workspace
            <Icon name="arrow-right" size={18} />
          </Link>
        </div>
        <CampusIllustration compact />
        <span className="hero-edition">SCHOOL MANAGEMENT SYSTEM · v3.0</span>
      </NeuCard>
      <div className="workspace-summary">
        <div>
          <span className="icon-tile small">
            <Icon name="building" />
          </span>
          <span>
            <small>YOUR CAMPUS</small>
            <b>{activeBranch?.short_name ?? "Campus not assigned"}</b>
          </span>
          <NeuBadge>{branches.length} assigned</NeuBadge>
        </div>
        <div>
          <span className="icon-tile small">
            <Icon name="shield" />
          </span>
          <span>
            <small>YOUR ACCESS</small>
            <b>{roleLabels[profile.role]}</b>
          </span>
        </div>
        <div>
          <span className="icon-tile small">
            <Icon name="layers" />
          </span>
          <span>
            <small>YOUR FOUNDATION</small>
            <b>Personalized & connected</b>
          </span>
          <span className="status-dot" />
        </div>
      </div>
      <div className="overview-columns">
        <section className="tools-section">
          <div className="section-heading">
            <div>
              <h2>Around your workspace</h2>
              <p>The right tools, for the way you work.</p>
            </div>
            <Link to={`${base}/directory`} className="text-button">
              View all
              <Icon name="arrow-right" size={15} />
            </Link>
          </div>
          <div className="workspace-grid">
            {tools.map((tool, i) => (
              <motion.div
                key={tool.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04, duration: 0.2 }}
              >
                <NeuCard className="workspace-tool">
                  <div className="tool-top">
                    <span className="icon-tile">
                      <Icon name={tool.icon} size={24} />
                    </span>
                    <NeuBadge>Phase {tool.phase}</NeuBadge>
                  </div>
                  <h3>{tool.name}</h3>
                  <p>{tool.description}</p>
                  <Link className="tool-link" to={`${base}/directory`}>
                    See what’s inside
                    <Icon name="arrow-up-right" size={16} />
                  </Link>
                </NeuCard>
              </motion.div>
            ))}
            {tools.length === 0 && (
              <NeuCard className="workspace-tool">
                <span className="icon-tile">
                  <Icon name="shield" size={24} />
                </span>
                <h3>Platform administration</h3>
                <p>
                  Your platform foundation is ready. School management and
                  revenue tools arrive in Phase 2.
                </p>
                <NeuBadge>Phase 2</NeuBadge>
              </NeuCard>
            )}
          </div>
        </section>
        <aside className="overview-right">
          <NeuCard className="getting-started">
            <div className="section-heading">
              <span className="icon-tile small">
                <Icon name="sparkles" />
              </span>
              <NeuBadge tone="success">LET’S BEGIN</NeuBadge>
            </div>
            <h2>Make yourself at home</h2>
            <p>Small steps. A smoother school day.</p>
            <NeuProgress value={33} label="Your workspace journey" />
            <div className="onboarding-list">
              <div className="completed">
                <span>
                  <Icon name="check" size={15} />
                </span>
                <div>
                  <b>Sign in to your workspace</b>
                  <small>You’re right where you belong.</small>
                </div>
              </div>
              <Link to={`${base}/preferences`}>
                <span>2</span>
                <div>
                  <b>Make it feel like you</b>
                  <small>Set your theme & preferences.</small>
                </div>
                <Icon name="right" size={14} />
              </Link>
              <Link to={`${base}/directory`}>
                <span>3</span>
                <div>
                  <b>Get to know your tools</b>
                  <small>Find your way around.</small>
                </div>
                <Icon name="right" size={14} />
              </Link>
            </div>
            <NeuButton variant="ghost" onClick={() => setIntroOpen(true)}>
              A quick introduction
              <Icon name="arrow-right" size={16} />
            </NeuButton>
          </NeuCard>
          <div className="privacy-note">
            <span className="icon-tile small">
              <Icon name="shield" />
            </span>
            <div>
              <b>A little peace of mind</b>
              <p>
                Your workspace is tailored to your role. Your school’s data
                stays in the right hands.
              </p>
            </div>
          </div>
        </aside>
      </div>
      <div className="community-strip">
        <span className="icon-tile">
          <Icon name="heart" size={24} />
        </span>
        <div>
          <b>Behind every great school, there’s a connected community.</b>
          <p>You’re part of something that makes a difference, every day.</p>
        </div>
        <span>
          Let’s make it a good one. <Icon name="sparkles" size={18} />
        </span>
      </div>
      <NeuModal
        open={introOpen}
        onClose={() => setIntroOpen(false)}
        title="One workspace. Your whole school."
        description="Start with the essentials, then grow together."
      >
        <div className="intro-list">
          <p>
            <b>Smart.</b> Find tools from the directory or global search.
          </p>
          <p>
            <b>Secure.</b> Role permissions and campus assignments define your
            access.
          </p>
          <p>
            <b>Connected.</b> Stay up to date through your notification center.
          </p>
          <p className="muted">
            This is Phase 1. Each module in the directory shows the phase in
            which it will become available.
          </p>
        </div>
      </NeuModal>
    </>
  );
}

````

## src/features/workspace/StatusPage.tsx

````tsx
import { Link } from "react-router-dom";
import { Icon } from "../../components/ui/Icon";
import { useAuth } from "../../store/auth";
import { homeFor } from "../../lib/permissions";
export default function StatusPage({
  status,
}: {
  status: "401" | "403" | "404";
}) {
  const profile = useAuth((s) => s.profile);
  const content = {
    "401": [
      "Let’s get you signed in",
      "Sign in securely to access your school workspace.",
    ],
    "403": [
      "This space is restricted",
      "Your role or campus assignment doesn’t grant access to this workspace.",
    ],
    "404": [
      "A little off the timetable",
      "We couldn’t find this page. Your workspace is just a click away.",
    ],
  }[status];
  return (
    <div className="status-page">
      <span className="icon-tile">
        <Icon name={status === "404" ? "search" : "lock"} size={32} />
      </span>
      <span className="eyebrow">{status}</span>
      <h1>{content[0]}</h1>
      <p>{content[1]}</p>
      <Link
        className="neu-button primary"
        to={profile ? homeFor(profile.role) : "/login"}
      >
        <Icon name="arrow-left" size={18} />
        {profile ? "Back to my workspace" : "Go to sign in"}
      </Link>
    </div>
  );
}

````

## src/hooks/useDebounce.ts

````ts
import { useEffect, useState } from "react";
export function useDebounce<T>(value: T, delay = 300): T {
  const [result, setResult] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setResult(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return result;
}

````

## src/hooks/usePermission.tsx

````tsx
import type { ReactNode } from "react";
import { hasPermission, type Permission } from "../lib/permissions";
import { useAuth } from "../store/auth";
export function usePermission(permission: Permission) {
  return hasPermission(
    useAuth((s) => s.profile?.role),
    permission,
  );
}
export function Can({
  permission,
  children,
  fallback = null,
}: {
  permission: Permission;
  children: ReactNode;
  fallback?: ReactNode;
}) {
  return usePermission(permission) ? children : fallback;
}

````

## src/hooks/useTheme.ts

````ts
import { useEffect, useState } from "react";
import { useUI } from "../store/ui";
export function useTheme() {
  const choice = useUI((s) => s.theme);
  const [systemDark, setSystemDark] = useState(
    () => matchMedia("(prefers-color-scheme: dark)").matches,
  );
  useEffect(() => {
    const media = matchMedia("(prefers-color-scheme: dark)");
    const update = () => setSystemDark(media.matches);
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  const resolved =
    choice === "system" ? (systemDark ? "dark" : "light") : choice;
  useEffect(() => {
    document.documentElement.dataset.theme = resolved;
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", resolved === "dark" ? "#1B1E24" : "#E9EDF3");
  }, [resolved]);
  return resolved;
}

````

## src/lib/config.ts

````ts
export const config = {
  mock: import.meta.env.VITE_USE_MOCK !== "false",
  appUrl: import.meta.env.VITE_APP_URL || window.location.origin,
};

````

## src/lib/permissions.test.ts

````ts
import { describe, expect, it } from "vitest";
import { hasPermission, homeFor, rolePermissions } from "./permissions";
import { roles } from "../types/domain";
describe("role boundaries", () => {
  it("does not grant master access to owners or other school roles", () => {
    for (const role of roles.filter((r) => r !== "master"))
      expect(hasPermission(role, "master.manage")).toBe(false);
    expect(hasPermission("master", "master.manage")).toBe(true);
  });
  it("keeps financial and academic responsibilities separate", () => {
    expect(hasPermission("teacher", "finance.manage")).toBe(false);
    expect(hasPermission("accountant", "academics.read")).toBe(false);
    expect(hasPermission("principal", "system.manage")).toBe(false);
    expect(hasPermission("parent", "users.manage")).toBe(false);
  });
  it("fails closed for signed-out users", () => {
    for (const permission of rolePermissions.owner)
      expect(hasPermission(undefined, permission)).toBe(false);
  });
  it("redirects every role to its own workspace", () => {
    expect(homeFor("master")).toBe("/sys-master/workspace");
    for (const role of roles.filter((r) => r !== "master"))
      expect(homeFor(role)).toBe(`/${role}`);
  });
});

````

## src/lib/permissions.ts

````ts
import type { Role } from "../types/domain";
export const permissions = [
  "workspace.read",
  "users.manage",
  "branches.manage",
  "academics.read",
  "attendance.manage",
  "finance.manage",
  "child.read",
  "whatsapp.manage",
  "system.manage",
  "master.manage",
] as const;
export type Permission = (typeof permissions)[number];
export const roleLabels: Record<Role, string> = {
  owner: "Owner / Super Admin",
  principal: "Principal",
  teacher: "Teacher",
  parent: "Parent",
  student: "Student",
  accountant: "Office / Accountant",
  master: "SaaS Creator",
};
export const rolePermissions: Record<Role, readonly Permission[]> = {
  owner: permissions.filter((p) => p !== "master.manage"),
  principal: [
    "workspace.read",
    "users.manage",
    "academics.read",
    "attendance.manage",
  ],
  teacher: ["workspace.read", "academics.read", "attendance.manage"],
  parent: ["workspace.read", "child.read"],
  student: ["workspace.read", "child.read"],
  accountant: ["workspace.read", "finance.manage"],
  master: ["workspace.read", "master.manage"],
};
export function hasPermission(
  role: Role | undefined,
  permission: Permission,
): boolean {
  return role ? rolePermissions[role].includes(permission) : false;
}
export function homeFor(role: Role) {
  return role === "master" ? "/sys-master/workspace" : `/${role}`;
}
export const navigation = [
  {
    label: "Overview",
    path: "",
    icon: "grid",
    permission: "workspace.read",
    phase: 1,
    section: "Workspace",
  },
  {
    label: "Workspace directory",
    path: "/directory",
    icon: "layers",
    permission: "workspace.read",
    phase: 1,
    section: "Workspace",
  },
  {
    label: "People & access",
    path: "/people",
    icon: "users",
    permission: "users.manage",
    phase: 2,
    section: "Workspace",
  },
  {
    label: "Branches",
    path: "/branches",
    icon: "building",
    permission: "branches.manage",
    phase: 2,
    section: "Workspace",
  },
  {
    label: "Academics",
    path: "/academics",
    icon: "book",
    permission: "academics.read",
    phase: 3,
    section: "Management",
  },
  {
    label: "Attendance",
    path: "/attendance",
    icon: "calendar-check",
    permission: "attendance.manage",
    phase: 3,
    section: "Management",
  },
  {
    label: "My child",
    path: "/child",
    icon: "heart",
    permission: "child.read",
    phase: 4,
    section: "Management",
  },
  {
    label: "Finance",
    path: "/finance",
    icon: "wallet",
    permission: "finance.manage",
    phase: 2,
    section: "Management",
  },
  {
    label: "WhatsApp",
    path: "/whatsapp",
    icon: "message",
    permission: "whatsapp.manage",
    phase: 5,
    section: "Management",
  },
  {
    label: "Component library",
    path: "/components",
    icon: "palette",
    permission: "workspace.read",
    phase: 1,
    section: "System",
  },
  {
    label: "My preferences",
    path: "/preferences",
    icon: "settings",
    permission: "workspace.read",
    phase: 1,
    section: "System",
  },
] as const;

````

## src/lib/query.ts

````ts
import { QueryClient } from "@tanstack/react-query";
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60_000,
      gcTime: 300_000,
      retry: 1,
      refetchOnWindowFocus: false,
    },
    mutations: { retry: 0 },
  },
});
export const queryKeys = {
  branches: (user: string) => ["branches", user] as const,
  notifications: (user: string, branch: string) =>
    ["notifications", user, branch] as const,
};

````

## src/main.tsx

````tsx
import React from "react";
import ReactDOM from "react-dom/client";
import { RouterProvider } from "react-router-dom";
import { QueryClientProvider } from "@tanstack/react-query";
import { MotionConfig } from "framer-motion";
import { Toaster } from "sonner";
import "@fontsource/inter/latin-400.css";
import "@fontsource/inter/latin-500.css";
import "@fontsource/inter/latin-600.css";
import "@fontsource/inter/latin-700.css";
import "../src/styles/tokens.css";
import "../src/styles/global.css";
import { queryClient } from "./lib/query";
import { router } from "./app/router";
import { AuthProvider } from "./app/AuthProvider";
import { IconGradients } from "./components/ui/Icon";
function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <MotionConfig
        reducedMotion="user"
        transition={{ duration: 0.2, ease: [0.22, 0.61, 0.36, 1] }}
      >
        <IconGradients />
        <AuthProvider>
          <RouterProvider router={router} />
        </AuthProvider>
        <Toaster position="bottom-right" richColors closeButton />
      </MotionConfig>
    </QueryClientProvider>
  );
}
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);

````

## src/mocks/adapter.test.ts

````ts
// These tests exercise the adapter's isolation contract with a small Web Storage implementation.
import { beforeEach, describe, expect, it } from "vitest";
import { mockRepository } from "./adapter";
function memoryStorage(): Storage {
  const map = new Map<string, string>();
  return {
    get length() {
      return map.size;
    },
    clear: () => map.clear(),
    getItem: (key) => map.get(key) ?? null,
    key: (index) => [...map.keys()][index] ?? null,
    removeItem: (key) => {
      map.delete(key);
    },
    setItem: (key, value) => {
      map.set(key, value);
    },
  };
}
beforeEach(() => {
  globalThis.localStorage = memoryStorage();
  globalThis.sessionStorage = memoryStorage();
});
describe("mock repository security contract", () => {
  it("rejects incorrect credentials and master accounts on the normal login", async () => {
    await expect(
      mockRepository.auth.signIn({
        identifier: "owner@greenwood.edu",
        password: "wrong",
        remember: true,
      }),
    ).rejects.toThrow();
    await expect(
      mockRepository.auth.signIn({
        identifier: "master@greenwood.edu",
        password: "Campus@2026",
        remember: true,
      }),
    ).rejects.toThrow();
  });
  it("isolates an assigned teacher from other campuses", async () => {
    await mockRepository.auth.signIn({
      identifier: "teacher@greenwood.edu",
      password: "Campus@2026",
      remember: false,
    });
    expect((await mockRepository.branches.list()).map((b) => b.id)).toEqual([
      "north",
    ]);
    await expect(mockRepository.notifications.list("central")).rejects.toThrow(
      "access",
    );
    expect(localStorage.length).toBe(0);
  });
  it("does not expose one account’s notifications to another", async () => {
    await mockRepository.auth.signIn({
      identifier: "owner@greenwood.edu",
      password: "Campus@2026",
      remember: true,
    });
    const owner = await mockRepository.notifications.list("north");
    await mockRepository.auth.signIn({
      identifier: "parent@greenwood.edu",
      password: "Campus@2026",
      remember: false,
    });
    const parent = await mockRepository.notifications.list("north");
    expect(parent.every((n) => n.user_id === "demo-parent")).toBe(true);
    expect(parent.some((n) => n.id === owner[0]?.id)).toBe(false);
  });
  it("restores a remembered session and clears it on sign out", async () => {
    const signedIn = await mockRepository.auth.signIn({
      identifier: "GW-001",
      password: "Campus@2026",
      remember: true,
    });
    expect(await mockRepository.auth.getProfile()).toEqual(signedIn);
    await mockRepository.auth.signOut();
    expect(await mockRepository.auth.getProfile()).toBeNull();
  });
});

````

## src/mocks/adapter.ts

````ts
import { z } from "zod";
import type { Notification, Profile, Role } from "../types/domain";
import { roles } from "../types/domain";
import type { Repository } from "../services/contracts";
import { branches, demoProfile } from "./data";
const key = "campus-demo-session";
const profileSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string().email(),
  role: z.enum(roles),
  schoolId: z.string(),
  branchIds: z.array(z.string()),
});
const pause = () => new Promise<void>((resolve) => setTimeout(resolve, 280));
function readProfile(): Profile | null {
  try {
    const raw = localStorage.getItem(key) ?? sessionStorage.getItem(key);
    return raw ? profileSchema.parse(JSON.parse(raw)) : null;
  } catch {
    localStorage.removeItem(key);
    sessionStorage.removeItem(key);
    return null;
  }
}
const listeners = new Set<(profile: Profile | null) => void>();
const events = new Set<() => void>();
const notifications = new Map<string, Notification[]>();
function current() {
  const profile = readProfile();
  if (!profile) throw new Error("Please sign in to continue.");
  return profile;
}
export const mockRepository: Repository = {
  auth: {
    async getProfile() {
      await pause();
      return readProfile();
    },
    async signIn({ identifier, password, remember, master }) {
      await pause();
      const normalized = identifier.toLowerCase().trim();
      const role =
        normalized === "gw-001" ? "owner" : (normalized.split("@")[0] as Role);
      if (
        !roles.includes(role) ||
        (normalized !== "gw-001" && normalized !== `${role}@greenwood.edu`) ||
        password !== "Campus@2026" ||
        (master ? role !== "master" : role === "master")
      )
        throw new Error("The email, school code, or password is incorrect.");
      const profile = demoProfile(role);
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
      (remember ? localStorage : sessionStorage).setItem(
        key,
        JSON.stringify(profile),
      );
      listeners.forEach((fn) => fn(profile));
      return profile;
    },
    async signOut() {
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
      listeners.forEach((fn) => fn(null));
    },
    async resetPassword() {
      await pause();
      throw new Error(
        "Demo accounts use Campus@2026. Password emails are available in Supabase mode.",
      );
    },
    async updatePassword() {
      await pause();
      throw new Error("Demo passwords cannot be changed.");
    },
    onChange(callback) {
      listeners.add(callback);
      const sync = (event: StorageEvent) => {
        if (event.key === key) callback(readProfile());
      };
      window.addEventListener("storage", sync);
      return () => {
        listeners.delete(callback);
        window.removeEventListener("storage", sync);
      };
    },
  },
  branches: {
    async list() {
      await pause();
      const profile = current();
      return branches.filter((b) => profile.branchIds.includes(b.id));
    },
  },
  notifications: {
    async list(branchId) {
      await pause();
      const profile = current();
      if (!profile.branchIds.includes(branchId))
        throw new Error("You do not have access to this campus.");
      const scoped = `${profile.id}:${branchId}`;
      if (!notifications.has(scoped))
        notifications.set(scoped, [
          {
            id: `${scoped}-welcome`,
            user_id: profile.id,
            branch_id: branchId,
            title: "Your workspace is ready",
            body: "Explore your workspace, personalize your theme, and find everything in one place.",
            created_at: new Date().toISOString(),
            read: false,
          },
          {
            id: `${scoped}-access`,
            user_id: profile.id,
            branch_id: branchId,
            title: "Access tailored to your role",
            body: "Your assigned campuses and permissions keep school information in the right hands.",
            created_at: new Date(Date.now() - 3_600_000).toISOString(),
            read: false,
          },
        ]);
      return structuredClone(notifications.get(scoped) ?? []);
    },
    async markRead(id) {
      await pause();
      const profile = current();
      for (const list of notifications.values()) {
        const item = list.find((n) => n.id === id && n.user_id === profile.id);
        if (item) item.read = true;
      }
      events.forEach((fn) => fn());
    },
    subscribe(_branchId, callback) {
      events.add(callback);
      return () => {
        events.delete(callback);
      };
    },
  },
  storage: {
    async upload(file, branchId) {
      await pause();
      if (!current().branchIds.includes(branchId))
        throw new Error("Campus access denied.");
      return `demo://${branchId}/${encodeURIComponent(file.name)}`;
    },
  },
};

````

## src/mocks/data.ts

````ts
import type { Branch, Profile, Role, Workspace } from "../types/domain";
export const branches: Branch[] = [
  {
    id: "north",
    school_id: "greenwood",
    name: "Greenwood · North Campus",
    short_name: "North Campus",
    city: "Bengaluru",
  },
  {
    id: "central",
    school_id: "greenwood",
    name: "Greenwood · Central Campus",
    short_name: "Central Campus",
    city: "Bengaluru",
  },
  {
    id: "east",
    school_id: "greenwood",
    name: "Greenwood · East Campus",
    short_name: "East Campus",
    city: "Whitefield",
  },
];
const names: Record<Role, string> = {
  owner: "Alex Morgan",
  principal: "Sarah Williams",
  teacher: "James Wilson",
  parent: "Priya Sharma",
  student: "Aarav Sharma",
  accountant: "Olivia Davis",
  master: "Jordan Lee",
};
export function demoProfile(role: Role): Profile {
  return {
    id: `demo-${role}`,
    name: names[role],
    email: `${role}@greenwood.edu`,
    role,
    schoolId: "greenwood",
    branchIds:
      role === "owner" || role === "master"
        ? branches.map((b) => b.id)
        : ["north"],
  };
}
export const workspaces: Workspace[] = [
  {
    id: "people",
    name: "People & access",
    description: "A connected directory of students, families, and staff.",
    category: "Community",
    permission: "users.manage",
    phase: 2,
    icon: "users",
  },
  {
    id: "branches",
    name: "Branches & campuses",
    description: "Every campus, connected through one workspace.",
    category: "Operations",
    permission: "branches.manage",
    phase: 2,
    icon: "building",
  },
  {
    id: "academics",
    name: "Learning & academics",
    description: "Classes, subjects, timetables, and learning journeys.",
    category: "Academics",
    permission: "academics.read",
    phase: 3,
    icon: "book",
  },
  {
    id: "attendance",
    name: "Attendance",
    description: "Stay close to your school community, every day.",
    category: "Academics",
    permission: "attendance.manage",
    phase: 3,
    icon: "calendar-check",
  },
  {
    id: "finance",
    name: "Fees & finance",
    description: "Bring clarity to fees, expenses, and school accounts.",
    category: "Operations",
    permission: "finance.manage",
    phase: 2,
    icon: "wallet",
  },
  {
    id: "child",
    name: "My child’s journey",
    description: "Follow learning, attendance, and important milestones.",
    category: "Community",
    permission: "child.read",
    phase: 4,
    icon: "heart",
  },
  {
    id: "whatsapp",
    name: "Communication",
    description: "Keep families in the loop with thoughtful messaging.",
    category: "Community",
    permission: "whatsapp.manage",
    phase: 5,
    icon: "message",
  },
  {
    id: "system",
    name: "School settings",
    description: "Make your school’s workspace feel like your own.",
    category: "System",
    permission: "system.manage",
    phase: 5,
    icon: "settings",
  },
];

````

## src/services/contracts.ts

````ts
import type {
  Branch,
  Notification,
  Profile,
  SignInInput,
  Unsubscribe,
} from "../types/domain";
export interface Repository {
  auth: {
    getProfile(): Promise<Profile | null>;
    signIn(input: SignInInput): Promise<Profile>;
    signOut(): Promise<void>;
    resetPassword(email: string): Promise<void>;
    updatePassword(password: string): Promise<void>;
    onChange(callback: (profile: Profile | null) => void): Unsubscribe;
  };
  branches: { list(): Promise<Branch[]> };
  notifications: {
    list(branchId: string): Promise<Notification[]>;
    markRead(id: string): Promise<void>;
    subscribe(branchId: string, callback: () => void): Unsubscribe;
  };
  storage: { upload(file: File, branchId: string): Promise<string> };
}

````

## src/services/index.ts

````ts
import { config } from "../lib/config";
import type { Repository } from "./contracts";
let adapter: Promise<Repository> | undefined;
export function getRepository(): Promise<Repository> {
  adapter ??= config.mock
    ? import("../mocks/adapter").then((m) => m.mockRepository)
    : import("./supabase").then((m) => m.supabaseRepository);
  return adapter;
}

````

## src/services/supabase.ts

````ts
import { createClient } from "@supabase/supabase-js";
import type { Database } from "../types/database";
import { roles, type Profile } from "../types/domain";
import type { Repository } from "./contracts";
import { config } from "../lib/config";
const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  import.meta.env.VITE_SUPABASE_ANON_KEY) as string | undefined;
if (!url || !key)
  throw new Error(
    "Supabase is not configured. Set the URL and publishable key in .env.local, or enable VITE_USE_MOCK=true.",
  );
const storageKey = "campus.auth.remember";
// Session-only mode never writes access tokens to persistent storage.
const authStorage = {
  getItem: (name: string) =>
    localStorage.getItem(storageKey) === "true"
      ? localStorage.getItem(name)
      : sessionStorage.getItem(name),
  setItem: (name: string, value: string) => {
    (localStorage.getItem(storageKey) === "true"
      ? localStorage
      : sessionStorage
    ).setItem(name, value);
  },
  removeItem: (name: string) => {
    localStorage.removeItem(name);
    sessionStorage.removeItem(name);
  },
};
const client = createClient<Database>(url, key, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: authStorage,
  },
});
async function getProfile(): Promise<Profile | null> {
  const { data: sessionData, error: sessionError } =
    await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) return null;
  const {
    data: { user },
    error: userError,
  } = await client.auth.getUser();
  if (userError) throw userError;
  if (!user) return null;
  const { data, error } = await client
    .from("profiles")
    .select("id,school_id,name,email,role,branch_ids")
    .eq("id", user.id)
    .single();
  if (error) throw error;
  const role = roles.find((r) => r === data.role);
  // app_metadata is provisioned by a trusted administrator; user_metadata is never authorization input.
  if (!role || user.app_metadata.role !== role)
    throw new Error(
      "Your school access is not provisioned. Contact your school administrator.",
    );
  return {
    id: data.id,
    schoolId: data.school_id,
    name: data.name,
    email: data.email,
    role,
    branchIds: data.branch_ids,
  };
}
export const supabaseRepository: Repository = {
  auth: {
    getProfile,
    async signIn({ identifier, password, remember, master }) {
      if (!identifier.includes("@"))
        throw new Error(
          "Please use your school email address when signing in to the live service.",
        );
      localStorage.setItem(storageKey, String(remember));
      const { error } = await client.auth.signInWithPassword({
        email: identifier,
        password,
      });
      if (error) throw error;
      try {
        const profile = await getProfile();
        if (
          !profile ||
          (master ? profile.role !== "master" : profile.role === "master")
        )
          throw new Error("This account cannot access this sign-in page.");
        return profile;
      } catch (error) {
        await client.auth.signOut();
        throw error;
      }
    },
    async signOut() {
      const { error } = await client.auth.signOut();
      if (error) throw error;
    },
    async resetPassword(email) {
      const { error } = await client.auth.resetPasswordForEmail(email, {
        redirectTo: `${config.appUrl}/reset-password`,
      });
      if (error) throw error;
    },
    async updatePassword(password) {
      const { error } = await client.auth.updateUser({ password });
      if (error) throw error;
    },
    onChange(callback) {
      let active = true;
      const timers = new Set<ReturnType<typeof setTimeout>>();
      const {
        data: { subscription },
      } = client.auth.onAuthStateChange((event) => {
        if (event === "SIGNED_OUT") callback(null);
        if (event === "SIGNED_IN" || event === "USER_UPDATED") {
          // Keep Supabase calls outside the auth callback to avoid its session lock.
          const timer = setTimeout(() => {
            timers.delete(timer);
            void getProfile()
              .then((profile) => {
                if (active) callback(profile);
              })
              .catch(() => {
                if (active) callback(null);
              });
          }, 0);
          timers.add(timer);
        }
      });
      return () => {
        active = false;
        timers.forEach(clearTimeout);
        subscription.unsubscribe();
      };
    },
  },
  branches: {
    async list() {
      const { data, error } = await client
        .from("branches")
        .select("id,school_id,name,city,short_name")
        .order("name");
      if (error) throw error;
      return data;
    },
  },
  notifications: {
    async list(branchId) {
      const { data, error } = await client
        .from("notifications")
        .select("id,user_id,branch_id,title,body,created_at,read")
        .or(`branch_id.eq.${branchId},branch_id.is.null`)
        .order("created_at", { ascending: false })
        .range(0, 49);
      if (error) throw error;
      return data;
    },
    async markRead(id) {
      const { error } = await client
        .from("notifications")
        .update({ read: true })
        .eq("id", id);
      if (error) throw error;
    },
    subscribe(_branchId, callback) {
      const channel = client
        .channel("my-notifications")
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "notifications" },
          callback,
        )
        .subscribe();
      return () => {
        void client.removeChannel(channel);
      };
    },
  },
  storage: {
    async upload(file, branchId) {
      const profile = await getProfile();
      if (!profile) throw new Error("Sign in to upload files.");
      const path = `${profile.schoolId}/${branchId}/${profile.id}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error } = await client.storage
        .from("school-files")
        .upload(path, file, { upsert: false });
      if (error) throw error;
      return path;
    },
  },
};

````

## src/store/auth.ts

````ts
import { create } from "zustand";
import type { Profile } from "../types/domain";
type AuthState = {
  profile: Profile | null;
  initialized: boolean;
  expired: boolean;
  setProfile: (profile: Profile | null) => void;
  setExpired: (expired: boolean) => void;
};
export const useAuth = create<AuthState>((set) => ({
  profile: null,
  initialized: false,
  expired: false,
  setProfile: (profile) => set({ profile, initialized: true }),
  setExpired: (expired) => set({ expired }),
}));

````

## src/store/ui.ts

````ts
import { create } from "zustand";
import { persist } from "zustand/middleware";
export type ThemeChoice = "light" | "dark" | "system";
type UIState = {
  theme: ThemeChoice;
  branchId: string;
  collapsed: boolean;
  emailUpdates: boolean;
  inAppUpdates: boolean;
  setTheme: (theme: ThemeChoice) => void;
  setBranch: (branchId: string) => void;
  toggleSidebar: () => void;
  setPreference: (key: "emailUpdates" | "inAppUpdates", value: boolean) => void;
};
export const useUI = create<UIState>()(
  persist(
    (set) => ({
      theme: "system",
      branchId: "",
      collapsed: false,
      emailUpdates: true,
      inAppUpdates: true,
      setTheme: (theme) => set({ theme }),
      setBranch: (branchId) => set({ branchId }),
      toggleSidebar: () => set((s) => ({ collapsed: !s.collapsed })),
      setPreference: (key, value) => set({ [key]: value }),
    }),
    { name: "campus-ui-v3" },
  ),
);

````

## src/styles/global.css

````css
@tailwind base;
@tailwind components;
@tailwind utilities;

* {
  box-sizing: border-box;
}
body {
  margin: 0;
  background: var(--base);
  color: var(--text);
  font-size: 14px;
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
}
button,
input,
select,
textarea {
  font: inherit;
}
button,
a,
input,
select {
  touch-action: manipulation;
}
button {
  cursor: pointer;
  color: inherit;
}
button:disabled {
  cursor: not-allowed;
}
a {
  color: inherit;
  text-decoration: none;
}
button {
  border: 0;
}
h1,
h2,
h3,
p {
  margin: 0;
}
h1,
h2,
h3 {
  line-height: 1.3;
  font-weight: 600;
  letter-spacing: -0.04em;
}
h1 {
  font-size: clamp(25px, 3vw, 34px);
}
h2 {
  font-size: 19px;
}
h3 {
  font-size: 16px;
}
p {
  color: var(--muted);
}
small {
  font-size: 11px;
  color: var(--muted);
}
svg {
  flex-shrink: 0;
}
::selection {
  background: #a99bd666;
}
:focus-visible {
  outline: 2px solid var(--accent-text);
  outline-offset: 4px;
  border-radius: 8px;
  box-shadow: 0 0 0 4px var(--accent-soft);
}
input:focus-visible,
select:focus-visible {
  outline-offset: 2px;
}
button:disabled {
  opacity: 0.5;
}
.gradient-defs {
  position: absolute;
  pointer-events: none;
}
.muted {
  color: var(--muted);
}
.eyebrow {
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.14em;
  color: var(--muted);
}
.text-button {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: transparent;
  color: var(--accent-text);
  font-size: 12px;
  font-weight: 600;
  min-height: 44px;
  padding: 0;
}
.text-button:hover {
  text-decoration: underline;
}
.icon {
  vertical-align: middle;
}
.neu-card {
  background: var(--surface);
  border-radius: var(--radius);
  box-shadow: var(--raised-sm);
  padding: 24px;
  min-width: 0;
}
.neu-button {
  min-height: 44px;
  border: 1px solid transparent;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 10px 18px;
  border-radius: 12px;
  background: var(--base);
  box-shadow: var(--raised-sm);
  font-size: 12px;
  font-weight: 600;
  transition:
    transform 0.15s,
    opacity 0.15s;
  white-space: normal;
}
.neu-button:hover:not(:disabled) {
  transform: translateY(-1px);
}
.neu-button:active:not(:disabled) {
  box-shadow: var(--inset-pressed);
  transform: translateY(1px);
}
.neu-button.primary {
  background: var(--text);
  color: var(--base);
  box-shadow: var(--raised-sm);
}
.neu-button.icon {
  width: 44px;
  padding: 10px;
}
.neu-button.ghost {
  box-shadow: none;
  background: transparent;
  padding: 8px 12px;
}
.neu-button.danger {
  color: var(--danger);
  border-color: var(--danger);
}
.icon-tile {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  background: var(--base);
  box-shadow: var(--raised-sm);
  border-radius: 14px;
  flex-shrink: 0;
}
.icon-tile.small {
  width: 36px;
  height: 36px;
  border-radius: 11px;
  box-shadow: none;
  background: var(--accent-soft);
}
.badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  border: 1px solid var(--line);
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.01em;
  white-space: nowrap;
  color: var(--muted);
  line-height: 1.6;
}
.badge.accent {
  background: var(--accent-soft);
  color: var(--accent-text);
  border-color: transparent;
}
.badge.success {
  color: var(--success);
  background: var(--success-bg);
  border-color: transparent;
}
.badge.warning {
  color: var(--warning);
  background: var(--warning-bg);
  border-color: transparent;
}
.avatar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #d9e9f5, #ddd8ec);
  color: #455376;
  font-size: 12px;
  font-weight: 600;
  flex-shrink: 0;
}
.avatar.sm {
  width: 34px;
  height: 34px;
  font-size: 10px;
}
.avatar.lg {
  width: 64px;
  height: 64px;
  font-size: 21px;
}
.field {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
}
.field label {
  font-size: 12px;
  font-weight: 500;
}
.input-wrap {
  position: relative;
  display: flex;
  align-items: center;
}
.input-wrap > .icon {
  position: absolute;
  left: 15px;
  pointer-events: none;
}
.input-wrap input,
.select-wrap select {
  width: 100%;
  min-width: 0;
  min-height: 48px;
  background: var(--base);
  border: 1px solid var(--line);
  box-shadow: var(--inset-pressed);
  border-radius: 12px;
  padding: 12px 14px;
  color: var(--text);
  font-size: 12px;
}
.input-wrap > .icon + input {
  padding-left: 44px;
}
.input-wrap input::placeholder {
  color: var(--muted);
  opacity: 0.85;
}
.field-error {
  font-size: 11px;
  color: var(--danger);
}
.field-hint {
  font-size: 11px;
  color: var(--muted);
}
.select-wrap {
  position: relative;
}
.select-wrap select {
  appearance: none;
  padding-right: 34px;
}
.select-wrap > .icon {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
}
.choice {
  display: inline-flex;
  gap: 8px;
  align-items: center;
  min-height: 44px;
  font-size: 12px;
  cursor: pointer;
}
.choice input {
  width: 17px;
  height: 17px;
  accent-color: #667dad;
  cursor: pointer;
}
.toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  min-height: 64px;
  padding: 12px 0;
}
.toggle-row > span {
  display: flex;
  flex-direction: column;
}
.control-label {
  font-size: 13px;
  font-weight: 500;
}
.toggle {
  padding: 5px;
  width: 46px;
  min-width: 46px;
  height: 44px;
  border-radius: 22px;
  display: flex;
  align-items: center;
  background: transparent;
  position: relative;
}
.toggle::before {
  position: absolute;
  content: "";
  inset: 8px 0;
  border-radius: 18px;
  background: var(--base);
  box-shadow: var(--inset-pressed);
}
.toggle span {
  width: 20px;
  height: 20px;
  background: var(--muted);
  border-radius: 50%;
  position: relative;
}
.toggle.on {
  justify-content: flex-end;
}
.toggle.on::before {
  background: var(--gradient);
  box-shadow: none;
}
.toggle.on span {
  background: #f3f5f8;
}
.neu-tabs {
  display: inline-flex;
  gap: 4px;
  padding: 5px;
  box-shadow: var(--inset-pressed);
  border-radius: 12px;
  max-width: 100%;
  flex-wrap: wrap;
}
.neu-tabs button {
  min-height: 38px;
  padding: 8px 14px;
  border-radius: 8px;
  background: transparent;
  color: var(--muted);
  font-size: 12px;
  position: relative;
}
.neu-tabs button.active {
  background: var(--base);
  color: var(--text);
  box-shadow: var(--raised-sm);
}
.neu-tabs button.active::after {
  content: "";
  position: absolute;
  bottom: 3px;
  left: 35%;
  right: 35%;
  height: 2px;
  border-radius: 2px;
  background: var(--gradient);
}
.progress-block {
  padding: 16px 0;
}
.progress-label {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  font-size: 11px;
  color: var(--muted);
  margin-bottom: 10px;
}
.progress-label b {
  font-weight: 500;
}
.progress-track {
  height: 7px;
  overflow: hidden;
  border-radius: 6px;
  box-shadow: var(--inset-pressed);
}
.progress-track > div {
  height: 100%;
  width: 100%;
  background: var(--gradient);
  transform-origin: left;
  border-radius: 6px;
}
.search-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  border: 1px solid var(--line);
  box-shadow: var(--inset-pressed);
  border-radius: 12px;
  min-height: 44px;
  padding: 0 14px;
  min-width: 0;
}
.search-bar input {
  min-width: 0;
  width: 100%;
  background: transparent;
  border: 0;
  color: var(--text);
  font-size: 12px;
  padding: 12px 0;
}
.search-bar input:focus-visible {
  outline: 0;
  box-shadow: none;
}
.search-bar:focus-within {
  outline: 2px solid var(--accent-text);
  outline-offset: 2px;
}
.search-bar .neu-button {
  padding: 0;
  min-width: 28px;
  min-height: 32px;
}
.skeleton {
  background: var(--line);
  border-radius: 12px;
  position: relative;
  overflow: hidden;
}
.skeleton::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
    90deg,
    transparent,
    rgba(255, 255, 255, 0.17),
    transparent
  );
  transform: translateX(-100%);
  animation: shimmer 1.4s infinite;
}
.spin {
  animation: spin 0.8s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes shimmer {
  to {
    transform: translateX(100%);
  }
}
.empty-state {
  text-align: center;
  padding: 36px 20px;
  display: flex;
  align-items: center;
  flex-direction: column;
  gap: 12px;
}
.empty-state p {
  max-width: 340px;
  font-size: 13px;
}
.overlay {
  position: fixed;
  inset: 0;
  z-index: 100;
  background: rgba(13, 20, 32, 0.35);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}
.overlay-panel {
  background: var(--base);
  border: 1px solid var(--line);
  border-radius: 24px;
  width: 100%;
  max-width: 520px;
  max-height: 90dvh;
  display: flex;
  flex-direction: column;
  outline: none;
}
.overlay-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  padding: 28px 28px 16px;
}
.overlay-header h2 {
  font-size: 21px;
}
.overlay-header p {
  font-size: 12px;
  margin-top: 8px;
}
.overlay-content {
  padding: 8px 28px 28px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.overlay-footer {
  padding: 16px 28px 24px;
  border-top: 1px solid var(--line);
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}
.drawer-overlay {
  justify-content: flex-end;
  padding: 12px;
}
.drawer-panel {
  height: calc(100dvh - 24px);
  max-height: none;
  max-width: 420px;
}
.drawer-panel .overlay-content {
  flex: 1;
}
.file-upload {
  border: 1px dashed var(--line);
  border-radius: 16px;
  text-align: center;
  padding: 24px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  margin-top: 16px;
}
.file-upload.dragging {
  outline: 2px solid var(--accent-text);
}
.file-upload b {
  font-size: 12px;
}
.file-upload [role="status"] {
  font-size: 11px;
  color: var(--muted);
}
.table-scroll {
  margin-top: 20px;
  max-width: 100%;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.neu-table {
  width: 100%;
  table-layout: fixed;
  border-collapse: collapse;
  font-size: 12px;
}
.neu-table th {
  text-align: left;
  font-size: 10px;
  font-weight: 500;
  color: var(--muted);
  border-bottom: 1px solid var(--line);
  position: sticky;
  top: 0;
  background: var(--base);
  z-index: 1;
}
.neu-table th button {
  background: transparent;
  padding: 10px 4px;
  min-height: 44px;
  width: 100%;
  text-align: left;
  display: flex;
  gap: 12px;
  align-items: center;
}
.neu-table th:first-child {
  width: 52%;
}
.neu-table td {
  padding: 14px 4px;
  border-bottom: 1px solid var(--line);
  overflow-wrap: anywhere;
}
.table-person {
  display: flex;
  align-items: center;
  gap: 10px;
}
.table-person span:last-child {
  display: flex;
  flex-direction: column;
}
.table-person b {
  font-weight: 500;
}
.table-person small {
  font-size: 10px;
}
.mobile-table {
  display: none;
}
.stat-top {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  align-items: center;
  color: var(--muted);
  font-size: 12px;
}
.stat-card > strong {
  display: block;
  font-size: 32px;
  font-weight: 600;
  letter-spacing: -0.06em;
  margin: 10px 0;
}
.stat-card > small {
  display: block;
}
.brand {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  font-size: 28px;
  font-weight: 700;
  letter-spacing: -0.08em;
  line-height: 1;
}
.brand-dot {
  color: #8099c9;
}
.brand-mark {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  box-shadow: var(--raised-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.brand > span:last-child {
  padding-bottom: 4px;
}
.login-page {
  padding: 28px clamp(24px, 4vw, 72px) 0;
  min-height: 100dvh;
  display: flex;
  flex-direction: column;
  max-width: 1800px;
  margin: auto;
}
.login-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.login-top-right {
  display: flex;
  align-items: center;
  gap: 28px;
}
.version-label {
  color: var(--muted);
  font-size: 9px;
  letter-spacing: 0.14em;
  font-weight: 500;
}
.login-layout {
  display: grid;
  grid-template-columns: 1.1fr 1fr;
  gap: clamp(24px, 6vw, 100px);
  align-items: center;
  flex: 1;
  max-width: 1180px;
  width: 100%;
  margin: 48px auto;
}
.login-story > .badge {
  font-size: 10px;
  padding: 7px 10px;
  margin-bottom: 24px;
}
.login-story h1 {
  font-size: clamp(34px, 3.5vw, 53px);
  line-height: 1.18;
  font-weight: 600;
  letter-spacing: -0.06em;
}
.login-story h1 > span {
  color: var(--accent-text);
}
.login-story > p {
  margin-top: 20px;
  font-size: 14px;
  line-height: 1.9;
}
.login-form-side {
  max-width: 440px;
  width: 100%;
  justify-self: end;
}
.login-card {
  padding: 36px 36px 24px;
  box-shadow: var(--raised-md);
  border: 1px solid var(--white);
  border-radius: 26px;
}
.login-symbol {
  margin-bottom: 26px;
  width: 56px;
  height: 56px;
  border-radius: 18px;
}
.login-heading .eyebrow {
  font-size: 9px;
}
.login-heading h2 {
  font-size: 29px;
  margin: 8px 0 8px;
  letter-spacing: -0.05em;
}
.login-heading > p {
  font-size: 12px;
}
.login-card form {
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-top: 28px;
}
.password-field {
  position: relative;
}
.password-field > .neu-button {
  position: absolute;
  right: 5px;
  top: 29px;
  width: 42px;
  padding: 8px;
}
.password-field input {
  padding-right: 48px;
}
.login-options {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: -9px;
  gap: 8px;
}
.login-options .text-button {
  font-size: 11px;
}
.login-options .choice {
  font-size: 11px;
}
.login-submit {
  width: 100%;
  min-height: 48px;
  margin-top: -5px;
}
.login-submit > .icon {
  margin-left: auto;
}
.secure-note {
  display: flex;
  gap: 7px;
  justify-content: center;
  align-items: center;
  margin: 19px 0 22px;
  font-size: 10px;
  color: var(--muted);
}
.demo-box {
  border-top: 1px solid var(--line);
  padding-top: 20px;
}
.demo-box > div:first-child {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  align-items: center;
}
.demo-box > div:first-child > span:last-child {
  font-size: 10px;
  color: var(--muted);
}
.demo-box .badge {
  font-size: 8px;
  letter-spacing: 0.06em;
}
.demo-controls {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 8px;
}
.demo-controls select {
  min-width: 0;
  flex: 1;
  min-height: 44px;
  background: transparent;
  border: 0;
  color: var(--text);
  font-size: 12px;
  padding: 0;
}
.demo-controls .neu-button {
  padding: 8px 0;
  font-size: 11px;
}
.demo-box > small {
  font-size: 9px;
}
.login-help {
  text-align: center;
  font-size: 10px;
  margin: 20px -20px 0;
}
.login-help .text-button {
  font-size: 10px;
  min-height: 32px;
  font-weight: 500;
}
.login-footer {
  border-top: 1px solid var(--line);
  padding: 22px 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 10px;
  color: var(--muted);
}
.login-footer > span:first-child {
  display: flex;
  align-items: center;
  gap: 10px;
}
.login-footer i {
  width: 3px;
  height: 3px;
  background: #94a4c1;
  border-radius: 50%;
}
.story-bottom {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-top: 8px;
}
.story-bottom > div:last-child {
  display: flex;
  flex-direction: column;
}
.story-bottom b {
  font-size: 10px;
  font-weight: 500;
}
.story-bottom small {
  font-size: 9px;
  margin-top: 3px;
}
.avatar-stack {
  display: flex;
  padding-left: 6px;
}
.avatar-stack > span {
  margin-left: -6px;
  width: 29px;
  height: 29px;
  display: flex;
  justify-content: center;
  align-items: center;
  border: 2px solid var(--base);
  border-radius: 50%;
  font-size: 8px;
  font-weight: 600;
  background: #ccd9e9;
  color: #3e5576;
}
.avatar-stack > span:nth-child(2) {
  background: #d9d4e7;
}
.avatar-stack > span:nth-child(3) {
  background: #d5e2dd;
}
.avatar-stack > span:nth-child(4) {
  background: #e4d9cb;
}
.form-error {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: 11px;
  color: var(--danger);
  padding: 10px 12px;
  border-radius: 10px;
  border: 1px solid var(--danger);
}
.campus-illustration {
  height: 290px;
  position: relative;
  width: 100%;
  max-width: 500px;
  isolation: isolate;
  margin: 6px auto 0;
}
.orbit {
  position: absolute;
  border: 1px dashed var(--line);
  border-radius: 50%;
  width: 300px;
  height: 220px;
  left: 50%;
  top: 25px;
  transform: translateX(-50%) rotate(-16deg);
}
.orbit-two {
  width: 390px;
  height: 165px;
  top: 60px;
  transform: translateX(-50%) rotate(16deg);
  border-style: solid;
  border-color: var(--line);
  opacity: 0.6;
}
.campus-platform {
  position: absolute;
  width: 286px;
  height: 105px;
  border-radius: 50%;
  left: 50%;
  bottom: 32px;
  transform: translateX(-50%);
  background: var(--base);
  box-shadow: var(--raised-md);
}
.campus-building {
  width: 166px;
  height: 140px;
  position: absolute;
  bottom: 47px;
  left: 60px;
  background: var(--base);
  border: 1px solid var(--white);
  border-radius: 12px 12px 6px 6px;
  box-shadow: var(--raised-md);
}
.building-roof {
  height: 54px;
  position: absolute;
  top: -33px;
  left: 16px;
  right: 16px;
  background: var(--base);
  border-radius: 32px 32px 8px 8px;
  box-shadow: var(--raised-sm);
  display: flex;
  align-items: center;
  justify-content: center;
}
.building-clock {
  position: absolute;
  width: 17px;
  height: 17px;
  top: 34px;
  left: 74px;
  border: 2px solid #93a6c3;
  border-radius: 50%;
}
.building-clock::after {
  content: "";
  position: absolute;
  width: 4px;
  height: 5px;
  border-left: 1px solid #8196b6;
  border-bottom: 1px solid #8196b6;
  left: 6px;
  top: 3px;
}
.building-label {
  font-size: 6px;
  font-weight: 600;
  letter-spacing: 0.22em;
  position: absolute;
  top: 25px;
  width: 100%;
  text-align: center;
  color: var(--accent-text);
}
.building-windows {
  display: grid;
  grid-template-columns: repeat(3, 15px);
  gap: 13px 33px;
  position: absolute;
  top: 61px;
  left: 27px;
}
.building-windows i {
  height: 21px;
  background: linear-gradient(135deg, #b2d4e8, #c3bcde);
  border-radius: 4px;
  box-shadow: var(--inset-pressed);
}
.building-door {
  position: absolute;
  bottom: 0;
  left: 67px;
  width: 33px;
  height: 46px;
  background: var(--base);
  border-radius: 18px 18px 0 0;
  box-shadow: var(--inset-pressed);
}
.campus-path {
  position: absolute;
  width: 66px;
  height: 23px;
  border-radius: 50%;
  bottom: 7px;
  left: 110px;
  background: var(--base);
  box-shadow: var(--inset-pressed);
}
.campus-tree {
  position: absolute;
  bottom: 28px;
  width: 34px;
  height: 60px;
}
.campus-tree > i {
  position: absolute;
  width: 4px;
  height: 35px;
  left: 15px;
  bottom: 0;
  background: #a6b6b3;
  border-radius: 4px;
}
.campus-tree > span {
  position: absolute;
  width: 32px;
  height: 40px;
  top: 0;
  left: 1px;
  background: #cfded9;
  border-radius: 50% 50% 45% 45%;
  box-shadow: var(--raised-sm);
}
.tree-left {
  left: 15px;
}
.tree-right {
  right: 12px;
  transform: scale(0.85);
}
.floating-tile {
  position: absolute;
  width: 54px;
  height: 54px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: var(--raised-sm);
  background: var(--base);
  border-radius: 16px;
  z-index: 2;
}
.tile-book {
  left: 15%;
  top: 48px;
  transform: rotate(-10deg);
}
.tile-community {
  right: 9%;
  top: 16px;
  transform: rotate(10deg);
}
.tile-message {
  right: 7%;
  bottom: 62px;
  transform: rotate(-6deg);
  width: 46px;
  height: 46px;
}
.online-dot {
  position: absolute;
  width: 8px;
  height: 8px;
  top: 9px;
  right: 9px;
  background: #80ab9c;
  border: 2px solid var(--base);
  border-radius: 50%;
}
.illustration-caption {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 7px;
  white-space: nowrap;
  font-size: 9px;
  letter-spacing: 0.01em;
  color: var(--muted);
}
.status-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--success);
  display: inline-block;
  flex-shrink: 0;
}
[data-theme="dark"] .campus-tree > span {
  background: #334d45;
}
[data-theme="dark"] .building-windows i {
  background: linear-gradient(135deg, #405d70, #54506a);
}
.app-shell {
  min-height: 100dvh;
}
.sidebar {
  width: var(--sidebar);
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  padding: 30px 20px 16px;
  border-right: 1px solid var(--line);
  display: flex;
  flex-direction: column;
  z-index: 30;
  background: var(--base);
}
.sidebar > .brand {
  padding-left: 8px;
  margin-bottom: 32px;
}
.sidebar .brand {
  font-size: 27px;
}
.school-identity {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 12px 4px 22px;
  border-bottom: 1px solid var(--line);
  margin-bottom: 15px;
}
.school-monogram {
  width: 28px;
  height: 32px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--accent-soft);
  font-family: Georgia, serif;
  color: var(--accent-text);
  font-weight: bold;
}
.school-identity > div {
  flex: 1;
  min-width: 0;
}
.school-identity b {
  display: block;
  font-size: 10px;
  letter-spacing: -0.01em;
}
.school-identity small {
  font-size: 8px;
  display: block;
  margin-top: 2px;
}
.sidebar > nav {
  flex: 1;
  overflow-y: auto;
  scrollbar-width: none;
}
.nav-section {
  margin: 12px 0 18px;
}
.nav-section-label {
  font-size: 9px;
  letter-spacing: 0.12em;
  color: var(--muted);
  padding: 0 12px 9px;
}
.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  min-height: 44px;
  border-radius: 11px;
  font-size: 11px;
  color: var(--muted);
  margin: 4px 0;
  position: relative;
}
.nav-item > .icon:first-child {
  width: 18px;
  height: 18px;
}
.nav-item > span:nth-child(2) {
  flex: 1;
}
.nav-item.active {
  background: var(--base);
  box-shadow: var(--inset-pressed);
  color: var(--text);
  font-weight: 500;
}
.nav-item.active::before {
  position: absolute;
  content: "";
  left: 0;
  top: 13px;
  bottom: 13px;
  width: 3px;
  border-radius: 3px;
  background: var(--gradient);
}
.nav-active-dot {
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: #81a3d0;
  display: none;
}
.nav-item.active .nav-active-dot {
  display: block;
}
.nav-item.unavailable {
  color: var(--muted);
}
.nav-item.unavailable > .icon:first-child {
  opacity: 0.75;
}
.nav-item.unavailable > .icon:last-child {
  opacity: 0.65;
}
.sidebar-bottom {
  padding-top: 10px;
}
.help-card {
  padding: 16px 14px;
  border: 1px solid var(--line);
  border-radius: 14px;
}
.help-card .icon-tile {
  float: right;
  width: 28px;
  height: 28px;
}
.help-card b {
  font-size: 11px;
  font-weight: 500;
}
.help-card p {
  font-size: 10px;
  line-height: 1.8;
  margin-top: 5px;
}
.help-card .neu-button {
  font-size: 9px;
  padding: 8px 0;
  min-height: 36px;
  color: var(--accent-text);
  justify-content: space-between;
  width: 100%;
  margin-top: 8px;
}
.sidebar-account {
  display: flex;
  align-items: center;
  width: 100%;
  text-align: left;
  gap: 10px;
  background: transparent;
  border-top: 1px solid var(--line);
  margin-top: 20px;
  padding: 18px 0 0;
}
.sidebar-account > span:nth-child(2) {
  flex: 1;
  min-width: 0;
}
.sidebar-account b {
  font-size: 10px;
  font-weight: 500;
  display: block;
}
.sidebar-account small {
  font-size: 8px;
  display: block;
}
.sidebar-collapse {
  position: absolute;
  right: -15px;
  top: 84px;
  min-height: 28px !important;
  width: 28px !important;
  border-radius: 50%;
  padding: 5px !important;
  background: var(--base);
  border: 1px solid var(--line);
}
.sidebar-collapse .icon {
  width: 13px;
  height: 13px;
}
.app-main {
  margin-left: var(--sidebar);
  min-width: 0;
}
.top-header {
  height: 85px;
  padding: 0 36px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid var(--line);
  gap: 16px;
}
.header-branch,
.header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}
.header-branch .select-wrap select {
  background: transparent;
  box-shadow: none;
  border: 0;
  padding-left: 0;
  font-size: 12px;
  font-weight: 500;
  max-width: 200px;
}
.header-branch .badge {
  font-size: 8px;
  padding: 1px 5px;
}
.header-actions {
  gap: 14px;
}
.global-search-trigger {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 44px;
  background: transparent;
  color: var(--muted);
  font-size: 10px;
  min-width: 210px;
}
.global-search-trigger kbd {
  margin-left: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  border: 1px solid var(--line);
  border-radius: 5px;
  font-size: 14px;
}
.header-actions .neu-button {
  box-shadow: none;
  background: transparent;
}
.notification-trigger {
  position: relative;
}
.notification-trigger > span {
  position: absolute;
  right: 12px;
  top: 9px;
  border: 2px solid var(--base);
  background: #889fd1;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  pointer-events: none;
}
.header-divider {
  width: 1px;
  height: 26px;
  background: var(--line);
  margin: 0 3px;
}
.header-profile {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 44px;
  background: transparent;
}
.main-content {
  max-width: 1520px;
  margin: 0 auto;
  padding: 24px 36px 0;
  outline: none;
}
.breadcrumb {
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: var(--muted);
  font-size: 10px;
  margin-bottom: 30px;
  gap: 12px;
}
.breadcrumb > span {
  display: flex;
  align-items: center;
  gap: 10px;
}
.breadcrumb > .badge {
  font-size: 8px;
}
.page-heading {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  align-items: center;
  margin-bottom: 28px;
}
.page-heading .eyebrow {
  margin-bottom: 9px;
  font-size: 9px;
}
.page-heading p {
  font-size: 12px;
  margin-top: 9px;
}
.page-heading h1 {
  font-size: 29px;
}
.greeting-dot {
  font-size: 22px;
  color: #97aac8;
  padding-left: 5px;
}
.date-chip {
  display: flex;
  align-items: center;
  gap: 9px;
  white-space: nowrap;
  font-size: 10px;
  color: var(--muted);
  padding-top: 20px;
}
.welcome-hero {
  position: relative;
  padding: 32px 36px;
  display: flex;
  overflow: hidden;
  min-height: 270px;
  box-shadow: var(--raised-sm);
  border: 1px solid var(--white);
}
.welcome-copy {
  position: relative;
  z-index: 2;
}
.welcome-copy > .badge {
  font-size: 8px;
  letter-spacing: 0.09em;
  padding: 4px 8px;
}
.welcome-copy h2 {
  font-size: 32px;
  line-height: 1.3;
  margin-top: 16px;
  letter-spacing: -0.05em;
}
.welcome-copy h2 > span {
  color: var(--accent-text);
}
.welcome-copy p {
  font-size: 11px;
  line-height: 1.9;
  margin-top: 12px;
}
.welcome-copy > .neu-button {
  margin-top: 20px;
  font-size: 10px;
  min-height: 40px;
  padding: 9px 14px;
  gap: 22px;
}
.welcome-hero .campus-illustration {
  position: absolute;
  right: 10px;
  top: 0;
  width: 40%;
  height: 270px;
  margin: 0;
  max-width: 420px;
}
.welcome-hero .campus-platform {
  transform: translateX(-50%) scale(0.8);
  bottom: 28px;
}
.welcome-hero .orbit-one {
  width: 260px;
  height: 200px;
  top: 30px;
}
.welcome-hero .orbit-two {
  width: 330px;
  height: 150px;
  top: 50px;
}
.welcome-hero .tile-book {
  width: 42px;
  height: 42px;
  top: 70px;
  left: 10%;
}
.welcome-hero .tile-community {
  width: 42px;
  height: 42px;
  top: 30px;
  right: 16%;
}
.welcome-hero .tile-message {
  bottom: 62px;
  right: 9%;
  width: 36px;
  height: 36px;
}
.welcome-hero .floating-tile .icon {
  width: 23px;
  height: 23px;
}
.welcome-hero .illustration-caption {
  bottom: 20px;
  font-size: 8px;
}
.hero-edition {
  position: absolute;
  bottom: 10px;
  right: 20px;
  font-size: 6px;
  color: var(--muted);
  letter-spacing: 0.12em;
  opacity: 0.8;
}
.workspace-summary {
  display: grid;
  grid-template-columns: 1.1fr 1fr 1.1fr;
  margin: 26px 0 38px;
  padding: 14px 0;
  border-top: 1px solid var(--line);
  border-bottom: 1px solid var(--line);
}
.workspace-summary > div {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 0 16px;
  border-right: 1px solid var(--line);
  min-width: 0;
}
.workspace-summary > div:first-child {
  padding-left: 0;
}
.workspace-summary > div:last-child {
  border: 0;
  padding-right: 0;
}
.workspace-summary small {
  display: block;
  font-size: 7px;
  letter-spacing: 0.11em;
}
.workspace-summary b {
  display: block;
  font-size: 10px;
  font-weight: 500;
  line-height: 1.8;
}
.workspace-summary .badge {
  font-size: 7px;
  padding: 1px 4px;
}
.workspace-summary .icon-tile {
  width: 30px;
  height: 30px;
  background: transparent;
}
.workspace-summary .icon-tile .icon {
  width: 20px;
}
.workspace-summary .status-dot {
  margin-left: auto;
}
.overview-columns {
  display: grid;
  grid-template-columns: 1fr 310px;
  gap: 28px;
}
.section-heading {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  align-items: center;
  margin-bottom: 20px;
}
.section-heading h2 {
  font-size: 16px;
}
.section-heading p {
  font-size: 10px;
  margin-top: 6px;
}
.section-heading > .text-button {
  font-size: 10px;
  white-space: nowrap;
}
.workspace-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 20px;
}
.workspace-tool {
  padding: 22px;
  display: flex;
  flex-direction: column;
  height: 100%;
}
.tool-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  gap: 12px;
}
.tool-top .badge {
  font-size: 8px;
  padding: 2px 6px;
}
.workspace-tool h3 {
  font-size: 13px;
  margin-bottom: 8px;
}
.workspace-tool p {
  font-size: 10px;
  line-height: 1.8;
  flex: 1;
  margin-bottom: 16px;
}
.tool-link {
  font-size: 9px;
  color: var(--accent-text);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 36px;
}
.workspace-tool .icon-tile {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  box-shadow: none;
  background: var(--accent-soft);
}
.workspace-tool .neu-button {
  font-size: 10px;
  justify-content: space-between;
  padding: 8px 0;
}
.workspace-tool .eyebrow {
  margin-bottom: 12px;
  font-size: 7px;
}
.getting-started {
  padding: 24px;
}
.getting-started .section-heading {
  margin-bottom: 18px;
}
.getting-started h2 {
  font-size: 16px;
}
.getting-started > p {
  font-size: 10px;
  margin-top: 7px;
}
.getting-started > .neu-button {
  font-size: 10px;
  width: 100%;
  justify-content: space-between;
  color: var(--accent-text);
  border-top: 1px solid var(--line);
  border-radius: 0;
  margin-top: 14px;
  padding: 12px 0 0;
}
.getting-started .progress-label {
  font-size: 9px;
  margin-top: 8px;
}
.onboarding-list {
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding-top: 10px;
}
.onboarding-list > a,
.onboarding-list > div {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 44px;
}
.onboarding-list > a > span,
.onboarding-list > div > span {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 23px;
  height: 23px;
  box-shadow: var(--inset-pressed);
  border-radius: 50%;
  font-size: 9px;
  color: var(--muted);
  flex-shrink: 0;
}
.onboarding-list .completed > span {
  background: var(--accent-soft);
  box-shadow: none;
}
.onboarding-list b {
  font-size: 10px;
  font-weight: 500;
  display: block;
}
.onboarding-list small {
  font-size: 8px;
  display: block;
  margin-top: 3px;
}
.onboarding-list a > .icon {
  margin-left: auto;
}
.privacy-note {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 24px 12px;
}
.privacy-note .icon-tile {
  width: 28px;
  height: 28px;
  background: transparent;
}
.privacy-note b {
  font-size: 10px;
  font-weight: 500;
}
.privacy-note p {
  font-size: 9px;
  margin-top: 5px;
  line-height: 1.8;
}
.community-strip {
  display: flex;
  align-items: center;
  gap: 16px;
  border-top: 1px solid var(--line);
  margin-top: 34px;
  padding: 24px 0;
}
.community-strip > .icon-tile {
  box-shadow: none;
  background: var(--accent-soft);
  width: 40px;
  height: 40px;
}
.community-strip b {
  font-size: 10px;
  font-weight: 500;
}
.community-strip p {
  font-size: 9px;
  margin-top: 4px;
}
.community-strip > span:last-child {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-left: auto;
  font-size: 9px;
  color: var(--muted);
}
.workspace-footer {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  border-top: 1px solid var(--line);
  padding: 20px 0;
  font-size: 8px;
  color: var(--muted);
}
.workspace-footer > span {
  display: flex;
  align-items: center;
  gap: 8px;
}
.workspace-footer i {
  width: 3px;
  height: 3px;
  background: var(--muted);
  border-radius: 50%;
}
.bottom-nav {
  display: none;
}
.skip-link {
  position: fixed;
  top: -80px;
  left: 20px;
  z-index: 999;
  padding: 12px;
  background: var(--base);
}
.skip-link:focus {
  top: 20px;
}
.branch-skeleton {
  width: 140px;
  height: 26px;
}
.notification {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  padding: 20px 0;
  border-bottom: 1px solid var(--line);
}
.notification b {
  font-size: 13px;
  font-weight: 500;
}
.notification p {
  font-size: 12px;
  margin: 6px 0;
}
.notification small {
  font-size: 10px;
  display: block;
}
.notification .text-button {
  font-size: 10px;
}
.notification.read {
  opacity: 0.75;
}
.profile-summary {
  text-align: center;
  margin: 10px 0 28px;
}
.profile-summary h3 {
  margin-top: 12px;
}
.profile-summary p {
  font-size: 12px;
  margin: 6px 0 12px;
}
.profile-menu {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.profile-menu .neu-button {
  justify-content: flex-start;
}
.profile-menu .neu-button > .icon:last-child {
  margin-left: auto;
}
.search-results {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-top: 16px;
}
.search-results a {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  min-height: 48px;
  border-radius: 10px;
}
.search-results a:hover {
  box-shadow: var(--inset-pressed);
}
.search-results a > span {
  flex: 1;
}
.help-steps {
  margin: 0;
  padding-left: 20px;
}
.help-steps li {
  padding: 8px;
}
.help-steps b {
  font-size: 13px;
}
.help-steps p {
  font-size: 12px;
  margin-top: 6px;
}
.help-steps ~ p {
  font-size: 11px;
  margin-top: 20px;
}
.directory-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 20px;
}
.directory-toolbar > .search-bar {
  max-width: 240px;
  width: 100%;
}
.directory-note {
  font-size: 11px;
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 20px 0;
}
.directory-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 24px;
  margin-bottom: 40px;
}
.restricted-tool .icon-tile {
  background: transparent;
}
.module-details h3 {
  margin: 20px 0 12px;
}
.module-details p {
  font-size: 13px;
  margin: 12px 0;
}
.preferences-grid {
  display: grid;
  grid-template-columns: 320px 1fr;
  gap: 28px;
  margin: 36px 0 48px;
}
.preference-stack {
  display: flex;
  flex-direction: column;
  gap: 28px;
}
.info-note {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  border-top: 1px solid var(--line);
  padding-top: 20px;
}
.info-note p {
  font-size: 10px;
}
.theme-options {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 16px;
}
.theme-option {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  border: 1px solid var(--line);
  border-radius: 12px;
  padding: 20px 8px 6px;
}
.theme-option.selected {
  box-shadow: var(--inset-pressed);
  border-color: #8b9db9;
}
.theme-option .choice {
  font-size: 10px;
}
.preferences-grid .toggle-row + .toggle-row {
  border-top: 1px solid var(--line);
}
.library-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin: 30px 0;
}
.library-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 28px;
  margin-bottom: 40px;
}
.library-grid > .neu-card > .icon-tile {
  margin-bottom: 24px;
}
.library-grid > .neu-card > h2 {
  margin-bottom: 12px;
}
.library-grid > .neu-card > .muted {
  font-size: 12px;
  margin-bottom: 20px;
}
.component-row {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
  align-items: center;
  margin: 20px 0;
}
.component-form {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 20px;
}
.library-data {
  display: flex;
  flex-direction: column;
  gap: 28px;
}
.stat-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 28px;
}
.skeleton-demo {
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-top: 24px;
}
.line-skeleton {
  height: 16px;
}
.line-skeleton.short {
  width: 65%;
}
.title-skeleton {
  height: 30px;
  width: 50%;
  max-width: 330px;
}
.hero-skeleton {
  height: 270px;
  margin: 32px 0;
}
.card-skeleton {
  height: 180px;
}
.route-loading {
  padding: 40px;
  max-width: 1400px;
  margin: auto;
}
.loading-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 24px;
}
.status-page,
.full-screen {
  min-height: 75dvh;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 20px;
  padding: 32px;
  text-align: center;
}
.status-page p {
  max-width: 430px;
}
.status-page h1 {
  font-size: 30px;
}
.reset-card {
  max-width: 480px;
  width: 100%;
  text-align: left;
}
.reset-card form {
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-top: 24px;
}
.reset-card h1 {
  font-size: 23px;
}
.reset-card p {
  font-size: 12px;
}
.intro-list p {
  margin: 16px 0;
  font-size: 13px;
}
.inline-error {
  padding: 12px 16px;
  border: 1px solid var(--danger);
  border-radius: 12px;
  font-size: 12px;
  margin-bottom: 20px;
}
.sidebar-collapsed {
  --sidebar: 84px;
}
.sidebar-collapsed .sidebar {
  padding-left: 16px;
  padding-right: 16px;
}
.sidebar-collapsed .sidebar > .brand {
  padding-left: 4px;
}
.sidebar-collapsed .brand > span:last-child,
.sidebar-collapsed .school-identity,
.sidebar-collapsed .nav-section-label,
.sidebar-collapsed .nav-item > span,
.sidebar-collapsed .nav-item > .icon:last-child:not(:first-child),
.sidebar-collapsed .help-card,
.sidebar-collapsed .sidebar-account > span:last-of-type,
.sidebar-collapsed .sidebar-account > .icon {
  display: none;
}
.sidebar-collapsed .sidebar > .brand {
  margin-bottom: 30px;
}
.sidebar-collapsed .nav-item {
  justify-content: center;
  padding: 10px;
}
.sidebar-collapsed .sidebar-account {
  justify-content: center;
}
.drawer-nav .nav-section-label {
  margin-top: 20px;
}
@media (min-width: 1600px) {
  .overview-columns {
    grid-template-columns: 1fr 340px;
  }
  .workspace-tool p {
    font-size: 12px;
  }
  .workspace-tool h3 {
    font-size: 15px;
  }
  .getting-started h2 {
    font-size: 19px;
  }
  .welcome-hero {
    min-height: 300px;
  }
  .welcome-hero .campus-illustration {
    height: 290px;
  }
  .welcome-copy h2 {
    font-size: 36px;
  }
  .main-content {
    padding-left: 48px;
    padding-right: 48px;
  }
  .page-heading h1 {
    font-size: 33px;
  }
}
@media (max-width: 1200px) {
  .overview-columns {
    grid-template-columns: 1fr 280px;
    gap: 20px;
  }
  .main-content {
    padding-left: 24px;
    padding-right: 24px;
  }
  .top-header {
    padding: 0 24px;
  }
  .global-search-trigger {
    min-width: 44px;
    justify-content: center;
  }
  .global-search-trigger span,
  .global-search-trigger kbd {
    display: none;
  }
  .header-actions {
    gap: 6px;
  }
  .workspace-summary {
    grid-template-columns: 1fr 1fr;
  }
  .workspace-summary > div:last-child {
    display: none;
  }
  .workspace-summary > div:nth-child(2) {
    border: 0;
  }
  .workspace-summary .badge {
    display: none;
  }
  .workspace-tool {
    padding: 18px;
  }
  .getting-started {
    padding: 20px;
  }
  .community-strip > span:last-child {
    display: none;
  }
  .directory-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .directory-toolbar {
    align-items: flex-start;
  }
  .directory-toolbar .neu-tabs {
    flex: 1;
  }
  .preferences-grid {
    grid-template-columns: 260px 1fr;
    gap: 20px;
  }
  .theme-options {
    gap: 8px;
  }
  .component-form {
    grid-template-columns: 1fr;
  }
  .welcome-hero {
    padding: 28px;
  }
  .welcome-copy h2 {
    font-size: 28px;
  }
  .welcome-hero .campus-illustration {
    right: -22px;
    width: 43%;
  }
  .welcome-copy p {
    max-width: 310px;
  }
  .welcome-copy .desktop-break {
    display: none;
  }
}
@media (min-width: 640px) and (max-width: 1024px) {
  .app-shell {
    --sidebar: 80px;
  }
  .sidebar {
    padding: 25px 14px 16px;
  }
  .sidebar > .brand {
    padding-left: 3px;
    margin-bottom: 30px;
  }
  .sidebar .brand > span:last-child,
  .sidebar .school-identity,
  .sidebar .nav-section-label,
  .sidebar .nav-item > span,
  .sidebar .nav-item > .icon:last-child:not(:first-child),
  .sidebar .help-card,
  .sidebar .sidebar-account > span:last-of-type,
  .sidebar .sidebar-account > .icon,
  .sidebar-collapse {
    display: none;
  }
  .sidebar .nav-item {
    justify-content: center;
    padding: 10px;
  }
  .sidebar .sidebar-account {
    justify-content: center;
  }
  .sidebar .nav-section {
    margin-bottom: 24px;
  }
  .nav-item {
    min-height: 48px;
  }
  .overview-columns {
    grid-template-columns: 1fr 260px;
  }
  .page-heading h1 {
    font-size: 25px;
  }
  .workspace-tool p {
    font-size: 10px;
  }
  .workspace-grid {
    gap: 14px;
  }
  .getting-started {
    padding: 18px;
  }
  .workspace-tool h3 {
    font-size: 12px;
  }
  .workspace-tool {
    padding: 16px;
  }
  .overview-columns {
    gap: 20px;
  }
  .privacy-note {
    padding: 20px 0;
  }
  .welcome-copy h2 {
    font-size: 28px;
  }
  .welcome-copy p {
    max-width: 260px;
  }
  .welcome-hero .campus-illustration {
    right: -5%;
    width: 45%;
  }
  .login-story h1 {
    font-size: 37px;
  }
  .login-layout {
    gap: 36px;
  }
  .login-card {
    padding: 28px;
  }
  .login-story .badge {
    font-size: 8px;
  }
  .campus-illustration {
    max-width: 380px;
  }
  .orbit-two {
    width: 310px;
  }
  .login-layout .campus-illustration {
    transform: scale(0.9);
  }
  .story-bottom {
    gap: 8px;
  }
  .story-bottom b {
    font-size: 9px;
  }
  .story-bottom small {
    font-size: 8px;
  }
  .date-chip {
    font-size: 9px;
  }
  .preferences-grid {
    grid-template-columns: 1fr;
  }
  .preferences-grid > .neu-card .profile-summary {
    margin: 10px 0 20px;
  }
  .library-grid {
    gap: 20px;
  }
  .directory-toolbar {
    flex-direction: column;
  }
  .directory-toolbar > .search-bar {
    max-width: 100%;
  }
}
@media (min-width: 640px) and (max-width: 850px) {
  .overview-columns {
    grid-template-columns: 1fr;
  }
  .overview-right {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
  }
  .privacy-note {
    padding: 20px 12px;
  }
  .login-story {
    display: none;
  }
  .login-layout {
    grid-template-columns: 1fr;
    margin: 48px auto;
    max-width: 440px;
  }
  .login-form-side {
    justify-self: center;
  }
  .welcome-hero .campus-illustration {
    right: -5%;
    width: 48%;
    opacity: 0.8;
  }
  .welcome-copy h2 {
    font-size: 26px;
  }
  .welcome-copy p {
    max-width: 240px;
  }
}
@media (max-width: 639px) {
  .login-page {
    padding: 22px 22px 0;
  }
  .version-label {
    display: none;
  }
  .login-story {
    display: none;
  }
  .login-layout {
    display: block;
    margin: 40px auto 24px;
    max-width: 420px;
  }
  .login-form-side {
    max-width: 100%;
  }
  .login-card {
    padding: 28px 24px 22px;
    border-radius: 24px;
  }
  .login-heading h2 {
    font-size: 28px;
  }
  .login-symbol {
    margin-bottom: 24px;
  }
  .login-top .brand {
    font-size: 26px;
  }
  .login-help {
    margin-left: 0;
    margin-right: 0;
    line-height: 1.8;
  }
  .login-footer {
    font-size: 8px;
    flex-wrap: wrap;
    gap: 12px;
    justify-content: center;
    margin-top: auto;
    padding: 20px 0;
  }
  .login-footer > span:nth-child(2) {
    display: none;
  }
  .login-footer > span:last-child {
    margin-left: auto;
  }
  .login-options {
    gap: 4px;
  }
  .login-options .choice,
  .login-options .text-button {
    font-size: 10px;
  }
  .neu-button {
    font-size: 11px;
  }
  .overlay {
    align-items: flex-end;
    padding: 0;
  }
  .overlay-panel {
    border-radius: 24px 24px 0 0;
    max-height: 94dvh;
    padding-bottom: env(safe-area-inset-bottom);
  }
  .overlay-header {
    padding: 24px 22px 16px;
  }
  .overlay-header h2 {
    font-size: 20px;
  }
  .overlay-content {
    padding: 8px 22px 28px;
  }
  .overlay-footer {
    padding: 16px 22px 24px;
  }
  .drawer-panel {
    height: 94dvh;
  }
  .drawer-overlay {
    padding: 0;
  }
  .sidebar {
    display: none;
  }
  .app-main {
    margin-left: 0;
  }
  .top-header {
    height: 76px;
    padding: 0 16px;
    gap: 8px;
  }
  .header-branch {
    gap: 6px;
    flex: 1;
  }
  .header-branch > .icon-tile {
    width: 28px;
    height: 28px;
    background: transparent;
  }
  .header-branch .select-wrap select {
    font-size: 11px;
    max-width: 150px;
  }
  .header-branch > .badge {
    display: none;
  }
  .header-actions {
    gap: 0;
  }
  .header-actions .neu-button {
    width: 40px;
    min-height: 44px;
    padding: 10px;
  }
  .header-actions .header-divider,
  .header-profile {
    display: none;
  }
  .global-search-trigger {
    min-width: 36px;
    padding: 5px;
  }
  .main-content {
    padding: 20px 20px calc(80px + env(safe-area-inset-bottom));
  }
  .breadcrumb {
    margin-bottom: 25px;
    font-size: 9px;
  }
  .breadcrumb > .badge {
    font-size: 7px;
    max-width: 50%;
    white-space: normal;
  }
  .page-heading {
    margin-bottom: 24px;
    gap: 12px;
    align-items: flex-start;
  }
  .page-heading .eyebrow {
    font-size: 8px;
  }
  .page-heading h1 {
    font-size: 26px;
  }
  .page-heading p {
    font-size: 11px;
    line-height: 1.9;
  }
  .date-chip {
    display: none;
  }
  .welcome-hero {
    min-height: 340px;
    padding: 24px;
  }
  .welcome-copy h2 {
    font-size: 27px;
  }
  .welcome-copy p {
    max-width: 215px;
    font-size: 10px;
    margin-top: 12px;
  }
  .welcome-copy .neu-button {
    margin-top: 18px;
    font-size: 10px;
    gap: 16px;
  }
  .welcome-hero .campus-illustration {
    right: -60px;
    top: 125px;
    width: 220px;
    height: 220px;
    opacity: 0.65;
    pointer-events: none;
    z-index: 0;
  }
  .welcome-hero .campus-platform {
    transform: translateX(-50%) scale(0.58);
    bottom: 13px;
  }
  .welcome-hero .orbit {
    display: none;
  }
  .welcome-hero .tile-book {
    top: 85px;
    left: 9px;
    width: 32px;
    height: 32px;
  }
  .welcome-hero .tile-community {
    top: 58px;
    right: 35px;
    width: 32px;
    height: 32px;
  }
  .welcome-hero .tile-message {
    display: none;
  }
  .welcome-hero .illustration-caption {
    display: none;
  }
  .hero-edition {
    font-size: 5px;
    left: 24px;
    bottom: 15px;
    right: auto;
  }
  .welcome-copy > .badge {
    font-size: 6px;
  }
  .workspace-summary {
    grid-template-columns: 1fr 1fr;
    margin: 22px 0 30px;
    padding: 14px 0;
    gap: 8px;
  }
  .workspace-summary > div {
    padding: 0 6px;
    gap: 6px;
  }
  .workspace-summary > div:last-child {
    display: none;
  }
  .workspace-summary > div:nth-child(2) {
    border: 0;
  }
  .workspace-summary b {
    font-size: 9px;
  }
  .workspace-summary small {
    font-size: 6px;
  }
  .workspace-summary .icon-tile {
    width: 24px;
    height: 24px;
  }
  .workspace-summary .icon-tile > .icon {
    width: 17px;
  }
  .overview-columns {
    grid-template-columns: 1fr;
    gap: 30px;
  }
  .workspace-grid {
    gap: 16px;
  }
  .workspace-tool {
    padding: 18px;
  }
  .workspace-tool h3 {
    font-size: 12px;
  }
  .workspace-tool p {
    font-size: 10px;
    line-height: 1.8;
  }
  .tool-top {
    margin-bottom: 18px;
  }
  .tool-top .badge {
    font-size: 7px;
  }
  .workspace-tool .icon-tile {
    width: 35px;
    height: 35px;
  }
  .tool-link {
    font-size: 8px;
    min-height: 44px;
  }
  .section-heading h2 {
    font-size: 16px;
  }
  .section-heading p {
    font-size: 10px;
  }
  .getting-started {
    padding: 24px;
  }
  .getting-started h2 {
    font-size: 19px;
  }
  .onboarding-list b {
    font-size: 12px;
  }
  .onboarding-list small {
    font-size: 10px;
  }
  .getting-started > p {
    font-size: 12px;
  }
  .getting-started .progress-label {
    font-size: 11px;
  }
  .onboarding-list {
    gap: 14px;
  }
  .privacy-note {
    padding: 28px 8px 0;
  }
  .privacy-note b {
    font-size: 11px;
  }
  .privacy-note p {
    font-size: 10px;
  }
  .community-strip {
    margin-top: 28px;
    align-items: flex-start;
    padding: 24px 0;
  }
  .community-strip b {
    font-size: 10px;
  }
  .community-strip p {
    font-size: 9px;
  }
  .workspace-footer {
    font-size: 7px;
    flex-wrap: wrap;
  }
  .workspace-footer > span:last-child {
    display: none;
  }
  .bottom-nav {
    display: flex;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: calc(68px + env(safe-area-inset-bottom));
    padding: 5px 8px calc(5px + env(safe-area-inset-bottom));
    background: var(--base);
    border-top: 1px solid var(--line);
    z-index: 40;
    align-items: center;
    justify-content: space-around;
  }
  .bottom-nav > a,
  .bottom-nav > button {
    display: flex;
    flex-direction: column;
    gap: 3px;
    align-items: center;
    justify-content: center;
    background: transparent;
    min-width: 52px;
    min-height: 50px;
    color: var(--muted);
    font-size: 9px;
    border-radius: 12px;
    position: relative;
  }
  .bottom-nav > a.active {
    box-shadow: var(--inset-pressed);
    color: var(--text);
  }
  .bottom-nav > a.active::before {
    content: "";
    position: absolute;
    top: 4px;
    height: 2px;
    width: 14px;
    border-radius: 2px;
    background: var(--gradient);
  }
  .bottom-nav .icon {
    width: 19px;
    height: 19px;
  }
  .directory-toolbar {
    flex-direction: column;
    align-items: stretch;
  }
  .directory-toolbar .neu-tabs {
    width: 100%;
    justify-content: flex-start;
  }
  .directory-toolbar .neu-tabs button {
    font-size: 10px;
    padding: 8px 10px;
  }
  .directory-toolbar > .search-bar {
    max-width: none;
  }
  .directory-grid {
    grid-template-columns: 1fr;
    gap: 20px;
  }
  .directory-grid .workspace-tool h3 {
    font-size: 15px;
  }
  .directory-grid .workspace-tool p {
    font-size: 12px;
  }
  .directory-note {
    font-size: 10px;
    align-items: flex-start;
  }
  .directory-grid .workspace-tool {
    padding: 24px;
  }
  .preferences-grid {
    grid-template-columns: 1fr;
    gap: 24px;
  }
  .theme-options {
    gap: 8px;
  }
  .theme-option .choice {
    font-size: 9px;
    gap: 5px;
  }
  .theme-option .choice input {
    width: 14px;
    height: 14px;
  }
  .library-grid {
    grid-template-columns: 1fr;
    gap: 24px;
  }
  .library-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 18px;
  }
  .library-header .neu-tabs button {
    font-size: 10px;
    padding: 8px 12px;
  }
  .component-form {
    grid-template-columns: 1fr;
  }
  .library-data > .neu-card {
    padding: 20px;
  }
  .stat-grid {
    gap: 16px;
  }
  .stat-card {
    padding: 20px;
  }
  .stat-top {
    font-size: 10px;
  }
  .stat-top .icon-tile {
    display: none;
  }
  .stat-card > strong {
    font-size: 28px;
  }
  .stat-card small {
    font-size: 9px;
  }
  .mobile-table {
    display: block;
  }
  .neu-table {
    display: none;
  }
  .mobile-table article {
    padding: 16px 0;
    border-bottom: 1px solid var(--line);
    min-height: 64px;
  }
  .mobile-person {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .mobile-person > span:nth-child(2) {
    flex: 1;
    min-width: 0;
  }
  .mobile-person b {
    font-size: 11px;
    font-weight: 500;
    display: block;
  }
  .mobile-person small {
    display: block;
    font-size: 9px;
  }
  .mobile-person .badge {
    font-size: 8px;
  }
  .route-loading {
    padding: 24px;
  }
  .loading-grid {
    grid-template-columns: 1fr;
  }
  .control-label {
    font-size: 12px;
  }
  .toggle-row small {
    font-size: 10px;
  }
  .full-screen {
    padding: 24px;
  }
  .status-page h1 {
    font-size: 26px;
  }
}
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation: none !important;
    transition: none !important;
    scroll-behavior: auto !important;
  }
  .skeleton::after {
    display: none;
  }
}
.neu-tabs button.active::after {
  display: none;
}
.neu-tabs button > span {
  position: relative;
}
.neu-tabs button > .tab-indicator {
  position: absolute;
  inset: 3px;
  border-bottom: 2px solid #8ca5d3;
  border-radius: 7px;
  pointer-events: none;
}
@media (max-width: 639px) {
  .mobile-table article {
    height: 73px;
    min-height: 73px;
    padding: 16px 0;
  }
  .mobile-person b {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
}
@media (max-width: 639px) {
  .workspace-grid {
    grid-template-columns: 1fr;
  }
  .workspace-grid .workspace-tool {
    padding: 24px;
  }
  .workspace-grid .workspace-tool h3 {
    font-size: 15px;
  }
  .workspace-grid .workspace-tool p {
    font-size: 12px;
  }
  .workspace-grid .tool-link {
    font-size: 11px;
  }
  .workspace-grid .workspace-tool .icon-tile {
    width: 40px;
    height: 40px;
  }
}
.mobile-account-actions {
  display: flex;
  align-items: center;
  gap: 14px;
  margin: 28px 0 16px;
  padding-top: 24px;
  border-top: 1px solid var(--line);
}
.mobile-account-actions b,
.mobile-account-actions small {
  display: block;
}
.mobile-account-actions b {
  font-size: 12px;
  font-weight: 500;
}

````

## src/styles/tokens.css

````css
:root {
  color-scheme: light;
  --base: #e9edf3;
  --surface: #e9edf3;
  --text: #14181f;
  --muted: #5b6577;
  --subtle: #6a7485;
  --sky: #4db8ff;
  --purple: #a99bd6;
  --accent-text: #42618f;
  --accent-soft: #dfe8f3;
  --line: rgba(84, 103, 132, 0.16);
  --white: rgba(255, 255, 255, 0.9);
  --shadow: rgba(163, 177, 198, 0.5);
  --raised-sm: 3px 3px 6px var(--shadow), -3px -3px 6px var(--white);
  --raised-md: 5px 5px 12px var(--shadow), -5px -5px 12px var(--white);
  --inset-pressed:
    inset 3px 3px 6px var(--shadow), inset -3px -3px 6px var(--white);
  --gradient: linear-gradient(135deg, #4db8ff, #a99bd6);
  --success: #2d6959;
  --success-bg: #dcece6;
  --warning: #7e5d24;
  --warning-bg: #ede5d4;
  --danger: #a23446;
  --radius: 20px;
  --sidebar: 244px;
  font-family: Inter, ui-sans-serif, system-ui, sans-serif;
}
[data-theme="dark"] {
  color-scheme: dark;
  --base: #1b1e24;
  --surface: #1b1e24;
  --text: #f2f4f8;
  --muted: #9aa3b2;
  --subtle: #9aa3b2;
  --accent-text: #acbeea;
  --accent-soft: #242f40;
  --line: rgba(164, 179, 202, 0.17);
  --white: rgba(255, 255, 255, 0.04);
  --shadow: rgba(0, 0, 0, 0.5);
  --success: #9cd0ba;
  --success-bg: #263c35;
  --warning: #d8be88;
  --warning-bg: #3b3426;
  --danger: #f59aaa;
}

````

## src/types/database.ts

````ts
// Schema contract for database/phase1.sql, using the Supabase generator's shape.
// Regenerate from the connected database before releasing live schema changes.
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];
export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          school_id: string;
          name: string;
          email: string;
          role: string;
          branch_ids: string[];
        };
        Insert: {
          id: string;
          school_id: string;
          name: string;
          email: string;
          role: string;
          branch_ids: string[];
        };
        Update: { name?: string };
        Relationships: [];
      };
      branches: {
        Row: {
          id: string;
          school_id: string;
          name: string;
          city: string;
          short_name: string;
        };
        Insert: {
          id?: string;
          school_id: string;
          name: string;
          city: string;
          short_name: string;
        };
        Update: { name?: string; city?: string; short_name?: string };
        Relationships: [];
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          branch_id: string | null;
          title: string;
          body: string;
          created_at: string;
          read: boolean;
        };
        Insert: {
          id?: string;
          user_id: string;
          branch_id?: string | null;
          title: string;
          body: string;
          created_at?: string;
          read?: boolean;
        };
        Update: { read?: boolean };
        Relationships: [];
      };
    };
    Views: { [_ in never]: never };
    Functions: { [_ in never]: never };
    Enums: { [_ in never]: never };
    CompositeTypes: { [_ in never]: never };
  };
};

````

## src/types/domain.ts

````ts
export const roles = [
  "owner",
  "principal",
  "teacher",
  "parent",
  "student",
  "accountant",
  "master",
] as const;
export type Role = (typeof roles)[number];
export type Profile = {
  id: string;
  name: string;
  email: string;
  role: Role;
  schoolId: string;
  branchIds: string[];
};
export type Branch = {
  id: string;
  school_id: string;
  name: string;
  city: string;
  short_name: string;
};
export type Notification = {
  id: string;
  user_id: string;
  branch_id: string | null;
  title: string;
  body: string;
  created_at: string;
  read: boolean;
};
export type Workspace = {
  id: string;
  name: string;
  description: string;
  category: "Community" | "Academics" | "Operations" | "System";
  permission: import("../lib/permissions").Permission;
  phase: number;
  icon: import("../components/ui/Icon").IconName;
};
export type SignInInput = {
  identifier: string;
  password: string;
  remember: boolean;
  master?: boolean;
};
export type Unsubscribe = () => void;

````

## tailwind.config.ts

````ts
import type { Config } from "tailwindcss";
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: ["class", '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        base: "var(--base)",
        ink: "var(--text)",
        muted: "var(--muted)",
        accent: "var(--sky)",
      },
      borderRadius: { neu: "20px" },
      boxShadow: {
        "raised-sm": "var(--raised-sm)",
        "raised-md": "var(--raised-md)",
        "inset-pressed": "var(--inset-pressed)",
      },
    },
  },
  plugins: [],
} satisfies Config;

````

## tsconfig.json

````json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "noUncheckedIndexedAccess": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "types": ["vite/client"]
  },
  "include": [
    "src",
    "vite.config.ts",
    "tailwind.config.ts",
    "postcss.config.ts"
  ]
}

````

## vite.config.ts

````ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  build: { target: "es2022", sourcemap: false, manifest: true },
});

````
