# School Management System v3.0 - Comprehensive Test Plan

## Overview & Scope
- **Target Project**: Supabase project `oqsvedpkqgajjrnxbehz` (https://oqsvedpkqgajjrnxbehz.supabase.co)
- **Local Application**: Vite Dev Server (127.0.0.1:5173) and Vite Preview (127.0.0.1:4173)
- **QA Isolation**: Dedicated QA Tenant ("QA Test School", `is_qa = true`) across 2 branches.
- **Safety**: Third-party APIs (WhatsApp Cloud API, payment gateways, email providers) are sandboxed/mocked.

---

## 1. Inventory Summary

### 1.1 Routes by Role
| Role | Base Path | Core Routes & Modules |
| :--- | :--- | :--- |
| **Public / Unauthenticated** | `/` | `/login`, `/sys-master/login`, `/reset-password`, `/401`, `/403`, `/404` |
| **Master** | `/sys-master/workspace` | `overview`, `schools`, `create-school`, `revenue`, `plans`, `roles`, `monitoring`, `audit`, `settings`, `security` |
| **Owner** | `/owner` | `index (Dashboard)`, `people`, `branches`, `finance`, `roles`, `settings`, `security`, `templates`, `audit`, `monitoring`, `view-as`, `directory`, `components`, `preferences`, `whatsapp`, `academics`, workflow modules |
| **Principal** | `/principal` | `index (SchoolHome)`, `directory`, `components`, `preferences`, `academics`, `classes`, `timetable`, `attendance`, `admissions`, `leaves`, `meetings`, `announcements`, `reports` |
| **Teacher** | `/teacher` | `index (SchoolHome)`, `directory`, `components`, `preferences`, `academics`, `classes`, `timetable`, `attendance`, `homework`, `marks`, `leaves`, `messages`, `study-material` |
| **Parent** | `/parent` | `index (SchoolHome)`, `directory`, `components`, `preferences`, `attendance`, `homework`, `marks`, `fees`, `calendar`, `notices`, `messages` |
| **Student** | `/student` | `index (SchoolHome)`, `directory`, `components`, `preferences`, `attendance`, `homework`, `marks`, `timetable`, `calendar`, `notices` |
| **Accountant** | `/accountant` | `index (SchoolHome)`, `directory`, `components`, `preferences`, `fees`, `invoices`, `payments`, `expenses`, `payroll`, `reconciliation`, `certificates`, `reports` |

### 1.2 Edge Functions (15 Endpoints)
1. `apply-role-template` (Master only)
2. `create-payment-order` (Parent / Accountant)
3. `create-school` (Master only)
4. `export-data` (Owner / Master / Accountant)
5. `health` (Public probe)
6. `import-csv` (Owner / Principal / Accountant)
7. `manage-user` (Master / Owner / Principal)
8. `payment-webhook` (Gateway Webhook with HMAC signature)
9. `provision-school` (Master only)
10. `record-school-payment` (Master only)
11. `school-admin` (Master only)
12. `school-whatsapp` (Owner only)
13. `set-role-permissions` (Owner / Master)
14. `whatsapp-send-worker` (Background / Webhook worker)
15. `whatsapp-webhook` (Meta Webhook with HMAC signature)

### 1.3 Database Remote Procedure Calls (RPCs)
1. `admin_summary(p_scope: jsonb)`
2. `admin_list(p_resource: text, p_scope: jsonb, p_options: jsonb)`
3. `admin_save(p_resource: text, p_record: jsonb)`
4. `admin_delete(p_resource: text, p_id: text, p_scope: jsonb, p_version: int)`
5. `workflow_context(p_branch: uuid)`
6. `workflow_list(p_module: text, p_scope: jsonb)`
7. `workflow_save(p_record: jsonb)`
8. `workflow_remove(p_id: uuid, p_version: int)`
9. `workflow_delivery(p_provider_id: text, p_status: text)`
10. `attendance_mark_bulk(p_class_id: uuid, p_branch_id: uuid, p_date: date, p_records: jsonb)`
11. `marks_upsert_bulk(p_exam_id: uuid, p_class_id: uuid, p_subject_id: uuid, p_branch_id: uuid, p_marks: jsonb)`
12. `fee_collect_payment(p_student_fee_id: uuid, p_amount: numeric, p_method: text, p_notes: text)`
13. `search_global(p_query: text)`
14. `get_realtime_monitoring(p_school_id: uuid)`

### 1.4 Database Tables (47 Tables)
`academic_years`, `admin_records`, `admissions`, `announcements`, `assignments`, `attendance_records`, `audit_logs`, `branches`, `certificates`, `class_students`, `classes`, `exams`, `expenses`, `export_jobs`, `fee_payments`, `fee_structures`, `grades`, `homework_submissions`, `idempotency_keys`, `import_jobs`, `leaves`, `lesson_plans`, `meetings`, `notifications`, `offline_payments`, `parent_students`, `payment_orders`, `payroll_records`, `plans`, `profiles`, `rate_limits`, `reconciliations`, `roles`, `school_classes`, `school_memberships`, `school_students`, `school_workflows`, `schools`, `security_alerts`, `student_fees`, `subjects`, `subscriptions`, `system_metrics`, `timetable_entries`, `user_consents`, `user_role_overrides`, `vendors`, `whatsapp_templates`, `workflow_modules`.

### 1.5 Storage & Realtime
- Storage Bucket: `school-files` (Private, authenticated tenant RLS)
- Realtime Topic: `school:{school_id}:monitoring`

---

## 2. Master Test Matrix

| Test ID | Area / Subject | Role Scope | Planned Test Type | Expected Behavior / Security Assertion |
| :--- | :--- | :--- | :--- | :--- |
| **SEC-01** | Static Analysis & Lint | System | Static (`tsc`, `eslint`) | 0 TypeScript errors, 0 ESLint warnings, strict mode. |
| **SEC-02** | Supply Chain Audit | System | Dependency Audit (`npm audit`) | 0 high/critical vulnerabilities, versions pinned. |
| **SEC-03** | Secret Scan (Tree + Git) | System | Secret Scanning (`gitleaks`, custom) | 0 credentials in code, history, config, or dist/. |
| **SEC-04** | Bundle & Asset Inspection | System | Bundle Analysis (`check-bundle.ts`) | JS < 200KB gzip, no source maps, no secrets in dist/. |
| **SEC-05** | Supabase Advisors & Linter | Database | Remote CLI Advisor / Linter | 0 security errors, 0 performance warnings. |
| **SEC-06** | Dangerous Sink Grep | Frontend | Static Pattern Grep | No innerHTML, eval, missing rel on target=_blank. |
| **RLS-01** | Table RLS Coverage | Database | pgTAP / Direct SQL | All 47 tables have RLS enabled and proper policies. |
| **RLS-02** | Public/Anon Default Deny | Database | PostgREST / SQL | Anon has 0 table access except allowed public plans. |
| **RLS-03** | Cross-Tenant Isolation | Database | pgTAP / SQL | User in School A cannot read/write School B rows. |
| **RLS-04** | Cross-Branch Isolation | Database | pgTAP / SQL | Principal in Branch A cannot read/mutate Branch B. |
| **RLS-05** | Security Definer Functions | Database | SQL Inspection / Fuzzing | Search path empty, explicit auth + permission checks. |
| **RLS-06** | Mass Assignment Prevention | Database | SQL Mutators | Update cannot overwrite `school_id`, `branch_id`, `role`. |
| **RLS-07** | Immutability of Audit Logs | Database | SQL Mutator | UPDATE and DELETE on `audit_logs` are strictly denied. |
| **API-01** | PostgREST Anon Restrictions | API | Direct HTTP Fetch | Anon receives 401/403 for protected REST endpoints. |
| **API-02** | Edge Functions Auth Guards | API | HTTP / Vitest | Missing or tampered JWT returns 401 Unauthorized. |
| **API-03** | Edge Functions CORS Config | API | HTTP Preflight / Origin | CORS restricted to valid origin; preflight handles 204. |
| **API-04** | User Management Privilege Check| API | Edge Function (`manage-user`)| Principal cannot create owner or escalate to master. |
| **API-05** | Payment Webhook Signature | API | Edge Function (`payment-webhook`)| Missing/invalid HMAC signature returns 401/400. |
| **API-06** | WhatsApp Webhook & Consent | API | Edge Function (`whatsapp-*`) | Webhook signature checked, recipient consent verified. |
| **API-07** | CSV Export Formula Injection | API | Edge Function (`export-data`)| Neutralizes `=, +, -, @` leading characters. |
| **API-08** | Storage Path Traversal & RLS | Storage | Supabase Storage API | Signed URL TTL enforced, cross-tenant file access blocked. |
| **E2E-01** | Master SaaS Lifecycle | Master | Playwright Desktop | Login with TOTP, school creation, suspend/reactivate. |
| **E2E-02** | Master Access Control Guard | Public/Other| Playwright Desktop | Unauthenticated visitors hitting `/sys-master` get 404. |
| **E2E-03** | Owner First Login & Setup | Owner | Playwright Desktop | Forced password change, branch CRUD, role permissions. |
| **E2E-04** | Owner Monitoring & Realtime | Owner | Playwright (2 Contexts) | Presence counter and telemetry updates without flicker. |
| **E2E-05** | Principal Campus Workflows | Principal | Playwright Desktop/Tablet| Timetable CRUD, admissions, conflict detection. |
| **E2E-06** | Teacher Attendance & Marks | Teacher | Playwright Desktop/Mobile| Bulk attendance, marks entry, rollback on failure. |
| **E2E-07** | Parent & Student Portal | Parent/Student| Playwright Mobile/Desktop| Child switcher, fee payment sandbox, report card. |
| **E2E-08** | Accountant Financial Ledger | Accountant | Playwright Desktop | Invoice creation, fee collection, reconciliation. |
| **E2E-09** | Cross-Role Lifecycle Chain | Multi-Role | Playwright End-to-End | Admission -> fee invoice -> payment -> marks -> card. |
| **NFR-01** | Core Web Vitals & Lighthouse | Frontend | Lighthouse CI / Playwright | Performance >= 90, A11y >= 95, CLS < 0.1, Best P. >= 95.|
| **NFR-02** | Accessibility (a11y) Axe-Core | Frontend | `@axe-core/playwright` | Zero critical/serious WCAG 2.1 AA violations. |
| **NFR-03** | Multi-Device Responsive Check | UI | Playwright (Mobile/Tablet)| 360px, 768px, 1280px without horizontal scroll. |
| **NFR-04** | Performance & API Latency | Performance| Autocannon / k6 | p95 < 200ms for lists, p95 < 400ms for dashboards. |
| **NFR-05** | Realtime Soak & Memory Leak | Realtime | Soak Test Script | 0 memory leak, clean disconnect and unsubscribe. |
