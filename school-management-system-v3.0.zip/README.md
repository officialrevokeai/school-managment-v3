# Campus · School Management System v3.0

> Smart • Secure • Multi-Tenant Connected Education Management System  
> Architecture: React 18, TypeScript (strict), Vite, Tailwind CSS Neumorphism, and Supabase.

---

## 1. System Architecture & Target Project

This repository connects the School Management System v3.0 frontend directly to the dedicated production Supabase project:
- **Target Project Ref**: `oqsvedpkqgajjrnxbehz`
- **Target Project URL**: `https://oqsvedpkqgajjrnxbehz.supabase.co`

### Stack Components
- **Frontend**: React 18 with TypeScript 5.7 (strict mode), Vite 6, TanStack Query v5, Zustand, React Router v6, React Hook Form, Zod.
- **Design System**: Accessible Neumorphic token system with light and dark mode support, fluid responsiveness (360px mobile, 768px tablet, 1280px desktop), and layout stability (CLS < 0.1).
- **Backend**: Supabase Postgres with Row Level Security (RLS) on 100% of tables, timestamp-ordered idempotent migrations (`supabase/migrations/`), custom JWT hook claims (`school_id`, `role`, `branch_ids`), and automated append-only audit logging.
- **Serverless Compute**: Deno-based Supabase Edge Functions (`supabase/functions/`) with strict Zod validation, JWT authentication, rate limiting, and idempotent processing.
- **Real-Time & Communications**: Tenant-scoped Supabase Realtime channels for live attendance, fee updates, security alerts, and Meta WhatsApp Cloud API outbox processing.

---

## 2. Environment Setup

The application uses two distinct environment files to protect privileged secrets:

### A. Frontend Environment (`.env.local`)
Only client-safe public variables are exposed to the browser.
```bash
# Production Supabase URL
VITE_SUPABASE_URL=https://oqsvedpkqgajjrnxbehz.supabase.co

# Supabase Public Anon / Publishable Key
VITE_SUPABASE_PUBLISHABLE_KEY=your_publishable_anon_key_here

# Runtime Mode (false = live Supabase connection; true = local mock simulation)
VITE_USE_MOCK=false

# Application Origin
VITE_APP_URL=https://your-domain.com
```

### B. Server & Deployment Environment (`.env.server.local`)
**Never exposed to the frontend or committed to git.** Used exclusively by the Supabase CLI, CI/CD runners, and administrative deployment scripts.
```bash
# Supabase Management Token (from Supabase Account Settings)
SUPABASE_ACCESS_TOKEN=your_access_token_here

# Postgres Database Connection Password
SUPABASE_DB_PASSWORD=your_db_password_here

# Initial Platform Master Credentials
MASTER_EMAIL=master@greenwood.edu
MASTER_PASSWORD=Campus@Master2026!
```

---

## 3. Local Development & Quality Gates

### Prerequisites
- Node.js 22.13+ (or 24 LTS)
- npm 10+
- Supabase CLI (`v2+`)

### Install Dependencies
```bash
npm ci
```

### Run Development Server
```bash
npm run dev
```
Starts Vite dev server at `http://127.0.0.1:5173`.

### Run Quality Gates
```bash
# 1. Type check frontend codebase (strict TypeScript, 0 errors)
npm run typecheck

# 2. Type check Edge Functions (Deno / TS, 0 errors)
npm run typecheck:edge

# 3. Unit & Integration test suite (Vitest + in-memory PGlite RLS isolation)
npm test

# 4. End-to-end test suite (Playwright: single document load, CLS < 0.1, responsive, themes)
npm run test:e2e

# 5. Production build & bundle budget check (Initial JS < 200 KiB gzip)
npm run build
```

---

## 4. Deployment to Target Supabase Project

To deploy migrations, database seed, and Edge Functions to the target project (`oqsvedpkqgajjrnxbehz`):

### Step 1: Authenticate and Link CLI
```powershell
$env:SUPABASE_ACCESS_TOKEN = (Get-Content .env.server.local | Select-String "SUPABASE_ACCESS_TOKEN=").Line.Split("=")[1]
npx supabase login
npx supabase link --project-ref oqsvedpkqgajjrnxbehz
```

### Step 2: Push Database Migrations
Applies all 12 idempotent migrations (`20261101000001_core_extensions_and_platform.sql` through `20261101000012_storage_and_security.sql`):
```powershell
npx supabase db push
```

### Step 3: Populate Baseline Seed Data
Loads default platform plans, Greenwood High school, branches, academic years, classes, and workflows:
```powershell
npx supabase db execute --file supabase/seed.sql
```

### Step 4: Deploy Edge Functions
Deploy all production Edge Functions:
```powershell
npx supabase functions deploy health --no-verify-jwt
npx supabase functions deploy set-role-permissions
npx supabase functions deploy create-payment-order
npx supabase functions deploy payment-webhook --no-verify-jwt
npx supabase functions deploy whatsapp-webhook --no-verify-jwt
npx supabase functions deploy whatsapp-send-worker
npx supabase functions deploy export-data
npx supabase functions deploy import-csv
npx supabase functions deploy manage-user
```

---

## 5. Security & Operational Runbooks

### A. Key Rotation Procedures
If keys or credentials need to be rotated:
1. **Rotate Publishable / Anon Key**:
   - In Supabase Dashboard -> Project Settings -> API -> Generate New API Key.
   - Update `VITE_SUPABASE_PUBLISHABLE_KEY` in `.env.local` and in your frontend hosting platform environment variables (Vercel/Netlify).
   - Trigger a frontend deployment.
2. **Rotate Database Password (`SUPABASE_DB_PASSWORD`)**:
   - In Supabase Dashboard -> Database -> Database Settings -> Reset database password.
   - Update `.env.server.local` and any backend database connection pools.
3. **Rotate Webhook Signatures (Razorpay / Stripe / Meta WhatsApp)**:
   - In the provider console, generate a new signing secret.
   - Set the secret in Supabase Edge Functions:
     ```bash
     npx supabase secrets set RAZORPAY_WEBHOOK_SECRET=... WHATSAPP_WEBHOOK_VERIFY_TOKEN=...
     ```

### B. Backup & Restore Procedures
1. **Automated Backups**:
   - Supabase automatically takes daily physical and WAL backups with Point-In-Time Recovery (PITR) enabled.
2. **Manual Schema & Data Dump**:
   ```powershell
   # Dump full database schema
   npx supabase db dump --project-ref oqsvedpkqgajjrnxbehz -f backup_schema.sql
   
   # Dump public data (excluding sensitive auth tables)
   npx supabase db dump --project-ref oqsvedpkqgajjrnxbehz --data-only -f backup_data.sql
   ```
3. **Restoration**:
   - Restore using `psql` or `supabase db execute -f backup_data.sql`.

### C. Break-Glass Emergency Procedures
1. **Emergency Master Account Access**:
   - Platform Master administration is partitioned at `/sys-master` with isolated authentication.
   - In the event of primary credential loss, a privileged database administrator can update the auth email via the Supabase Auth Admin console or run:
     ```sql
     UPDATE auth.users SET encrypted_password = crypt('NewEmergencyPassword!', gen_salt('bf'))
     WHERE email = 'master@greenwood.edu';
     ```
2. **Immediate Session Revocation**:
   - If an account is compromised, invoke session revocation:
     ```sql
     UPDATE auth.users SET raw_app_meta_data = raw_app_meta_data || '{"revoked_at":"' || now() || '"}'::jsonb
     WHERE id = 'target_user_uuid';
     ```
   - This immediately invalidates active refresh tokens and triggers the frontend bootstrap re-authentication gate.

---

## 6. Accessing the Master Panel (SaaS Creator Console)

The platform includes a dedicated **Master Panel** built from scratch for multi-tenant SaaS oversight, school provisioning, revenue monitoring, and fleet role governance.

### A. Reaching the Master Panel
- **Entry URL**: `https://your-domain.com/sys-master` (or local `http://127.0.0.1:5173/sys-master`).
- **Configuration**: Path is governed by `VITE_MASTER_PATH=/sys-master` and enabled via `VITE_ENABLE_MASTER=true`.
- **Security & Obscurity Model**:
  - The master panel is **never linked** in any user navigation, footer, sitemap, or robots.txt.
  - Any non-master user (Student, Parent, Teacher, Principal, Owner) or anonymous visitor attempting to access `/sys-master/*` is shown the standard generic **404 Page Not Found** component.
  - Real security rests on Supabase Auth JWT `role: "master"` claims, Row Level Security (RLS) denying tenant access, and MFA enforcement—never solely on URL obscurity.

### B. Master Console Pages & Capabilities
1. **Overview**: Fleet KPIs (Active, Trial, Suspended, MRR, ARR, fleet student totals, user totals), live system health probe, expiring-soon queue.
2. **Schools**: Searchable, status/plan filtered directory with row actions (view details, suspend, reactivate, extend plan, reset owner password, CSV export, soft delete with immediate session revocation).
3. **Create School**: Atomically provisions organization, default branch, default roles from templates, owner Auth account, and initial subscription via `create-school` edge function. Includes password strength generator and one-time credentials modal.
4. **Revenue**: School-wise and month-wise billing tables, revenue charts (by school, plan, month), record offline payment modal, and CSV export.
5. **Plans & Billing**: Tier CRUD (Starter, Growth, Enterprise) with price, student and branch limits, feature flags, and pg_cron auto-suspension telemetry.
6. **Global Role Control**: Role-permission matrix editor across 6 tenant roles, diff preview modal, and "Apply to all schools" type-to-confirm distribution.
7. **Platform Monitoring**: Realtime presence count, p95 API latency, Edge function failure tracking, WhatsApp Cloud API delivery stream, and security alert feed.
8. **Platform Audit Log**: Immutable log of all master actions, school state mutations, and administrative logins with CSV export.
9. **Settings & Security**: Global feature flags, broadcast announcements to all school owners, maintenance mode banner, active master sessions list with revoke, and secondary master admin provisioning.

