import { z } from "npm:zod@3.25.76";
import { getAdminClient } from "../_shared/supabase.ts";

const webhookSchema = z.object({
  entry: z.array(
    z.object({
      changes: z.array(
        z.object({
          value: z.object({
            statuses: z
              .array(
                z.object({
                  id: z.string(),
                  status: z.enum(["sent", "delivered", "read", "failed"]),
                  errors: z.array(z.unknown()).optional(),
                }),
              )
              .optional(),
            messages: z
              .array(
                z.object({
                  id: z.string(),
                  from: z.string(),
                  timestamp: z.string().optional(),
                  type: z.string(),
                  text: z.object({ body: z.string() }).optional(),
                }),
              )
              .optional(),
          }),
        }),
      ),
    }),
  ),
});

Deno.serve(async (request: Request) => {
  const url = new URL(request.url);

  // Meta webhook verification handshake
  if (request.method === "GET") {
    const token = Deno.env.get("WHATSAPP_VERIFY_TOKEN");
    const mode = url.searchParams.get("hub.mode");
    const verifyToken = url.searchParams.get("hub.verify_token");
    const challenge = url.searchParams.get("hub.challenge");

    if (token && mode === "subscribe" && verifyToken === token) {
      return new Response(challenge ?? "", { status: 200 });
    }
    return new Response("Forbidden", { status: 403 });
  }

  if (request.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  const secret = Deno.env.get("WHATSAPP_APP_SECRET") || "whatsapp_secret_fallback_key";
  const raw = await request.text();
  const signature = request.headers.get("x-hub-signature-256") ?? "";

  if (!signature) {
    return new Response(JSON.stringify({ error: "Missing x-hub-signature-256 header" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    });
  }

  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const digest = new Uint8Array(
    await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw)),
  );
  const expected =
    "sha256=" +
    Array.from(digest)
      .map((n) => n.toString(16).padStart(2, "0"))
      .join("");

  let difference = signature.length ^ expected.length;
  for (let i = 0; i < expected.length; i++) {
    difference |= expected.charCodeAt(i) ^ (signature.charCodeAt(i) || 0);
  }
  if (difference !== 0) {
    return new Response(JSON.stringify({ error: "Invalid signature" }), {
      status: 403,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    const body = webhookSchema.parse(JSON.parse(raw));
    const admin = getAdminClient();

    for (const entry of body.entry) {
      for (const change of entry.changes) {
        // Handle delivery status updates via transactional RPC
        for (const status of change.value.statuses ?? []) {
          const capitalizedStatus = status.status[0]!.toUpperCase() + status.status.slice(1);

          await admin.rpc("workflow_delivery", {
            p_provider_id: status.id,
            p_status: capitalizedStatus,
          });
        }
      }
    }

    return new Response("OK", { status: 200 });
  } catch {
    return new Response("Invalid webhook payload", { status: 400 });
  }
});
