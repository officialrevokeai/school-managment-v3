import { z } from "npm:zod@3.25.76";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller, requireRoles } from "../_shared/auth.ts";
import { parseCsvRows } from "../_shared/csv.ts";

const importSchema = z.object({
  resource: z.enum(["students", "attendance", "marks", "fees"]),
  branchId: z.string().uuid(),
  csvContent: z.string().min(10),
});

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    const profile = auth.profile;
    const roleCheck = requireRoles(req, profile, ["owner", "principal", "accountant", "master"]);
    if (roleCheck) return roleCheck;

    const input = importSchema.parse(await req.json());
    const admin = auth.adminClient;
    const schoolId = profile!.school_id || (auth.user.app_metadata?.school_id as string);

    if (!schoolId) {
      return jsonError(req, "School ID context required for import", 400);
    }

    const callerRole = profile?.role ?? (auth.user.app_metadata?.role as string);
    const callerBranches = profile?.branch_ids ?? ((auth.user.app_metadata?.branch_ids as string[]) || []);

    if (callerRole === "principal" && (!callerBranches || !callerBranches.includes(input.branchId))) {
      return jsonError(req, "Branch access denied: Principal is not authorized for this branch", 403);
    }

    // Create import job record in admin_records
    const jobId = crypto.randomUUID();
    const now = new Date().toISOString();

    // RFC 4180 robust CSV parsing
    const { rows } = parseCsvRows(input.csvContent);

    const errorLog: Array<{ row: number; error: string }> = [];
    let processedRows = 0;

    for (let i = 0; i < rows.length; i++) {
      const rowNum = i + 2;
      const record = rows[i];

      try {
        if (input.resource === "students") {
          const name = record.name || record.student_name;
          const email = record.email || record.student_email;
          if (!name || !email) {
            throw new Error("Missing required student name or email");
          }

          const studentId = crypto.randomUUID();
          await admin.from("profiles").insert({
            id: studentId,
            school_id: schoolId,
            branch_ids: [input.branchId],
            role: "student",
            name,
            email: email.toLowerCase(),
            phone: record.phone || "",
            active: true,
          });

          await admin.from("admin_records").insert({
            id: studentId,
            school_id: schoolId,
            branch_id: input.branchId,
            resource: "users",
            payload: {
              id: studentId,
              schoolId,
              branchId: input.branchId,
              version: 1,
              name,
              email: email.toLowerCase(),
              role: "student",
              status: "Active",
              phone: record.phone || "",
              joinedAt: new Date().toISOString().slice(0, 10),
            },
            version: 1,
          });
        } else if (input.resource === "attendance") {
          const studentId = record.studentId || record.student_id;
          const classId = record.classId || record.class_id;
          const date = record.date || new Date().toISOString().slice(0, 10);
          const rawStatus = record.status || "Present";
          const status = ["Present", "Absent", "Late", "Leave"].includes(rawStatus)
            ? (rawStatus as "Present" | "Absent" | "Late" | "Leave")
            : "Present";

          if (!studentId || !classId) {
            throw new Error("Missing required student_id or class_id");
          }

          await admin.from("attendance_records").insert({
            school_id: schoolId,
            branch_id: input.branchId,
            class_id: classId,
            student_id: studentId,
            marked_by: profile!.id,
            date,
            status,
            notes: record.notes || "",
          });
        } else if (input.resource === "marks") {
          const studentId = record.studentId || record.student_id;
          const classId = record.classId || record.class_id;
          const subjectId = record.subjectId || record.subject_id;
          const examId = record.examId || record.exam_id || null;
          const score = Number(record.score ?? record.marksObtained ?? 0);
          const maximum = Number(record.maximum ?? record.maxMarks ?? 100);

          if (!studentId || !classId || !subjectId) {
            throw new Error("Missing required student_id, class_id, or subject_id");
          }

          await admin.from("marks").insert({
            school_id: schoolId,
            branch_id: input.branchId,
            class_id: classId,
            subject_id: subjectId,
            student_id: studentId,
            exam_id: examId,
            entered_by: profile!.id,
            score,
            maximum,
            published: true,
            notes: record.notes || record.remarks || "",
          });
        } else if (input.resource === "fees") {
          const studentId = record.studentId || record.student_id;
          const title = record.title || "Tuition Fee";
          const amount = Number(record.amount || 0);
          const dueDate = record.dueDate || record.due_date || new Date().toISOString().slice(0, 10);

          if (!studentId) {
            throw new Error("Missing required student_id");
          }

          await admin.from("student_fees").insert({
            school_id: schoolId,
            branch_id: input.branchId,
            student_id: studentId,
            fee_structure_id: record.feeStructureId || record.fee_structure_id || null,
            title,
            amount,
            paid_amount: 0,
            discount: Number(record.discount || 0),
            fine: Number(record.fine || 0),
            status: "Pending",
            due_date: dueDate,
            notes: record.notes || "",
          });
        }

        processedRows++;
      } catch (err: unknown) {
        errorLog.push({ row: rowNum, error: err instanceof Error ? err.message : "Parse error" });
      }
    }

    // Persist import log into admin_records
    await admin.from("admin_records").insert({
      id: jobId,
      school_id: schoolId,
      branch_id: input.branchId,
      resource: "audit_logs",
      version: 1,
      payload: {
        school_id: schoolId,
        actor_id: profile!.id,
        actor_name: profile!.name,
        action: "IMPORT_CSV",
        resource: input.resource,
        resource_id: jobId,
        details: {
          totalRows: rows.length,
          processedRows,
          errorCount: errorLog.length,
          errors: errorLog.slice(0, 10),
        },
        timestamp: now,
      },
      updated_at: now,
    });

    return jsonResponse(req, {
      ok: true,
      data: {
        jobId,
        total: rows.length,
        processed: processedRows,
        errors: errorLog.length,
      },
    });
  } catch (err: unknown) {
    return jsonError(req, err, 400);
  }
});
