import { z } from "npm:zod@3.25.76";
import type { Json } from "../../../src/types/database.ts";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller, requireRoles } from "../_shared/auth.ts";

const inputSchema = z.object({
  roleId: z.string().uuid(),
  permissions: z.array(z.string().min(2)),
});

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    // Only owner or master can configure role policies
    const roleCheck = requireRoles(req, auth.profile, ["master", "owner"]);
    if (roleCheck) return roleCheck;

    const input = inputSchema.parse(await req.json());
    const admin = auth.adminClient;
    const now = new Date().toISOString();

    // 1. Fetch role from admin_records
    const { data: roleRecord, error: fetchError } = await admin
      .from("admin_records")
      .select("id, school_id, payload, version")
      .eq("id", input.roleId)
      .eq("resource", "roles")
      .maybeSingle();

    if (fetchError || !roleRecord) {
      return jsonError(req, "Role not found", 404);
    }

    // Tenant check: Non-master cannot modify roles belonging to another school
    if (auth.profile!.role !== "master" && roleRecord.school_id !== auth.profile!.school_id) {
      return jsonError(req, "Forbidden: Cannot modify roles for another school", 403);
    }

    const payload = (roleRecord.payload as Record<string, unknown>) || {};
    const updatedPayload = {
      ...payload,
      permissions: input.permissions,
      updatedAt: now,
    };

    // 2. Update role in admin_records
    const { error: updateError } = await admin
      .from("admin_records")
      .update({
        payload: updatedPayload as unknown as Json,
        version: (roleRecord.version ?? 1) + 1,
        updated_at: now,
      })
      .eq("id", input.roleId)
      .eq("resource", "roles");

    if (updateError) {
      return jsonError(req, updateError.message, 400);
    }

    // 3. Audit log in admin_records
    await admin.from("admin_records").insert({
      id: crypto.randomUUID(),
      school_id: roleRecord.school_id,
      branch_id: null,
      resource: "audit_logs",
      version: 1,
      payload: {
        school_id: roleRecord.school_id,
        actor_id: auth.profile!.id,
        actor_name: auth.profile!.name,
        action: "UPDATE_ROLE_PERMISSIONS",
        resource: "roles",
        resource_id: input.roleId,
        details: { newPermissions: input.permissions },
        timestamp: now,
      } as unknown as Json,
      updated_at: now,
    });

    return jsonResponse(req, { ok: true, data: updatedPayload });
  } catch (err: unknown) {
    return jsonError(req, err, 400);
  }
});
