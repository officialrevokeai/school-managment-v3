import { z } from "npm:zod@3.25.76";
import type { Json } from "../../../src/types/database.ts";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller } from "../_shared/auth.ts";

const orderSchema = z.object({
  studentFeeId: z.string().uuid(),
  amount: z.number().positive(),
  notes: z.string().optional(),
});

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    const input = orderSchema.parse(await req.json());
    const admin = auth.adminClient;

    // Fetch student fee
    const { data: fee, error: feeError } = await admin
      .from("student_fees")
      .select("id, school_id, branch_id, student_id, amount, paid_amount, status")
      .eq("id", input.studentFeeId)
      .maybeSingle();

    if (feeError || !fee) {
      return jsonError(req, "Student fee record not found", 404);
    }

    // Tenant isolation verification: Non-master users can only initiate orders for their own school
    if (auth.profile && auth.profile.role !== "master" && fee.school_id !== auth.profile.school_id) {
      return jsonError(req, "Forbidden: Fee record belongs to another school", 403);
    }

    const orderRef = `ORDER_${Date.now()}_${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const now = new Date().toISOString();

    // Store payment intent / idempotency record in admin_records
    await admin.from("admin_records").insert({
      id: crypto.randomUUID(),
      school_id: fee.school_id,
      branch_id: fee.branch_id,
      resource: "payment_orders",
      version: 1,
      payload: {
        orderRef,
        studentFeeId: fee.id,
        amount: input.amount,
        userId: auth.user.id,
        notes: input.notes || "",
        createdAt: now,
      } as unknown as Json,
      updated_at: now,
    });

    return jsonResponse(req, {
      ok: true,
      data: {
        orderRef,
        studentFeeId: fee.id,
        amount: input.amount,
        currency: "INR",
        createdAt: now,
      },
    });
  } catch (err: unknown) {
    return jsonError(req, err, 400);
  }
});
