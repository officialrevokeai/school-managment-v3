import { handleCors, jsonResponse } from "../_shared/cors.ts";

Deno.serve((req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  const requestId = req.headers.get("x-request-id") || crypto.randomUUID();

  return jsonResponse(req, {
    ok: true,
    data: {
      status: "healthy",
      service: "campus-school-management",
      timestamp: new Date().toISOString(),
      requestId,
    },
  });
});
