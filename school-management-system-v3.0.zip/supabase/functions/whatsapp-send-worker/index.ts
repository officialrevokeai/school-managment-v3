import type { Json } from "../../../src/types/database.ts";
import { getAdminClient } from "../_shared/supabase.ts";

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  try {
    const admin = getAdminClient();

    // 1. Fetch pending queued WhatsApp messages from school_workflows
    const { data: workflows, error: fetchError } = await admin
      .from("school_workflows")
      .select("id, school_id, branch_id, author_id, class_id, student_id, module, version, payload")
      .eq("module", "whatsapp")
      .limit(50);

    if (fetchError || !workflows || workflows.length === 0) {
      return Response.json({ ok: true, processed: 0 });
    }

    const metaToken = Deno.env.get("META_WHATSAPP_TOKEN") || Deno.env.get("WHATSAPP_TOKEN");
    const phoneNumberId = Deno.env.get("WHATSAPP_PHONE_ID");
    const rawVersion = Deno.env.get("WHATSAPP_API_VERSION") || "v21.0";
    const apiVersion = rawVersion.startsWith("v") ? rawVersion : `v${rawVersion}`;

    let processedCount = 0;

    for (const wf of workflows) {
      const payload = (wf.payload as Record<string, unknown>) || {};
      const data = (payload.data as Record<string, unknown>) || {};

      if (data.status !== "Queued") continue;

      const recipient = String(data.recipient || "");
      const templateName = String(data.template || "");
      const attempts = Number(data.attempts || 0);

      // 2. User Consent Check (Compliance requirement)
      if (recipient) {
        const { data: consent } = await admin
          .from("user_consents")
          .select("consented")
          .eq("school_id", wf.school_id)
          .eq("phone_number", recipient)
          .eq("channel", "whatsapp")
          .maybeSingle();

        if (consent && consent.consented === false) {
          await admin
            .from("school_workflows")
            .update({
              payload: {
                ...payload,
                data: {
                  ...data,
                  status: "Failed",
                  attempts: attempts + 1,
                  notes: "Recipient has opted out or withdrawn WhatsApp communication consent",
                },
              } as unknown as Json,
              version: wf.version + 1,
              updated_at: new Date().toISOString(),
            })
            .eq("id", wf.id);
          continue;
        }
      }

      if (!phoneNumberId || !metaToken) {
        await admin
          .from("school_workflows")
          .update({
            payload: {
              ...payload,
              data: {
                ...data,
                status: "Failed",
                attempts: attempts + 1,
                notes: "WhatsApp account or Meta credentials not configured",
              },
            } as unknown as Json,
            version: wf.version + 1,
            updated_at: new Date().toISOString(),
          })
          .eq("id", wf.id);
        continue;
      }

      // 3. Dispatch to Meta Cloud API
      const dispatchBody = templateName
        ? {
            messaging_product: "whatsapp",
            to: recipient.replace("+", ""),
            type: "template",
            template: {
              name: templateName,
              language: { code: "en" },
            },
          }
        : {
            messaging_product: "whatsapp",
            to: recipient.replace("+", ""),
            type: "text",
            text: { body: String(data.title || "Campus update") },
          };

      try {
        const metaRes = await fetch(
          `https://graph.facebook.com/${apiVersion}/${phoneNumberId}/messages`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${metaToken}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify(dispatchBody),
          }
        );

        const metaData = await metaRes.json();

        if (metaRes.ok && metaData.messages?.[0]?.id) {
          const providerId = metaData.messages[0].id;
          await admin
            .from("school_workflows")
            .update({
              payload: {
                ...payload,
                data: {
                  ...data,
                  status: "Sent",
                  providerId,
                  sentAt: new Date().toISOString(),
                  attempts: attempts + 1,
                },
              } as unknown as Json,
              version: wf.version + 1,
              updated_at: new Date().toISOString(),
            })
            .eq("id", wf.id);
          processedCount++;
        } else {
          const isDeadLetter = attempts + 1 >= 3;
          await admin
            .from("school_workflows")
            .update({
              payload: {
                ...payload,
                data: {
                  ...data,
                  status: isDeadLetter ? "Failed" : "Queued",
                  attempts: attempts + 1,
                  notes: JSON.stringify(metaData.error || "Meta API error"),
                },
              } as unknown as Json,
              version: wf.version + 1,
              updated_at: new Date().toISOString(),
            })
            .eq("id", wf.id);
        }
      } catch (err: unknown) {
        const isDeadLetter = attempts + 1 >= 3;
        await admin
          .from("school_workflows")
          .update({
            payload: {
              ...payload,
              data: {
                ...data,
                status: isDeadLetter ? "Failed" : "Queued",
                attempts: attempts + 1,
                notes: err instanceof Error ? err.message : "Network error",
              },
            } as unknown as Json,
            version: wf.version + 1,
            updated_at: new Date().toISOString(),
          })
          .eq("id", wf.id);
      }
    }

    return Response.json({ ok: true, processed: processedCount });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Worker error";
    return Response.json({ ok: false, error: msg }, { status: 500 });
  }
});
