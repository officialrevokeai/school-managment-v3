import { z } from "npm:zod@3.25.76";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller, requireMaster } from "../_shared/auth.ts";

const inputSchema = z.object({
  schoolId: z.string().uuid(),
  amount: z.number().positive(),
  paymentMethod: z.enum(["bank_transfer", "card", "upi", "cheque", "cash"]).default("bank_transfer"),
  referenceNumber: z.string().min(2),
  billingPeriodStart: z.string(),
  billingPeriodEnd: z.string(),
  notes: z.string().optional(),
});

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    const masterCheck = requireMaster(req, auth.user, auth.profile);
    if (masterCheck) return masterCheck;

    const input = inputSchema.parse(await req.json());
    const admin = auth.adminClient;
    const paymentId = crypto.randomUUID();
    const now = new Date().toISOString();

    const paymentPayload = {
      id: paymentId,
      schoolId: input.schoolId,
      amount: input.amount,
      paymentMethod: input.paymentMethod,
      referenceNumber: input.referenceNumber,
      billingPeriodStart: input.billingPeriodStart,
      billingPeriodEnd: input.billingPeriodEnd,
      notes: input.notes,
      status: "completed",
      recordedBy: auth.user.id,
      createdAt: now,
    };

    // Store in admin_records (resource: "school_payments")
    const { error: paymentErr } = await admin.from("admin_records").insert({
      id: paymentId,
      school_id: input.schoolId,
      branch_id: null,
      resource: "school_payments",
      version: 1,
      payload: paymentPayload,
      updated_at: now,
    });

    if (paymentErr) {
      return jsonError(req, paymentErr.message, 400);
    }

    // Update school status to Active if suspended/expired
    await admin
      .from("schools")
      .update({ status: "Active", updated_at: now })
      .eq("id", input.schoolId);

    // Sync admin_records schools payload status
    const { data: schoolRecord } = await admin
      .from("admin_records")
      .select("payload")
      .eq("id", input.schoolId)
      .eq("resource", "schools")
      .maybeSingle();

    if (schoolRecord?.payload) {
      const payload = schoolRecord.payload as Record<string, unknown>;
      await admin
        .from("admin_records")
        .update({ payload: { ...payload, status: "Active" }, updated_at: now })
        .eq("id", input.schoolId);
    }

    // Platform Audit log
    await admin.from("admin_records").insert({
      id: crypto.randomUUID(),
      school_id: input.schoolId,
      branch_id: null,
      resource: "audit_logs",
      version: 1,
      payload: {
        school_id: input.schoolId,
        actor_id: auth.user.id,
        actor_name: auth.user.email ?? "Master Admin",
        action: "RECORD_SCHOOL_PAYMENT",
        resource: "school_payments",
        resource_id: paymentId,
        details: {
          amount: input.amount,
          referenceNumber: input.referenceNumber,
          period: `${input.billingPeriodStart} to ${input.billingPeriodEnd}`,
        },
        timestamp: now,
      },
      updated_at: now,
    });

    return jsonResponse(req, { ok: true, data: paymentPayload }, 201);
  } catch (error) {
    return jsonError(req, error, 400);
  }
});
