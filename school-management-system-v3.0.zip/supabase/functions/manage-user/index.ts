import { z } from "npm:zod@3.25.76";
import type { Json } from "../../../src/types/database.ts";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller, requireRoles } from "../_shared/auth.ts";

const passwordSchema = z
  .string()
  .min(10, "Password must be at least 10 characters")
  .regex(/[A-Z]/, "Password must contain an uppercase letter")
  .regex(/[a-z]/, "Password must contain a lowercase letter")
  .regex(/[0-9]/, "Password must contain a number")
  .regex(/[^A-Za-z0-9]/, "Password must contain a special character");

const createUserSchema = z.object({
  action: z.literal("create"),
  schoolId: z.string().uuid(),
  name: z.string().trim().min(2, "Name must be at least 2 characters"),
  email: z.string().trim().email("Invalid email address"),
  role: z.enum(["owner", "principal", "teacher", "parent", "student", "accountant"]),
  branchIds: z.array(z.string().uuid()).min(1, "At least one campus must be assigned"),
  phone: z.string().trim().default(""),
  password: passwordSchema,
  forcePasswordChange: z.boolean().default(true),
  policyId: z.string().uuid().nullable().optional(),
});

const updateUserSchema = z.object({
  action: z.literal("update"),
  userId: z.string().uuid(),
  name: z.string().trim().min(2).optional(),
  phone: z.string().trim().optional(),
  branchIds: z.array(z.string().uuid()).optional(),
  policyId: z.string().uuid().nullable().optional(),
});

const setPasswordSchema = z.object({
  action: z.literal("set-password"),
  userId: z.string().uuid(),
  password: passwordSchema,
  forcePasswordChange: z.boolean().default(false),
});

const toggleStatusSchema = z.object({
  action: z.literal("toggle-status"),
  userId: z.string().uuid(),
  active: z.boolean(),
});

const revokeSessionsSchema = z.object({
  action: z.literal("revoke-sessions"),
  userId: z.string().uuid(),
});

const requestSchema = z.discriminatedUnion("action", [
  createUserSchema,
  updateUserSchema,
  setPasswordSchema,
  toggleStatusSchema,
  revokeSessionsSchema,
]);

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    const callerProfile = auth.profile;
    const roleCheck = requireRoles(req, callerProfile, ["master", "owner", "principal"]);
    if (roleCheck) return roleCheck;

    const callerRole = callerProfile!.role;
    const callerSchoolId = callerProfile!.school_id;
    const callerBranchIds = callerProfile!.branch_ids || [];
    const admin = auth.adminClient;
    const payload = requestSchema.parse(await req.json());
    const now = new Date().toISOString();

    // 1. Action: CREATE USER
    if (payload.action === "create") {
      // Enforce tenant boundary
      if (callerRole !== "master" && payload.schoolId !== callerSchoolId) {
        return jsonError(req, "Forbidden: Cannot create users for another school", 403);
      }

      // Owner permission checks
      if (callerRole === "owner") {
        if (payload.role === "owner") {
          return jsonError(req, "Forbidden: Owner cannot create another owner account", 403);
        }
      }

      // Principal permission checks
      if (callerRole === "principal") {
        if (payload.role === "principal" || (payload.role as string) === "owner") {
          return jsonError(req, "Forbidden: Principal cannot create administrative accounts", 403);
        }
        const outsideBranch = payload.branchIds.some((b) => !callerBranchIds.includes(b));
        if (outsideBranch) {
          return jsonError(req, "Forbidden: Principal cannot assign users outside assigned branches", 403);
        }
      }

      // Ensure email uniqueness across profiles
      const { data: existingUser } = await admin
        .from("profiles")
        .select("id")
        .eq("email", payload.email.toLowerCase())
        .maybeSingle();

      if (existingUser) {
        return jsonError(req, "An account with this email address already exists", 409);
      }

      // Create Supabase Auth user
      const { data: newAuth, error: createAuthError } = await admin.auth.admin.createUser({
        email: payload.email.toLowerCase(),
        password: payload.password,
        email_confirm: true,
        app_metadata: {
          role: payload.role,
          school_id: payload.schoolId,
          branch_ids: payload.branchIds,
          force_password_change: payload.forcePasswordChange,
        },
        user_metadata: {
          name: payload.name,
          phone: payload.phone,
        },
      });

      if (createAuthError || !newAuth.user) {
        return jsonError(req, createAuthError?.message || "User creation failed", 400);
      }

      const newUserId = newAuth.user.id;

      // Insert profile row
      const { error: insertProfileError } = await admin.from("profiles").insert({
        id: newUserId,
        school_id: payload.schoolId,
        branch_ids: payload.branchIds,
        role: payload.role,
        name: payload.name,
        email: payload.email.toLowerCase(),
        phone: payload.phone,
        active: true,
        must_change_password: payload.forcePasswordChange,
        policy_id: payload.policyId || null,
      });

      if (insertProfileError) {
        await admin.auth.admin.deleteUser(newUserId);
        return jsonError(req, `Failed to persist profile: ${insertProfileError.message}`, 500);
      }

      // Record in admin_records for directory view
      await admin.from("admin_records").insert({
        id: newUserId,
        school_id: payload.schoolId,
        branch_id: payload.branchIds[0] || null,
        resource: "users",
        payload: {
          id: newUserId,
          schoolId: payload.schoolId,
          branchId: payload.branchIds[0] || null,
          version: 1,
          name: payload.name,
          email: payload.email.toLowerCase(),
          role: payload.role,
          status: "Active",
          phone: payload.phone,
          joinedAt: new Date().toISOString().slice(0, 10),
          policyId: payload.policyId || null,
        } as unknown as Json,
        version: 1,
        updated_at: now,
      });

      // Audit Log in admin_records
      await admin.from("admin_records").insert({
        id: crypto.randomUUID(),
        school_id: payload.schoolId,
        branch_id: payload.branchIds[0] || null,
        resource: "audit_logs",
        version: 1,
        payload: {
          school_id: payload.schoolId,
          actor_id: callerProfile!.id,
          actor_name: callerProfile!.name,
          action: "CREATE_USER",
          resource: "profiles",
          resource_id: newUserId,
          details: {
            targetEmail: payload.email.toLowerCase(),
            targetRole: payload.role,
            targetBranches: payload.branchIds,
          },
          timestamp: now,
        } as unknown as Json,
        updated_at: now,
      });

      return jsonResponse(
        req,
        {
          ok: true,
          data: {
            id: newUserId,
            name: payload.name,
            email: payload.email.toLowerCase(),
            role: payload.role,
            branchIds: payload.branchIds,
          },
        },
        201
      );
    }

    // 2. Cross-user operations: Verify target user tenant boundary
    const targetUserId = payload.userId;
    const { data: targetProfile, error: targetFetchError } = await admin
      .from("profiles")
      .select("id, school_id, role, name, branch_ids")
      .eq("id", targetUserId)
      .maybeSingle();

    if (targetFetchError || !targetProfile) {
      return jsonError(req, "Target user not found", 404);
    }

    if (callerRole !== "master" && targetProfile.school_id !== callerSchoolId) {
      return jsonError(req, "Forbidden: Access denied to target user", 403);
    }

    if (callerRole === "principal" && ["owner", "master", "principal"].includes(targetProfile.role)) {
      return jsonError(req, "Forbidden: Principal cannot manage administrative accounts", 403);
    }

    if (payload.action === "set-password") {
      const { error: updateAuthError } = await admin.auth.admin.updateUserById(payload.userId, {
        password: payload.password,
      });

      if (updateAuthError) {
        return jsonError(req, updateAuthError.message, 400);
      }

      if (payload.forcePasswordChange) {
        await admin.from("profiles").update({ must_change_password: true }).eq("id", payload.userId);
      }

      await admin.from("admin_records").insert({
        id: crypto.randomUUID(),
        school_id: targetProfile.school_id,
        branch_id: null,
        resource: "audit_logs",
        version: 1,
        payload: {
          school_id: targetProfile.school_id,
          actor_id: callerProfile!.id,
          actor_name: callerProfile!.name,
          action: "SET_PASSWORD",
          resource: "profiles",
          resource_id: payload.userId,
          details: { forcedChange: payload.forcePasswordChange },
          timestamp: now,
        } as unknown as Json,
        updated_at: now,
      });

      return jsonResponse(req, { ok: true, data: { userId: payload.userId } });
    }

    if (payload.action === "toggle-status") {
      await admin.from("profiles").update({ active: payload.active }).eq("id", payload.userId);

      if (!payload.active) {
        await admin.auth.admin.signOut(payload.userId, "global");
      }

      // Sync admin_records user payload
      const { data: userRec } = await admin
        .from("admin_records")
        .select("payload")
        .eq("id", payload.userId)
        .eq("resource", "users")
        .maybeSingle();

      if (userRec?.payload) {
        const p = userRec.payload as Record<string, unknown>;
        await admin
          .from("admin_records")
          .update({
            payload: { ...p, status: payload.active ? "Active" : "Inactive" } as unknown as Json,
            updated_at: now,
          })
          .eq("id", payload.userId);
      }

      await admin.from("admin_records").insert({
        id: crypto.randomUUID(),
        school_id: targetProfile.school_id,
        branch_id: null,
        resource: "audit_logs",
        version: 1,
        payload: {
          school_id: targetProfile.school_id,
          actor_id: callerProfile!.id,
          actor_name: callerProfile!.name,
          action: payload.active ? "ENABLE_USER" : "DISABLE_USER",
          resource: "profiles",
          resource_id: payload.userId,
          details: { active: payload.active },
          timestamp: now,
        } as unknown as Json,
        updated_at: now,
      });

      return jsonResponse(req, { ok: true, data: { userId: payload.userId, active: payload.active } });
    }

    if (payload.action === "revoke-sessions") {
      await admin.auth.admin.signOut(payload.userId, "global");

      await admin.from("admin_records").insert({
        id: crypto.randomUUID(),
        school_id: targetProfile.school_id,
        branch_id: null,
        resource: "audit_logs",
        version: 1,
        payload: {
          school_id: targetProfile.school_id,
          actor_id: callerProfile!.id,
          actor_name: callerProfile!.name,
          action: "REVOKE_SESSIONS",
          resource: "profiles",
          resource_id: payload.userId,
          details: {},
          timestamp: now,
        } as unknown as Json,
        updated_at: now,
      });

      return jsonResponse(req, { ok: true, data: { userId: payload.userId } });
    }

    if (payload.action === "update") {
      const updates: {
        name?: string;
        phone?: string;
        branch_ids?: string[];
        policy_id?: string | null;
        updated_at?: string;
      } = {};
      if (payload.name) updates.name = payload.name;
      if (payload.phone !== undefined) updates.phone = payload.phone;
      if (payload.branchIds) updates.branch_ids = payload.branchIds;
      if (payload.policyId !== undefined) updates.policy_id = payload.policyId;
      updates.updated_at = now;

      await admin.from("profiles").update(updates).eq("id", payload.userId);

      // Sync admin_records
      const { data: userRec } = await admin
        .from("admin_records")
        .select("payload")
        .eq("id", payload.userId)
        .eq("resource", "users")
        .maybeSingle();

      if (userRec?.payload) {
        const p = userRec.payload as Record<string, unknown>;
        await admin
          .from("admin_records")
          .update({
            payload: { ...p, ...updates } as unknown as Json,
            updated_at: now,
          })
          .eq("id", payload.userId);
      }

      await admin.from("admin_records").insert({
        id: crypto.randomUUID(),
        school_id: targetProfile.school_id,
        branch_id: null,
        resource: "audit_logs",
        version: 1,
        payload: {
          school_id: targetProfile.school_id,
          actor_id: callerProfile!.id,
          actor_name: callerProfile!.name,
          action: "UPDATE_USER",
          resource: "profiles",
          resource_id: payload.userId,
          details: updates,
          timestamp: now,
        } as unknown as Json,
        updated_at: now,
      });

      return jsonResponse(req, { ok: true, data: { userId: payload.userId } });
    }

    return jsonError(req, "Unknown action", 400);
  } catch (err: unknown) {
    return jsonError(req, err, 400);
  }
});
