import { z } from "npm:zod@3.25.76";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller } from "../_shared/auth.ts";
import { formatCsv } from "../_shared/csv.ts";

const exportSchema = z.object({
  resource: z.enum(["students", "attendance", "fees", "expenses", "payroll", "marks", "branches", "all"]),
  format: z.enum(["csv", "json", "xlsx"]).default("csv"),
  branchId: z.string().uuid().optional(),
  schoolId: z.string().uuid().optional(),
});

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    const profile = auth.profile;
    if (!profile || !profile.active) {
      return jsonError(req, "Active profile required", 403);
    }

    const input = exportSchema.parse(await req.json());
    const admin = auth.adminClient;

    // Resolve target school ID
    const effectiveSchoolId =
      profile.role === "master" ? (input.schoolId || profile.school_id) : profile.school_id;

    if (!effectiveSchoolId) {
      return jsonError(req, "School ID is required for data export", 400);
    }

    // Role-based permission & scope validation
    if (input.resource === "all" && profile.role !== "owner" && profile.role !== "master") {
      return jsonError(req, "Only school owners can export the complete school dataset", 403);
    }

    if (profile.role === "accountant" && !["fees", "expenses", "payroll"].includes(input.resource)) {
      return jsonError(req, "Accountants can only export financial records", 403);
    }

    if (profile.role === "teacher" && ["fees", "expenses", "payroll", "all"].includes(input.resource)) {
      return jsonError(req, "Teachers cannot export financial or full school records", 403);
    }

    if (["parent", "student"].includes(profile.role)) {
      return jsonError(req, "Students and parents cannot perform bulk exports", 403);
    }

    // Branch scoping for principal and teacher
    const isBranchScoped = ["principal", "teacher"].includes(profile.role);
    if (isBranchScoped && input.branchId && profile.branch_ids?.length && !profile.branch_ids.includes(input.branchId)) {
      return jsonError(req, "Branch access denied", 403);
    }
    const effectiveBranchId =
      isBranchScoped && profile.branch_ids?.length
        ? (input.branchId || profile.branch_ids[0])
        : input.branchId;

    const jobId = crypto.randomUUID();
    const now = new Date().toISOString();

    let rows: Record<string, unknown>[] = [];
    let exportContent = "";

    if (input.resource === "all") {
      const [branchesRes, profilesRes, feesRes, attendanceRes] = await Promise.all([
        admin.from("branches").select("id, name, code, city, status").eq("school_id", effectiveSchoolId),
        admin.from("profiles").select("id, name, email, role, phone, active").eq("school_id", effectiveSchoolId),
        admin
          .from("fee_payments")
          .select("id, amount, paid_at, receipt_number, payment_method")
          .eq("school_id", effectiveSchoolId)
          .limit(2000),
        admin
          .from("attendance_records")
          .select("id, date, status, notes")
          .eq("school_id", effectiveSchoolId)
          .limit(2000),
      ]);

      const fullArchive = {
        exportedAt: now,
        schoolId: effectiveSchoolId,
        branches: branchesRes.data || [],
        members: profilesRes.data || [],
        fees: feesRes.data || [],
        attendance: attendanceRes.data || [],
      };

      exportContent = JSON.stringify(fullArchive, null, 2);
      rows = (profilesRes.data || []) as Record<string, unknown>[];
    } else if (input.resource === "students") {
      let query = admin
        .from("profiles")
        .select("id, name, email, role, phone, active, created_at")
        .eq("school_id", effectiveSchoolId)
        .eq("role", "student");
      if (effectiveBranchId) query = query.contains("branch_ids", [effectiveBranchId]);
      const { data } = await query.limit(5000);
      rows = (data || []) as Record<string, unknown>[];
    } else if (input.resource === "fees") {
      let query = admin
        .from("student_fees")
        .select("*")
        .eq("school_id", effectiveSchoolId);
      if (effectiveBranchId) query = query.eq("branch_id", effectiveBranchId);
      const { data } = await query.limit(5000);
      rows = (data || []) as Record<string, unknown>[];
    } else if (input.resource === "attendance") {
      let query = admin
        .from("attendance_records")
        .select("*")
        .eq("school_id", effectiveSchoolId);
      if (effectiveBranchId) query = query.eq("branch_id", effectiveBranchId);
      const { data } = await query.limit(5000);
      rows = (data || []) as Record<string, unknown>[];
    } else if (input.resource === "marks") {
      let query = admin
        .from("marks")
        .select("*")
        .eq("school_id", effectiveSchoolId);
      if (effectiveBranchId) query = query.eq("branch_id", effectiveBranchId);
      const { data } = await query.limit(5000);
      rows = (data || []) as Record<string, unknown>[];
    } else if (input.resource === "branches") {
      const { data } = await admin
        .from("branches")
        .select("*")
        .eq("school_id", effectiveSchoolId);
      rows = (data || []) as Record<string, unknown>[];
    } else {
      // Dynamic resources (expenses, payroll) from admin_records
      let query = admin
        .from("admin_records")
        .select("id, payload, updated_at")
        .eq("school_id", effectiveSchoolId)
        .eq("resource", input.resource);
      if (effectiveBranchId) query = query.eq("branch_id", effectiveBranchId);
      const { data } = await query.limit(5000);
      rows = (data?.map((d) => (d.payload as Record<string, unknown>)) || []) as Record<string, unknown>[];
    }

    if (input.resource !== "all") {
      if (input.format === "json") {
        exportContent = JSON.stringify(rows, null, 2);
      } else {
        exportContent = formatCsv(rows);
      }
    }

    const fileExt = input.resource === "all" ? "json" : input.format === "xlsx" ? "csv" : input.format;
    const filePath = `exports/${effectiveSchoolId}/${jobId}.${fileExt}`;
    const contentType = fileExt === "json" ? "application/json" : "text/csv; charset=utf-8";

    let downloadUrl: string | undefined;

    try {
      const { error: uploadError } = await admin.storage.from("school-files").upload(filePath, exportContent, {
        contentType,
        upsert: true,
      });

      if (!uploadError) {
        // Signed URL valid for 15 minutes (900 seconds)
        const { data: signed } = await admin.storage.from("school-files").createSignedUrl(filePath, 900);
        downloadUrl = signed?.signedUrl;
      }
    } catch {
      // If storage bucket is unconfigured, return row data directly
    }

    // Persist audit log
    await admin.from("admin_records").insert({
      id: jobId,
      school_id: effectiveSchoolId,
      branch_id: effectiveBranchId || null,
      resource: "audit_logs",
      version: 1,
      payload: {
        school_id: effectiveSchoolId,
        actor_id: profile.id,
        actor_name: profile.name,
        action: "DATA_EXPORTED",
        resource: input.resource,
        resource_id: jobId,
        details: { format: input.format, rowCount: rows.length, fileUrl: downloadUrl },
        timestamp: now,
      },
      updated_at: now,
    });

    return jsonResponse(req, {
      ok: true,
      data: {
        jobId,
        downloadUrl,
        content: downloadUrl ? undefined : exportContent,
        rowCount: rows.length,
        format: input.format,
        expiresInMinutes: 15,
      },
    });
  } catch (err: unknown) {
    return jsonError(req, err, 400);
  }
});
