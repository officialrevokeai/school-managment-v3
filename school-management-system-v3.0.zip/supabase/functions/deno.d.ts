// Local compile-time surface for the Deno APIs used by the deployed Edge Function.
declare const Deno: {
  env: { get(name: string): string | undefined };
  serve(handler: (request: Request) => Response | Promise<Response>): void;
};
