import { z } from "npm:zod@3.25.76";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller, requireMaster } from "../_shared/auth.ts";
import { provisionSchoolTenant } from "../_shared/provisioning.ts";

const inputSchema = z.object({
  name: z.string().trim().min(2).max(120),
  code: z
    .string()
    .trim()
    .min(2)
    .max(30)
    .regex(/^[A-Za-z0-9-]+$/),
  ownerEmail: z.string().email(),
  password: z.string().min(10).optional(),
  plan: z.enum(["Starter", "Growth", "Enterprise"]).default("Growth"),
  monthlyFee: z.number().nonnegative().max(10000000).default(5000),
  forcePasswordChange: z.boolean().default(true),
});

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    const masterCheck = requireMaster(req, auth.user, auth.profile);
    if (masterCheck) return masterCheck;

    const input = inputSchema.parse(await req.json());
    const origin = req.headers.get("origin");

    const result = await provisionSchoolTenant(
      auth.adminClient,
      input,
      auth.user.id,
      auth.user.email ?? "Master Admin",
      origin
    );

    return jsonResponse(req, result, 201);
  } catch (error) {
    return jsonError(req, error, 400);
  }
});
