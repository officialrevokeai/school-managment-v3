import { z } from "npm:zod@3.25.76";
import type { Json } from "../../../src/types/database.ts";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller, requireMaster } from "../_shared/auth.ts";

const inputSchema = z.object({
  schoolId: z.string().uuid(),
  action: z.enum(["suspend", "reactivate", "delete", "reset-owner", "extend-plan", "revoke-sessions"]),
  payload: z
    .object({
      plan: z.enum(["Starter", "Growth", "Enterprise"]).optional(),
      expiryDate: z.string().optional(),
      reason: z.string().optional(),
      newPassword: z.string().min(10).optional(),
    })
    .default({}),
});

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    const masterCheck = requireMaster(req, auth.user, auth.profile);
    if (masterCheck) return masterCheck;

    const input = inputSchema.parse(await req.json());
    const admin = auth.adminClient;
    const now = new Date().toISOString();

    // Load target school from schools table
    const { data: school, error: schoolFetchErr } = await admin
      .from("schools")
      .select("*")
      .eq("id", input.schoolId)
      .maybeSingle();

    if (schoolFetchErr || !school) {
      return jsonError(req, "School not found", 404);
    }

    let resultData: Record<string, unknown> = {};

    switch (input.action) {
      case "suspend": {
        await admin
          .from("schools")
          .update({ status: "Suspended", updated_at: now })
          .eq("id", input.schoolId);

        // Update admin_records cache
        const { data: schoolRecord } = await admin
          .from("admin_records")
          .select("payload")
          .eq("id", input.schoolId)
          .eq("resource", "schools")
          .maybeSingle();

        if (schoolRecord?.payload) {
          const payload = schoolRecord.payload as Record<string, unknown>;
          await admin
            .from("admin_records")
            .update({ payload: { ...payload, status: "Suspended" }, updated_at: now })
            .eq("id", input.schoolId);
        }

        // Revoke active sessions for all users of this school
        const { data: schoolUsers } = await admin
          .from("profiles")
          .select("id")
          .eq("school_id", input.schoolId);

        if (schoolUsers && schoolUsers.length > 0) {
          for (const u of schoolUsers) {
            await admin.auth.admin.signOut(u.id, "global");
          }
        }
        resultData = { status: "Suspended", revokedSessions: schoolUsers?.length ?? 0 };
        break;
      }

      case "reactivate": {
        await admin
          .from("schools")
          .update({ status: "Active", updated_at: now })
          .eq("id", input.schoolId);

        const { data: schoolRecord } = await admin
          .from("admin_records")
          .select("payload")
          .eq("id", input.schoolId)
          .eq("resource", "schools")
          .maybeSingle();

        if (schoolRecord?.payload) {
          const payload = schoolRecord.payload as Record<string, unknown>;
          await admin
            .from("admin_records")
            .update({ payload: { ...payload, status: "Active" }, updated_at: now })
            .eq("id", input.schoolId);
        }

        resultData = { status: "Active" };
        break;
      }

      case "delete": {
        // Soft delete school
        await admin
          .from("schools")
          .update({ status: "Deleted", updated_at: now })
          .eq("id", input.schoolId);

        const { data: schoolUsers } = await admin
          .from("profiles")
          .select("id")
          .eq("school_id", input.schoolId);

        if (schoolUsers) {
          for (const u of schoolUsers) {
            await admin.auth.admin.signOut(u.id, "global");
            await admin.from("profiles").update({ active: false }).eq("id", u.id);
          }
        }
        resultData = { status: "Deleted", purgedScheduled: true };
        break;
      }

      case "extend-plan": {
        const updates: { plan?: "Starter" | "Growth" | "Enterprise"; updated_at: string } = { updated_at: now };
        if (input.payload.plan) updates.plan = input.payload.plan;
        await admin.from("schools").update(updates).eq("id", input.schoolId);

        const { data: schoolRecord } = await admin
          .from("admin_records")
          .select("payload")
          .eq("id", input.schoolId)
          .eq("resource", "schools")
          .maybeSingle();

        if (schoolRecord?.payload && input.payload.plan) {
          const payload = schoolRecord.payload as Record<string, unknown>;
          await admin
            .from("admin_records")
            .update({ payload: { ...payload, plan: input.payload.plan }, updated_at: now })
            .eq("id", input.schoolId);
        }

        resultData = { updated: true, plan: input.payload.plan };
        break;
      }

      case "reset-owner": {
        const { data: ownerProfile } = await admin
          .from("profiles")
          .select("id, email")
          .eq("school_id", input.schoolId)
          .eq("role", "owner")
          .maybeSingle();

        if (!ownerProfile) {
          return jsonError(req, "School owner account not found", 404);
        }

        const newPwd = input.payload.newPassword || `Campus!${crypto.randomUUID().replaceAll("-", "")}`;
        
        // Preserve existing user app_metadata
        const { data: targetUser } = await admin.auth.admin.getUserById(ownerProfile.id);
        const existingAppMeta = targetUser?.user?.app_metadata || {};

        const { error: resetErr } = await admin.auth.admin.updateUserById(ownerProfile.id, {
          password: newPwd,
          app_metadata: { ...existingAppMeta, force_password_change: true },
        });

        if (resetErr) {
          return jsonError(req, resetErr.message, 400);
        }

        await admin.from("profiles").update({ must_change_password: true }).eq("id", ownerProfile.id);
        await admin.auth.admin.signOut(ownerProfile.id, "global");

        resultData = { email: ownerProfile.email, temporaryPassword: newPwd };
        break;
      }

      case "revoke-sessions": {
        const { data: schoolUsers } = await admin
          .from("profiles")
          .select("id")
          .eq("school_id", input.schoolId);

        if (schoolUsers && schoolUsers.length > 0) {
          for (const u of schoolUsers) {
            await admin.auth.admin.signOut(u.id, "global");
          }
        }
        resultData = { revokedCount: schoolUsers?.length ?? 0 };
        break;
      }
    }

    // Write audit log into admin_records
    await admin.from("admin_records").insert({
      id: crypto.randomUUID(),
      school_id: input.schoolId,
      branch_id: null,
      resource: "audit_logs",
      version: 1,
      payload: {
        school_id: input.schoolId,
        actor_id: auth.user.id,
        actor_name: auth.user.email ?? "Master Admin",
        action: `MASTER_${input.action.toUpperCase().replace("-", "_")}`,
        resource: "schools",
        resource_id: input.schoolId,
        details: {
          action: input.action,
          payload: input.payload,
          result: resultData,
        },
        timestamp: now,
      } as unknown as Json,
      updated_at: now,
    });

    return jsonResponse(req, { ok: true, data: resultData });
  } catch (error) {
    return jsonError(req, error, 400);
  }
});
