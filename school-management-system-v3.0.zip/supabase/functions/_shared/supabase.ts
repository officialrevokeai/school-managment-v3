import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2.118.0";
import type { Database } from "../../../src/types/database.ts";

export function getSupabaseUrl(): string {
  const url = Deno.env.get("SUPABASE_URL");
  if (!url) throw new Error("Missing SUPABASE_URL environment variable");
  return url;
}

export function getSupabaseAnonKey(): string {
  const key = Deno.env.get("SUPABASE_ANON_KEY");
  if (!key) throw new Error("Missing SUPABASE_ANON_KEY environment variable");
  return key;
}

export function getSupabaseServiceRoleKey(): string {
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!key) throw new Error("Missing SUPABASE_SERVICE_ROLE_KEY environment variable");
  return key;
}

/**
 * Returns an administrative Supabase client using the SERVICE_ROLE_KEY.
 * Bypasses RLS for secure background/admin operations.
 */
export function getAdminClient(): SupabaseClient<Database> {
  return createClient<Database>(getSupabaseUrl(), getSupabaseServiceRoleKey(), {
    auth: { persistSession: false },
  });
}

/**
 * Returns a caller-scoped Supabase client that carries the caller's JWT Authorization.
 */
export function getCallerClient(authHeader: string): SupabaseClient<Database> {
  return createClient<Database>(getSupabaseUrl(), getSupabaseAnonKey(), {
    global: { headers: { Authorization: authHeader } },
    auth: { persistSession: false },
  });
}
