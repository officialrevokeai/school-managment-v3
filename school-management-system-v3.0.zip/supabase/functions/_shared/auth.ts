import type { User, SupabaseClient } from "npm:@supabase/supabase-js@2.118.0";
import type { Database } from "../../../src/types/database.ts";
import { jsonError } from "./cors.ts";
import { getAdminClient, getCallerClient } from "./supabase.ts";

export interface CallerProfile {
  id: string;
  school_id: string | null;
  branch_ids: string[];
  role: "master" | "owner" | "principal" | "teacher" | "parent" | "student" | "accountant";
  name: string;
  active: boolean;
  email?: string;
}

export type AuthResult =
  | {
      ok: true;
      user: User;
      profile: CallerProfile | null;
      callerClient: SupabaseClient<Database>;
      adminClient: SupabaseClient<Database>;
    }
  | {
      ok: false;
      errorResponse: Response;
    };

/**
 * Authenticates the incoming request via the Bearer token in the Authorization header.
 * Validates the session with Supabase Auth and loads the caller's profile.
 */
export async function authenticateCaller(req: Request): Promise<AuthResult> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return {
      ok: false,
      errorResponse: jsonError(req, "Authentication required", 401),
    };
  }

  const callerClient = getCallerClient(authHeader);
  const {
    data: { user },
    error: userError,
  } = await callerClient.auth.getUser();

  if (userError || !user) {
    return {
      ok: false,
      errorResponse: jsonError(req, "Authentication invalid", 401),
    };
  }

  const adminClient = getAdminClient();
  const { data: profile } = await adminClient
    .from("profiles")
    .select("id, school_id, branch_ids, role, name, active, email")
    .eq("id", user.id)
    .maybeSingle();

  const formattedProfile: CallerProfile | null = profile
    ? {
        id: profile.id,
        school_id: profile.school_id,
        branch_ids: Array.isArray(profile.branch_ids) ? (profile.branch_ids as string[]) : [],
        role: profile.role as CallerProfile["role"],
        name: profile.name,
        active: profile.active ?? true,
        email: profile.email,
      }
    : null;

  return {
    ok: true,
    user,
    profile: formattedProfile,
    callerClient,
    adminClient,
  };
}

/**
 * Ensures the caller has the Master role in JWT claims or verified profile.
 */
export function requireMaster(
  req: Request,
  user: User,
  profile: CallerProfile | null
): Response | null {
  const isMasterClaim = user.app_metadata?.role === "master";
  const isMasterProfile = profile?.role === "master";

  if (!isMasterClaim && !isMasterProfile) {
    return jsonError(req, "Forbidden: Master role required", 403);
  }

  if (profile && !profile.active) {
    return jsonError(req, "Forbidden: Active master profile required", 403);
  }

  return null;
}

/**
 * Ensures the caller has one of the allowed roles and an active profile.
 */
export function requireRoles(
  req: Request,
  profile: CallerProfile | null,
  allowedRoles: Array<CallerProfile["role"]>
): Response | null {
  if (!profile || !profile.active) {
    return jsonError(req, "Active profile required", 403);
  }

  if (!allowedRoles.includes(profile.role)) {
    return jsonError(req, `Insufficient permissions. Allowed roles: ${allowedRoles.join(", ")}`, 403);
  }

  return null;
}
