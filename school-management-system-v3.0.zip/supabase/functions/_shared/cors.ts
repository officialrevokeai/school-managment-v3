// Centralized CORS & standard HTTP response helpers

export function getCorsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get("origin");
  const allowedOrigin = Deno.env.get("APP_ORIGIN");

  // If APP_ORIGIN is specified and matches or is wildcard, use it, else permit origin or fallback to *
  const resolvedOrigin =
    allowedOrigin && allowedOrigin !== "*"
      ? (origin && (origin === allowedOrigin || origin.startsWith(allowedOrigin)) ? origin : allowedOrigin)
      : (origin || "*");

  return {
    "Access-Control-Allow-Origin": resolvedOrigin,
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type, x-request-id, x-payment-signature, x-hub-signature-256",
    "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
    "Vary": "Origin",
  };
}

export function handleCors(req: Request): Response | null {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: getCorsHeaders(req) });
  }
  return null;
}

export function jsonResponse(
  req: Request,
  body: unknown,
  status = 200,
  extraHeaders?: Record<string, string>,
): Response {
  return Response.json(body, {
    status,
    headers: {
      ...getCorsHeaders(req),
      ...extraHeaders,
    },
  });
}

export function jsonError(
  req: Request,
  error: unknown,
  status = 400,
  extraHeaders?: Record<string, string>,
): Response {
  let message = "Internal error";
  if (typeof error === "string") {
    message = error;
  } else if (error && typeof error === "object") {
    if ("issues" in error && Array.isArray((error as { issues: { message: string }[] }).issues)) {
      message = (error as { issues: { message: string }[] }).issues.map((i) => i.message).join(", ");
    } else if (error instanceof Error) {
      message = error.message;
    } else if ("message" in error && typeof (error as { message: unknown }).message === "string") {
      message = (error as { message: string }).message;
    }
  }

  return Response.json(
    {
      ok: false,
      error: message,
    },
    {
      status,
      headers: {
        ...getCorsHeaders(req),
        ...extraHeaders,
      },
    },
  );
}
