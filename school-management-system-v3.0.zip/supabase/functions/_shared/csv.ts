/**
 * Safe CSV formatting and parsing utilities adhering to RFC 4180 and OWASP security guidelines.
 */

export function sanitizeCsvCell(val: unknown): string {
  if (val === null || val === undefined) return '""';
  let str = typeof val === "object" ? JSON.stringify(val) : String(val);
  // Formula injection prevention (OWASP CSV Injection rule: =, +, -, @, tab, cr)
  if (/^[=+@\-\t\r]/.test(str)) {
    str = `'${str}`;
  }
  return `"${str.replace(/"/g, '""')}"`;
}

export function formatCsv(rows: Record<string, unknown>[]): string {
  if (rows.length === 0) {
    return "\uFEFF";
  }
  const headers = Object.keys(rows[0]);
  const lines = [headers.map(sanitizeCsvCell).join(",")];
  for (const row of rows) {
    lines.push(headers.map((h) => sanitizeCsvCell(row[h])).join(","));
  }
  return "\uFEFF" + lines.join("\r\n");
}

export function parseCsvRows(content: string): { headers: string[]; rows: Record<string, string>[] } {
  const clean = content.replace(/^\uFEFF/, "").trim();
  if (!clean) return { headers: [], rows: [] };

  const parsedLines: string[][] = [];
  let currentRow: string[] = [];
  let currentField = "";
  let inQuotes = false;

  for (let i = 0; i < clean.length; i++) {
    const char = clean[i];
    const nextChar = clean[i + 1];

    if (inQuotes) {
      if (char === '"' && nextChar === '"') {
        currentField += '"';
        i++; // skip next quote
      } else if (char === '"') {
        inQuotes = false;
      } else {
        currentField += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ",") {
        currentRow.push(currentField.trim());
        currentField = "";
      } else if (char === "\r") {
        if (nextChar === "\n") i++;
        currentRow.push(currentField.trim());
        parsedLines.push(currentRow);
        currentRow = [];
        currentField = "";
      } else if (char === "\n") {
        currentRow.push(currentField.trim());
        parsedLines.push(currentRow);
        currentRow = [];
        currentField = "";
      } else {
        currentField += char;
      }
    }
  }

  if (currentField.length > 0 || currentRow.length > 0) {
    currentRow.push(currentField.trim());
    parsedLines.push(currentRow);
  }

  if (parsedLines.length === 0) return { headers: [], rows: [] };

  const headers = parsedLines[0].map((h) => h.replace(/^["']|["']$/g, "").trim());
  const rows: Record<string, string>[] = [];

  for (let i = 1; i < parsedLines.length; i++) {
    const values = parsedLines[i];
    if (values.length === 1 && !values[0]) continue; // skip blank line
    const record: Record<string, string> = {};
    headers.forEach((h, idx) => {
      record[h] = (values[idx] || "").replace(/^["']|["']$/g, "").trim();
    });
    rows.push(record);
  }

  return { headers, rows };
}
