import type { SupabaseClient } from "npm:@supabase/supabase-js@2.118.0";
import type { Database } from "../../../src/types/database.ts";

export interface ProvisionSchoolInput {
  name: string;
  code: string;
  ownerEmail: string;
  plan?: "Starter" | "Growth" | "Enterprise";
  monthlyFee?: number;
  password?: string;
  forcePasswordChange?: boolean;
}

export interface ProvisionSchoolResult {
  ok: true;
  school: unknown;
  email: string;
  password: string;
  loginUrl: string;
  data: {
    school: unknown;
    email: string;
    password: string;
    loginUrl: string;
  };
}

export async function provisionSchoolTenant(
  admin: SupabaseClient<Database>,
  input: ProvisionSchoolInput,
  actorId: string,
  actorEmail: string,
  origin?: string | null
): Promise<ProvisionSchoolResult> {
  const rawPassword =
    input.password ||
    `Campus!${crypto.randomUUID().replaceAll("-", "")}${crypto.randomUUID().slice(0, 8)}`;

  // 1. Create Auth user for school owner atomically
  const { data: account, error: accountError } = await admin.auth.admin.createUser({
    email: input.ownerEmail.toLowerCase(),
    password: rawPassword,
    email_confirm: true,
    app_metadata: {
      role: "owner",
      force_password_change: input.forcePasswordChange ?? true,
    },
  });

  if (accountError || !account.user) {
    throw new Error(accountError?.message ?? "Failed to create owner auth account");
  }

  const schoolId = crypto.randomUUID();
  const schoolRecord = {
    id: schoolId,
    schoolId,
    branchId: null,
    name: input.name,
    code: input.code.toLowerCase(),
    ownerEmail: input.ownerEmail.toLowerCase(),
    plan: input.plan ?? "Growth",
    monthlyFee: input.monthlyFee ?? 5000,
    status: "Active",
    version: 1,
    createdAt: new Date().toISOString().slice(0, 10),
  };

  try {
    // 2. Insert into relational public.schools table first to satisfy foreign keys
    const { error: schoolTableError } = await admin.from("schools").upsert({
      id: schoolId,
      name: input.name,
      code: input.code.toLowerCase(),
      owner_email: input.ownerEmail.toLowerCase(),
      plan: input.plan ?? "Growth",
      monthly_fee: input.monthlyFee ?? 5000,
      status: "Active",
    });

    if (schoolTableError) {
      console.warn("Relational schools table upsert notice:", schoolTableError.message);
    }

    // 3. Call transactional provision_school_record RPC
    const { data: provisionedData, error: rpcError } = await admin.rpc("provision_school_record", {
      p_school: schoolRecord,
      p_owner_id: account.user.id,
      p_actor: actorId,
    });

    if (rpcError) {
      throw new Error("School provisioning transaction failed: " + rpcError.message);
    }

    // 4. Update owner profile's app_metadata and profile linkage
    await admin.auth.admin.updateUserById(account.user.id, {
      app_metadata: {
        role: "owner",
        school_id: schoolId,
        force_password_change: input.forcePasswordChange ?? true,
      },
    });

    // 5. Write Platform Audit Log to admin_records
    const now = new Date().toISOString();
    await admin.from("admin_records").insert({
      id: crypto.randomUUID(),
      school_id: schoolId,
      branch_id: null,
      resource: "audit_logs",
      version: 1,
      payload: {
        school_id: schoolId,
        actor_id: actorId,
        actor_name: actorEmail || "Master Admin",
        action: "PLATFORM_PROVISION_SCHOOL",
        resource: "schools",
        resource_id: schoolId,
        details: {
          schoolName: input.name,
          code: input.code,
          ownerEmail: input.ownerEmail,
          plan: input.plan ?? "Growth",
        },
        timestamp: now,
      },
      updated_at: now,
    });

    const finalSchool = provisionedData || schoolRecord;
    const loginUrl = `${origin || "https://campus.app"}/login`;

    return {
      ok: true,
      school: finalSchool,
      email: input.ownerEmail.toLowerCase(),
      password: rawPassword,
      loginUrl,
      data: {
        school: finalSchool,
        email: input.ownerEmail.toLowerCase(),
        password: rawPassword,
        loginUrl,
      },
    };
  } catch (err) {
    // Rollback Auth user on failure
    await admin.auth.admin.deleteUser(account.user.id);
    throw err;
  }
}
