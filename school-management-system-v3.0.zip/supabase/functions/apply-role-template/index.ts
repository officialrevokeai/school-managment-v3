import { z } from "npm:zod@3.25.76";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller, requireMaster } from "../_shared/auth.ts";

const inputSchema = z.object({
  targetRole: z.enum(["owner", "principal", "teacher", "parent", "student", "accountant"]),
  permissions: z.array(z.string().min(2)),
  confirmPhrase: z.literal("APPLY TEMPLATE TO ALL SCHOOLS"),
});

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    const masterCheck = requireMaster(req, auth.user, auth.profile);
    if (masterCheck) return masterCheck;

    const input = inputSchema.parse(await req.json());
    const admin = auth.adminClient;
    const now = new Date().toISOString();

    // 1. Find existing template or generate valid UUID
    const { data: existingTpl } = await admin
      .from("admin_records")
      .select("id")
      .eq("resource", "role_templates")
      .contains("payload", { roleKey: input.targetRole })
      .maybeSingle();

    const templateId = existingTpl?.id || crypto.randomUUID();

    const { error: tplErr } = await admin.from("admin_records").upsert({
      id: templateId,
      school_id: "00000000-0000-0000-0000-000000000000",
      branch_id: null,
      resource: "role_templates",
      version: 1,
      payload: {
        roleKey: input.targetRole,
        permissions: input.permissions,
        updatedAt: now,
      },
      updated_at: now,
    });

    if (tplErr) {
      return jsonError(req, tplErr.message, 400);
    }

    // 2. Fetch existing school roles for this role key
    const { data: roles } = await admin
      .from("admin_records")
      .select("id, school_id, payload, version")
      .eq("resource", "roles");

    let updatedCount = 0;
    if (roles && roles.length > 0) {
      for (const r of roles) {
        const payload = r.payload as { name?: string; permissions?: string[]; isCustom?: boolean };
        if (payload?.name === input.targetRole && !payload?.isCustom) {
          await admin
            .from("admin_records")
            .update({
              payload: { ...payload, permissions: input.permissions, updatedAt: now },
              version: (r.version ?? 1) + 1,
              updated_at: now,
            })
            .eq("id", r.id);
          updatedCount++;
        }
      }
    }

    // 3. Platform Audit log
    await admin.from("admin_records").insert({
      id: crypto.randomUUID(),
      school_id: "00000000-0000-0000-0000-000000000000",
      branch_id: null,
      resource: "audit_logs",
      version: 1,
      payload: {
        school_id: null,
        actor_id: auth.user.id,
        actor_name: auth.user.email ?? "Master Admin",
        action: "PLATFORM_APPLY_ROLE_TEMPLATE",
        resource: "role_templates",
        resource_id: input.targetRole,
        details: {
          targetRole: input.targetRole,
          newPermissions: input.permissions,
          affectedSchoolsCount: updatedCount,
        },
        timestamp: now,
      },
      updated_at: now,
    });

    return jsonResponse(req, {
      ok: true,
      data: {
        role: input.targetRole,
        updatedSchoolsCount: updatedCount,
      },
    });
  } catch (error) {
    return jsonError(req, error, 400);
  }
});
