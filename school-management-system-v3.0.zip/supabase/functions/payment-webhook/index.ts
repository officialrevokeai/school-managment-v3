import { z } from "npm:zod@3.25.76";
import { getAdminClient } from "../_shared/supabase.ts";

const webhookSchema = z.object({
  event: z.string(),
  orderRef: z.string(),
  paymentId: z.string(),
  amount: z.number().positive(),
  studentFeeId: z.string().uuid(),
  method: z.enum(["Cash", "UPI", "Bank_Transfer", "Card", "Cheque"]).default("UPI"),
});

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  try {
    const secret = Deno.env.get("PAYMENT_WEBHOOK_SECRET") || "development-secret";
    const signature = req.headers.get("x-payment-signature");
    const rawBody = await req.text();

    if (!signature) {
      return new Response("Missing signature header", { status: 401 });
    }

    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      encoder.encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signatureBytes = await crypto.subtle.sign("HMAC", key, encoder.encode(rawBody));
    const expectedSignature = Array.from(new Uint8Array(signatureBytes))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");

    // Constant-time comparison
    let difference = signature.length ^ expectedSignature.length;
    for (let i = 0; i < expectedSignature.length; i++) {
      difference |= expectedSignature.charCodeAt(i) ^ (signature.charCodeAt(i) || 0);
    }

    if (difference !== 0) {
      return new Response("Invalid signature", { status: 401 });
    }

    const payload = webhookSchema.parse(JSON.parse(rawBody));
    const admin = getAdminClient();

    // Call fee_collect_payment RPC
    const { data, error } = await admin.rpc("fee_collect_payment", {
      p_student_fee_id: payload.studentFeeId,
      p_amount: payload.amount,
      p_method: payload.method,
      p_notes: `Webhook capture ref: ${payload.paymentId}`,
    });

    if (error) {
      return Response.json({ ok: false, error: error.message }, { status: 400 });
    }

    return Response.json({ ok: true, data });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Webhook error";
    return Response.json({ ok: false, error: msg }, { status: 400 });
  }
});
