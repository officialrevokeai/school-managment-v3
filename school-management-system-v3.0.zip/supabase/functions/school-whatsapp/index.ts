import { z } from "npm:zod@3.25.76";
import type { Json } from "../../../src/types/database.ts";
import { handleCors, jsonError, jsonResponse } from "../_shared/cors.ts";
import { authenticateCaller, requireRoles } from "../_shared/auth.ts";

const templateSchema = z.object({
  data: z.array(
    z.object({ name: z.string(), status: z.string(), language: z.string() }),
  ),
});

const inputSchema = z.object({
  operation: z.enum(["status", "send", "flush"]),
  recipient: z.string().optional(),
  template: z.string().optional(),
  branchId: z.string().uuid().optional(),
});

Deno.serve(async (req: Request) => {
  const preflight = handleCors(req);
  if (preflight) return preflight;

  if (req.method !== "POST") {
    return jsonError(req, "Method not allowed", 405);
  }

  try {
    const auth = await authenticateCaller(req);
    if (!auth.ok) return auth.errorResponse;

    const roleCheck = requireRoles(req, auth.profile, ["owner", "master"]);
    if (roleCheck) return roleCheck;

    const profile = auth.profile!;
    const client = auth.callerClient;
    const body = inputSchema.parse(await req.json());

    const token = Deno.env.get("WHATSAPP_TOKEN");
    const rawVersion = Deno.env.get("WHATSAPP_API_VERSION") || "v21.0";
    const version = rawVersion.startsWith("v") ? rawVersion : `v${rawVersion}`;
    const phone = Deno.env.get("WHATSAPP_PHONE_ID");
    const business = Deno.env.get("WHATSAPP_BUSINESS_ID");

    if (!token || !phone || !business) {
      return jsonResponse(req, {
        connected: false,
        message: "Configure the server-side WhatsApp provider secrets (WHATSAPP_TOKEN, WHATSAPP_PHONE_ID, WHATSAPP_BUSINESS_ID).",
        templates: [],
      });
    }

    const graph = `https://graph.facebook.com/${encodeURIComponent(version)}`;
    const providerHeaders = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };

    const response = await fetch(
      `${graph}/${encodeURIComponent(business)}/message_templates?fields=name,status,language&limit=100`,
      { headers: providerHeaders },
    );

    if (!response.ok) {
      throw new Error(`Provider template lookup failed (${response.status})`);
    }

    const templates = templateSchema
      .parse(await response.json())
      .data.filter((t) => t.status === "APPROVED");

    if (body.operation === "status") {
      return jsonResponse(req, {
        connected: true,
        message: "Meta Cloud API connected; approved templates loaded.",
        templates: templates.map(({ name, language }) => ({ name, language })),
      });
    }

    const userBranches = profile.branch_ids || [];
    if (profile.role !== "master" && body.branchId && userBranches.length > 0 && !userBranches.includes(body.branchId)) {
      return jsonError(req, "Assigned branch required", 403);
    }

    const effectiveBranchId = body.branchId || userBranches[0] || "00000000-0000-0000-0000-000000000000";

    const deliver = async (
      record: Record<string, Json>,
      recipient: string,
      name: string,
    ) => {
      const template = templates.find((t) => t.name === name);
      if (!template || !/^\+[1-9]\d{7,14}$/.test(recipient)) {
        throw new Error("An approved template and valid E.164 recipient are required");
      }

      const sent = await fetch(
        `${graph}/${encodeURIComponent(phone)}/messages`,
        {
          method: "POST",
          headers: providerHeaders,
          body: JSON.stringify({
            messaging_product: "whatsapp",
            to: recipient.replace("+", ""),
            type: "template",
            template: {
              name: template.name,
              language: { code: template.language },
            },
          }),
        },
      );

      if (!sent.ok) {
        throw new Error(`WhatsApp rejected the message (${sent.status})`);
      }

      const result = z
        .object({ messages: z.array(z.object({ id: z.string() })) })
        .parse(await sent.json());

      const data =
        record.data && typeof record.data === "object" && !Array.isArray(record.data)
          ? (record.data as Record<string, Json>)
          : {};

      const { error } = await client.rpc("workflow_save", {
        p_record: {
          ...record,
          data: {
            ...data,
            status: "Sent",
            providerId: result.messages[0]?.id ?? "",
          },
        },
      });

      if (error) throw error;
    };

    if (body.operation === "send") {
      const id = crypto.randomUUID();
      const record: Record<string, Json> = {
        id,
        schoolId: profile.school_id || "",
        branchId: effectiveBranchId,
        classId: null,
        studentId: null,
        authorId: auth.user.id,
        module: "whatsapp",
        version: 1,
        updatedAt: new Date().toISOString(),
        data: {
          title: "Template Broadcast",
          recipient: body.recipient ?? "",
          template: body.template ?? "",
          date: new Date().toISOString().slice(0, 10),
          status: "Queued",
          notes: "",
        },
      };

      await deliver(record, body.recipient ?? "", body.template ?? "");
      return jsonResponse(req, { ok: true, sent: true });
    }

    // Flush queued messages
    const { data, error } = await client.rpc("workflow_list", {
      p_module: "whatsapp",
      p_scope: { branchId: effectiveBranchId, pageSize: 50 },
    });

    if (error) throw error;

    const page = z.object({ rows: z.array(z.record(z.string(), z.unknown())) }).parse(data);
    let sentCount = 0;
    let failedCount = 0;

    for (const value of page.rows) {
      const row = z.record(z.string(), z.custom<Json>()).parse(value) as Record<string, Json>;
      const details =
        row.data && typeof row.data === "object" && !Array.isArray(row.data)
          ? (row.data as Record<string, unknown>)
          : {};

      if (details.status !== "Queued") continue;

      try {
        await deliver(
          row,
          String(details.recipient ?? ""),
          String(details.template ?? ""),
        );
        sentCount++;
      } catch (err: unknown) {
        failedCount++;
        await client.rpc("workflow_save", {
          p_record: {
            ...row,
            data: {
              ...(details as Record<string, Json>),
              status: "Failed",
              notes: err instanceof Error ? err.message : "Delivery failed",
            },
          },
        });
      }
    }

    return jsonResponse(req, { ok: true, sent: sentCount, failed: failedCount });
  } catch (error) {
    return jsonError(req, error, 400);
  }
});
