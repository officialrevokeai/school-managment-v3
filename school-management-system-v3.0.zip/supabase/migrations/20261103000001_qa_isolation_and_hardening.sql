-- Migration 20261103000001: QA Isolation, RLS Hardening, and Security Advisor Remediation

-- 1. Add is_qa column to all public tables for rigorous QA tenant isolation
DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'academic_years', 'admin_records', 'admissions', 'announcements', 'assignments',
    'attendance_records', 'audit_logs', 'branches', 'certificates', 'class_students',
    'classes', 'exams', 'expenses', 'export_jobs', 'fee_payments', 'fee_structures',
    'grades', 'homework_submissions', 'idempotency_keys', 'import_jobs', 'leaves',
    'lesson_plans', 'meetings', 'notifications', 'offline_payments', 'parent_students',
    'payment_orders', 'payroll_records', 'plans', 'profiles', 'rate_limits',
    'reconciliations', 'roles', 'school_classes', 'school_memberships', 'school_students',
    'school_workflows', 'schools', 'security_alerts', 'student_fees', 'subjects',
    'subscriptions', 'system_metrics', 'timetable_entries', 'user_consents',
    'user_role_overrides', 'vendors', 'whatsapp_templates', 'workflow_modules'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = t) THEN
      EXECUTE format('ALTER TABLE public.%I ADD COLUMN IF NOT EXISTS is_qa BOOLEAN NOT NULL DEFAULT false;', t);
    END IF;
  END LOOP;
END $$;

-- 2. Security Advisor: Fix set_updated_at function search_path
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = ''
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- 3. Security Advisor: Revoke excessive table and function grants from anon and PUBLIC
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL ROUTINES IN SCHEMA public FROM PUBLIC, anon;

-- Anon may only view public subscription plans (for landing/pricing page)
GRANT SELECT ON public.plans TO anon;

-- Grant EXECUTE on essential public RPCs exclusively to authenticated users
GRANT EXECUTE ON FUNCTION public.admin_summary(JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_list(TEXT, JSONB, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_save(TEXT, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_delete(TEXT, TEXT, JSONB, INT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_context(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_list(TEXT, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_save(JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_remove(UUID, INT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_delivery(TEXT, TEXT) TO service_role;
GRANT EXECUTE ON FUNCTION public.get_realtime_monitoring(UUID, UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.attendance_mark_bulk(UUID, UUID, DATE, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.marks_upsert_bulk(UUID, UUID, UUID, UUID, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fee_collect_payment(UUID, NUMERIC, public.payment_mode, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.search_global(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_user_role() TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_user_school_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_user_branch_ids() TO authenticated;

-- 4. Hardened admin_summary RPC (Enforces authentication & tenant isolation)
CREATE OR REPLACE FUNCTION public.admin_summary(p_scope JSONB)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_role TEXT;
  v_user_sid UUID;
  v_target_sid UUID;
  v_bid UUID;
  v_result JSONB;
BEGIN
  v_uid := auth.uid();
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required' USING ERRCODE = '42501';
  END IF;

  v_role := public.current_user_role();
  v_user_sid := public.current_user_school_id();

  IF v_role = 'master' THEN
    v_target_sid := NULLIF(p_scope->>'schoolId', '')::uuid;
  ELSE
    IF v_user_sid IS NULL THEN
      RAISE EXCEPTION 'User has no assigned school' USING ERRCODE = '42501';
    END IF;
    v_target_sid := v_user_sid;
  END IF;

  v_bid := NULLIF(p_scope->>'branchId', '')::uuid;

  WITH scoped AS (
    SELECT resource, payload FROM public.admin_records
    WHERE (v_target_sid IS NULL OR school_id = v_target_sid)
      AND (v_bid IS NULL OR branch_id = v_bid)
  ),
  finances AS (
    SELECT payload FROM scoped WHERE resource = 'finance'
  ),
  people AS (
    SELECT payload FROM scoped WHERE resource = 'users' AND payload->>'status' = 'Active'
  ),
  schools AS (
    SELECT payload FROM public.admin_records
    WHERE resource = 'schools'
      AND (COALESCE(p_scope->>'from', '') = '' OR LEFT(payload->>'createdAt', 10) >= p_scope->>'from')
      AND (COALESCE(p_scope->>'to', '') = '' OR LEFT(payload->>'createdAt', 10) <= p_scope->>'to')
  ),
  months AS (
    SELECT generate_series(date_trunc('month', NOW()) - INTERVAL '5 months', date_trunc('month', NOW()), INTERVAL '1 month') AS month
  ),
  revenue AS (
    SELECT
      to_char(month, 'Mon') AS label,
      month,
      COALESCE(SUM((payload->>'amount')::numeric) FILTER (WHERE payload->>'kind' = 'Income'), 0) AS income,
      COALESCE(SUM((payload->>'amount')::numeric) FILTER (WHERE payload->>'kind' = 'Expense'), 0) AS expense
    FROM months
    LEFT JOIN finances ON LEFT(payload->>'date', 7) = to_char(month, 'YYYY-MM') AND payload->>'status' = 'Paid'
    GROUP BY month
  )
  SELECT jsonb_build_object(
    'students', (SELECT COUNT(*) FROM people WHERE payload->>'role' = 'student'),
    'staff', (SELECT COUNT(*) FROM people WHERE payload->>'role' IN ('teacher', 'principal', 'accountant')),
    'attendance', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('label', to_char(month::date, 'Mon'), 'value', rate) ORDER BY month)
      FROM (
        SELECT LEFT(payload->>'date', 7) || '-01' AS month,
               ROUND(100.0 * SUM((payload->>'present')::numeric) / NULLIF(SUM((payload->>'total')::numeric), 0), 1) AS rate
        FROM scoped WHERE resource = 'analytics' GROUP BY LEFT(payload->>'date', 7)
      ) monthly WHERE rate IS NOT NULL
    ), '[]'::jsonb),
    'income', COALESCE((SELECT SUM((payload->>'amount')::numeric) FROM finances WHERE payload->>'kind' = 'Income' AND payload->>'status' = 'Paid'), 0),
    'expenses', COALESCE((SELECT SUM((payload->>'amount')::numeric) FROM finances WHERE payload->>'kind' = 'Expense' AND payload->>'status' = 'Paid'), 0),
    'outstanding', COALESCE((SELECT SUM((payload->>'amount')::numeric) FROM finances WHERE payload->>'kind' = 'Income' AND payload->>'status' <> 'Paid'), 0),
    'schools', (SELECT COUNT(*) FROM schools),
    'active', (SELECT COUNT(*) FROM schools WHERE payload->>'status' = 'Active'),
    'suspended', (SELECT COUNT(*) FROM schools WHERE payload->>'status' <> 'Active'),
    'mrr', COALESCE((SELECT SUM((payload->>'monthlyFee')::numeric) FROM schools WHERE payload->>'status' = 'Active'), 0),
    'revenue', CASE
      WHEN v_role = 'master' THEN
        COALESCE((
          SELECT jsonb_agg(jsonb_build_object('label', payload->>'code', 'value', CASE WHEN payload->>'status' = 'Active' THEN (payload->>'monthlyFee')::numeric ELSE 0 END))
          FROM (SELECT payload FROM schools ORDER BY (payload->>'monthlyFee')::numeric DESC LIMIT 10) top_schools
        ), '[]'::jsonb)
      ELSE
        COALESCE((SELECT jsonb_agg(jsonb_build_object('label', label, 'value', income, 'secondary', expense) ORDER BY month) FROM revenue), '[]'::jsonb)
    END,
    'enrollment', CASE
      WHEN v_role = 'master' THEN
        COALESCE((
          SELECT jsonb_agg(jsonb_build_object('label', plan, 'value', (SELECT COUNT(*) FROM schools WHERE payload->>'plan' = plan AND payload->>'status' = 'Active')))
          FROM unnest(ARRAY['Starter', 'Growth', 'Enterprise']) plan
        ), '[]'::jsonb)
      ELSE
        COALESCE((
          SELECT jsonb_agg(jsonb_build_object('label', b.payload->>'code', 'value', (SELECT COUNT(*) FROM people p WHERE p.payload->>'branchId' = b.payload->>'id' AND p.payload->>'role' = 'student')))
          FROM scoped b WHERE b.resource = 'branches'
        ), '[]'::jsonb)
    END
  ) INTO v_result;

  RETURN v_result;
END;
$$;

-- 5. Hardened admin_list RPC
CREATE OR REPLACE FUNCTION public.admin_list(p_resource TEXT, p_scope JSONB, p_options JSONB)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_role TEXT;
  v_user_sid UUID;
  v_user_bids UUID[];
  v_sid UUID;
  v_bid UUID;
  v_search TEXT;
  v_page INT;
  v_page_size INT;
  v_result JSONB;
BEGIN
  v_uid := auth.uid();
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required' USING ERRCODE = '42501';
  END IF;

  v_role := public.current_user_role();
  v_user_sid := public.current_user_school_id();
  v_user_bids := public.current_user_branch_ids();

  IF v_role = 'master' THEN
    v_sid := NULLIF(p_scope->>'schoolId', '')::uuid;
  ELSE
    IF v_user_sid IS NULL THEN
      RAISE EXCEPTION 'User has no assigned school' USING ERRCODE = '42501';
    END IF;
    v_sid := v_user_sid;
  END IF;

  v_bid := NULLIF(p_scope->>'branchId', '')::uuid;
  IF v_role = 'principal' AND v_bid IS NOT NULL THEN
    IF NOT (v_bid = ANY(v_user_bids)) THEN
      RAISE EXCEPTION 'Branch access denied' USING ERRCODE = '42501';
    END IF;
  END IF;

  IF v_role IN ('teacher', 'student', 'parent') AND p_resource IN ('finance', 'settings', 'roles', 'audit', 'schools') THEN
    RAISE EXCEPTION 'Resource access denied' USING ERRCODE = '42501';
  END IF;

  IF v_role = 'accountant' AND p_resource IN ('roles', 'settings', 'schools') THEN
    RAISE EXCEPTION 'Resource access denied' USING ERRCODE = '42501';
  END IF;

  v_search := COALESCE(p_options->>'search', '');
  v_page := GREATEST(0, COALESCE((p_options->>'page')::int, 0));
  v_page_size := LEAST(500, GREATEST(1, COALESCE((p_options->>'pageSize')::int, 20)));

  WITH filtered AS (
    SELECT payload, version, updated_at
    FROM public.admin_records
    WHERE resource = p_resource
      AND (v_sid IS NULL OR school_id = v_sid)
      AND (v_bid IS NULL OR branch_id = v_bid)
      AND (v_search = '' OR (payload)::text ILIKE '%' || v_search || '%')
    ORDER BY updated_at DESC
  ),
  paged AS (
    SELECT payload FROM filtered
    LIMIT v_page_size OFFSET (v_page * v_page_size)
  )
  SELECT jsonb_build_object(
    'rows', COALESCE((SELECT jsonb_agg(payload) FROM paged), '[]'::jsonb),
    'total', (SELECT COUNT(*) FROM filtered)
  ) INTO v_result;

  RETURN v_result;
END;
$$;

-- 6. Hardened admin_save RPC
CREATE OR REPLACE FUNCTION public.admin_save(p_resource TEXT, p_record JSONB)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_role TEXT;
  v_user_sid UUID;
  v_rid UUID;
  v_sid UUID;
  v_bid UUID;
  v_version INT;
  v_next_version INT;
  v_result JSONB;
  v_is_qa BOOLEAN;
BEGIN
  v_uid := auth.uid();
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required' USING ERRCODE = '42501';
  END IF;

  v_role := public.current_user_role();
  v_user_sid := public.current_user_school_id();

  IF v_role NOT IN ('master', 'owner', 'principal', 'accountant') THEN
    RAISE EXCEPTION 'Administrative write permission denied' USING ERRCODE = '42501';
  END IF;

  v_rid := (p_record->>'id')::uuid;
  v_sid := (p_record->>'schoolId')::uuid;

  IF v_role <> 'master' THEN
    IF v_sid IS NULL OR v_sid <> v_user_sid THEN
      RAISE EXCEPTION 'Cannot modify records of another school' USING ERRCODE = '42501';
    END IF;
  END IF;

  IF v_role = 'principal' AND p_resource IN ('finance', 'roles', 'settings', 'schools') THEN
    RAISE EXCEPTION 'Principal not authorized to modify resource %', p_resource USING ERRCODE = '42501';
  END IF;

  IF v_role = 'accountant' AND p_resource IN ('roles', 'settings', 'schools', 'branches', 'users') THEN
    RAISE EXCEPTION 'Accountant not authorized to modify resource %', p_resource USING ERRCODE = '42501';
  END IF;

  v_bid := NULLIF(p_record->>'branchId', '')::uuid;
  v_version := COALESCE((p_record->>'version')::int, 0);
  v_next_version := v_version + 1;
  v_is_qa := COALESCE((p_record->>'isQa')::boolean, (p_record->>'is_qa')::boolean, false);

  v_result := p_record || jsonb_build_object('version', v_next_version, 'updatedAt', NOW());

  INSERT INTO public.admin_records(id, school_id, branch_id, resource, payload, version, updated_at, is_qa)
  VALUES (v_rid, v_sid, v_bid, p_resource, v_result, v_next_version, NOW(), v_is_qa)
  ON CONFLICT (id) DO UPDATE SET
    payload = EXCLUDED.payload,
    version = EXCLUDED.version,
    branch_id = EXCLUDED.branch_id,
    updated_at = NOW(),
    is_qa = EXCLUDED.is_qa;

  RETURN v_result;
END;
$$;

-- 7. Hardened admin_delete RPC
CREATE OR REPLACE FUNCTION public.admin_delete(p_resource TEXT, p_id TEXT, p_scope JSONB, p_version INT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_role TEXT;
  v_user_sid UUID;
  v_uuid UUID;
  v_sid UUID;
BEGIN
  v_uid := auth.uid();
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required' USING ERRCODE = '42501';
  END IF;

  v_role := public.current_user_role();
  v_user_sid := public.current_user_school_id();

  IF v_role NOT IN ('master', 'owner', 'principal') THEN
    RAISE EXCEPTION 'Administrative delete permission denied' USING ERRCODE = '42501';
  END IF;

  v_uuid := p_id::uuid;
  v_sid := (p_scope->>'schoolId')::uuid;

  IF v_role <> 'master' THEN
    IF v_sid IS NULL OR v_sid <> v_user_sid THEN
      RAISE EXCEPTION 'Cannot delete records of another school' USING ERRCODE = '42501';
    END IF;
  END IF;

  IF v_role = 'principal' AND p_resource IN ('finance', 'roles', 'settings', 'schools') THEN
    RAISE EXCEPTION 'Principal not authorized to delete resource %', p_resource USING ERRCODE = '42501';
  END IF;

  DELETE FROM public.admin_records
  WHERE id = v_uuid AND school_id = v_sid AND resource = p_resource;

  RETURN jsonb_build_object('deleted', true);
END;
$$;

-- 8. Hardened workflow_context RPC
CREATE OR REPLACE FUNCTION public.workflow_context(p_branch UUID)
RETURNS JSONB
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  WITH auth_check AS (
    SELECT 
      auth.uid() as uid,
      public.current_user_role() as role,
      public.current_user_school_id() as school_id,
      public.current_user_branch_ids() as branch_ids
  ),
  valid_access AS (
    SELECT 1 FROM auth_check
    WHERE uid IS NOT NULL
      AND (
        role IN ('master', 'owner')
        OR (p_branch = ANY(branch_ids))
      )
  )
  SELECT CASE 
    WHEN NOT EXISTS (SELECT 1 FROM valid_access) THEN
      jsonb_build_object('students', '[]'::jsonb, 'classes', '[]'::jsonb)
    ELSE
      jsonb_build_object(
        'students', COALESCE((
          SELECT jsonb_agg(jsonb_build_object('id', id, 'name', name, 'classId', class_id, 'branchId', branch_id) ORDER BY name)
          FROM public.school_students WHERE branch_id = p_branch
        ), '[]'::jsonb),
        'classes', COALESCE((
          SELECT jsonb_agg(jsonb_build_object('id', id, 'name', name, 'branchId', branch_id) ORDER BY name)
          FROM public.school_classes WHERE branch_id = p_branch
        ), '[]'::jsonb)
      )
  END;
$$;

-- 9. Hardened workflow_list RPC
CREATE OR REPLACE FUNCTION public.workflow_list(p_module TEXT, p_scope JSONB)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_role TEXT;
  v_user_sid UUID;
  v_user_bids UUID[];
  v_bid UUID;
  v_result JSONB;
BEGIN
  v_uid := auth.uid();
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required' USING ERRCODE = '42501';
  END IF;

  v_role := public.current_user_role();
  v_user_sid := public.current_user_school_id();
  v_user_bids := public.current_user_branch_ids();
  v_bid := NULLIF(p_scope->>'branchId', '')::uuid;

  IF v_role <> 'master' THEN
    IF v_bid IS NOT NULL AND v_role IN ('principal', 'teacher') AND NOT (v_bid = ANY(v_user_bids)) THEN
      RAISE EXCEPTION 'Branch access denied' USING ERRCODE = '42501';
    END IF;
  END IF;

  WITH accessible AS (
    SELECT * FROM public.school_workflows
    WHERE (v_role = 'master' OR school_id = v_user_sid)
      AND (v_bid IS NULL OR branch_id = v_bid)
      AND (COALESCE(p_scope->>'classId', '') = '' OR class_id IS NULL OR class_id = (p_scope->>'classId')::uuid)
      AND (
        v_role IN ('master', 'owner', 'principal', 'accountant')
        OR (v_role = 'teacher' AND (v_bid IS NULL OR v_bid = ANY(v_user_bids)))
        OR (v_role IN ('parent', 'student') AND (student_id IS NULL OR student_id = v_uid OR student_id IN (SELECT student_id FROM public.parent_students WHERE parent_id = v_uid)))
      )
      AND (COALESCE(p_scope->>'studentId', '') = '' OR student_id IS NULL OR student_id = (p_scope->>'studentId')::uuid)
  ),
  matching AS (
    SELECT * FROM accessible
    WHERE (p_module = 'all' OR module = p_module)
      AND (COALESCE(p_scope->>'date', '') = '' OR payload->'data'->>'date' = p_scope->>'date')
      AND (COALESCE(p_scope->>'title', '') = '' OR payload->'data'->>'title' = p_scope->>'title')
      AND (COALESCE(p_scope->>'subject', '') = '' OR payload->'data'->>'subject' = p_scope->>'subject')
      AND (COALESCE(p_scope->>'search', '') = '' OR (payload->'data')::text ILIKE '%' || (p_scope->>'search') || '%')
  ),
  paged AS (
    SELECT * FROM matching
    ORDER BY updated_at DESC, id
    LIMIT LEAST(500, GREATEST(1, COALESCE((p_scope->>'pageSize')::int, 12)))
    OFFSET GREATEST(0, COALESCE((p_scope->>'page')::int, 0)) * LEAST(500, GREATEST(1, COALESCE((p_scope->>'pageSize')::int, 12)))
  )
  SELECT jsonb_build_object(
    'rows', COALESCE((SELECT jsonb_agg(payload || jsonb_build_object('version', version, 'updatedAt', updated_at) ORDER BY updated_at DESC, id) FROM paged), '[]'::jsonb),
    'total', (SELECT COUNT(*) FROM matching),
    'counts', COALESCE((SELECT jsonb_object_agg(module, count) FROM (SELECT module, COUNT(*) FROM accessible GROUP BY module) c), '{}'::jsonb)
  ) INTO v_result;

  RETURN v_result;
END;
$$;

-- 10. Hardened workflow_save RPC
CREATE OR REPLACE FUNCTION public.workflow_save(p_record JSONB)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_role TEXT;
  v_user_sid UUID;
  v_user_bids UUID[];
  v_rid UUID;
  v_sid UUID;
  v_bid UUID;
  v_cid UUID;
  v_student UUID;
  v_author UUID;
  v_module TEXT;
  v_version INT;
  v_next_version INT;
  v_result JSONB;
  v_is_qa BOOLEAN;
BEGIN
  v_uid := auth.uid();
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required' USING ERRCODE = '42501';
  END IF;

  v_role := public.current_user_role();
  v_user_sid := public.current_user_school_id();
  v_user_bids := public.current_user_branch_ids();

  v_rid := (p_record->>'id')::uuid;
  v_sid := (p_record->>'schoolId')::uuid;
  v_bid := (p_record->>'branchId')::uuid;

  IF v_role <> 'master' THEN
    IF v_sid IS NULL OR v_sid <> v_user_sid THEN
      RAISE EXCEPTION 'Cannot modify workflows of another school' USING ERRCODE = '42501';
    END IF;
    IF v_role IN ('principal', 'teacher') AND NOT (v_bid = ANY(v_user_bids)) THEN
      RAISE EXCEPTION 'Cannot modify workflows outside assigned branch' USING ERRCODE = '42501';
    END IF;
  END IF;

  v_module := p_record->>'module';
  IF v_role IN ('parent', 'student') AND v_module NOT IN ('leaves') THEN
    RAISE EXCEPTION 'Students/Parents cannot create workflow records in module %', v_module USING ERRCODE = '42501';
  END IF;
  IF v_role = 'accountant' AND v_module IN ('marks', 'lessons', 'performance') THEN
    RAISE EXCEPTION 'Accountants cannot modify academic workflow records' USING ERRCODE = '42501';
  END IF;

  v_cid := NULLIF(p_record->>'classId', '')::uuid;
  v_student := NULLIF(p_record->>'studentId', '')::uuid;
  v_author := COALESCE(NULLIF(p_record->>'authorId', '')::uuid, v_uid);
  v_version := COALESCE((p_record->>'version')::int, 0);
  v_next_version := v_version + 1;
  v_is_qa := COALESCE((p_record->>'isQa')::boolean, (p_record->>'is_qa')::boolean, false);

  v_result := p_record || jsonb_build_object('version', v_next_version, 'updatedAt', NOW());

  INSERT INTO public.school_workflows(id, school_id, branch_id, class_id, student_id, author_id, module, version, payload, updated_at, is_qa)
  VALUES (v_rid, v_sid, v_bid, v_cid, v_student, v_author, v_module, v_next_version, v_result, NOW(), v_is_qa)
  ON CONFLICT (id) DO UPDATE SET
    payload = EXCLUDED.payload,
    version = EXCLUDED.version,
    updated_at = NOW(),
    is_qa = EXCLUDED.is_qa;

  RETURN v_result;
END;
$$;

-- 11. Hardened workflow_remove RPC
CREATE OR REPLACE FUNCTION public.workflow_remove(p_id UUID, p_version INT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_role TEXT;
  v_user_sid UUID;
  v_user_bids UUID[];
  v_rec_sid UUID;
  v_rec_bid UUID;
  v_rec_author UUID;
BEGIN
  v_uid := auth.uid();
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required' USING ERRCODE = '42501';
  END IF;

  v_role := public.current_user_role();
  v_user_sid := public.current_user_school_id();
  v_user_bids := public.current_user_branch_ids();

  SELECT school_id, branch_id, author_id INTO v_rec_sid, v_rec_bid, v_rec_author
  FROM public.school_workflows WHERE id = p_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('deleted', false, 'reason', 'not_found');
  END IF;

  IF v_role <> 'master' THEN
    IF v_rec_sid <> v_user_sid THEN
      RAISE EXCEPTION 'Cross-tenant deletion denied' USING ERRCODE = '42501';
    END IF;
    IF v_role IN ('principal', 'teacher') AND NOT (v_rec_bid = ANY(v_user_bids)) THEN
      RAISE EXCEPTION 'Branch deletion denied' USING ERRCODE = '42501';
    END IF;
    IF v_role IN ('parent', 'student') AND v_rec_author <> v_uid THEN
      RAISE EXCEPTION 'Family deletion denied' USING ERRCODE = '42501';
    END IF;
  END IF;

  DELETE FROM public.school_workflows WHERE id = p_id;
  RETURN jsonb_build_object('deleted', true);
END;
$$;
