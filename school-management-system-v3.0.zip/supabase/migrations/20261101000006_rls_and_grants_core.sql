-- Migration 000006: RLS & Explicit Grants - Core Platform & Identity
-- Enables RLS on platform, school, role, and profile tables and establishes base grants.

-- 1. Explicit Grants (Revoke permissive defaults, assign minimal operational grants)
REVOKE ALL ON SCHEMA public FROM anon, authenticated;
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- Public read-only reference data
GRANT SELECT ON public.plans TO anon, authenticated;
-- Authenticated base tables
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.schools TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.branches TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.roles TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.academic_years TO authenticated;
GRANT SELECT, UPDATE ON public.notifications TO authenticated;
GRANT SELECT ON public.audit_logs TO authenticated;
-- Service role has full administrative access
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;

-- 2. Enable RLS on core tables
ALTER TABLE public.schools ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.academic_years ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_role_overrides ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- 3. RLS Policies: Plans (Public read)
CREATE POLICY "Public can view active subscription plans"
  ON public.plans FOR SELECT
  USING (true);

-- 4. RLS Policies: Schools
CREATE POLICY "Master admin can view all schools"
  ON public.schools FOR SELECT
  TO authenticated
  USING ((SELECT public.current_user_role()) = 'master');

CREATE POLICY "Master admin can manage all schools"
  ON public.schools FOR ALL
  TO authenticated
  USING ((SELECT public.current_user_role()) = 'master');

CREATE POLICY "School users can view own school"
  ON public.schools FOR SELECT
  TO authenticated
  USING (id = (SELECT public.current_user_school_id()));

CREATE POLICY "Owner can update own school"
  ON public.schools FOR UPDATE
  TO authenticated
  USING (
    id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) = 'owner'
  );

-- 5. RLS Policies: Branches
CREATE POLICY "Master can view all branches"
  ON public.branches FOR SELECT
  TO authenticated
  USING ((SELECT public.current_user_role()) = 'master');

CREATE POLICY "Users can view assigned school branches"
  ON public.branches FOR SELECT
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (
      (SELECT public.current_user_role()) IN ('owner', 'accountant')
      OR id = ANY((SELECT public.current_user_branch_ids()))
    )
  );

CREATE POLICY "Owner can manage school branches"
  ON public.branches FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) = 'owner'
  );

-- 6. RLS Policies: Roles & Policies
CREATE POLICY "Users can view roles within own school or system roles"
  ON public.roles FOR SELECT
  TO authenticated
  USING (
    school_id IS NULL
    OR school_id = (SELECT public.current_user_school_id())
    OR (SELECT public.current_user_role()) = 'master'
  );

CREATE POLICY "Owner can manage school custom roles"
  ON public.roles FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) = 'owner'
  );

-- 7. RLS Policies: Profiles
CREATE POLICY "Master can view all profiles for platform management"
  ON public.profiles FOR SELECT
  TO authenticated
  USING ((SELECT public.current_user_role()) = 'master');

CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (id = (SELECT auth.uid()));

CREATE POLICY "Users can update own basic profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (id = (SELECT auth.uid()))
  WITH CHECK (id = (SELECT auth.uid()));

CREATE POLICY "Owner and Principal can view profiles within school"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (
      (SELECT public.current_user_role()) = 'owner'
      OR (
        (SELECT public.current_user_role()) = 'principal'
        AND branch_ids && (SELECT public.current_user_branch_ids())
      )
    )
  );

-- 8. RLS Policies: Notifications
CREATE POLICY "Users can view own notifications"
  ON public.notifications FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

CREATE POLICY "Users can mark own notifications as read"
  ON public.notifications FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- 9. RLS Policies: Audit Logs
CREATE POLICY "Owner and Principal can view school audit logs"
  ON public.audit_logs FOR SELECT
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('owner', 'principal')
  );
