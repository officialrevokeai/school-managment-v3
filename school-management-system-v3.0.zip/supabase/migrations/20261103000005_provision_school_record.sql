-- Migration: Add missing provision_school_record RPC for atomic school onboarding
CREATE OR REPLACE FUNCTION public.provision_school_record(
  p_school JSONB,
  p_owner_id UUID,
  p_actor UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_school_id UUID;
  v_branch_id UUID;
  v_name TEXT;
  v_code TEXT;
  v_owner_email TEXT;
  v_plan TEXT;
  v_monthly_fee NUMERIC;
BEGIN
  v_school_id := COALESCE((p_school->>'id')::UUID, gen_random_uuid());
  v_name := p_school->>'name';
  v_code := p_school->>'code';
  v_owner_email := p_school->>'ownerEmail';
  v_plan := COALESCE(p_school->>'plan', 'Growth');
  v_monthly_fee := COALESCE((p_school->>'monthlyFee')::numeric, 5000.00);

  -- 1. Ensure school exists in public.schools
  INSERT INTO public.schools (id, name, code, status, plan, monthly_fee, owner_email, created_at, updated_at)
  VALUES (
    v_school_id,
    v_name,
    v_code,
    'Active'::public.school_status,
    v_plan::public.plan_tier,
    v_monthly_fee,
    v_owner_email,
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    code = EXCLUDED.code,
    plan = EXCLUDED.plan,
    monthly_fee = EXCLUDED.monthly_fee,
    owner_email = EXCLUDED.owner_email,
    updated_at = NOW();

  -- 2. Create default main campus branch
  v_branch_id := gen_random_uuid();
  INSERT INTO public.branches (id, school_id, name, code, short_name, city, principal_name, capacity, status, created_at, updated_at)
  VALUES (
    v_branch_id,
    v_school_id,
    'Main Campus',
    v_code || '-MAIN',
    'MAIN',
    'City',
    'Owner / Admin',
    500,
    'Active'::public.branch_status,
    NOW(),
    NOW()
  );

  -- 3. Create or update owner profile in public.profiles
  INSERT INTO public.profiles (id, school_id, branch_ids, role, name, email, active, created_at, updated_at)
  VALUES (
    p_owner_id,
    v_school_id,
    ARRAY[v_branch_id],
    'owner'::public.user_role,
    v_name || ' Owner',
    v_owner_email,
    true,
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    school_id = EXCLUDED.school_id,
    branch_ids = EXCLUDED.branch_ids,
    role = 'owner'::public.user_role,
    active = true,
    updated_at = NOW();

  -- 4. Insert into admin_records for schools resource
  INSERT INTO public.admin_records (id, school_id, branch_id, resource, payload, version, updated_at)
  VALUES (
    v_school_id,
    v_school_id,
    null,
    'schools',
    p_school || jsonb_build_object(
      'id', v_school_id,
      'schoolId', v_school_id,
      'branchId', null,
      'version', 1,
      'studentCount', 0,
      'branchCount', 1,
      'status', 'Active',
      'createdAt', to_char(NOW(), 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')
    ),
    1,
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    payload = EXCLUDED.payload,
    version = EXCLUDED.version,
    updated_at = NOW();

  -- 5. Insert default roles into admin_records
  INSERT INTO public.admin_records (id, school_id, branch_id, resource, payload, version, updated_at)
  VALUES 
    (gen_random_uuid(), v_school_id, null, 'roles', jsonb_build_object('id', gen_random_uuid(), 'schoolId', v_school_id, 'branchId', null, 'version', 1, 'name', 'Principal', 'role', 'principal', 'custom', false, 'permissions', jsonb_build_array('workspace.read', 'users.manage', 'academics.read', 'attendance.manage')), 1, NOW()),
    (gen_random_uuid(), v_school_id, null, 'roles', jsonb_build_object('id', gen_random_uuid(), 'schoolId', v_school_id, 'branchId', null, 'version', 1, 'name', 'Teacher', 'role', 'teacher', 'custom', false, 'permissions', jsonb_build_array('workspace.read', 'academics.read', 'attendance.manage')), 1, NOW()),
    (gen_random_uuid(), v_school_id, null, 'roles', jsonb_build_object('id', gen_random_uuid(), 'schoolId', v_school_id, 'branchId', null, 'version', 1, 'name', 'Accountant', 'role', 'accountant', 'custom', false, 'permissions', jsonb_build_array('workspace.read', 'finance.manage')), 1, NOW())
  ON CONFLICT DO NOTHING;

  RETURN p_school || jsonb_build_object(
    'id', v_school_id,
    'schoolId', v_school_id,
    'branchId', null,
    'branchCount', 1,
    'studentCount', 0
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION public.provision_school_record(JSONB, UUID, UUID) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.provision_school_record(JSONB, UUID, UUID) FROM anon;
GRANT EXECUTE ON FUNCTION public.provision_school_record(JSONB, UUID, UUID) TO service_role;
