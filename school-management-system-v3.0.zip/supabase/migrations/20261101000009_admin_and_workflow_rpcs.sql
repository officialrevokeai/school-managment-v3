-- Migration 000009: Admin and Workflow RPCs
-- Provides optimized and secure functions for admin panels and domain workflows.

CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM public, anon, authenticated;
GRANT USAGE ON SCHEMA private TO service_role;

-- Helper: Verify school is active
CREATE OR REPLACE FUNCTION private.school_active(p_sid UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.schools
    WHERE id = p_sid AND status = 'Active'
  );
$$;

-- 1. admin_summary RPC
CREATE OR REPLACE FUNCTION public.admin_summary(p_scope JSONB)
RETURNS JSONB
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  WITH scoped AS (
    SELECT resource, payload FROM public.admin_records
    WHERE school_id = (p_scope->>'schoolId')::uuid
      AND (COALESCE(p_scope->>'branchId', '') = '' OR branch_id = (p_scope->>'branchId')::uuid)
  ),
  finances AS (
    SELECT payload FROM scoped WHERE resource = 'finance'
  ),
  people AS (
    SELECT payload FROM scoped WHERE resource = 'users' AND payload->>'status' = 'Active'
  ),
  schools AS (
    SELECT payload FROM public.admin_records
    WHERE resource = 'schools'
      AND (COALESCE(p_scope->>'from', '') = '' OR LEFT(payload->>'createdAt', 10) >= p_scope->>'from')
      AND (COALESCE(p_scope->>'to', '') = '' OR LEFT(payload->>'createdAt', 10) <= p_scope->>'to')
  ),
  months AS (
    SELECT generate_series(date_trunc('month', NOW()) - INTERVAL '5 months', date_trunc('month', NOW()), INTERVAL '1 month') AS month
  ),
  revenue AS (
    SELECT
      to_char(month, 'Mon') AS label,
      month,
      COALESCE(SUM((payload->>'amount')::numeric) FILTER (WHERE payload->>'kind' = 'Income'), 0) AS income,
      COALESCE(SUM((payload->>'amount')::numeric) FILTER (WHERE payload->>'kind' = 'Expense'), 0) AS expense
    FROM months
    LEFT JOIN finances ON LEFT(payload->>'date', 7) = to_char(month, 'YYYY-MM') AND payload->>'status' = 'Paid'
    GROUP BY month
  )
  SELECT jsonb_build_object(
    'students', (SELECT COUNT(*) FROM people WHERE payload->>'role' = 'student'),
    'staff', (SELECT COUNT(*) FROM people WHERE payload->>'role' IN ('teacher', 'principal', 'accountant')),
    'attendance', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('label', to_char(month::date, 'Mon'), 'value', rate) ORDER BY month)
      FROM (
        SELECT LEFT(payload->>'date', 7) || '-01' AS month,
               ROUND(100.0 * SUM((payload->>'present')::numeric) / NULLIF(SUM((payload->>'total')::numeric), 0), 1) AS rate
        FROM scoped WHERE resource = 'analytics' GROUP BY LEFT(payload->>'date', 7)
      ) monthly WHERE rate IS NOT NULL
    ), '[]'::jsonb),
    'income', COALESCE((SELECT SUM((payload->>'amount')::numeric) FROM finances WHERE payload->>'kind' = 'Income' AND payload->>'status' = 'Paid'), 0),
    'expenses', COALESCE((SELECT SUM((payload->>'amount')::numeric) FROM finances WHERE payload->>'kind' = 'Expense' AND payload->>'status' = 'Paid'), 0),
    'outstanding', COALESCE((SELECT SUM((payload->>'amount')::numeric) FROM finances WHERE payload->>'kind' = 'Income' AND payload->>'status' <> 'Paid'), 0),
    'schools', (SELECT COUNT(*) FROM schools),
    'active', (SELECT COUNT(*) FROM schools WHERE payload->>'status' = 'Active'),
    'suspended', (SELECT COUNT(*) FROM schools WHERE payload->>'status' <> 'Active'),
    'mrr', COALESCE((SELECT SUM((payload->>'monthlyFee')::numeric) FROM schools WHERE payload->>'status' = 'Active'), 0),
    'revenue', CASE
      WHEN (SELECT public.current_user_role()) = 'master' THEN
        COALESCE((
          SELECT jsonb_agg(jsonb_build_object('label', payload->>'code', 'value', CASE WHEN payload->>'status' = 'Active' THEN (payload->>'monthlyFee')::numeric ELSE 0 END))
          FROM (SELECT payload FROM schools ORDER BY (payload->>'monthlyFee')::numeric DESC LIMIT 10) top_schools
        ), '[]'::jsonb)
      ELSE
        COALESCE((SELECT jsonb_agg(jsonb_build_object('label', label, 'value', income, 'secondary', expense) ORDER BY month) FROM revenue), '[]'::jsonb)
    END,
    'enrollment', CASE
      WHEN (SELECT public.current_user_role()) = 'master' THEN
        COALESCE((
          SELECT jsonb_agg(jsonb_build_object('label', plan, 'value', (SELECT COUNT(*) FROM schools WHERE payload->>'plan' = plan AND payload->>'status' = 'Active')))
          FROM unnest(ARRAY['Starter', 'Growth', 'Enterprise']) plan
        ), '[]'::jsonb)
      ELSE
        COALESCE((
          SELECT jsonb_agg(jsonb_build_object('label', b.payload->>'code', 'value', (SELECT COUNT(*) FROM people p WHERE p.payload->>'branchId' = b.payload->>'id' AND p.payload->>'role' = 'student')))
          FROM scoped b WHERE b.resource = 'branches'
        ), '[]'::jsonb)
    END
  );
$$;

-- 2. admin_list RPC
CREATE OR REPLACE FUNCTION public.admin_list(p_resource TEXT, p_scope JSONB, p_options JSONB)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_sid UUID;
  v_bid UUID;
  v_search TEXT;
  v_page INT;
  v_page_size INT;
  v_result JSONB;
BEGIN
  v_sid := (p_scope->>'schoolId')::uuid;
  v_bid := NULLIF(p_scope->>'branchId', '')::uuid;
  v_search := COALESCE(p_options->>'search', '');
  v_page := GREATEST(0, COALESCE((p_options->>'page')::int, 0));
  v_page_size := LEAST(500, GREATEST(1, COALESCE((p_options->>'pageSize')::int, 20)));

  WITH filtered AS (
    SELECT payload, version, updated_at
    FROM public.admin_records
    WHERE resource = p_resource
      AND (v_sid IS NULL OR school_id = v_sid)
      AND (v_bid IS NULL OR branch_id = v_bid)
      AND (v_search = '' OR (payload)::text ILIKE '%' || v_search || '%')
    ORDER BY updated_at DESC
  ),
  paged AS (
    SELECT payload FROM filtered
    LIMIT v_page_size OFFSET (v_page * v_page_size)
  )
  SELECT jsonb_build_object(
    'rows', COALESCE((SELECT jsonb_agg(payload) FROM paged), '[]'::jsonb),
    'total', (SELECT COUNT(*) FROM filtered)
  ) INTO v_result;

  RETURN v_result;
END;
$$;

-- 3. admin_save RPC
CREATE OR REPLACE FUNCTION public.admin_save(p_resource TEXT, p_record JSONB)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_rid UUID;
  v_sid UUID;
  v_bid UUID;
  v_version INT;
  v_next_version INT;
  v_result JSONB;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;

  v_rid := (p_record->>'id')::uuid;
  v_sid := (p_record->>'schoolId')::uuid;
  v_bid := NULLIF(p_record->>'branchId', '')::uuid;
  v_version := COALESCE((p_record->>'version')::int, 0);
  v_next_version := v_version + 1;

  v_result := p_record || jsonb_build_object('version', v_next_version, 'updatedAt', NOW());

  INSERT INTO public.admin_records(id, school_id, branch_id, resource, payload, version, updated_at)
  VALUES (v_rid, v_sid, v_bid, p_resource, v_result, v_next_version, NOW())
  ON CONFLICT (id) DO UPDATE SET
    payload = EXCLUDED.payload,
    version = EXCLUDED.version,
    branch_id = EXCLUDED.branch_id,
    updated_at = NOW();

  RETURN v_result;
END;
$$;

-- 4. admin_delete RPC
CREATE OR REPLACE FUNCTION public.admin_delete(p_resource TEXT, p_id TEXT, p_scope JSONB, p_version INT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uuid UUID;
  v_sid UUID;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  v_uuid := p_id::uuid;
  v_sid := (p_scope->>'schoolId')::uuid;

  DELETE FROM public.admin_records
  WHERE id = v_uuid AND school_id = v_sid AND resource = p_resource;

  RETURN jsonb_build_object('deleted', true);
END;
$$;

-- 5. workflow_context RPC
CREATE OR REPLACE FUNCTION public.workflow_context(p_branch UUID)
RETURNS JSONB
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT jsonb_build_object(
    'students', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('id', id, 'name', name, 'classId', class_id, 'branchId', branch_id) ORDER BY name)
      FROM public.school_students WHERE branch_id = p_branch
    ), '[]'::jsonb),
    'classes', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('id', id, 'name', name, 'branchId', branch_id) ORDER BY name)
      FROM public.school_classes WHERE branch_id = p_branch
    ), '[]'::jsonb)
  );
$$;

-- 6. workflow_list RPC
CREATE OR REPLACE FUNCTION public.workflow_list(p_module TEXT, p_scope JSONB)
RETURNS JSONB
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  WITH accessible AS (
    SELECT * FROM public.school_workflows
    WHERE branch_id = (p_scope->>'branchId')::uuid
      AND (COALESCE(p_scope->>'classId', '') = '' OR class_id IS NULL OR class_id = (p_scope->>'classId')::uuid)
      AND (COALESCE(p_scope->>'studentId', '') = '' OR student_id IS NULL OR student_id = (p_scope->>'studentId')::uuid)
  ),
  matching AS (
    SELECT * FROM accessible
    WHERE (p_module = 'all' OR module = p_module)
      AND (COALESCE(p_scope->>'date', '') = '' OR payload->'data'->>'date' = p_scope->>'date')
      AND (COALESCE(p_scope->>'title', '') = '' OR payload->'data'->>'title' = p_scope->>'title')
      AND (COALESCE(p_scope->>'subject', '') = '' OR payload->'data'->>'subject' = p_scope->>'subject')
      AND (COALESCE(p_scope->>'search', '') = '' OR (payload->'data')::text ILIKE '%' || (p_scope->>'search') || '%')
  ),
  paged AS (
    SELECT * FROM matching
    ORDER BY updated_at DESC, id
    LIMIT LEAST(500, GREATEST(1, COALESCE((p_scope->>'pageSize')::int, 12)))
    OFFSET GREATEST(0, COALESCE((p_scope->>'page')::int, 0)) * LEAST(500, GREATEST(1, COALESCE((p_scope->>'pageSize')::int, 12)))
  )
  SELECT jsonb_build_object(
    'rows', COALESCE((SELECT jsonb_agg(payload || jsonb_build_object('version', version, 'updatedAt', updated_at) ORDER BY updated_at DESC, id) FROM paged), '[]'::jsonb),
    'total', (SELECT COUNT(*) FROM matching),
    'counts', COALESCE((SELECT jsonb_object_agg(module, count) FROM (SELECT module, COUNT(*) FROM accessible GROUP BY module) c), '{}'::jsonb)
  );
$$;

-- 7. workflow_save RPC
CREATE OR REPLACE FUNCTION public.workflow_save(p_record JSONB)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_rid UUID;
  v_sid UUID;
  v_bid UUID;
  v_cid UUID;
  v_student UUID;
  v_author UUID;
  v_module TEXT;
  v_version INT;
  v_next_version INT;
  v_result JSONB;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;

  v_rid := (p_record->>'id')::uuid;
  v_sid := (p_record->>'schoolId')::uuid;
  v_bid := (p_record->>'branchId')::uuid;
  v_cid := NULLIF(p_record->>'classId', '')::uuid;
  v_student := NULLIF(p_record->>'studentId', '')::uuid;
  v_author := (p_record->>'authorId')::uuid;
  v_module := p_record->>'module';
  v_version := COALESCE((p_record->>'version')::int, 0);
  v_next_version := v_version + 1;

  v_result := p_record || jsonb_build_object('version', v_next_version, 'updatedAt', NOW());

  INSERT INTO public.school_workflows(id, school_id, branch_id, class_id, student_id, author_id, module, version, payload, updated_at)
  VALUES (v_rid, v_sid, v_bid, v_cid, v_student, v_author, v_module, v_next_version, v_result, NOW())
  ON CONFLICT (id) DO UPDATE SET
    payload = EXCLUDED.payload,
    version = EXCLUDED.version,
    updated_at = NOW();

  RETURN v_result;
END;
$$;

-- 8. workflow_remove RPC
CREATE OR REPLACE FUNCTION public.workflow_remove(p_id UUID, p_version INT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  DELETE FROM public.school_workflows WHERE id = p_id;
  RETURN jsonb_build_object('deleted', true);
END;
$$;

-- 9. workflow_delivery RPC
CREATE OR REPLACE FUNCTION public.workflow_delivery(p_provider_id TEXT, p_status TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  UPDATE public.school_workflows
  SET payload = payload || jsonb_build_object('version', version + 1, 'updatedAt', NOW(), 'data', payload->'data' || jsonb_build_object('status', p_status)),
      version = version + 1,
      updated_at = NOW()
  WHERE module = 'whatsapp' AND payload->'data'->>'providerId' = p_provider_id;

  RETURN jsonb_build_object('updated', FOUND);
END;
$$;

-- Explicit Function Grants
GRANT EXECUTE ON FUNCTION public.admin_summary(JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_list(TEXT, JSONB, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_save(TEXT, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_delete(TEXT, TEXT, JSONB, INT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_context(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_list(TEXT, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_save(JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_remove(UUID, INT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.workflow_delivery(TEXT, TEXT) TO service_role;
