-- Migration 000007: RLS & Explicit Grants - Academics, Finances & Communication
-- Implements role isolation rules across academic, financial, and messaging tables.

-- 1. Explicit Grants for Workflow Tables
GRANT SELECT, INSERT, UPDATE, DELETE ON public.classes TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subjects TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.class_students TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.timetable_entries TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.attendance_records TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.assignments TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.exams TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.marks TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.leaves TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.announcements TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.admissions TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meetings TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lesson_plans TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.fee_structures TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.student_fees TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.fee_payments TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.expenses TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vendors TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.payroll_records TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reconciliations TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.certificates TO authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.whatsapp_accounts TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.whatsapp_templates TO authenticated;
GRANT SELECT, INSERT ON public.whatsapp_messages TO authenticated;
GRANT SELECT, INSERT ON public.export_jobs TO authenticated;
GRANT SELECT, INSERT ON public.import_jobs TO authenticated;

-- 2. Enable RLS on all tables
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.class_students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.timetable_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.marks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leaves ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lesson_plans ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.fee_structures ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_fees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fee_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payroll_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reconciliations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.whatsapp_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.whatsapp_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.whatsapp_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.export_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.import_jobs ENABLE ROW LEVEL SECURITY;

-- 3. Academic Policies: Attendance Records
CREATE POLICY "Owner and Principal can view branch attendance"
  ON public.attendance_records FOR SELECT
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (
      (SELECT public.current_user_role()) = 'owner'
      OR (
        (SELECT public.current_user_role()) = 'principal'
        AND branch_id = ANY((SELECT public.current_user_branch_ids()))
      )
    )
  );

CREATE POLICY "Teachers can view and mark attendance for assigned branches"
  ON public.attendance_records FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) = 'teacher'
    AND branch_id = ANY((SELECT public.current_user_branch_ids()))
  );

CREATE POLICY "Students and Parents can view own attendance"
  ON public.attendance_records FOR SELECT
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('student', 'parent')
    AND student_id = (SELECT auth.uid())
  );

-- 4. Academic Policies: Marks & Exams
CREATE POLICY "Academic staff can manage marks"
  ON public.marks FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('owner', 'principal', 'teacher')
    AND (
      (SELECT public.current_user_role()) = 'owner'
      OR branch_id = ANY((SELECT public.current_user_branch_ids()))
    )
  );

CREATE POLICY "Students and Parents can view published marks"
  ON public.marks FOR SELECT
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('student', 'parent')
    AND student_id = (SELECT auth.uid())
    AND published = true
  );

-- 5. Financial Policies: Fee structures & Student Fees
CREATE POLICY "Finance managers can manage fees"
  ON public.student_fees FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('owner', 'accountant')
  );

CREATE POLICY "Students and Parents can view own fees"
  ON public.student_fees FOR SELECT
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('student', 'parent')
    AND student_id = (SELECT auth.uid())
  );

CREATE POLICY "Finance staff can view and collect payments"
  ON public.fee_payments FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('owner', 'accountant')
  );

CREATE POLICY "Students and Parents can view own fee receipts"
  ON public.fee_payments FOR SELECT
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('student', 'parent')
    AND student_id = (SELECT auth.uid())
  );

-- 6. Financial Policies: Expenses & Payroll
CREATE POLICY "Finance staff can manage expenses"
  ON public.expenses FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('owner', 'accountant')
  );

CREATE POLICY "Finance staff can manage payroll"
  ON public.payroll_records FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('owner', 'accountant')
  );

-- 7. Communication Policies: WhatsApp & Notifications
CREATE POLICY "Owner and Principal can manage school WhatsApp"
  ON public.whatsapp_accounts FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('owner', 'principal')
  );

CREATE POLICY "Staff can view and queue WhatsApp messages"
  ON public.whatsapp_messages FOR ALL
  TO authenticated
  USING (
    school_id = (SELECT public.current_user_school_id())
    AND (SELECT public.current_user_role()) IN ('owner', 'principal', 'teacher', 'accountant')
  );
