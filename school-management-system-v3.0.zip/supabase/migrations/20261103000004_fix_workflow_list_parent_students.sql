-- Fix workflow_list RPC: replace non-existent parent_students table with school_memberships.student_ids
CREATE OR REPLACE FUNCTION public.workflow_list(p_module TEXT, p_scope JSONB)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_uid UUID;
  v_role TEXT;
  v_user_sid UUID;
  v_user_bids UUID[];
  v_bid UUID;
  v_result JSONB;
BEGIN
  v_uid := auth.uid();
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required' USING ERRCODE = '42501';
  END IF;

  v_role := public.current_user_role();
  v_user_sid := public.current_user_school_id();
  v_user_bids := public.current_user_branch_ids();
  v_bid := NULLIF(p_scope->>'branchId', '')::uuid;

  IF v_role <> 'master' THEN
    IF v_bid IS NOT NULL AND v_role IN ('principal', 'teacher') AND NOT (v_bid = ANY(v_user_bids)) THEN
      RAISE EXCEPTION 'Branch access denied' USING ERRCODE = '42501';
    END IF;
  END IF;

  WITH accessible AS (
    SELECT * FROM public.school_workflows
    WHERE (v_role = 'master' OR school_id = v_user_sid)
      AND (v_bid IS NULL OR branch_id = v_bid)
      AND (COALESCE(p_scope->>'classId', '') = '' OR class_id IS NULL OR class_id = (p_scope->>'classId')::uuid)
      AND (
        v_role IN ('master', 'owner', 'principal', 'accountant')
        OR (v_role = 'teacher' AND (v_bid IS NULL OR v_bid = ANY(v_user_bids)))
        OR (v_role = 'student' AND (student_id IS NULL OR student_id = v_uid))
        OR (v_role = 'parent' AND (student_id IS NULL OR student_id IN (SELECT UNNEST(student_ids) FROM public.school_memberships WHERE user_id = v_uid)))
      )
      AND (COALESCE(p_scope->>'studentId', '') = '' OR student_id IS NULL OR student_id = (p_scope->>'studentId')::uuid)
  ),
  matching AS (
    SELECT * FROM accessible
    WHERE (p_module = 'all' OR module = p_module)
      AND (COALESCE(p_scope->>'date', '') = '' OR payload->'data'->>'date' = p_scope->>'date')
      AND (COALESCE(p_scope->>'title', '') = '' OR payload->'data'->>'title' = p_scope->>'title')
      AND (COALESCE(p_scope->>'subject', '') = '' OR payload->'data'->>'subject' = p_scope->>'subject')
      AND (COALESCE(p_scope->>'search', '') = '' OR (payload->'data')::text ILIKE '%' || (p_scope->>'search') || '%')
  ),
  paged AS (
    SELECT * FROM matching
    ORDER BY updated_at DESC, id
    LIMIT LEAST(500, GREATEST(1, COALESCE((p_scope->>'pageSize')::int, 12)))
    OFFSET GREATEST(0, COALESCE((p_scope->>'page')::int, 0)) * LEAST(500, GREATEST(1, COALESCE((p_scope->>'pageSize')::int, 12)))
  )
  SELECT jsonb_build_object(
    'rows', COALESCE((SELECT jsonb_agg(payload || jsonb_build_object('version', version, 'updatedAt', updated_at) ORDER BY updated_at DESC, id) FROM paged), '[]'::jsonb),
    'total', (SELECT COUNT(*) FROM matching),
    'counts', COALESCE((SELECT jsonb_object_agg(module, count) FROM (SELECT module, COUNT(*) FROM accessible GROUP BY module) c), '{}'::jsonb)
  ) INTO v_result;

  RETURN v_result;
END;
$$;
