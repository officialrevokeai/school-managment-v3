-- Migration 000010: Bulk Operations, Payments & Global Search
-- Provides high-throughput atomic RPCs for daily attendance, examinations, fee collection, and global search.

-- 1. attendance_mark_bulk RPC
CREATE OR REPLACE FUNCTION public.attendance_mark_bulk(
  p_class_id UUID,
  p_branch_id UUID,
  p_date DATE,
  p_records JSONB -- Array of { studentId: uuid, status: text, notes: text }
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_school_id UUID;
  v_item JSONB;
  v_count INT := 0;
  v_student_id UUID;
  v_status public.attendance_status;
  v_notes TEXT;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  v_school_id := public.current_user_school_id();

  FOR v_item IN SELECT jsonb_array_elements(p_records) LOOP
    v_student_id := (v_item->>'studentId')::uuid;
    v_status := COALESCE(v_item->>'status', 'Present')::public.attendance_status;
    v_notes := COALESCE(v_item->>'notes', '');

    INSERT INTO public.attendance_records(school_id, branch_id, class_id, student_id, marked_by, date, status, notes)
    VALUES (v_school_id, p_branch_id, p_class_id, v_student_id, auth.uid(), p_date, v_status, v_notes)
    ON CONFLICT (student_id, date) DO UPDATE SET
      status = EXCLUDED.status,
      notes = EXCLUDED.notes,
      marked_by = EXCLUDED.marked_by;

    v_count := v_count + 1;
  END LOOP;

  RETURN jsonb_build_object('success', true, 'count', v_count);
END;
$$;

-- 2. marks_upsert_bulk RPC
CREATE OR REPLACE FUNCTION public.marks_upsert_bulk(
  p_exam_id UUID,
  p_class_id UUID,
  p_subject_id UUID,
  p_branch_id UUID,
  p_marks JSONB -- Array of { studentId: uuid, score: numeric, maximum: numeric, notes: text }
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_school_id UUID;
  v_item JSONB;
  v_count INT := 0;
  v_student_id UUID;
  v_score NUMERIC;
  v_maximum NUMERIC;
  v_notes TEXT;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  v_school_id := public.current_user_school_id();

  FOR v_item IN SELECT jsonb_array_elements(p_marks) LOOP
    v_student_id := (v_item->>'studentId')::uuid;
    v_score := (v_item->>'score')::numeric;
    v_maximum := (v_item->>'maximum')::numeric;
    v_notes := COALESCE(v_item->>'notes', '');

    INSERT INTO public.marks(school_id, branch_id, exam_id, class_id, subject_id, student_id, entered_by, score, maximum, notes)
    VALUES (v_school_id, p_branch_id, p_exam_id, p_class_id, p_subject_id, v_student_id, auth.uid(), v_score, v_maximum, v_notes);

    v_count := v_count + 1;
  END LOOP;

  RETURN jsonb_build_object('success', true, 'count', v_count);
END;
$$;

-- 3. fee_collect_payment RPC
CREATE OR REPLACE FUNCTION public.fee_collect_payment(
  p_student_fee_id UUID,
  p_amount NUMERIC,
  p_method public.payment_mode,
  p_notes TEXT DEFAULT ''
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_fee RECORD;
  v_receipt_number TEXT;
  v_new_paid NUMERIC;
  v_new_status public.fee_status;
  v_payment_id UUID;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;

  SELECT * INTO v_fee FROM public.student_fees WHERE id = p_student_fee_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Student fee record not found'; END IF;

  v_new_paid := v_fee.paid_amount + p_amount;
  IF v_new_paid >= (v_fee.amount - v_fee.discount + v_fee.fine) THEN
    v_new_status := 'Paid';
  ELSE
    v_new_status := 'Pending';
  END IF;

  UPDATE public.student_fees
  SET paid_amount = v_new_paid,
      status = v_new_status,
      updated_at = NOW()
  WHERE id = p_student_fee_id;

  v_receipt_number := 'REC-' || to_char(NOW(), 'YYYYMMDD') || '-' || upper(substr(gen_random_uuid()::text, 1, 6));

  INSERT INTO public.fee_payments(
    school_id, branch_id, student_fee_id, student_id, collected_by, amount, payment_method, receipt_number, notes
  ) VALUES (
    v_fee.school_id, v_fee.branch_id, p_student_fee_id, v_fee.student_id, auth.uid(), p_amount, p_method, v_receipt_number, p_notes
  ) RETURNING id INTO v_payment_id;

  RETURN jsonb_build_object(
    'paymentId', v_payment_id,
    'receiptNumber', v_receipt_number,
    'newPaidAmount', v_new_paid,
    'status', v_new_status
  );
END;
$$;

-- 4. search_global RPC
CREATE OR REPLACE FUNCTION public.search_global(p_query TEXT)
RETURNS JSONB
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  WITH results AS (
    SELECT 'profile' AS kind, id::text, name AS title, email AS subtitle, school_id
    FROM public.profiles
    WHERE school_id = public.current_user_school_id()
      AND (name ILIKE '%' || p_query || '%' OR email ILIKE '%' || p_query || '%')
    UNION ALL
    SELECT 'branch' AS kind, id::text, name AS title, city AS subtitle, school_id
    FROM public.branches
    WHERE school_id = public.current_user_school_id()
      AND (name ILIKE '%' || p_query || '%' OR city ILIKE '%' || p_query || '%')
    UNION ALL
    SELECT 'class' AS kind, id::text, name AS title, section AS subtitle, school_id
    FROM public.classes
    WHERE school_id = public.current_user_school_id()
      AND name ILIKE '%' || p_query || '%'
    LIMIT 20
  )
  SELECT COALESCE(jsonb_agg(jsonb_build_object('kind', kind, 'id', id, 'title', title, 'subtitle', subtitle)), '[]'::jsonb)
  FROM results;
$$;

GRANT EXECUTE ON FUNCTION public.attendance_mark_bulk(UUID, UUID, DATE, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.marks_upsert_bulk(UUID, UUID, UUID, UUID, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION public.fee_collect_payment(UUID, NUMERIC, public.payment_mode, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.search_global(TEXT) TO authenticated;
