-- Migration 000008: Admin Records, Workflows Schema and Realtime Publication
-- Provides the persistence layer for admin resources, workflows, and realtime broadcasts.

-- 1. Admin Records (for dynamic resource administration)
CREATE TABLE IF NOT EXISTS public.admin_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES public.branches(id) ON DELETE CASCADE,
  resource TEXT NOT NULL,
  payload JSONB NOT NULL,
  version INT NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_admin_records_resource ON public.admin_records(school_id, resource);
CREATE INDEX IF NOT EXISTS idx_admin_records_branch ON public.admin_records(branch_id, resource);

ALTER TABLE public.admin_records ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.admin_records TO authenticated;
GRANT ALL ON public.admin_records TO service_role;

-- 2. School Memberships (Links parents to students, teachers to classes)
CREATE TABLE IF NOT EXISTS public.school_memberships (
  user_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  class_ids UUID[] NOT NULL DEFAULT '{}',
  student_ids UUID[] NOT NULL DEFAULT '{}'
);

ALTER TABLE public.school_memberships ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.school_memberships TO authenticated;
GRANT ALL ON public.school_memberships TO service_role;

CREATE POLICY "Own workflow membership"
  ON public.school_memberships FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- 3. Workflow Classes & Students
CREATE TABLE IF NOT EXISTS public.school_classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public.school_students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES public.school_classes(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  guardian_phone TEXT
);

CREATE INDEX IF NOT EXISTS idx_school_classes_branch ON public.school_classes(branch_id);
CREATE INDEX IF NOT EXISTS idx_school_students_class ON public.school_students(class_id);

ALTER TABLE public.school_classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.school_students ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.school_classes, public.school_students TO authenticated;
GRANT ALL ON public.school_classes, public.school_students TO service_role;

-- 4. Workflow Modules & School Workflows
CREATE TABLE IF NOT EXISTS public.workflow_modules (
  module TEXT PRIMARY KEY,
  config JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS public.school_workflows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
  class_id UUID REFERENCES public.school_classes(id) ON DELETE SET NULL,
  student_id UUID REFERENCES public.school_students(id) ON DELETE SET NULL,
  author_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  module TEXT NOT NULL REFERENCES public.workflow_modules(module),
  version INT NOT NULL DEFAULT 1,
  payload JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_school_workflows_scope ON public.school_workflows(school_id, branch_id, module, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_school_workflows_student ON public.school_workflows(student_id, module);
CREATE INDEX IF NOT EXISTS idx_school_workflows_class ON public.school_workflows(class_id, module);

ALTER TABLE public.workflow_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.school_workflows ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.workflow_modules, public.school_workflows TO authenticated;
GRANT ALL ON public.workflow_modules, public.school_workflows TO service_role;

-- 5. Realtime Publication
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'school_workflows'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.school_workflows;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'notifications'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
  END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;
