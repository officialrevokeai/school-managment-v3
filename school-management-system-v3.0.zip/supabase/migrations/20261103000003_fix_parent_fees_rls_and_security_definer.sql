-- Migration 20261103000003: Fix Parent Fees RLS, rls_auto_enable search_path, and audit_logs grants

-- 1. Hardened rls_auto_enable function with search_path = ''
CREATE OR REPLACE FUNCTION public.rls_auto_enable()
RETURNS event_trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  cmd record;
  tbl name;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        SELECT c.relname INTO tbl FROM pg_catalog.pg_class c WHERE c.oid = cmd.objid;
        EXECUTE format('alter table if exists %I.%I enable row level security', cmd.schema_name, tbl);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;

-- 2. Fix BUG-008: Allow Parents to view their children's fee invoices via school_memberships
DROP POLICY IF EXISTS "Students and Parents can view own fees" ON public.student_fees;

CREATE POLICY "Students and Parents can view own fees" ON public.student_fees
FOR SELECT TO authenticated
USING (
  school_id = (SELECT public.current_user_school_id())
  AND (
    (
      (SELECT public.current_user_role()) = 'student'::public.user_role 
      AND student_id = (SELECT auth.uid())
    )
    OR
    (
      (SELECT public.current_user_role()) = 'parent'::public.user_role 
      AND student_id = ANY(
        SELECT unnest(student_ids) FROM public.school_memberships WHERE user_id = (SELECT auth.uid())
      )
    )
  )
);

-- 3. Explicitly revoke UPDATE and DELETE on audit_logs from authenticated and anon
REVOKE UPDATE, DELETE ON public.audit_logs FROM authenticated, anon;
