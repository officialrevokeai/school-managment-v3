-- Migration 000002: Profiles, RBAC, Claims Hook and Permissions
-- Defines user profiles, permission mappings, and the custom access token auth hook.

-- 1. Roles & Policies
CREATE TABLE IF NOT EXISTS public.roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role user_role NOT NULL,
  custom BOOLEAN NOT NULL DEFAULT FALSE,
  permissions TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TRIGGER trg_roles_updated_at
  BEFORE UPDATE ON public.roles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- 2. Profiles (Extends auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
  branch_ids UUID[] NOT NULL DEFAULT '{}',
  policy_id UUID REFERENCES public.roles(id) ON DELETE SET NULL,
  role user_role NOT NULL,
  name TEXT NOT NULL CHECK (char_length(name) >= 1),
  email TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- 3. User Permission Overrides
CREATE TABLE IF NOT EXISTS public.user_role_overrides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  granted_permissions TEXT[] NOT NULL DEFAULT '{}',
  revoked_permissions TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_user_override UNIQUE (user_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_profiles_school ON public.profiles(school_id);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(school_id, role);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_trgm_name ON public.profiles USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_roles_school ON public.roles(school_id, role);

-- Helper: Retrieve current user claims from JWT with fallback to profile table
CREATE OR REPLACE FUNCTION public.current_user_school_id()
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT COALESCE(
    NULLIF(current_setting('request.jwt.claims', true)::jsonb->'app_metadata'->>'school_id', '')::uuid,
    (SELECT school_id FROM public.profiles WHERE id = auth.uid())
  );
$$;

CREATE OR REPLACE FUNCTION public.current_user_role()
RETURNS public.user_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT COALESCE(
    (current_setting('request.jwt.claims', true)::jsonb->'app_metadata'->>'role')::public.user_role,
    (SELECT role FROM public.profiles WHERE id = auth.uid())
  );
$$;

CREATE OR REPLACE FUNCTION public.current_user_branch_ids()
RETURNS UUID[]
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT COALESCE(
    ARRAY(
      SELECT jsonb_array_elements_text(
        COALESCE(current_setting('request.jwt.claims', true)::jsonb->'app_metadata'->'branch_ids', '[]'::jsonb)
      )::uuid
    ),
    (SELECT branch_ids FROM public.profiles WHERE id = auth.uid()),
    '{}'::uuid[]
  );
$$;

-- Helper: has_permission function checking base role, custom policy, and overrides
CREATE OR REPLACE FUNCTION public.has_permission(p_permission TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_role public.user_role;
  v_policy_id UUID;
  v_perms TEXT[];
  v_overrides RECORD;
BEGIN
  -- 1. Master and Owner have universal platform/school access
  v_role := public.current_user_role();
  IF v_role = 'master' OR v_role = 'owner' THEN
    RETURN TRUE;
  END IF;

  -- 2. Check user-specific overrides
  SELECT granted_permissions, revoked_permissions INTO v_overrides
  FROM public.user_role_overrides
  WHERE user_id = auth.uid();

  IF v_overrides.revoked_permissions IS NOT NULL AND p_permission = ANY(v_overrides.revoked_permissions) THEN
    RETURN FALSE;
  END IF;

  IF v_overrides.granted_permissions IS NOT NULL AND p_permission = ANY(v_overrides.granted_permissions) THEN
    RETURN TRUE;
  END IF;

  -- 3. Check custom assigned policy
  SELECT policy_id INTO v_policy_id FROM public.profiles WHERE id = auth.uid();
  IF v_policy_id IS NOT NULL THEN
    SELECT permissions INTO v_perms FROM public.roles WHERE id = v_policy_id;
    RETURN (p_permission = ANY(COALESCE(v_perms, '{}')));
  END IF;

  -- 4. Default role permissions lookup
  SELECT permissions INTO v_perms FROM public.roles WHERE school_id IS NULL AND role = v_role AND NOT custom LIMIT 1;
  RETURN (p_permission = ANY(COALESCE(v_perms, '{}')));
END;
$$;

-- 4. Custom Access Token Hook for Supabase Auth
-- Automatically injects role, school_id, and branch_ids into the JWT upon login/refresh
CREATE OR REPLACE FUNCTION public.custom_access_token_hook(event JSONB)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_user_id UUID;
  v_profile RECORD;
  v_claims JSONB;
BEGIN
  v_user_id := (event->>'user_id')::uuid;
  v_claims := event->'claims';

  SELECT role, school_id, branch_ids
  INTO v_profile
  FROM public.profiles
  WHERE id = v_user_id AND active = true;

  IF FOUND THEN
    v_claims := jsonb_set(v_claims, '{app_metadata, role}', to_jsonb(v_profile.role::text));
    v_claims := jsonb_set(v_claims, '{app_metadata, school_id}', to_jsonb(v_profile.school_id::text));
    v_claims := jsonb_set(v_claims, '{app_metadata, branch_ids}', to_jsonb(v_profile.branch_ids));
  END IF;

  RETURN jsonb_set(event, '{claims}', v_claims);
END;
$$;
