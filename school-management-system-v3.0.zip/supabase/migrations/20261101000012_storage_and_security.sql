-- Migration 000012: Private Storage Buckets, Append-Only Audit Integrity & Security Hardening
-- Enforces private storage access, immutable audit trails, and automated audit triggers on sensitive entities.

-- 1. Private Storage Bucket Setup (school-files)
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'storage' AND table_name = 'buckets') THEN
    INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
    VALUES (
      'school-files',
      'school-files',
      FALSE,
      52428800, -- 50 MB
      ARRAY[
        'image/png',
        'image/jpeg',
        'image/webp',
        'image/svg+xml',
        'application/pdf',
        'text/csv',
        'application/json'
      ]
    )
    ON CONFLICT (id) DO UPDATE SET
      public = FALSE,
      file_size_limit = 52428800;
  END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- 2. Storage RLS Policies for Tenant Isolation
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'storage' AND table_name = 'objects') THEN
    ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

    -- Drop existing loose policies if any
    DROP POLICY IF EXISTS "Tenant storage access" ON storage.objects;
    DROP POLICY IF EXISTS "Tenant storage upload" ON storage.objects;
    DROP POLICY IF EXISTS "Tenant storage update" ON storage.objects;
    DROP POLICY IF EXISTS "Tenant storage delete" ON storage.objects;

    -- Read policy: Only signed URLs / authenticated tenant members
    CREATE POLICY "Tenant storage access"
      ON storage.objects FOR SELECT
      TO authenticated
      USING (
        bucket_id = 'school-files'
        AND (
          -- Direct tenant folder: school_id/...
          (storage.foldername(name))[1] = (SELECT school_id::text FROM public.profiles WHERE id = (SELECT auth.uid()))
          -- Export folder: exports/school_id/...
          OR (
            (storage.foldername(name))[1] = 'exports'
            AND (storage.foldername(name))[2] = (SELECT school_id::text FROM public.profiles WHERE id = (SELECT auth.uid()))
          )
          -- Master platform administrator
          OR (SELECT role FROM public.profiles WHERE id = (SELECT auth.uid())) = 'master'
        )
      );

    -- Insert/Upload policy: Restrict to tenant path
    CREATE POLICY "Tenant storage upload"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (
        bucket_id = 'school-files'
        AND (
          (storage.foldername(name))[1] = (SELECT school_id::text FROM public.profiles WHERE id = (SELECT auth.uid()))
          OR (
            (storage.foldername(name))[1] = 'exports'
            AND (storage.foldername(name))[2] = (SELECT school_id::text FROM public.profiles WHERE id = (SELECT auth.uid()))
          )
          OR (SELECT role FROM public.profiles WHERE id = (SELECT auth.uid())) = 'master'
        )
      );

    -- Delete policy: Owner and Master only within own school
    CREATE POLICY "Tenant storage delete"
      ON storage.objects FOR DELETE
      TO authenticated
      USING (
        bucket_id = 'school-files'
        AND (
          (
            (storage.foldername(name))[1] = (SELECT school_id::text FROM public.profiles WHERE id = (SELECT auth.uid()))
            AND (SELECT role FROM public.profiles WHERE id = (SELECT auth.uid())) = 'owner'
          )
          OR (SELECT role FROM public.profiles WHERE id = (SELECT auth.uid())) = 'master'
        )
      );
  END IF;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- 3. Append-Only Immutability for Audit Logs (Master Prompt Step 6)
CREATE OR REPLACE FUNCTION public.enforce_audit_logs_append_only()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  RAISE EXCEPTION 'Audit logs are immutable append-only records and cannot be modified or deleted (Operation: %)', TG_OP;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_logs_append_only ON public.audit_logs;
CREATE TRIGGER trg_audit_logs_append_only
  BEFORE UPDATE OR DELETE ON public.audit_logs
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_audit_logs_append_only();

-- 4. Automated Audit Trail Trigger for Sensitive Table Mutations
CREATE OR REPLACE FUNCTION public.audit_sensitive_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_actor_id UUID;
  v_actor_name TEXT;
  v_school_id UUID;
BEGIN
  v_actor_id := (SELECT auth.uid());
  SELECT name INTO v_actor_name FROM public.profiles WHERE id = v_actor_id;
  v_actor_name := COALESCE(v_actor_name, 'System');

  IF TG_TABLE_NAME = 'schools' THEN
    v_school_id := COALESCE(NEW.id, OLD.id);
  ELSIF TG_TABLE_NAME = 'roles' THEN
    v_school_id := COALESCE(NEW.school_id, OLD.school_id);
  ELSIF TG_TABLE_NAME = 'user_role_overrides' THEN
    v_school_id := COALESCE(NEW.school_id, OLD.school_id);
  ELSIF TG_TABLE_NAME = 'fee_payments' THEN
    v_school_id := COALESCE(NEW.school_id, OLD.school_id);
  END IF;

  INSERT INTO public.audit_logs (
    school_id,
    actor_id,
    actor_name,
    action,
    resource,
    resource_id,
    details
  ) VALUES (
    v_school_id,
    v_actor_id,
    v_actor_name,
    TG_TABLE_NAME || '_' || TG_OP,
    TG_TABLE_NAME,
    COALESCE(NEW.id::text, OLD.id::text, 'unknown'),
    jsonb_build_object(
      'operation', TG_OP,
      'timestamp', NOW()
    )
  );

  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_schools ON public.schools;
CREATE TRIGGER trg_audit_schools
  AFTER UPDATE OR DELETE ON public.schools
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_sensitive_changes();

DROP TRIGGER IF EXISTS trg_audit_roles ON public.roles;
CREATE TRIGGER trg_audit_roles
  AFTER INSERT OR UPDATE OR DELETE ON public.roles
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_sensitive_changes();

DROP TRIGGER IF EXISTS trg_audit_role_overrides ON public.user_role_overrides;
CREATE TRIGGER trg_audit_role_overrides
  AFTER INSERT OR UPDATE OR DELETE ON public.user_role_overrides
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_sensitive_changes();

DROP TRIGGER IF EXISTS trg_audit_fee_payments ON public.fee_payments;
CREATE TRIGGER trg_audit_fee_payments
  AFTER INSERT ON public.fee_payments
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_sensitive_changes();
