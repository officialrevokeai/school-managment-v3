-- Migration: 20261103000002_fix_audit_trigger_and_qa_cleanup.sql
-- Fixes BUG-002: School deletion fails due to audit trigger FK violation.
-- Fixes audit_sensitive_changes search_path and preserves QA audit cleanup.

-- 1. Alter audit_logs_school_id_fkey to ON DELETE SET NULL
ALTER TABLE public.audit_logs 
  DROP CONSTRAINT IF EXISTS audit_logs_school_id_fkey;

ALTER TABLE public.audit_logs 
  ADD CONSTRAINT audit_logs_school_id_fkey 
  FOREIGN KEY (school_id) REFERENCES public.schools(id) 
  ON DELETE SET NULL;

-- 2. Update audit_sensitive_changes function with fixed search_path and safe deletion handling
CREATE OR REPLACE FUNCTION public.audit_sensitive_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_actor_id UUID;
  v_actor_name TEXT;
  v_school_id UUID;
  v_is_qa BOOLEAN;
BEGIN
  v_actor_id := (SELECT auth.uid());
  SELECT name INTO v_actor_name FROM public.profiles WHERE id = v_actor_id;
  v_actor_name := COALESCE(v_actor_name, 'System');

  -- Extract is_qa
  IF TG_OP = 'DELETE' THEN
    v_is_qa := COALESCE(OLD.is_qa, false);
  ELSE
    v_is_qa := COALESCE(NEW.is_qa, false);
  END IF;

  IF TG_TABLE_NAME = 'schools' THEN
    IF TG_OP = 'DELETE' THEN
      v_school_id := NULL; -- Prevent FK violation on deleted school
    ELSE
      v_school_id := NEW.id;
    END IF;
  ELSIF TG_TABLE_NAME = 'roles' THEN
    v_school_id := COALESCE(NEW.school_id, OLD.school_id);
  ELSIF TG_TABLE_NAME = 'user_role_overrides' THEN
    v_school_id := COALESCE(NEW.school_id, OLD.school_id);
  ELSIF TG_TABLE_NAME = 'fee_payments' THEN
    v_school_id := COALESCE(NEW.school_id, OLD.school_id);
  END IF;

  INSERT INTO public.audit_logs (
    school_id,
    actor_id,
    actor_name,
    action,
    resource,
    resource_id,
    details,
    is_qa
  ) VALUES (
    v_school_id,
    v_actor_id,
    v_actor_name,
    TG_TABLE_NAME || '_' || TG_OP,
    TG_TABLE_NAME,
    COALESCE(NEW.id::text, OLD.id::text, 'unknown'),
    jsonb_build_object(
      'operation', TG_OP,
      'timestamp', NOW(),
      'entity_id', COALESCE(NEW.id::text, OLD.id::text),
      'deleted_school_id', CASE WHEN TG_TABLE_NAME = 'schools' AND TG_OP = 'DELETE' THEN OLD.id::text ELSE NULL END
    ),
    v_is_qa
  );

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- 3. Update enforce_audit_logs_append_only to allow deleting QA logs during teardown
CREATE OR REPLACE FUNCTION public.enforce_audit_logs_append_only()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  -- Allow teardown/deletion of QA-tagged test logs
  IF TG_OP = 'DELETE' AND OLD.is_qa = true THEN
    RETURN OLD;
  END IF;

  RAISE EXCEPTION 'Audit logs are immutable append-only records and cannot be modified or deleted (Operation: %)', TG_OP;
  RETURN NULL;
END;
$$;
