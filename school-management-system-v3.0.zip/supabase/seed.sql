-- Seed Data for School Management System v3.0
-- Seeds default plans, schools, branches, academic years, workflow modules, and roles.

-- 1. Subscription Plans
INSERT INTO public.plans (id, name, tier, price, max_students, max_branches, features) VALUES
  ('11111111-0000-0000-0000-000000000001', 'Starter Plan', 'Starter', 15000, 500, 1, '{"whatsapp": true, "finance": true, "analytics": false}'::jsonb),
  ('11111111-0000-0000-0000-000000000002', 'Growth Plan', 'Growth', 35000, 2000, 5, '{"whatsapp": true, "finance": true, "analytics": true, "multi_branch": true}'::jsonb),
  ('11111111-0000-0000-0000-000000000003', 'Enterprise Plan', 'Enterprise', 75000, 10000, 25, '{"whatsapp": true, "finance": true, "analytics": true, "multi_branch": true, "custom_roles": true}'::jsonb)
ON CONFLICT (id) DO NOTHING;

-- 2. Primary Seed School (Greenwood High)
INSERT INTO public.schools (id, name, code, status, plan, monthly_fee, owner_email, settings) VALUES
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Greenwood High International', 'GWH-001', 'Active', 'Growth', 35000, 'owner@greenwood.edu', '{"academicYear": "2026–2027", "sessionMinutes": 60}'::jsonb)
ON CONFLICT (id) DO NOTHING;

-- 3. Campuses / Branches
INSERT INTO public.branches (id, school_id, name, code, city, short_name, capacity, status) VALUES
  ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbb01', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'North Campus', 'NORTH-01', 'Bengaluru', 'North', 1200, 'Active'),
  ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbb02', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'South Campus', 'SOUTH-01', 'Bengaluru', 'South', 800, 'Active')
ON CONFLICT (id) DO NOTHING;

-- 4. Academic Year
INSERT INTO public.academic_years (id, school_id, name, starts_at, ends_at, is_current) VALUES
  ('cccccccc-cccc-cccc-cccc-cccccccc0001', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '2026–2027', '2026-06-01', '2027-04-30', TRUE)
ON CONFLICT (id) DO NOTHING;

-- 5. School Classes
INSERT INTO public.school_classes (id, school_id, branch_id, name) VALUES
  ('dddddddd-dddd-dddd-dddd-dddddddd0001', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbb01', 'Grade 10-A'),
  ('dddddddd-dddd-dddd-dddd-dddddddd0002', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbb01', 'Grade 8-A'),
  ('dddddddd-dddd-dddd-dddd-dddddddd0003', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbb01', 'Grade 6-B')
ON CONFLICT (id) DO NOTHING;

-- 6. Workflow Modules Catalog
INSERT INTO public.workflow_modules (module, config) VALUES
  ('timetable', '{"title": "Class Timetable", "readers": ["owner", "principal", "teacher", "parent", "student"]}'::jsonb),
  ('attendance', '{"title": "Student Attendance", "readers": ["owner", "principal", "teacher", "parent"]}'::jsonb),
  ('homework', '{"title": "Homework & Assignments", "readers": ["owner", "principal", "teacher", "parent", "student"]}'::jsonb),
  ('exams', '{"title": "Exams & Tests", "readers": ["owner", "principal", "teacher", "parent", "student"]}'::jsonb),
  ('marks', '{"title": "Report Cards & Marks", "readers": ["owner", "principal", "teacher", "parent", "student"]}'::jsonb),
  ('leaves', '{"title": "Leave Requests", "readers": ["owner", "principal", "teacher", "parent"]}'::jsonb),
  ('announcements', '{"title": "Campus Announcements", "readers": ["owner", "principal", "teacher", "parent", "student", "accountant"]}'::jsonb),
  ('admissions', '{"title": "Student Admissions", "readers": ["owner", "principal"]}'::jsonb),
  ('fees', '{"title": "Fees & Billing", "readers": ["owner", "accountant", "parent"]}'::jsonb),
  ('expenses', '{"title": "Expenses & Vendors", "readers": ["owner", "accountant"]}'::jsonb),
  ('payroll', '{"title": "Staff Payroll", "readers": ["owner", "accountant"]}'::jsonb),
  ('whatsapp', '{"title": "WhatsApp Console", "readers": ["owner", "principal"]}'::jsonb),
  ('automations', '{"title": "Automated Workflows", "readers": ["owner"]}'::jsonb)
ON CONFLICT (module) DO NOTHING;

-- 7. Standard System Roles
INSERT INTO public.roles (school_id, name, role, custom, permissions) VALUES
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Head of Department', 'teacher'::public.user_role, TRUE, ARRAY['academics.read', 'academics.write', 'attendance.read', 'attendance.write']),
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Senior Bursar', 'accountant'::public.user_role, TRUE, ARRAY['finance.read', 'finance.write', 'workspace.read'])
ON CONFLICT DO NOTHING;
