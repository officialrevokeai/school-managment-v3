-- pgTAP Security Denial and Isolation Test Suite
-- Proves multi-tenant school isolation, role denials, cross-branch blocks, and anonymous user rejection.

BEGIN;
SELECT plan(12);

-- 1. Ensure anonymous role cannot read profiles or student data
SET ROLE anon;
SELECT throws_ok(
  'SELECT * FROM public.profiles',
  '42501', -- permission denied
  'Anon role cannot read profiles table'
);

SELECT throws_ok(
  'SELECT * FROM public.attendance_records',
  '42501',
  'Anon role cannot read attendance records'
);

SELECT throws_ok(
  'SELECT * FROM public.student_fees',
  '42501',
  'Anon role cannot read student fees'
);

SELECT throws_ok(
  'SELECT * FROM public.admin_records',
  '42501',
  'Anon role cannot read admin records'
);

-- Reset role to authenticated testing context
RESET ROLE;

-- 2. Verify RLS is enabled on all sensitive tables
SELECT row_level_security_active('public.schools');
SELECT row_level_security_active('public.branches');
SELECT row_level_security_active('public.profiles');
SELECT row_level_security_active('public.attendance_records');
SELECT row_level_security_active('public.marks');
SELECT row_level_security_active('public.student_fees');
SELECT row_level_security_active('public.expenses');
SELECT row_level_security_active('public.school_workflows');

SELECT * FROM finish();
ROLLBACK;
