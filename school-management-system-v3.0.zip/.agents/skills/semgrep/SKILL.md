---
name: semgrep
description: >-
  Static analysis (SAST), AST pattern matching, vulnerability scanning, and security rule
  authoring with Semgrep. Use when scanning code for security vulnerabilities (OWASP Top 10,
  CWE, ASVS), detecting hardcoded secrets and tokens, finding logic bugs and code smells,
  performing source-to-sink taint analysis, or authoring custom Semgrep YAML rules for
  TypeScript, JavaScript, React, SQL, Postgres/Supabase, Python, Docker, and YAML.
---

# Semgrep Security & AST Analysis Skill

Semgrep is a fast, lightweight, and versatile static analysis engine for finding bugs, enforcing code standards, and detecting security vulnerabilities directly at the Abstract Syntax Tree (AST) level. Unlike regex-based scanners, Semgrep understands code structure, scope, imports, and dataflow (taint analysis).

---

## 1. Core Capabilities & When to Use

Use this skill whenever you need to:
1. **Audit & Scan Codebases**: Run static security scans across frontend (React, Vue, TS/JS) and backend (Node, Deno, Python, Postgres/SQL, Go) for OWASP Top 10 vulnerabilities.
2. **Author Custom Security Rules**: Write high-precision rules tailored to your application's architecture (e.g. Supabase RLS bypass, unsafe dynamic SQL, unvalidated webhook payloads, leaking secrets in client bundles).
3. **Trace Taint Flows (Taint Mode)**: Model how untrusted inputs (HTTP requests, query parameters, URL hash, unverified JWTs) flow into critical execution sinks (SQL execution, `eval`, `innerHTML`, shell exec, file storage).
4. **Enforce Architectural Invariants**: Guard against prohibited imports, deprecated API usage, unhandled error boundaries, missing authorization checks, or dangerous state mutations.
5. **Autofix Defects**: Use `fix` and `fix-regex` to automatically apply clean, syntax-aware refactors across hundreds of files.

---

## 2. Command-Line Reference

### Standard Scanning Commands

```bash
# Scan repository using default recommended rules
semgrep scan --config auto

# Scan using specific registry rulesets
semgrep scan --config p/security-audit --config p/owasp-top-ten

# Scan targeting specific languages
semgrep scan --config p/typescript --config p/react --config p/sql

# Scan using a local directory or custom rule file
semgrep scan --config .semgrep/
semgrep scan --config .semgrep/supabase-security.yml

# Output machine-readable results (SARIF or JSON)
semgrep scan --config .semgrep/ --json -o semgrep-results.json
semgrep scan --config .semgrep/ --sarif -o semgrep-results.sarif

# Autofix matching issues in-place
semgrep scan --config .semgrep/ --autofix

# Strict CI mode: fail on findings, quiet progress
semgrep scan --config .semgrep/ --error --strict --quiet
```
