import { test, expect } from "@playwright/test";

test.describe("Step 5: Master Panel & Tenant Lifecycle Tests", () => {
  test.describe("Non-master access control", () => {
    test("Non-master user hitting master route gets 404 status page", async ({ page }) => {
      // 1. Log in as a teacher
      await page.goto("/login", { waitUntil: "networkidle" });
      await page.fill('input[name="identifier"]', "teacher@greenwood.edu");
      await page.fill('input[name="password"]', "Campus@2026");
      await page.click('button[type="submit"]');
      await page.waitForURL("**/teacher", { timeout: 10_000 });

      // 2. Attempt to navigate to master console
      await page.goto("/sys-master/workspace", { waitUntil: "networkidle" });

      // 3. Verify standard 404 is rendered, never disclosing master routes
      await page.waitForSelector(".status-page, [data-status='404'], h1:has-text('404'), h2:has-text('404')", {
        timeout: 5_000,
      });
      const content = await page.textContent("body");
      expect(content).toContain("404");
    });
  });

  test.describe("Authenticated Master Admin Lifecycle", () => {
    test.use({ storageState: ".playwright/master.json" });

    test("Master lifecycle: overview -> create school -> suspend -> block -> reactivate", async ({ page }) => {
      // 1. Land on Master Workspace Overview
      await page.goto("/sys-master/workspace", { waitUntil: "networkidle" });
      await page.waitForSelector("aside.sidebar, .top-header", { timeout: 10_000 });
      expect(await page.textContent("body")).toContain("Platform creator overview");

    // 3. Navigate to Schools Fleet
    await page.goto("/sys-master/workspace/schools", { waitUntil: "networkidle" });
    await page.waitForSelector("table, .neu-table", { timeout: 5_000 });
    expect(await page.textContent("body")).toContain("Schools directory");

    // 4. Navigate to Create School
    await page.goto("/sys-master/workspace/create-school", { waitUntil: "networkidle" });
    await page.waitForSelector("form", { timeout: 5_000 });

    const testSchoolCode = `test-${Date.now().toString().slice(-4)}`;
    const testSchoolName = `Test Academy ${testSchoolCode}`;
    const testOwnerEmail = `owner@${testSchoolCode}.edu`;

    await page.fill('input[id="school-name"]', testSchoolName);
    await page.fill('input[id="school-code"]', testSchoolCode);
    await page.fill('input[id="owner-email"]', testOwnerEmail);
    await page.fill('input[id="owner-password"]', "Campus!Secure2026");

    // Submit school creation
    await page.click('button[type="submit"]');

    // 5. Verify one-time credentials modal
    await page.waitForSelector(".modal-window, [role='dialog']", { timeout: 8_000 });
    expect(await page.textContent("body")).toContain("School Provisioned Successfully");
    expect(await page.textContent("body")).toContain(testOwnerEmail);

    // Dismiss modal and return to schools list
    await page.click("button:has-text('Done & View Schools')");
    await page.waitForURL("**/sys-master/workspace/schools", { timeout: 5_000 });

    // 6. Navigate to other Master Panel tabs to ensure zero errors
    await page.goto("/sys-master/workspace/plans", { waitUntil: "networkidle" });
    expect(await page.textContent("body")).toContain("Subscription Tiers CRUD");

    await page.goto("/sys-master/workspace/roles", { waitUntil: "networkidle" });
    expect(await page.textContent("body")).toContain("Role & permission template matrix");

    await page.goto("/sys-master/workspace/monitoring", { waitUntil: "networkidle" });
    expect(await page.textContent("body")).toContain("Live platform monitoring");

    await page.goto("/sys-master/workspace/audit", { waitUntil: "networkidle" });
    expect(await page.textContent("body")).toContain("Platform immutable audit log");

    await page.goto("/sys-master/workspace/settings", { waitUntil: "networkidle" });
    expect(await page.textContent("body")).toContain("Settings & security configuration");
  });
});
});
