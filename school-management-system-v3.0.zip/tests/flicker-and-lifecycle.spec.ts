import { test, expect } from "@playwright/test";

type RoleConfig = {
  role: string;
  email: string;
  loginPath: string;
  homePath: string;
  routes: string[];
};

const rolesToTest: RoleConfig[] = [
  {
    role: "owner",
    email: "owner@greenwood.edu",
    loginPath: "/login",
    homePath: "/owner",
    routes: ["/owner", "/owner/people", "/owner/branches", "/owner/settings", "/owner/directory"],
  },
  {
    role: "principal",
    email: "principal@greenwood.edu",
    loginPath: "/login",
    homePath: "/principal",
    routes: ["/principal", "/principal/admissions", "/principal/directory"],
  },
  {
    role: "teacher",
    email: "teacher@greenwood.edu",
    loginPath: "/login",
    homePath: "/teacher",
    routes: ["/teacher", "/teacher/timetable", "/teacher/attendance"],
  },
  {
    role: "parent",
    email: "parent@greenwood.edu",
    loginPath: "/login",
    homePath: "/parent",
    routes: ["/parent", "/parent/attendance", "/parent/fees"],
  },
  {
    role: "student",
    email: "student@greenwood.edu",
    loginPath: "/login",
    homePath: "/student",
    routes: ["/student", "/student/timetable", "/student/assignments"],
  },
  {
    role: "accountant",
    email: "accountant@greenwood.edu",
    loginPath: "/login",
    homePath: "/accountant",
    routes: ["/accountant", "/accountant/fees", "/accountant/expenses"],
  },
  {
    role: "master",
    email: "master@greenwood.edu",
    loginPath: "/sys-master",
    homePath: "/sys-master/workspace",
    routes: ["/sys-master/workspace", "/sys-master/workspace/schools", "/sys-master/workspace/revenue"],
  },
];

test.describe("Step 1: Evidence-First Flicker, Reload & Lifecycle Tests", () => {
  for (const config of rolesToTest) {
    test(`Role [${config.role}]: single document load, zero console errors, CLS < 0.1, stable tab visibility`, async ({
      page,
    }) => {
      const consoleErrors: string[] = [];
      page.on("console", (msg) => {
        if (msg.type() === "error") {
          consoleErrors.push(msg.text());
        }
        if (msg.text().includes("[DEBUG") || msg.text().includes("[Tracker")) {
          console.log(msg.text());
        }
      });

      // 1. Navigate to login
      await page.goto(config.loginPath, { waitUntil: "networkidle" });

      // 2. Fill login form
      await page.fill('input[name="identifier"]', config.email);
      await page.fill('input[name="password"]', "Campus@2026");

      // 3. Submit
      await page.click('button[type="submit"]');
      await page.waitForURL(`**${config.homePath}`, { timeout: 10_000 });
      await page.waitForLoadState("networkidle");
      // Wait for shell and initial dashboard or home content to be rendered
      await page.waitForSelector(".admin-stat-grid, .school-home, .workspace-page, .dashboard-main-grid", {
        state: "visible",
        timeout: 10_000,
      });
      // Wait for all queries to settle completely
      await page.waitForFunction(() => {
        const qc = (window as unknown as { __queryClient?: { isFetching: () => number } }).__queryClient;
        return qc ? qc.isFetching() === 0 : true;
      });
      await page.waitForTimeout(600);

      // 4. Inspect tracker metrics on initial home route
      const metrics = await page.evaluate(() => {
        const tracker = (window as unknown as { __devTracker?: any }).__devTracker;
        return {
          documentLoads: tracker?.documentLoads ?? 1,
          authEvents: tracker?.authEvents ?? [],
          renderCounts: tracker?.renderCounts ?? {},
          layoutShifts: tracker?.layoutShifts ?? 0,
        };
      });

      // Document loads must be exactly 1 (no unwanted page reload)
      expect(metrics.documentLoads).toBe(1);

      // Auth state changes should be bounded (<= 2 for initial bootstrap + sign in)
      expect(metrics.authEvents.length).toBeLessThanOrEqual(2);

      // Cumulative layout shift must be < 0.1
      expect(metrics.layoutShifts).toBeLessThan(0.1);

      // Shell render count before tab visibility change
      const initialShellRenders = metrics.renderCounts["AppShell"] || 1;

      // 5. Test tab visibility change (hidden -> visible)
      await page.evaluate(() => {
        Object.defineProperty(document, "visibilityState", { value: "hidden", writable: true });
        document.dispatchEvent(new Event("visibilitychange"));
      });
      await page.waitForTimeout(300);
      await page.evaluate(() => {
        Object.defineProperty(document, "visibilityState", { value: "visible", writable: true });
        document.dispatchEvent(new Event("visibilitychange"));
      });
      await page.waitForTimeout(400);

      // Ensure tab visibility change caused 0 extra AppShell re-renders
      const afterVisibilityRenders = await page.evaluate(() => {
        const tracker = (window as unknown as { __devTracker?: any }).__devTracker;
        return tracker?.renderCounts["AppShell"] || 1;
      });
      expect(afterVisibilityRenders).toBe(initialShellRenders);

      // 6. Test sub-route navigations without reloading the document
      await page.waitForFunction(() => typeof (window as any).__devNavigate === "function");

      for (const route of config.routes) {
        await page.evaluate((target) => {
          const nav = (window as unknown as { __devNavigate?: (p: string) => void }).__devNavigate;
          if (nav) {
            nav(target);
          }
        }, route);
        await page.waitForTimeout(400);

        const currentLoads = await page.evaluate(() => {
          const tracker = (window as unknown as { __devTracker?: any }).__devTracker;
          return tracker?.documentLoads ?? 1;
        });
        // Still exactly 1 full document load
        expect(currentLoads).toBe(1);
      }

      // Zero console errors
      expect(consoleErrors).toEqual([]);
    });
  }
});
