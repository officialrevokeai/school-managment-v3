import { test as setup } from '@playwright/test';
import { readFileSync, existsSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

function loadQaCredentials(): Record<string, string> {
  const envFile = resolve(process.cwd(), '.env.test.local');
  const creds: Record<string, string> = {};
  if (existsSync(envFile)) {
    const lines = readFileSync(envFile, 'utf8').split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        creds[trimmed.slice(0, eqIdx).trim()] = trimmed.slice(eqIdx + 1).trim();
      }
    }
  }
  return creds;
}

const credentials = loadQaCredentials();

const rolesToSetup = [
  { role: 'master', path: '/sys-master/login', emailKey: 'QA_MASTER_EMAIL', passKey: 'QA_MASTER_PASSWORD', dest: 'master.json', expectedUrl: '**/sys-master/workspace' },
  { role: 'owner', path: '/login', emailKey: 'QA_OWNER_EMAIL', passKey: 'QA_OWNER_PASSWORD', dest: 'owner.json', expectedUrl: '**/owner' },
  { role: 'principal', path: '/login', emailKey: 'QA_PRINCIPAL_NORTH_EMAIL', passKey: 'QA_PRINCIPAL_NORTH_PASSWORD', dest: 'principal.json', expectedUrl: '**/principal' },
  { role: 'teacher', path: '/login', emailKey: 'QA_TEACHER_1_EMAIL', passKey: 'QA_TEACHER_1_PASSWORD', dest: 'teacher.json', expectedUrl: '**/teacher' },
  { role: 'parent', path: '/login', emailKey: 'QA_PARENT_1_EMAIL', passKey: 'QA_PARENT_1_PASSWORD', dest: 'parent.json', expectedUrl: '**/parent' },
  { role: 'student', path: '/login', emailKey: 'QA_STUDENT_1_EMAIL', passKey: 'QA_STUDENT_1_PASSWORD', dest: 'student.json', expectedUrl: '**/student' },
  { role: 'accountant', path: '/login', emailKey: 'QA_ACCOUNTANT_EMAIL', passKey: 'QA_ACCOUNTANT_PASSWORD', dest: 'accountant.json', expectedUrl: '**/accountant' },
];

const playwrightDir = resolve(process.cwd(), '.playwright');
if (!existsSync(playwrightDir)) {
  mkdirSync(playwrightDir, { recursive: true });
}

for (const target of rolesToSetup) {
  setup(`authenticate as ${target.role}`, async ({ page, context }) => {
    // Tracing and recording strictly disabled during credential entry
    await context.tracing.stop({ path: undefined }).catch(() => {});

    const email = credentials[target.emailKey];
    const password = credentials[target.passKey];

    if (!email || !password) {
      throw new Error(`Missing QA credentials for role ${target.role}. Ensure scripts/qa-seed.ts has run.`);
    }

    await page.goto(target.path, { waitUntil: 'networkidle' });

    // If already at expected destination, save state and exit
    if (page.url().includes(target.expectedUrl.replace(/\*/g, ''))) {
      const authStatePath = resolve(playwrightDir, target.dest);
      await page.context().storageState({ path: authStatePath });
      return;
    }

    if (target.role === 'master') {
      const onLogin = await page.waitForSelector('#master-email', { timeout: 4_000 }).catch(() => null);
      if (onLogin && !page.url().includes('sys-master/workspace')) {
        await page.fill('#master-email', email);
        await page.fill('#master-password', password);
        await page.click('button[type="submit"]');

        // Check if redirected directly or if TOTP prompt appeared
        const outcome = await Promise.race([
          page.waitForURL(target.expectedUrl, { timeout: 10_000 }).then(() => 'redirected' as const),
          page.waitForSelector('#totp-code', { timeout: 8_000 }).then(() => 'totp' as const),
        ]).catch(() => null);

        if (outcome === 'totp') {
          await page.fill('#totp-code', '123456');
          await page.click('button[type="submit"]');
        }
      }
    } else {
      const onLogin = await page.waitForSelector('#identifier', { timeout: 4_000 }).catch(() => null);
      if (onLogin) {
        await page.fill('#identifier', email);
        await page.fill('#password', password);
        await page.click('button[type="submit"]');
      }
    }

    // Wait for redirect to role workspace/dashboard
    await page.waitForURL(target.expectedUrl, { timeout: 15_000 });

    // Save authenticated storage state
    const authStatePath = resolve(playwrightDir, target.dest);
    await page.context().storageState({ path: authStatePath });
  });
}
