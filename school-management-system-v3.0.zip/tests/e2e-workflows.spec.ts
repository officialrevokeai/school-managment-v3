import { test, expect } from "@playwright/test";

// Helper to attach error listener & verify zero console errors
function trackConsole(page: import("@playwright/test").Page) {
  const errors: string[] = [];
  page.on("console", (msg) => {
    if (msg.type() === "error") {
      const text = msg.text();
      if (!text.includes("net::ERR_ABORTED") && !text.includes("favicon")) {
        console.error(`[BROWSER ERROR]: ${text}`);
        errors.push(text);
      }
    }
  });
  page.on("response", (res) => {
    if (res.status() >= 400 && !res.url().includes("favicon")) {
      console.error(`[HTTP ${res.status()}] ${res.url()}`);
    }
  });
  return errors;
}

test.describe("Phase T5: E2E Workflows Across Roles & Devices", () => {
  // 1. MASTER CONSOLE WORKFLOWS
  test.describe("1. Master Admin Workflows", () => {
    test.use({ storageState: ".playwright/master.json" });

    test("Master: Platform Overview renders metrics and telemetry", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/sys-master/workspace/overview", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      // Overview heading or metrics
      await expect(page.getByText(/Platform Overview|System Overview|Fleet|Master/i).first()).toBeVisible({ timeout: 15_000 });
      expect(errors).toHaveLength(0);
    });

    test("Master: Schools Directory lists registered tenants", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/sys-master/workspace/schools", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      await expect(page.getByText(/QA Test School|Schools|Campus/i).first()).toBeVisible({ timeout: 15_000 });
      expect(errors).toHaveLength(0);
    });

    test("Master: Create School page renders provisioning controls", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/sys-master/workspace/create-school", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      // Form fields for school creation
      await expect(page.locator("#school-name")).toBeVisible({ timeout: 15_000 });
      expect(errors).toHaveLength(0);
    });

    test("Master: Revenue, Plans, and Monitoring dashboards load cleanly", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/sys-master/workspace/plans", { waitUntil: "networkidle" });
      await expect(page.getByText(/Plans|Starter|Growth|Enterprise/i).first()).toBeVisible({ timeout: 15_000 });

      await page.goto("/sys-master/workspace/monitoring", { waitUntil: "networkidle" });
      await expect(page.getByText(/Monitoring|Telemetry|Metrics|Health/i).first()).toBeVisible({ timeout: 15_000 });
      expect(errors).toHaveLength(0);
    });
  });

  // 2. OWNER WORKFLOWS
  test.describe("2. School Owner Workflows", () => {
    test.use({ storageState: ".playwright/owner.json" });

    test("Owner: Dashboard renders stat cards and charts", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/owner", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      await expect(page.locator(".admin-stat-grid, .school-home, .workspace-page, .dashboard-main-grid, main").first()).toBeVisible({ timeout: 15_000 });
      expect(errors).toHaveLength(0);
    });

    test("Owner: Staff and Student Rosters load under People records", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/owner/people", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      await expect(page.getByText(/Users|Staff|Students|People|Directory/i).first()).toBeVisible({ timeout: 15_000 });
      expect(errors).toHaveLength(0);
    });

    test("Owner: Permissions, Settings, and Audit views load", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/owner/roles", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/owner/settings", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/owner/audit", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      expect(errors).toHaveLength(0);
    });
  });

  // 3. PRINCIPAL WORKFLOWS
  test.describe("3. Campus Principal Workflows", () => {
    test.use({ storageState: ".playwright/principal.json" });

    test("Principal: Campus home and Directory load", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/principal", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/principal/directory", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      expect(errors).toHaveLength(0);
    });

    test("Principal: Attendance and Classes workflow views load", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/principal/attendance", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/principal/classes", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      expect(errors).toHaveLength(0);
    });
  });

  // 4. TEACHER WORKFLOWS
  test.describe("4. Teacher Workflows", () => {
    test.use({ storageState: ".playwright/teacher.json" });

    test("Teacher: Dashboard, Attendance, and Timetable load", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/teacher", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/teacher/attendance", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/teacher/timetable", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      expect(errors).toHaveLength(0);
    });
  });

  // 5. PARENT WORKFLOWS
  test.describe("5. Parent Workflows", () => {
    test.use({ storageState: ".playwright/parent.json" });

    test("Parent: Portal, Child Attendance, and Fee Invoices load", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/parent", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/parent/attendance", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/parent/fees", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      expect(errors).toHaveLength(0);
    });
  });

  // 6. STUDENT WORKFLOWS
  test.describe("6. Student Workflows", () => {
    test.use({ storageState: ".playwright/student.json" });

    test("Student: Portal, Timetable, and Assignments load", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/student", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/student/timetable", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/student/assignments", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      expect(errors).toHaveLength(0);
    });
  });

  // 7. ACCOUNTANT WORKFLOWS
  test.describe("7. Accountant Workflows", () => {
    test.use({ storageState: ".playwright/accountant.json" });

    test("Accountant: Portal, Fee collection ledger, and Expenses load", async ({ page }) => {
      const errors = trackConsole(page);
      await page.goto("/accountant", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/accountant/fees", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();

      await page.goto("/accountant/expenses", { waitUntil: "networkidle" });
      await expect(page.locator("body")).toBeVisible();
      expect(errors).toHaveLength(0);
    });
  });
});
