import { test, expect } from "@playwright/test";

test.describe("Step 8: Responsive Layouts & Theme Checks", () => {
  const viewports = [
    { name: "mobile (360px)", width: 360, height: 800 },
    { name: "tablet (768px)", width: 768, height: 1024 },
    { name: "desktop (1280px)", width: 1280, height: 800 },
  ];

  for (const vp of viewports) {
    test(`No horizontal overflow at ${vp.name}`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto("/login", { waitUntil: "networkidle" });

      const hasHorizontalScroll = await page.evaluate(() => {
        return document.documentElement.scrollWidth > window.innerWidth;
      });
      expect(hasHorizontalScroll).toBe(false);

      // Sign in as Owner to inspect dashboard responsiveness
      await page.fill('input[name="identifier"]', "owner@greenwood.edu");
      await page.fill('input[name="password"]', "Campus@2026");
      await page.click('button[type="submit"]');

      await page.waitForURL("**/owner", { timeout: 10_000 });
      await page.waitForLoadState("networkidle");
      await page.waitForTimeout(600);

      const dashboardScroll = await page.evaluate(() => {
        return document.documentElement.scrollWidth > window.innerWidth;
      });
      expect(dashboardScroll).toBe(false);
    });
  }

  test("Theme toggle: seamless light and dark mode transition", async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 800 });
    await page.goto("/login", { waitUntil: "networkidle" });

    // Verify initial theme is applied without flash
    const initialTheme = await page.evaluate(() => {
      return document.documentElement.classList.contains("dark") ? "dark" : "light";
    });
    expect(["dark", "light"]).toContain(initialTheme);

    // Toggle theme to opposite
    await page.evaluate(() => {
      document.documentElement.classList.toggle("dark");
    });
    await page.waitForTimeout(200);

    const toggledTheme = await page.evaluate(() => {
      return document.documentElement.classList.contains("dark") ? "dark" : "light";
    });
    expect(toggledTheme).not.toBe(initialTheme);
  });
});
