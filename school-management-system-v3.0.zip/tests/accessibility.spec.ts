import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

test.describe("Phase T7: Accessibility Audits (WCAG 2.1 AA & Section 508)", () => {
  test.describe("Login & Public Views", () => {
    test("Login page meets WCAG 2.1 AA accessibility standards", async ({ page }) => {
      await page.goto("/login", { waitUntil: "networkidle" });
      const accessibilityScanResults = await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
        .analyze();

      const criticalViolations = accessibilityScanResults.violations.filter(
        (v) => v.impact === "critical" || v.impact === "serious",
      );
      expect(criticalViolations).toEqual([]);
    });

    test("Master Login page meets WCAG 2.1 AA accessibility standards", async ({ page }) => {
      await page.goto("/sys-master", { waitUntil: "networkidle" });
      const accessibilityScanResults = await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
        .analyze();

      const criticalViolations = accessibilityScanResults.violations.filter(
        (v) => v.impact === "critical" || v.impact === "serious",
      );
      expect(criticalViolations).toEqual([]);
    });
  });

  test.describe("Owner Portal Views", () => {
    test.use({ storageState: ".playwright/owner.json" });

    test("Owner Dashboard meets accessibility standards", async ({ page }) => {
      await page.goto("/owner", { waitUntil: "networkidle" });
      const accessibilityScanResults = await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
        .analyze();

      const criticalViolations = accessibilityScanResults.violations.filter(
        (v) => v.impact === "critical" || v.impact === "serious",
      );
      expect(criticalViolations).toEqual([]);
    });
  });

  test.describe("Teacher Portal Views", () => {
    test.use({ storageState: ".playwright/teacher.json" });

    test("Teacher Attendance view meets accessibility standards", async ({ page }) => {
      await page.goto("/teacher/attendance", { waitUntil: "networkidle" });
      const accessibilityScanResults = await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
        .analyze();

      const criticalViolations = accessibilityScanResults.violations.filter(
        (v) => v.impact === "critical" || v.impact === "serious",
      );
      expect(criticalViolations).toEqual([]);
    });
  });

  test.describe("Student Portal Views", () => {
    test.use({ storageState: ".playwright/student.json" });

    test("Student Portal meets accessibility standards", async ({ page }) => {
      await page.goto("/student", { waitUntil: "networkidle" });
      const accessibilityScanResults = await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"])
        .analyze();

      const criticalViolations = accessibilityScanResults.violations.filter(
        (v) => v.impact === "critical" || v.impact === "serious",
      );
      expect(criticalViolations).toEqual([]);
    });
  });
});
