import { readdirSync, statSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

function walk(dir: string, filter: (f: string) => boolean, out: string[] = []): string[] {
  for (const item of readdirSync(dir)) {
    const p = join(dir, item);
    if (statSync(p).isDirectory()) {
      if (item !== 'node_modules' && item !== '.git' && item !== 'dist') walk(p, filter, out);
    } else if (filter(p)) {
      out.push(p);
    }
  }
  return out;
}

const srcFiles = walk('src', (f) => f.endsWith('.tsx') || f.endsWith('.ts'));
const appFiles = walk('src/app', (f) => f.endsWith('.tsx'));
const featureFiles = walk('src/features', (f) => f.endsWith('.tsx'));
console.log('=== APP ROUTING FILES (' + appFiles.length + ') ===');
appFiles.forEach(p => console.log(' ', p));
console.log('\n=== FEATURE VIEWS (' + featureFiles.length + ') ===');
featureFiles.forEach(p => console.log(' ', p));

// 2. Direct table queries vs RPCs vs Edge Functions
const tableQueries = new Map<string, string[]>();
const rpcCalls = new Map<string, string[]>();
const edgeFunctionCalls = new Map<string, string[]>();

for (const file of srcFiles) {
  const content = readFileSync(file, 'utf8');
  const fromMatches = content.matchAll(/\.from\(['"]([a-zA-Z0-9_]+)['"]\)/g);
  for (const m of fromMatches) {
    const list = tableQueries.get(m[1]) || [];
    list.push(file);
    tableQueries.set(m[1], list);
  }

  const rpcMatches = content.matchAll(/\.rpc\(['"]([a-zA-Z0-9_]+)['"]/g);
  for (const m of rpcMatches) {
    const list = rpcCalls.get(m[1]) || [];
    list.push(file);
    rpcCalls.set(m[1], list);
  }

  const funcMatches = content.matchAll(/functions\.invoke\(['"]([a-zA-Z0-9_-]+)['"]/g);
  for (const m of funcMatches) {
    const list = edgeFunctionCalls.get(m[1]) || [];
    list.push(file);
    edgeFunctionCalls.set(m[1], list);
  }
}

console.log('\n=== TABLES DIRECTLY QUERIED FROM FRONTEND ===');
for (const [tbl, callers] of tableQueries.entries()) {
  console.log(`  ${tbl} (${callers.length} files)`);
}

console.log('\n=== RPCS CALLED FROM FRONTEND ===');
for (const [rpc, callers] of rpcCalls.entries()) {
  console.log(`  ${rpc} (${callers.length} files)`);
}

console.log('\n=== EDGE FUNCTIONS CALLED FROM FRONTEND ===');
for (const [fn, callers] of edgeFunctionCalls.entries()) {
  console.log(`  ${fn} (${callers.length} files)`);
}
