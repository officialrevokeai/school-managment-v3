import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const inventory = JSON.parse(readFileSync(resolve(process.cwd(), 'docs', 'schema-inventory.json'), 'utf8'));

console.log('=== RLS STATUS ON TABLES ===');
const unenabled = inventory.tables.filter((t: any) => !t.rls_enabled);
if (unenabled.length > 0) {
  console.log(`WARNING: ${unenabled.length} tables have RLS DISABLED:`, unenabled.map((t: any) => t.table_name));
} else {
  console.log('ALL 47 tables have RLS ENABLED!');
}

console.log('\n=== SECURITY DEFINER FUNCTIONS AUDIT ===');
const secDef = inventory.functions.filter((f: any) => f.security_definer);
console.log(`Total security definer functions: ${secDef.length}`);
const missingPath = secDef.filter((f: any) => !f.has_empty_search_path);
if (missingPath.length > 0) {
  console.log(`WARNING: ${missingPath.length} security definer functions MISSING search_path:`, missingPath.map((f: any) => f.function_name));
} else {
  console.log('All security definer functions have search_path configured!');
}

console.log('\n=== POLICIES AUDIT ===');
console.log(`Total policies: ${inventory.policies.length}`);
const usingTrue = inventory.policies.filter((p: any) => p.qual === 'true');
if (usingTrue.length > 0) {
  console.log(`WARNING: ${usingTrue.length} policies using 'true':`, usingTrue.map((p: any) => `${p.tablename}.${p.policyname} (${p.cmd})`));
}

console.log('\n=== GRANTS AUDIT ===');
const anonGrants = inventory.grants.filter((g: any) => g.grantee === 'anon');
console.log(`Grants to anon: ${anonGrants.length}`);
if (anonGrants.length > 0) {
  console.log(anonGrants);
}

console.log('\n=== EXTENSIONS ===');
console.log(inventory.extensions.map((e: any) => `${e.extname} (v${e.extversion})`).join(', '));
