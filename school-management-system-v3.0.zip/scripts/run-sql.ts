import { Client } from 'pg';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

function getEnvSecrets() {
  const envFile = resolve(process.cwd(), '.env.server.local');
  const env: Record<string, string> = {};
  if (existsSync(envFile)) {
    const content = readFileSync(envFile, 'utf8');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        env[trimmed.slice(0, eqIdx).trim()] = trimmed.slice(eqIdx + 1).trim();
      }
    }
  }
  return env;
}

export async function getDbClient() {
  const env = getEnvSecrets();
  const targetRef = env.SUPABASE_PROJECT_REF || 'oqsvedpkqgajjrnxbehz';
  const poolerHost = env.SUPABASE_POOLER_HOST || 'aws-0-ap-southeast-1.pooler.supabase.com';

  // Pooler is reliable on IPv4 networks
  try {
    const poolerClient = new Client({
      host: poolerHost,
      port: 6543,
      database: 'postgres',
      user: `postgres.${targetRef}`,
      password: env.SUPABASE_DB_PASSWORD,
      ssl: { rejectUnauthorized: false },
      connectionTimeoutMillis: 5000,
    });
    poolerClient.on('error', (err) => {
      // suppress unhandled errors on disconnect
    });
    await poolerClient.connect();
    return poolerClient;
  } catch {
    const directClient = new Client({
      host: `db.${targetRef}.supabase.co`,
      port: 5432,
      database: 'postgres',
      user: 'postgres',
      password: env.SUPABASE_DB_PASSWORD,
      ssl: { rejectUnauthorized: false },
      connectionTimeoutMillis: 5000,
    });
    directClient.on('error', () => {});
    await directClient.connect();
    return directClient;
  }
}

export async function executeSql(sql: string) {
  const client = await getDbClient();
  try {
    const res = await client.query(sql);
    return res;
  } finally {
    await client.end();
  }
}

if (process.argv[2]) {
  const arg = process.argv[2];
  const sql = existsSync(arg) ? readFileSync(arg, 'utf8') : arg;
  executeSql(sql)
    .then((res) => {
      console.log('SQL executed successfully:', res.command, res.rowCount);
      if (res.rows && res.rows.length > 0) {
        console.log('Result rows:', JSON.stringify(res.rows));
      }
    })
    .catch((err) => {
      console.error('SQL execution failed:', err.message);
      process.exit(1);
    });
}
