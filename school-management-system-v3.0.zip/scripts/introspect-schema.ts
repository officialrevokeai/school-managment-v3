import { Client } from 'pg';
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

function getEnvSecrets() {
  const envFile = resolve(process.cwd(), '.env.server.local');
  const env: Record<string, string> = {};
  if (existsSync(envFile)) {
    const content = readFileSync(envFile, 'utf8');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        env[trimmed.slice(0, eqIdx).trim()] = trimmed.slice(eqIdx + 1).trim();
      }
    }
  }
  return env;
}

async function introspect() {
  const env = getEnvSecrets();
  const dbPassword = env.SUPABASE_DB_PASSWORD;
  const client = new Client({
    host: 'db.oqsvedpkqgajjrnxbehz.supabase.co',
    port: 5432,
    database: 'postgres',
    user: 'postgres',
    password: dbPassword,
    ssl: { rejectUnauthorized: false },
  });

  await client.connect();

  try {
    // 1. Tables & RLS status
    const tablesRes = await client.query(`
      SELECT 
        c.relname as table_name,
        c.relrowsecurity as rls_enabled,
        c.relforcerowsecurity as rls_forced
      FROM pg_class c
      JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = 'public' AND c.relkind = 'r'
      ORDER BY c.relname;
    `);

    // 2. Views
    const viewsRes = await client.query(`
      SELECT 
        table_name,
        view_definition
      FROM information_schema.views
      WHERE table_schema = 'public'
      ORDER BY table_name;
    `);

    // 3. Policies
    const policiesRes = await client.query(`
      SELECT 
        schemaname,
        tablename,
        policyname,
        permissive,
        roles,
        cmd,
        qual,
        with_check
      FROM pg_policies
      WHERE schemaname = 'public'
      ORDER BY tablename, policyname;
    `);

    // 4. Grants on public tables
    const grantsRes = await client.query(`
      SELECT 
        table_name,
        grantee,
        privilege_type
      FROM information_schema.role_table_grants
      WHERE table_schema = 'public' AND grantee IN ('anon', 'authenticated')
      ORDER BY table_name, grantee, privilege_type;
    `);

    // 5. Functions & Security Definer
    const funcsRes = await client.query(`
      SELECT 
        p.proname as function_name,
        pg_get_function_arguments(p.oid) as arguments,
        p.prosecdef as security_definer,
        p.proconfig as config,
        pg_get_functiondef(p.oid) as definition
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname = 'public'
      ORDER BY p.proname;
    `);

    // 6. Triggers
    const triggersRes = await client.query(`
      SELECT 
        trigger_name,
        event_manipulation,
        event_object_table,
        action_statement,
        action_timing
      FROM information_schema.triggers
      WHERE trigger_schema = 'public'
      ORDER BY event_object_table, trigger_name;
    `);

    // 7. Storage buckets
    let bucketsRes = { rows: [] as any[] };
    try {
      bucketsRes = await client.query(`SELECT id, name, public, file_size_limit, allowed_mime_types FROM storage.buckets;`);
    } catch (e: any) {
      console.warn('Could not read storage.buckets:', e.message);
    }

    // 8. Cron jobs
    let cronRes = { rows: [] as any[] };
    try {
      cronRes = await client.query(`SELECT jobid, schedule, command, nodename, nodeport, database, username, active FROM cron.job;`);
    } catch (e: any) {
      console.warn('Could not read cron.job:', e.message);
    }

    // 9. Extensions
    const extRes = await client.query(`SELECT extname, extversion FROM pg_extension;`);

    const inventory = {
      tables: tablesRes.rows,
      views: viewsRes.rows,
      policies: policiesRes.rows,
      grants: grantsRes.rows,
      functions: funcsRes.rows.map(f => ({
        function_name: f.function_name,
        arguments: f.arguments,
        security_definer: f.security_definer,
        config: f.config,
        has_empty_search_path: f.config ? f.config.some((c: string) => c.startsWith('search_path=')) : false,
      })),
      triggers: triggersRes.rows,
      storage_buckets: bucketsRes.rows,
      cron_jobs: cronRes.rows,
      extensions: extRes.rows,
    };

    writeFileSync(resolve(process.cwd(), 'docs', 'schema-inventory.json'), JSON.stringify(inventory, null, 2), 'utf8');
    console.log('Schema inventory successfully saved to docs/schema-inventory.json');
    console.log(`Summary: ${inventory.tables.length} tables, ${inventory.views.length} views, ${inventory.policies.length} policies, ${inventory.functions.length} functions, ${inventory.triggers.length} triggers, ${inventory.storage_buckets.length} buckets, ${inventory.cron_jobs.length} cron jobs.`);
  } finally {
    await client.end();
  }
}

introspect().catch(err => {
  console.error('Introspection failed:', err.message);
  process.exit(1);
});
