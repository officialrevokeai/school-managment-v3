import { Client } from 'pg';
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { readFileSync, existsSync, unlinkSync } from 'node:fs';
import { resolve } from 'node:path';

const TARGET_REF = 'oqsvedpkqgajjrnxbehz';

function getEnvSecrets() {
  const envFile = resolve(process.cwd(), '.env.server.local');
  const env: Record<string, string> = {};
  if (existsSync(envFile)) {
    const content = readFileSync(envFile, 'utf8');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        env[trimmed.slice(0, eqIdx).trim()] = trimmed.slice(eqIdx + 1).trim();
      }
    }
  }
  return env;
}

async function getAdminClient(projectRef: string, accessToken: string): Promise<SupabaseClient> {
  const res = await fetch(`https://api.supabase.com/v1/projects/${projectRef}/api-keys`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch project API keys: ${res.status} ${res.statusText}`);
  }
  const keys = await res.json();
  const serviceKey = keys.find((k: { name: string; api_key: string }) => k.name === 'service_role')?.api_key;
  if (!serviceKey) throw new Error('service_role key not found');

  return createClient(`https://${projectRef}.supabase.co`, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}

export async function teardownQaTenant() {
  const env = getEnvSecrets();
  const dbPassword = env.SUPABASE_DB_PASSWORD;
  const accessToken = env.SUPABASE_ACCESS_TOKEN;
  if (!dbPassword) throw new Error('SUPABASE_DB_PASSWORD missing');
  if (!accessToken) throw new Error('SUPABASE_ACCESS_TOKEN missing');

  const projectRef = env.SUPABASE_PROJECT_REF || TARGET_REF;
  if (projectRef !== TARGET_REF) {
    throw new Error(`Target ref mismatch! Refusing to teardown: Expected ${TARGET_REF}, got ${projectRef}`);
  }

  console.log(`Connecting to Postgres database for project ref: ${TARGET_REF}...`);
  let client: Client;
  try {
    const directClient = new Client({
      host: `db.${TARGET_REF}.supabase.co`,
      port: 5432,
      database: 'postgres',
      user: 'postgres',
      password: dbPassword,
      ssl: { rejectUnauthorized: false },
      connectionTimeoutMillis: 2000,
    });
    await directClient.connect();
    client = directClient;
  } catch {
    const poolerClient = new Client({
      host: env.SUPABASE_POOLER_HOST || 'aws-0-ap-southeast-1.pooler.supabase.com',
      port: 6543,
      database: 'postgres',
      user: `postgres.${TARGET_REF}`,
      password: dbPassword,
      ssl: { rejectUnauthorized: false },
    });
    await poolerClient.connect();
    client = poolerClient;
  }

  try {
    console.log('--- Starting QA Tenant Teardown ---');

    // Disable immutable trigger temporarily for QA audit log cleanup
    try {
      await client.query('ALTER TABLE public.audit_logs DISABLE TRIGGER trg_audit_logs_append_only;');
      const auditRes = await client.query(`
        DELETE FROM public.audit_logs 
        WHERE is_qa = true 
           OR school_id IN (SELECT id FROM public.schools WHERE is_qa = true) 
           OR actor_id IN (SELECT id FROM public.profiles WHERE is_qa = true);
      `);
      if (auditRes.rowCount && auditRes.rowCount > 0) {
        console.log(`Deleted ${auditRes.rowCount} QA audit log rows.`);
      }
    } catch (err: any) {
      console.warn('Warning during audit log cleanup:', err.message);
    }

    // 1. Delete QA test data in reverse foreign key order
    console.log('Deleting QA records across tables where is_qa = true...');
    
    const qaTables = [
      'audit_logs',
      'school_workflows',
      'attendance_records',
      'student_fees',
      'fee_payments',
      'fee_structures',
      'class_students',
      'school_students',
      'classes',
      'school_classes',
      'school_memberships',
      'subjects',
      'timetable_entries',
      'assignments',
      'exams',
      'marks',
      'admissions',
      'announcements',
      'leaves',
      'lesson_plans',
      'meetings',
      'certificates',
      'notifications',
      'export_jobs',
      'import_jobs',
      'reconciliations',
      'expenses',
      'vendors',
      'payroll_records',
      'admin_records',
      'user_consents',
      'security_alerts',
      'system_metrics',
      'user_role_overrides',
      'roles',
      'profiles',
      'branches',
      'subscriptions',
      'schools',
    ];

    for (const table of qaTables) {
      try {
        const res = await client.query(`DELETE FROM public.${table} WHERE is_qa = true;`);
        if (res.rowCount && res.rowCount > 0) {
          console.log(`Deleted ${res.rowCount} QA rows from public.${table}`);
        }
      } catch (err: any) {
        console.warn(`Warning deleting from public.${table}: ${err.message}`);
      }
    }

    // Final sweep of audit logs generated by triggers during table deletions
    try {
      const res = await client.query(`DELETE FROM public.audit_logs WHERE is_qa = true;`);
      if (res.rowCount && res.rowCount > 0) {
        console.log(`Cleaned ${res.rowCount} trigger-generated QA rows from public.audit_logs`);
      }
    } catch (err: any) {
      console.warn(`Warning sweeping audit_logs: ${err.message}`);
    }

    try {
      await client.query('ALTER TABLE public.audit_logs ENABLE TRIGGER trg_audit_logs_append_only;');
    } catch (err: any) {
      console.warn('Warning re-enabling audit log trigger:', err.message);
    }

    // 2. Delete QA Users from Supabase Auth Admin API
    console.log('Deleting QA users via Auth Admin API...');
    const adminClient = await getAdminClient(TARGET_REF, accessToken);
    const dbUsers = await client.query("SELECT id FROM auth.users WHERE email LIKE '%@qatest.internal';");
    let deletedCount = 0;
    for (const row of dbUsers.rows) {
      try {
        await adminClient.auth.admin.deleteUser(row.id);
        deletedCount++;
      } catch (err: any) {
        console.warn(`Warning deleting auth user ${row.id}:`, err.message);
      }
    }
    console.log(`Deleted ${deletedCount} QA users via Auth Admin API.`);

    // 3. Verify zero QA residue
    console.log('Verifying 0 QA residue in database...');
    const verifySchools = await client.query(`SELECT count(*) FROM public.schools WHERE is_qa = true;`);
    const verifyUsers = await client.query(`SELECT count(*) FROM auth.users WHERE email LIKE '%@qatest.internal';`);
    const verifyProfiles = await client.query(`SELECT count(*) FROM public.profiles WHERE is_qa = true;`);
    const verifyAuditLogs = await client.query(`SELECT count(*) FROM public.audit_logs WHERE is_qa = true;`);

    const remainingSchools = Number(verifySchools.rows[0].count);
    const remainingUsers = Number(verifyUsers.rows[0].count);
    const remainingProfiles = Number(verifyProfiles.rows[0].count);
    const remainingAuditLogs = Number(verifyAuditLogs.rows[0].count);

    if (remainingSchools > 0 || remainingUsers > 0 || remainingProfiles > 0 || remainingAuditLogs > 0) {
      throw new Error(`QA Teardown incomplete! Remaining: schools=${remainingSchools}, users=${remainingUsers}, profiles=${remainingProfiles}, audit_logs=${remainingAuditLogs}`);
    }

    // 4. Remove local QA credentials file if present
    const envTestLocalPath = resolve(process.cwd(), '.env.test.local');
    if (existsSync(envTestLocalPath)) {
      unlinkSync(envTestLocalPath);
      console.log('Cleaned up .env.test.local credentials.');
    }

    console.log('QA Tenant Teardown complete. Zero residue verified.');
  } finally {
    await client.end();
  }
}

if (process.argv[1]?.endsWith('qa-teardown.ts')) {
  teardownQaTenant().catch((err) => {
    console.error('QA Teardown failed:', err.message);
    process.exit(1);
  });
}
