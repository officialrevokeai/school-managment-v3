import { Client } from 'pg';
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { randomBytes, randomUUID } from 'node:crypto';

const TARGET_REF = 'oqsvedpkqgajjrnxbehz';

function getEnvSecrets() {
  const envFile = resolve(process.cwd(), '.env.server.local');
  const env: Record<string, string> = {};
  if (existsSync(envFile)) {
    const content = readFileSync(envFile, 'utf8');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        env[trimmed.slice(0, eqIdx).trim()] = trimmed.slice(eqIdx + 1).trim();
      }
    }
  }
  return env;
}

function generatePassword(): string {
  return randomBytes(8).toString('hex') + 'Aa1!' + randomBytes(4).toString('hex');
}

async function getAdminClient(projectRef: string, accessToken: string): Promise<SupabaseClient> {
  const res = await fetch(`https://api.supabase.com/v1/projects/${projectRef}/api-keys`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch project API keys: ${res.status} ${res.statusText}`);
  }
  const keys = await res.json();
  const serviceKey = keys.find((k: { name: string; api_key: string }) => k.name === 'service_role')?.api_key;
  if (!serviceKey) throw new Error('service_role key not found');

  return createClient(`https://${projectRef}.supabase.co`, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}

export async function seedQaTenant() {
  const env = getEnvSecrets();
  const dbPassword = env.SUPABASE_DB_PASSWORD;
  const accessToken = env.SUPABASE_ACCESS_TOKEN;
  if (!dbPassword) throw new Error('SUPABASE_DB_PASSWORD missing');
  if (!accessToken) throw new Error('SUPABASE_ACCESS_TOKEN missing');

  const projectRef = env.SUPABASE_PROJECT_REF || TARGET_REF;
  if (projectRef !== TARGET_REF) {
    throw new Error(`Target ref mismatch! Expected ${TARGET_REF}, got ${projectRef}`);
  }

  console.log(`Initializing Admin Auth client for project ref: ${TARGET_REF}...`);
  const adminClient = await getAdminClient(TARGET_REF, accessToken);

  console.log(`Connecting to Postgres database for project ref: ${TARGET_REF}...`);
  let client: Client;
  try {
    const directClient = new Client({
      host: `db.${TARGET_REF}.supabase.co`,
      port: 5432,
      database: 'postgres',
      user: 'postgres',
      password: dbPassword,
      ssl: { rejectUnauthorized: false },
      connectionTimeoutMillis: 2000,
    });
    await directClient.connect();
    client = directClient;
  } catch {
    const poolerClient = new Client({
      host: env.SUPABASE_POOLER_HOST || 'aws-0-ap-southeast-1.pooler.supabase.com',
      port: 6543,
      database: 'postgres',
      user: `postgres.${TARGET_REF}`,
      password: dbPassword,
      ssl: { rejectUnauthorized: false },
    });
    await poolerClient.connect();
    client = poolerClient;
  }

  try {
    console.log('--- Starting Idempotent QA Tenant Seed (Auth Admin API + Postgres) ---');

    // 1. Clean existing QA users via Auth Admin API & QA data
    console.log('Cleaning any previous QA test data & auth users...');
    const { data: listData } = await adminClient.auth.admin.listUsers({ page: 1, perPage: 100 });
    if (listData?.users) {
      for (const u of listData.users) {
        if (u.email && u.email.endsWith('@qatest.internal')) {
          await adminClient.auth.admin.deleteUser(u.id);
        }
      }
    }

    await client.query(`DELETE FROM public.audit_logs WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.school_workflows WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.attendance_records WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.student_fees WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.fee_structures WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.class_students WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.school_students WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.school_classes WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.classes WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.school_memberships WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.admin_records WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.profiles WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.branches WHERE is_qa = true;`);
    await client.query(`DELETE FROM public.schools WHERE is_qa = true;`);
    await client.query(`DELETE FROM auth.identities WHERE email LIKE '%@qatest.internal';`);
    await client.query(`DELETE FROM auth.users WHERE email LIKE '%@qatest.internal';`);

    // 2. Generate Credentials Map for .env.test.local
    const credentials: Record<string, string> = {
      QA_MODE: 'true',
      QA_PROJECT_REF: TARGET_REF,
    };

    // 3. Create QA School A (Primary Multi-Branch School)
    const schoolAId = randomUUID();
    const branch1Id = randomUUID();
    const branch2Id = randomUUID();

    await client.query(`
      INSERT INTO public.schools (id, name, code, status, plan, monthly_fee, owner_email, is_qa, created_at, updated_at)
      VALUES ($1, 'QA Test School', 'QA-TEST-01', 'Active', 'Growth', 15000.00, 'qa-owner@qatest.internal', true, NOW(), NOW());
    `, [schoolAId]);

    await client.query(`
      INSERT INTO public.branches (id, school_id, name, city, code, short_name, principal_name, capacity, status, is_qa, created_at, updated_at)
      VALUES 
        ($1, $2, 'QA North Campus', 'QA City', 'QA-NORTH', 'QAN', 'Principal North', 500, 'Active', true, NOW(), NOW()),
        ($3, $2, 'QA South Campus', 'QA City', 'QA-SOUTH', 'QAS', 'Principal South', 500, 'Active', true, NOW(), NOW());
    `, [branch1Id, schoolAId, branch2Id]);

    // 4. Create QA School B (Cross-Tenant Isolation School)
    const schoolBId = randomUUID();
    const branchBId = randomUUID();

    await client.query(`
      INSERT INTO public.schools (id, name, code, status, plan, monthly_fee, owner_email, is_qa, created_at, updated_at)
      VALUES ($1, 'QA Isolation School B', 'QA-ISOL-02', 'Active', 'Starter', 8000.00, 'qa-owner-b@qatest.internal', true, NOW(), NOW());
    `, [schoolBId]);

    await client.query(`
      INSERT INTO public.branches (id, school_id, name, city, code, short_name, principal_name, capacity, status, is_qa, created_at, updated_at)
      VALUES ($1, $2, 'QA School B Main Campus', 'QA City', 'QA-B-MAIN', 'QAB', 'Principal B', 500, 'Active', true, NOW(), NOW());
    `, [branchBId, schoolBId]);

    // Record schools in admin_records for Master schools directory
    await client.query(`
      INSERT INTO public.admin_records (id, school_id, branch_id, resource, payload, version, is_qa, updated_at)
      VALUES 
        ($1, $1, null, 'schools', $2::jsonb, 1, true, NOW()),
        ($3, $3, null, 'schools', $4::jsonb, 1, true, NOW())
      ON CONFLICT (id) DO UPDATE SET
        payload = EXCLUDED.payload,
        version = EXCLUDED.version,
        is_qa = true,
        updated_at = NOW();
    `, [
      schoolAId,
      JSON.stringify({
        id: schoolAId,
        schoolId: schoolAId,
        branchId: null,
        version: 1,
        name: 'QA Test School',
        code: 'QA-TEST-01',
        status: 'Active',
        plan: 'Growth',
        monthlyFee: 15000,
        ownerEmail: 'qa-owner@qatest.internal',
        studentCount: 6,
        branchCount: 2,
        createdAt: new Date().toISOString(),
      }),
      schoolBId,
      JSON.stringify({
        id: schoolBId,
        schoolId: schoolBId,
        branchId: null,
        version: 1,
        name: 'QA Isolation School B',
        code: 'QA-ISOL-02',
        status: 'Active',
        plan: 'Starter',
        monthlyFee: 8000,
        ownerEmail: 'qa-owner-b@qatest.internal',
        studentCount: 0,
        branchCount: 1,
        createdAt: new Date().toISOString(),
      }),
    ]);

    console.log('Created QA Schools and Branches.');

    // Helper: Create Auth User via Auth Admin API & Profile in Postgres
    async function createQaUser(
      email: string,
      role: string,
      name: string,
      schoolId: string | null,
      branchIds: string[],
      envKeyPrefix: string
    ): Promise<string> {
      const password = generatePassword();

      // Create via Supabase Auth Admin API (standard official flow)
      const { data, error } = await adminClient.auth.admin.createUser({
        email: email.toLowerCase(),
        password,
        email_confirm: true,
        app_metadata: {
          role,
          school_id: schoolId,
          branch_ids: branchIds,
          is_qa: true,
        },
        user_metadata: {
          name,
          is_qa: true,
        },
      });

      if (error || !data.user) {
        throw new Error(`Auth Admin API failed to create user ${email}: ${error?.message}`);
      }

      const userId = data.user.id;

      // Insert into public.profiles
      await client.query(`
        INSERT INTO public.profiles (
          id, school_id, branch_ids, role, name, email, active, is_qa, created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, true, true, NOW(), NOW())
        ON CONFLICT (id) DO UPDATE SET
          school_id = EXCLUDED.school_id,
          branch_ids = EXCLUDED.branch_ids,
          role = EXCLUDED.role,
          name = EXCLUDED.name,
          email = EXCLUDED.email,
          active = true,
          is_qa = true;
      `, [userId, schoolId, branchIds, role, name, email.toLowerCase()]);

      // Record in admin_records for directory visibility
      if (schoolId) {
        await client.query(`
          INSERT INTO public.admin_records (
            id, school_id, branch_id, resource, payload, version, is_qa, updated_at
          ) VALUES ($1, $2, $3, 'users', $4::jsonb, 1, true, NOW())
          ON CONFLICT (id) DO UPDATE SET
            payload = EXCLUDED.payload,
            version = EXCLUDED.version,
            is_qa = true,
            updated_at = NOW();
        `, [
          userId,
          schoolId,
          branchIds[0] || null,
          JSON.stringify({
            id: userId,
            schoolId,
            branchId: branchIds[0] || null,
            name,
            email: email.toLowerCase(),
            role,
            status: 'Active',
            joinedAt: new Date().toISOString().slice(0, 10),
            version: 1,
            isQa: true,
          }),
        ]);
      }

      credentials[`${envKeyPrefix}_EMAIL`] = email.toLowerCase();
      credentials[`${envKeyPrefix}_PASSWORD`] = password;
      credentials[`${envKeyPrefix}_ID`] = userId;

      return userId;
    }

    // 5. Create QA Users across roles
    console.log('Creating QA Users across roles via Auth Admin API...');

    // 1 Master Admin
    const qaMasterId = await createQaUser(
      'qa-master@qatest.internal',
      'master',
      'QA Master Admin',
      null,
      [],
      'QA_MASTER'
    );

    // 1 Owner (School A)
    const qaOwnerId = await createQaUser(
      'qa-owner@qatest.internal',
      'owner',
      'QA School Owner',
      schoolAId,
      [branch1Id, branch2Id],
      'QA_OWNER'
    );

    // 1 Owner (School B - Isolation)
    const qaOwnerBId = await createQaUser(
      'qa-owner-b@qatest.internal',
      'owner',
      'QA School B Owner',
      schoolBId,
      [branchBId],
      'QA_OWNER_B'
    );

    // 2 Principals (School A: North and South)
    const principalNorthId = await createQaUser(
      'qa-principal-north@qatest.internal',
      'principal',
      'Principal North',
      schoolAId,
      [branch1Id],
      'QA_PRINCIPAL_NORTH'
    );

    const principalSouthId = await createQaUser(
      'qa-principal-south@qatest.internal',
      'principal',
      'Principal South',
      schoolAId,
      [branch2Id],
      'QA_PRINCIPAL_SOUTH'
    );

    // 3 Teachers (School A)
    const teacher1Id = await createQaUser(
      'qa-teacher-1@qatest.internal',
      'teacher',
      'Teacher Alice (Math)',
      schoolAId,
      [branch1Id],
      'QA_TEACHER_1'
    );

    const teacher2Id = await createQaUser(
      'qa-teacher-2@qatest.internal',
      'teacher',
      'Teacher Bob (Science)',
      schoolAId,
      [branch1Id],
      'QA_TEACHER_2'
    );

    const teacher3Id = await createQaUser(
      'qa-teacher-3@qatest.internal',
      'teacher',
      'Teacher Charlie (English)',
      schoolAId,
      [branch2Id],
      'QA_TEACHER_3'
    );

    // 1 Accountant
    const accountantId = await createQaUser(
      'qa-accountant@qatest.internal',
      'accountant',
      'Accountant Dave',
      schoolAId,
      [branch1Id, branch2Id],
      'QA_ACCOUNTANT'
    );

    // 6 Students (School A)
    const student1Id = await createQaUser(
      'qa-student-1@qatest.internal',
      'student',
      'Student Emma',
      schoolAId,
      [branch1Id],
      'QA_STUDENT_1'
    );

    const student2Id = await createQaUser(
      'qa-student-2@qatest.internal',
      'student',
      'Student Ethan',
      schoolAId,
      [branch1Id],
      'QA_STUDENT_2'
    );

    const student3Id = await createQaUser(
      'qa-student-3@qatest.internal',
      'student',
      'Student Liam',
      schoolAId,
      [branch1Id],
      'QA_STUDENT_3'
    );

    const student4Id = await createQaUser(
      'qa-student-4@qatest.internal',
      'student',
      'Student Noah',
      schoolAId,
      [branch1Id],
      'QA_STUDENT_4'
    );

    const student5Id = await createQaUser(
      'qa-student-5@qatest.internal',
      'student',
      'Student Olivia',
      schoolAId,
      [branch2Id],
      'QA_STUDENT_5'
    );

    const student6Id = await createQaUser(
      'qa-student-6@qatest.internal',
      'student',
      'Student Sophia',
      schoolAId,
      [branch2Id],
      'QA_STUDENT_6'
    );

    // 4 Parents (with multi-child relationships)
    const parent1Id = await createQaUser(
      'qa-parent-1@qatest.internal',
      'parent',
      'Parent Sarah (Emma & Ethan)',
      schoolAId,
      [branch1Id],
      'QA_PARENT_1'
    );

    const parent2Id = await createQaUser(
      'qa-parent-2@qatest.internal',
      'parent',
      'Parent Robert (Liam)',
      schoolAId,
      [branch1Id],
      'QA_PARENT_2'
    );

    const parent3Id = await createQaUser(
      'qa-parent-3@qatest.internal',
      'parent',
      'Parent Michael (Noah & Olivia)',
      schoolAId,
      [branch1Id, branch2Id],
      'QA_PARENT_3'
    );

    const parent4Id = await createQaUser(
      'qa-parent-4@qatest.internal',
      'parent',
      'Parent Jennifer (Sophia)',
      schoolAId,
      [branch2Id],
      'QA_PARENT_4'
    );

    // 6. Create Classes, Timetable, Fees, and Workflows
    console.log('Seeding Classes, Timetables, and Workflow Records...');

    const class10AId = randomUUID();
    const class10BId = randomUUID();
    const class8AId = randomUUID();

    await client.query(`
      INSERT INTO public.classes (id, school_id, branch_id, name, section, room, capacity, is_qa, created_at, updated_at)
      VALUES 
        ($1, $2, $3, 'Class 10-A', 'A', 'Room 101', 35, true, NOW(), NOW()),
        ($4, $2, $3, 'Class 10-B', 'B', 'Room 102', 35, true, NOW(), NOW()),
        ($5, $2, $6, 'Class 8-A', 'A', 'Room 201', 30, true, NOW(), NOW());
    `, [class10AId, schoolAId, branch1Id, class10BId, class8AId, branch2Id]);

    await client.query(`
      INSERT INTO public.school_classes (id, school_id, branch_id, name, is_qa)
      VALUES 
        ($1, $2, $3, 'Class 10-A', true),
        ($4, $2, $3, 'Class 10-B', true),
        ($5, $2, $6, 'Class 8-A', true);
    `, [class10AId, schoolAId, branch1Id, class10BId, class8AId, branch2Id]);

    // Insert into school_students directory
    await client.query(`
      INSERT INTO public.school_students (id, school_id, branch_id, class_id, name, guardian_phone, is_qa)
      VALUES 
        ($1, $2, $3, $4, 'Student Emma', '+1555001', true),
        ($5, $2, $3, $4, 'Student Ethan', '+1555001', true),
        ($6, $2, $3, $7, 'Student Liam', '+1555002', true),
        ($8, $2, $3, $7, 'Student Noah', '+1555003', true),
        ($9, $2, $10, $11, 'Student Olivia', '+1555003', true),
        ($12, $2, $10, $11, 'Student Sophia', '+1555004', true)
      ON CONFLICT DO NOTHING;
    `, [
      student1Id, schoolAId, branch1Id, class10AId,
      student2Id,
      student3Id, class10BId,
      student4Id,
      student5Id, branch2Id, class8AId,
      student6Id,
    ]);

    // Assign students to classes
    await client.query(`
      INSERT INTO public.class_students (id, school_id, branch_id, class_id, student_id, roll_number, is_qa, created_at)
      VALUES 
        (gen_random_uuid(), $1, $2, $3, $4, '10A-01', true, NOW()),
        (gen_random_uuid(), $1, $2, $3, $5, '10A-02', true, NOW()),
        (gen_random_uuid(), $1, $2, $6, $7, '10B-01', true, NOW()),
        (gen_random_uuid(), $1, $2, $6, $8, '10B-02', true, NOW()),
        (gen_random_uuid(), $1, $9, $10, $11, '8A-01', true, NOW()),
        (gen_random_uuid(), $1, $9, $10, $12, '8A-02', true, NOW())
      ON CONFLICT DO NOTHING;
    `, [
      schoolAId, branch1Id, class10AId, student1Id, student2Id,
      class10BId, student3Id, student4Id,
      branch2Id, class8AId, student5Id, student6Id
    ]);

    // Link Memberships: Parents -> Students & Teachers -> Classes
    await client.query(`
      INSERT INTO public.school_memberships (user_id, class_ids, student_ids, is_qa)
      VALUES 
        ($1, '{}', $2, true),
        ($3, '{}', $4, true),
        ($5, '{}', $6, true),
        ($7, '{}', $8, true),
        ($9, $10, '{}', true),
        ($11, $12, '{}', true),
        ($13, $14, '{}', true)
      ON CONFLICT (user_id) DO UPDATE SET
        class_ids = EXCLUDED.class_ids,
        student_ids = EXCLUDED.student_ids,
        is_qa = true;
    `, [
      parent1Id, [student1Id, student2Id],
      parent2Id, [student3Id],
      parent3Id, [student4Id, student5Id],
      parent4Id, [student6Id],
      teacher1Id, [class10AId],
      teacher2Id, [class10BId],
      teacher3Id, [class8AId],
    ]);

    // Create Fee Structure and Student Fees
    const feeStructureId = randomUUID();
    await client.query(`
      INSERT INTO public.fee_structures (id, school_id, branch_id, title, amount, frequency, is_qa, created_at)
      VALUES ($1, $2, $3, 'Term 1 Tuition Fee', 25000.00, 'Term', true, NOW());
    `, [feeStructureId, schoolAId, branch1Id]);

    const feeInvoiceId = randomUUID();
    await client.query(`
      INSERT INTO public.student_fees (id, school_id, branch_id, student_id, fee_structure_id, title, amount, paid_amount, status, due_date, is_qa, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, 'Term 1 Tuition Fee', 25000.00, 0.00, 'Pending', (NOW() + INTERVAL '30 days')::date, true, NOW(), NOW());
    `, [feeInvoiceId, schoolAId, branch1Id, student1Id, feeStructureId]);

    // Create Sample Attendance Record
    await client.query(`
      INSERT INTO public.attendance_records (id, school_id, branch_id, class_id, student_id, date, status, is_qa, created_at)
      VALUES (gen_random_uuid(), $1, $2, $3, $4, CURRENT_DATE, 'Present', true, NOW());
    `, [schoolAId, branch1Id, class10AId, student1Id]);

    // Create Sample Workflow Announcement
    await client.query(`
      INSERT INTO public.school_workflows (
        id, school_id, branch_id, class_id, student_id, author_id, module, version, payload, is_qa, updated_at
      ) VALUES (
        $1, $2, $3, null, null, $4, 'announcements', 1,
        $5::jsonb, true, NOW()
      );
    `, [
      randomUUID(),
      schoolAId,
      branch1Id,
      principalNorthId,
      JSON.stringify({
        title: 'Welcome to Term 1 QA Orientation',
        body: 'Classes will commence at 08:30 AM. Attendance is mandatory.',
        audience: 'all',
        date: new Date().toISOString().slice(0, 10),
      }),
    ]);

    // Store School IDs in credentials map
    credentials['QA_SCHOOL_A_ID'] = schoolAId;
    credentials['QA_BRANCH_1_ID'] = branch1Id;
    credentials['QA_BRANCH_2_ID'] = branch2Id;
    credentials['QA_SCHOOL_B_ID'] = schoolBId;
    credentials['QA_BRANCH_B_ID'] = branchBId;
    credentials['QA_STUDENT_1_ID'] = student1Id;
    credentials['QA_CLASS_10A_ID'] = class10AId;
    credentials['QA_FEE_INVOICE_ID'] = feeInvoiceId;

    // 7. Write credentials to git-ignored .env.test.local
    const envTestLocalPath = resolve(process.cwd(), '.env.test.local');
    let envContent = `# QA Test Environment Credentials (AUTO-GENERATED - NEVER COMMIT)\n`;
    for (const [k, v] of Object.entries(credentials)) {
      envContent += `${k}=${v}\n`;
    }
    writeFileSync(envTestLocalPath, envContent, 'utf8');

    console.log(`QA Tenant successfully seeded via Auth Admin API!`);
    console.log(`Credentials safely written to git-ignored: .env.test.local`);
    console.log(`- School A ID: ${schoolAId}`);
    console.log(`- School B (Isolation) ID: ${schoolBId}`);
    console.log(`- 12 QA Users provisioned across Master, Owner, Principal, Teacher, Parent, Student, Accountant.`);
  } finally {
    await client.end();
  }
}

seedQaTenant().catch((err) => {
  console.error('QA Seed failed:', err.message);
  process.exit(1);
});
