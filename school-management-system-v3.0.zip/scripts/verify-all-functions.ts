import { createClient } from '@supabase/supabase-js';
import { Client } from 'pg';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHmac } from 'node:crypto';

const TARGET_REF = 'oqsvedpkqgajjrnxbehz';
const SUPABASE_URL = `https://${TARGET_REF}.supabase.co`;

function loadEnv(): Record<string, string> {
  const env: Record<string, string> = {};
  const files = ['.env.local', '.env.server.local', '.env.test.local'];
  for (const f of files) {
    const fullPath = resolve(process.cwd(), f);
    if (existsSync(fullPath)) {
      const content = readFileSync(fullPath, 'utf8');
      for (const line of content.split('\n')) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;
        const eqIdx = trimmed.indexOf('=');
        if (eqIdx !== -1) {
          env[trimmed.slice(0, eqIdx).trim()] = trimmed.slice(eqIdx + 1).trim();
        }
      }
    }
  }
  return env;
}

export interface FunctionCheckResult {
  category: 'Database RPC' | 'Edge Function' | 'Frontend / Auth Service';
  name: string;
  endpointOrSignature: string;
  testedRole: string;
  status: 'WORKING' | 'FAILED';
  httpOrSqlStatus: number | string;
  latencyMs: number;
  details: string;
  error?: string;
}

async function main() {
  const env = loadEnv();
  const publishableKey = env.VITE_SUPABASE_PUBLISHABLE_KEY || '';
  const dbPassword = env.SUPABASE_DB_PASSWORD || '';
  const results: FunctionCheckResult[] = [];

  console.log('--- Starting Comprehensive Function Verification ---');

  const supabase = createClient(SUPABASE_URL, publishableKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  // 1. Authenticate roles to acquire tokens
  const tokens: Record<string, string> = {};
  const rolesToAuth = [
    { role: 'master', email: env.QA_MASTER_EMAIL, pass: env.QA_MASTER_PASSWORD },
    { role: 'owner', email: env.QA_OWNER_EMAIL, pass: env.QA_OWNER_PASSWORD },
    { role: 'principal', email: env.QA_PRINCIPAL_NORTH_EMAIL, pass: env.QA_PRINCIPAL_NORTH_PASSWORD },
    { role: 'teacher', email: env.QA_TEACHER_1_EMAIL, pass: env.QA_TEACHER_1_PASSWORD },
    { role: 'parent', email: env.QA_PARENT_1_EMAIL, pass: env.QA_PARENT_1_PASSWORD },
    { role: 'student', email: env.QA_STUDENT_1_EMAIL, pass: env.QA_STUDENT_1_PASSWORD },
    { role: 'accountant', email: env.QA_ACCOUNTANT_EMAIL, pass: env.QA_ACCOUNTANT_PASSWORD },
  ];

  for (const r of rolesToAuth) {
    if (!r.email || !r.pass) continue;
    const start = Date.now();
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: r.email,
        password: r.pass,
      });
      const latency = Date.now() - start;
      if (error) {
        results.push({
          category: 'Frontend / Auth Service',
          name: `auth.signInWithPassword (${r.role})`,
          endpointOrSignature: 'supabase.auth.signInWithPassword',
          testedRole: r.role,
          status: 'FAILED',
          httpOrSqlStatus: error.status || 400,
          latencyMs: latency,
          details: `Sign-in failed for ${r.role}`,
          error: error.message,
        });
      } else if (data.session) {
        tokens[r.role] = data.session.access_token;
        results.push({
          category: 'Frontend / Auth Service',
          name: `auth.signInWithPassword (${r.role})`,
          endpointOrSignature: 'supabase.auth.signInWithPassword',
          testedRole: r.role,
          status: 'WORKING',
          httpOrSqlStatus: 200,
          latencyMs: latency,
          details: `Authenticated successfully; token issued.`,
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Frontend / Auth Service',
        name: `auth.signInWithPassword (${r.role})`,
        endpointOrSignature: 'supabase.auth.signInWithPassword',
        testedRole: r.role,
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception during sign-in',
        error: e.message,
      });
    }
  }

  // Helper client for specific authenticated role
  function getRoleClient(role: string) {
    const token = tokens[role];
    return createClient(SUPABASE_URL, publishableKey, {
      global: { headers: token ? { Authorization: `Bearer ${token}` } : {} },
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }

  // -------------------------------------------------------------------------
  // SECTION 2: Database RPC Functions
  // -------------------------------------------------------------------------
  const ownerClient = getRoleClient('owner');
  const teacherClient = getRoleClient('teacher');
  const principalClient = getRoleClient('principal');
  const parentClient = getRoleClient('parent');

  // RPC 1: admin_list
  {
    const start = Date.now();
    try {
      const { data, error, status } = await ownerClient.rpc('admin_list', {
        p_resource: 'schools',
        p_scope: { schoolId: env.QA_SCHOOL_A_ID },
        p_options: { page: 0, pageSize: 10 },
      });
      const latency = Date.now() - start;
      if (error) {
        results.push({
          category: 'Database RPC',
          name: 'admin_list',
          endpointOrSignature: 'admin_list(p_resource, p_scope, p_options)',
          testedRole: 'owner',
          status: 'FAILED',
          httpOrSqlStatus: status,
          latencyMs: latency,
          details: 'Failed to query admin_list for schools',
          error: error.message,
        });
      } else {
        const rows = data?.rows || [];
        results.push({
          category: 'Database RPC',
          name: 'admin_list',
          endpointOrSignature: 'admin_list(p_resource, p_scope, p_options)',
          testedRole: 'owner',
          status: 'WORKING',
          httpOrSqlStatus: status || 200,
          latencyMs: latency,
          details: `Returned ${rows.length} records cleanly (total=${data?.total || 0}).`,
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Database RPC',
        name: 'admin_list',
        endpointOrSignature: 'admin_list(p_resource, p_scope, p_options)',
        testedRole: 'owner',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in admin_list',
        error: e.message,
      });
    }
  }

  // RPC 2: admin_save & admin_delete
  const testAdminRecordId = '22222222-3333-4444-5555-666666666666';
  {
    const start = Date.now();
    try {
      const { data, error, status } = await ownerClient.rpc('admin_save', {
        p_resource: 'announcements',
        p_record: {
          id: testAdminRecordId,
          schoolId: env.QA_SCHOOL_A_ID,
          branchId: env.QA_BRANCH_1_ID,
          title: 'QA System Test Announcement',
          message: 'All functions operational test',
          version: 1,
          isQa: true,
        },
      });
      const latency = Date.now() - start;
      if (error) {
        results.push({
          category: 'Database RPC',
          name: 'admin_save',
          endpointOrSignature: 'admin_save(p_resource, p_record)',
          testedRole: 'owner',
          status: 'FAILED',
          httpOrSqlStatus: status,
          latencyMs: latency,
          details: 'Failed to execute admin_save',
          error: error.message,
        });
      } else {
        results.push({
          category: 'Database RPC',
          name: 'admin_save',
          endpointOrSignature: 'admin_save(p_resource, p_record)',
          testedRole: 'owner',
          status: 'WORKING',
          httpOrSqlStatus: status || 200,
          latencyMs: latency,
          details: `Saved admin record into admin_records (v=${data?.version || 1}).`,
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Database RPC',
        name: 'admin_save',
        endpointOrSignature: 'admin_save(p_resource, p_record)',
        testedRole: 'owner',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in admin_save',
        error: e.message,
      });
    }
  }

  // RPC 3: admin_delete
  {
    const start = Date.now();
    try {
      const { error, status } = await ownerClient.rpc('admin_delete', {
        p_resource: 'announcements',
        p_id: testAdminRecordId,
        p_scope: { schoolId: env.QA_SCHOOL_A_ID },
        p_version: 2,
      });
      const latency = Date.now() - start;
      if (error) {
        results.push({
          category: 'Database RPC',
          name: 'admin_delete',
          endpointOrSignature: 'admin_delete(p_resource, p_id, p_scope, p_version)',
          testedRole: 'owner',
          status: 'FAILED',
          httpOrSqlStatus: status,
          latencyMs: latency,
          details: 'Failed to delete test admin record',
          error: error.message,
        });
      } else {
        results.push({
          category: 'Database RPC',
          name: 'admin_delete',
          endpointOrSignature: 'admin_delete(p_resource, p_id, p_scope, p_version)',
          testedRole: 'owner',
          status: 'WORKING',
          httpOrSqlStatus: status || 200,
          latencyMs: latency,
          details: 'Cleanly deleted test record from admin_records.',
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Database RPC',
        name: 'admin_delete',
        endpointOrSignature: 'admin_delete(p_resource, p_id, p_scope, p_version)',
        testedRole: 'owner',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in admin_delete',
        error: e.message,
      });
    }
  }

  // RPC 4: workflow_context
  {
    const start = Date.now();
    try {
      const { data, error, status } = await teacherClient.rpc('workflow_context', {
        p_branch: env.QA_BRANCH_1_ID,
      });
      const latency = Date.now() - start;
      if (error) {
        results.push({
          category: 'Database RPC',
          name: 'workflow_context',
          endpointOrSignature: 'workflow_context(p_branch)',
          testedRole: 'teacher',
          status: 'FAILED',
          httpOrSqlStatus: status,
          latencyMs: latency,
          details: 'Failed to load teacher workflow context',
          error: error.message,
        });
      } else {
        results.push({
          category: 'Database RPC',
          name: 'workflow_context',
          endpointOrSignature: 'workflow_context(p_branch)',
          testedRole: 'teacher',
          status: 'WORKING',
          httpOrSqlStatus: status || 200,
          latencyMs: latency,
          details: `Loaded context with ${data?.classes?.length || 0} classes and ${data?.students?.length || 0} students.`,
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Database RPC',
        name: 'workflow_context',
        endpointOrSignature: 'workflow_context(p_branch)',
        testedRole: 'teacher',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in workflow_context',
        error: e.message,
      });
    }
  }

  // RPC 5: workflow_list
  {
    const start = Date.now();
    try {
      const { data, error, status } = await teacherClient.rpc('workflow_list', {
        p_module: 'attendance',
        p_scope: { branchId: env.QA_BRANCH_1_ID, classId: env.QA_CLASS_1_ID },
      });
      const latency = Date.now() - start;
      if (error) {
        results.push({
          category: 'Database RPC',
          name: 'workflow_list (teacher attendance)',
          endpointOrSignature: 'workflow_list(p_module, p_scope)',
          testedRole: 'teacher',
          status: 'FAILED',
          httpOrSqlStatus: status,
          latencyMs: latency,
          details: 'Failed to query attendance workflow',
          error: error.message,
        });
      } else {
        results.push({
          category: 'Database RPC',
          name: 'workflow_list (teacher attendance)',
          endpointOrSignature: 'workflow_list(p_module, p_scope)',
          testedRole: 'teacher',
          status: 'WORKING',
          httpOrSqlStatus: status || 200,
          latencyMs: latency,
          details: `Returned ${Array.isArray(data?.rows) ? data.rows.length : 0} attendance records (total=${data?.total || 0}).`,
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Database RPC',
        name: 'workflow_list (teacher attendance)',
        endpointOrSignature: 'workflow_list(p_module, p_scope)',
        testedRole: 'teacher',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in workflow_list',
        error: e.message,
      });
    }
  }

  // RPC 6: workflow_save & workflow_remove
  const testWorkflowId = '33333333-4444-5555-6666-777777777777';
  {
    const start = Date.now();
    try {
      const { data, error, status } = await teacherClient.rpc('workflow_save', {
        p_record: {
          id: testWorkflowId,
          schoolId: env.QA_SCHOOL_A_ID,
          branchId: env.QA_BRANCH_1_ID,
          classId: env.QA_CLASS_1_ID,
          module: 'attendance',
          data: {
            title: 'QA Algebra Assignment',
            dueDate: new Date().toISOString(),
            assignedBy: 'QA Teacher 1',
          },
          version: 1,
          isQa: true,
        },
      });
      const latency = Date.now() - start;
      if (error) {
        results.push({
          category: 'Database RPC',
          name: 'workflow_save',
          endpointOrSignature: 'workflow_save(p_record)',
          testedRole: 'teacher',
          status: 'FAILED',
          httpOrSqlStatus: status,
          latencyMs: latency,
          details: 'Failed to save attendance workflow record',
          error: error.message,
        });
      } else {
        results.push({
          category: 'Database RPC',
          name: 'workflow_save',
          endpointOrSignature: 'workflow_save(p_record)',
          testedRole: 'teacher',
          status: 'WORKING',
          httpOrSqlStatus: status || 200,
          latencyMs: latency,
          details: `Saved workflow record into school_workflows (v=${data?.version || 2}).`,
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Database RPC',
        name: 'workflow_save',
        endpointOrSignature: 'workflow_save(p_record)',
        testedRole: 'teacher',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in workflow_save',
        error: e.message,
      });
    }
  }

  // RPC 7: workflow_remove
  {
    const start = Date.now();
    try {
      const { error, status } = await teacherClient.rpc('workflow_remove', {
        p_id: testWorkflowId,
        p_version: 2,
      });
      const latency = Date.now() - start;
      if (error) {
        results.push({
          category: 'Database RPC',
          name: 'workflow_remove',
          endpointOrSignature: 'workflow_remove(p_id, p_version)',
          testedRole: 'teacher',
          status: 'FAILED',
          httpOrSqlStatus: status,
          latencyMs: latency,
          details: 'Failed to remove workflow record',
          error: error.message,
        });
      } else {
        results.push({
          category: 'Database RPC',
          name: 'workflow_remove',
          endpointOrSignature: 'workflow_remove(p_id, p_version)',
          testedRole: 'teacher',
          status: 'WORKING',
          httpOrSqlStatus: status || 200,
          latencyMs: latency,
          details: 'Cleanly removed workflow record from school_workflows.',
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Database RPC',
        name: 'workflow_remove',
        endpointOrSignature: 'workflow_remove(p_id, p_version)',
        testedRole: 'teacher',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in workflow_remove',
        error: e.message,
      });
    }
  }

  // RPC 8: provision_school_record
  {
    const start = Date.now();
    let pgClient: Client;
    try {
      try {
        const directClient = new Client({
          host: `db.${TARGET_REF}.supabase.co`,
          port: 5432,
          database: 'postgres',
          user: 'postgres',
          password: dbPassword,
          ssl: { rejectUnauthorized: false },
          connectionTimeoutMillis: 2000,
        });
        await directClient.connect();
        pgClient = directClient;
      } catch {
        const poolerClient = new Client({
          host: env.SUPABASE_POOLER_HOST || 'aws-0-ap-southeast-1.pooler.supabase.com',
          port: 6543,
          database: 'postgres',
          user: `postgres.${TARGET_REF}`,
          password: dbPassword,
          ssl: { rejectUnauthorized: false },
        });
        await poolerClient.connect();
        pgClient = poolerClient;
      }

      // Fetch real owner user ID from auth.users for valid foreign key reference
      const ownerUserRes = await pgClient.query('SELECT id FROM auth.users WHERE email = $1 LIMIT 1;', [env.QA_OWNER_EMAIL]);
      const validOwnerId = ownerUserRes.rows[0]?.id;

      // Test direct call with rollback
      await pgClient.query('BEGIN;');
      const testSchoolId = '11111111-2222-3333-4444-555555555555';
      const rpcRes = await pgClient.query(
        `SELECT public.provision_school_record(
          $1::jsonb,
          $2::uuid,
          $3::uuid
        ) as res;`,
        [
          JSON.stringify({
            id: testSchoolId,
            name: 'QA Stored Procedure Test School',
            code: 'QA-SP-01',
            subdomain: 'qa-sp-test',
            plan: 'Starter',
            currency: 'USD',
            studentCount: 100,
            branchCount: 1,
            ownerEmail: env.QA_OWNER_EMAIL,
            ownerName: 'QA Stored Proc Owner',
          }),
          validOwnerId,
          validOwnerId,
        ]
      );
      await pgClient.query('ROLLBACK;');
      const latency = Date.now() - start;
      results.push({
        category: 'Database RPC',
        name: 'provision_school_record',
        endpointOrSignature: 'provision_school_record(JSONB, UUID, UUID)',
        testedRole: 'postgres (SECURITY DEFINER)',
        status: 'WORKING',
        httpOrSqlStatus: '200 (SQL SUCCESS)',
        latencyMs: latency,
        details: `RPC executed atomically with explicit enum casts: ${JSON.stringify(rpcRes.rows[0]?.res)}`,
      });
    } catch (e: any) {
      await pgClient.query('ROLLBACK;').catch(() => {});
      results.push({
        category: 'Database RPC',
        name: 'provision_school_record',
        endpointOrSignature: 'provision_school_record(JSONB, UUID, UUID)',
        testedRole: 'postgres (SECURITY DEFINER)',
        status: 'FAILED',
        httpOrSqlStatus: 'SQL ERROR',
        latencyMs: Date.now() - start,
        details: 'Exception executing provision_school_record',
        error: e.message,
      });
    } finally {
      await pgClient.end().catch(() => {});
    }
  }

  // -------------------------------------------------------------------------
  // SECTION 3: Edge Functions
  // -------------------------------------------------------------------------

  // Edge Function 1: health
  {
    const start = Date.now();
    try {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/health`, {
        headers: { apikey: publishableKey },
      });
      const data = await res.json();
      const latency = Date.now() - start;
      if (res.status === 200 && (data.ok === true || data.status === 'ok' || data.data?.status === 'healthy')) {
        results.push({
          category: 'Edge Function',
          name: 'health',
          endpointOrSignature: 'GET /functions/v1/health',
          testedRole: 'anon',
          status: 'WORKING',
          httpOrSqlStatus: res.status,
          latencyMs: latency,
          details: `Healthy: status=${data.data?.status || data.status}, service=${data.data?.service || 'campus-school-management'}`,
        });
      } else {
        results.push({
          category: 'Edge Function',
          name: 'health',
          endpointOrSignature: 'GET /functions/v1/health',
          testedRole: 'anon',
          status: 'FAILED',
          httpOrSqlStatus: res.status,
          latencyMs: latency,
          details: 'Unexpected health response',
          error: JSON.stringify(data),
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Edge Function',
        name: 'health',
        endpointOrSignature: 'GET /functions/v1/health',
        testedRole: 'anon',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in health call',
        error: e.message,
      });
    }
  }

  // Edge Function 2: manage-user
  {
    const start = Date.now();
    try {
      // Test teacher blocked from manage-user (RBAC invariant)
      const res = await fetch(`${SUPABASE_URL}/functions/v1/manage-user`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: publishableKey,
          Authorization: `Bearer ${tokens.teacher}`,
        },
        body: JSON.stringify({
          action: 'create',
          email: 'illegal-create@qatest.internal',
          name: 'Illegal User',
          role: 'teacher',
          schoolId: env.QA_SCHOOL_A_ID,
          branchIds: [env.QA_BRANCH_1_ID],
        }),
      });
      const latency = Date.now() - start;
      if (res.status === 403) {
        results.push({
          category: 'Edge Function',
          name: 'manage-user (RBAC Boundary)',
          endpointOrSignature: 'POST /functions/v1/manage-user',
          testedRole: 'teacher',
          status: 'WORKING',
          httpOrSqlStatus: 403,
          latencyMs: latency,
          details: 'Correctly rejected unauthorized teacher call with 403 Forbidden.',
        });
      } else {
        results.push({
          category: 'Edge Function',
          name: 'manage-user (RBAC Boundary)',
          endpointOrSignature: 'POST /functions/v1/manage-user',
          testedRole: 'teacher',
          status: 'FAILED',
          httpOrSqlStatus: res.status,
          latencyMs: latency,
          details: 'Failed to enforce 403 RBAC boundary for teacher.',
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Edge Function',
        name: 'manage-user (RBAC Boundary)',
        endpointOrSignature: 'POST /functions/v1/manage-user',
        testedRole: 'teacher',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in manage-user',
        error: e.message,
      });
    }
  }

  // Edge Function 3: payment-webhook
  {
    const start = Date.now();
    try {
      // Test HMAC verification
      const rawBody = JSON.stringify({ event: 'payment.success', invoiceId: env.QA_FEE_INVOICE_ID, amount: 5000 });
      const webhookSecret = env.PAYMENT_WEBHOOK_SECRET || 'qa-test-webhook-secret-key-12345';
      const hmac = createHmac('sha256', webhookSecret).update(rawBody).digest('hex');

      const res = await fetch(`${SUPABASE_URL}/functions/v1/payment-webhook`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-payment-signature': `sha256=${hmac}`,
        },
        body: rawBody,
      });
      const latency = Date.now() - start;
      // It should process or acknowledge the signature
      results.push({
        category: 'Edge Function',
        name: 'payment-webhook',
        endpointOrSignature: 'POST /functions/v1/payment-webhook',
        testedRole: 'Webhook Gateway',
        status: res.status < 500 ? 'WORKING' : 'FAILED',
        httpOrSqlStatus: res.status,
        latencyMs: latency,
        details: `HMAC verification processed with HTTP ${res.status}.`,
      });
    } catch (e: any) {
      results.push({
        category: 'Edge Function',
        name: 'payment-webhook',
        endpointOrSignature: 'POST /functions/v1/payment-webhook',
        testedRole: 'Webhook Gateway',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in payment-webhook',
        error: e.message,
      });
    }
  }

  // Edge Function 4: whatsapp-webhook
  {
    const start = Date.now();
    try {
      // Test missing signature rejection
      const res = await fetch(`${SUPABASE_URL}/functions/v1/whatsapp-webhook`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ object: 'whatsapp_business_account' }),
      });
      const latency = Date.now() - start;
      if (res.status === 401 || res.status === 403) {
        results.push({
          category: 'Edge Function',
          name: 'whatsapp-webhook',
          endpointOrSignature: 'POST /functions/v1/whatsapp-webhook',
          testedRole: 'Public Webhook',
          status: 'WORKING',
          httpOrSqlStatus: res.status,
          latencyMs: latency,
          details: 'Correctly enforced HMAC signature requirement (rejected unsigned request with 401/403).',
        });
      } else {
        results.push({
          category: 'Edge Function',
          name: 'whatsapp-webhook',
          endpointOrSignature: 'POST /functions/v1/whatsapp-webhook',
          testedRole: 'Public Webhook',
          status: 'FAILED',
          httpOrSqlStatus: res.status,
          latencyMs: latency,
          details: 'Failed to enforce signature on unsigned request.',
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Edge Function',
        name: 'whatsapp-webhook',
        endpointOrSignature: 'POST /functions/v1/whatsapp-webhook',
        testedRole: 'Public Webhook',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in whatsapp-webhook',
        error: e.message,
      });
    }
  }

  // Edge Function 5: import-csv (IDOR check)
  {
    const start = Date.now();
    try {
      // Principal North attempting to import into Branch 2 (South Campus)
      const res = await fetch(`${SUPABASE_URL}/functions/v1/import-csv`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: publishableKey,
          Authorization: `Bearer ${tokens.principal}`,
        },
        body: JSON.stringify({
          resource: 'students',
          branchId: env.QA_BRANCH_2_ID, // South campus (not authorized for Principal North)
          csvContent: 'fullName,email,classId\nTest Rogue Student,rogue@qatest.internal,cls-1\n',
        }),
      });
      const latency = Date.now() - start;
      if (res.status === 403) {
        results.push({
          category: 'Edge Function',
          name: 'import-csv (Branch IDOR Guard)',
          endpointOrSignature: 'POST /functions/v1/import-csv',
          testedRole: 'principal',
          status: 'WORKING',
          httpOrSqlStatus: 403,
          latencyMs: latency,
          details: 'Correctly blocked cross-branch import with 403 Forbidden.',
        });
      } else {
        results.push({
          category: 'Edge Function',
          name: 'import-csv (Branch IDOR Guard)',
          endpointOrSignature: 'POST /functions/v1/import-csv',
          testedRole: 'principal',
          status: 'FAILED',
          httpOrSqlStatus: res.status,
          latencyMs: latency,
          details: 'Cross-branch import was not blocked with 403.',
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Edge Function',
        name: 'import-csv (Branch IDOR Guard)',
        endpointOrSignature: 'POST /functions/v1/import-csv',
        testedRole: 'principal',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in import-csv',
        error: e.message,
      });
    }
  }

  // Edge Function 6: export-data (Branch Scoping)
  {
    const start = Date.now();
    try {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/export-data`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: publishableKey,
          Authorization: `Bearer ${tokens.principal}`,
        },
        body: JSON.stringify({
          resource: 'students',
          branchId: env.QA_BRANCH_2_ID, // South campus (not authorized for Principal North)
          format: 'json',
        }),
      });
      const latency = Date.now() - start;
      if (res.status === 403) {
        results.push({
          category: 'Edge Function',
          name: 'export-data (Branch Scope Guard)',
          endpointOrSignature: 'POST /functions/v1/export-data',
          testedRole: 'principal',
          status: 'WORKING',
          httpOrSqlStatus: 403,
          latencyMs: latency,
          details: 'Correctly blocked cross-branch data export with 403 Forbidden.',
        });
      } else {
        results.push({
          category: 'Edge Function',
          name: 'export-data (Branch Scope Guard)',
          endpointOrSignature: 'POST /functions/v1/export-data',
          testedRole: 'principal',
          status: 'FAILED',
          httpOrSqlStatus: res.status,
          latencyMs: latency,
          details: 'Cross-branch data export was not blocked with 403.',
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Edge Function',
        name: 'export-data (Branch Scope Guard)',
        endpointOrSignature: 'POST /functions/v1/export-data',
        testedRole: 'principal',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in export-data',
        error: e.message,
      });
    }
  }

  // Edge Function 7: create-school (Platform Master Guard)
  {
    const start = Date.now();
    try {
      // Owner should be rejected with 403
      const res = await fetch(`${SUPABASE_URL}/functions/v1/create-school`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: publishableKey,
          Authorization: `Bearer ${tokens.owner}`,
        },
        body: JSON.stringify({
          name: 'Illegal School',
          subdomain: 'illegal-school',
          plan: 'Starter',
          ownerEmail: 'owner2@qatest.internal',
          ownerName: 'Owner 2',
        }),
      });
      const latency = Date.now() - start;
      if (res.status === 403) {
        results.push({
          category: 'Edge Function',
          name: 'create-school (Platform Master Guard)',
          endpointOrSignature: 'POST /functions/v1/create-school',
          testedRole: 'owner',
          status: 'WORKING',
          httpOrSqlStatus: 403,
          latencyMs: latency,
          details: 'Correctly rejected non-master call to platform create-school with 403.',
        });
      } else {
        results.push({
          category: 'Edge Function',
          name: 'create-school (Platform Master Guard)',
          endpointOrSignature: 'POST /functions/v1/create-school',
          testedRole: 'owner',
          status: 'FAILED',
          httpOrSqlStatus: res.status,
          latencyMs: latency,
          details: 'Owner was not rejected with 403 on create-school.',
        });
      }
    } catch (e: any) {
      results.push({
        category: 'Edge Function',
        name: 'create-school (Platform Master Guard)',
        endpointOrSignature: 'POST /functions/v1/create-school',
        testedRole: 'owner',
        status: 'FAILED',
        httpOrSqlStatus: 'EXCEPTION',
        latencyMs: Date.now() - start,
        details: 'Exception in create-school',
        error: e.message,
      });
    }
  }

  // Output summary and markdown table
  console.log('\n=== FUNCTION VERIFICATION CHART ===');
  console.table(
    results.map((r) => ({
      Category: r.category,
      Name: r.name,
      Role: r.testedRole,
      Status: r.status === 'WORKING' ? '✅ WORKING' : '❌ FAILED',
      'Status / Code': r.httpOrSqlStatus,
      'Latency (ms)': r.latencyMs,
      Details: r.details,
    }))
  );

  const passed = results.filter((r) => r.status === 'WORKING').length;
  const failed = results.filter((r) => r.status === 'FAILED').length;
  console.log(`\nTotal Functions Checked: ${results.length}`);
  console.log(`Working Properly: ${passed}`);
  console.log(`Issues Found: ${failed}`);

  // Write JSON report
  const reportPath = resolve(process.cwd(), 'docs/FUNCTION_VERIFICATION.json');
  const fs = await import('node:fs');
  fs.writeFileSync(reportPath, JSON.stringify(results, null, 2), 'utf8');
  console.log(`Report written to ${reportPath}`);
}

main().catch(console.error);
