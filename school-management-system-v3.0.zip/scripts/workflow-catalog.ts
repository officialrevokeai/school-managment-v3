import { writeFile } from 'node:fs/promises';
import { modules } from '../src/features/school/model.ts';
const quote=(value:string)=>`'${value.replaceAll("'","''")}'`;
await writeFile('database/workflow-catalog.sql','-- Apply after phases3-5.sql. Generated from the frontend module contract.\n'+Object.entries(modules).map(([key,config])=>`insert into public.workflow_modules(module,config) values(${quote(key)},${quote(JSON.stringify(config))}::jsonb) on conflict(module) do update set config=excluded.config;`).join('\n')+'\n');
