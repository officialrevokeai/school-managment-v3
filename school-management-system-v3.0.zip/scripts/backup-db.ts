import { Client } from 'pg';
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

function getEnvSecrets() {
  const envFile = resolve(process.cwd(), '.env.server.local');
  const env: Record<string, string> = {};
  if (existsSync(envFile)) {
    const content = readFileSync(envFile, 'utf8');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        env[trimmed.slice(0, eqIdx).trim()] = trimmed.slice(eqIdx + 1).trim();
      }
    }
  }
  return env;
}

async function backup() {
  const env = getEnvSecrets();
  const dbPassword = env.SUPABASE_DB_PASSWORD;
  if (!dbPassword) {
    throw new Error('SUPABASE_DB_PASSWORD not found in .env.server.local');
  }

  const client = new Client({
    host: 'db.oqsvedpkqgajjrnxbehz.supabase.co',
    port: 5432,
    database: 'postgres',
    user: 'postgres',
    password: dbPassword,
    ssl: { rejectUnauthorized: false },
  });

  console.log('Connecting to remote database to create pre-QA backup...');
  await client.connect();

  try {
    // 1. Get all public tables
    const tablesRes = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
      ORDER BY table_name;
    `);

    const tableNames: string[] = tablesRes.rows.map(r => r.table_name);
    console.log(`Found ${tableNames.length} tables in public schema.`);

    let backupSql = `-- School Management System v3.0 Pre-QA Backup\n-- Generated at: ${new Date().toISOString()}\n\n`;

    for (const tbl of tableNames) {
      const rowsRes = await client.query(`SELECT * FROM public."${tbl}"`);
      backupSql += `-- Table: public.${tbl} (${rowsRes.rows.length} rows)\n`;
      if (rowsRes.rows.length > 0) {
        for (const row of rowsRes.rows) {
          const cols = Object.keys(row).map(c => `"${c}"`).join(', ');
          const vals = Object.values(row).map(v => {
            if (v === null) return 'NULL';
            if (typeof v === 'number' || typeof v === 'boolean') return `${v}`;
            if (typeof v === 'object') return `'${JSON.stringify(v).replace(/'/g, "''")}'::jsonb`;
            return `'${String(v).replace(/'/g, "''")}'`;
          }).join(', ');
          backupSql += `INSERT INTO public."${tbl}" (${cols}) VALUES (${vals}) ON CONFLICT DO NOTHING;\n`;
        }
      }
      backupSql += '\n';
    }

    const backupFile = resolve(process.cwd(), 'backups', 'pre-qa-backup.sql');
    writeFileSync(backupFile, backupSql, 'utf8');
    console.log(`Backup completed successfully to ${backupFile}`);
  } finally {
    await client.end();
  }
}

backup().catch(err => {
  console.error('Backup failed:', err.message);
  process.exit(1);
});
