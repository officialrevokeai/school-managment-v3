import { readFile, readdir, stat } from "node:fs/promises";
import { existsSync, readFileSync } from "node:fs";
import { gzipSync } from "node:zlib";
import { join, resolve } from "node:path";

type Chunk = {
  file: string;
  isEntry?: boolean;
  imports?: string[];
  dynamicImports?: string[];
};

// 1. Initial Bundle size check
const manifest = JSON.parse(
  await readFile("dist/.vite/manifest.json", "utf8"),
) as Record<string, Chunk>;

const entry = Object.entries(manifest).find(([, chunk]) => chunk.isEntry)?.[0];
if (!entry) throw new Error("No build entry found.");

const dependencies = new Set<string>();
function collect(key: string) {
  if (dependencies.has(key)) return;
  dependencies.add(key);
  manifest[key]?.imports?.forEach(collect);
}
collect(entry);

// Count entry dependencies plus the initial login route and mock auth adapter.
for (const key of Object.keys(manifest)) {
  if (key.endsWith("/Login.tsx") || key.endsWith("/adapter.ts")) {
    collect(key);
  }
}

let total = 0;
for (const key of dependencies) {
  const file = manifest[key]?.file;
  if (file?.endsWith(".js")) {
    total += gzipSync(await readFile(join("dist", file))).byteLength;
  }
}

const kib = total / 1024;
console.log(
  `Initial login + mock auth JavaScript: ${kib.toFixed(1)} KiB gzip (budget: <200 KiB).`,
);
if (kib >= 200) {
  throw new Error("Initial JavaScript exceeds the requested size budget.");
}

// 2. Production Secret Scan on dist/
const envFile = resolve(process.cwd(), ".env.server.local");
const secretsToDetect: string[] = [];
if (existsSync(envFile)) {
  const content = readFileSync(envFile, "utf8");
  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx !== -1) {
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim();
      if (
        key === "SUPABASE_ACCESS_TOKEN" ||
        key === "SUPABASE_DB_PASSWORD" ||
        key === "MASTER_PASSWORD"
      ) {
        if (val.length >= 6) {
          secretsToDetect.push(val);
        }
      }
    }
  }
}

async function scanDist(dir: string) {
  const files = await readdir(dir);
  for (const file of files) {
    const fullPath = join(dir, file);
    const s = await stat(fullPath);
    if (s.isDirectory()) {
      await scanDist(fullPath);
    } else if (file.endsWith(".js") || file.endsWith(".html") || file.endsWith(".css")) {
      const content = await readFile(fullPath, "utf8");
      if (content.includes("sbp_")) {
        throw new Error(`SECURITY ALERT: 'sbp_' found in dist asset: ${file}`);
      }
      if (/sb_secret_[a-zA-Z0-9_\-]{16,}/.test(content)) {
        throw new Error(`SECURITY ALERT: 'sb_secret_' key found in dist asset: ${file}`);
      }
      if (content.includes("service_role")) {
        throw new Error(`SECURITY ALERT: 'service_role' found in dist asset: ${file}`);
      }
      for (const secret of secretsToDetect) {
        if (content.includes(secret)) {
          throw new Error(`SECURITY ALERT: Environment secret found in dist asset: ${file}`);
        }
      }
    }
  }
}

await scanDist(resolve(process.cwd(), "dist"));
console.log("Dist secret scan passed: 0 credentials, secrets, or privileged keys in bundle.");
