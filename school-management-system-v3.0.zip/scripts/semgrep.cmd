@echo off
set "PATH=%APPDATA%\Python\Python315\Scripts;%PATH%"
"%APPDATA%\Python\Python315\Scripts\semgrep.exe" %*
