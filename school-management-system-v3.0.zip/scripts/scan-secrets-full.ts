import { execSync } from "node:child_process";
import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import { resolve, join } from "node:path";

// 1. Silently load real secrets into memory to search for them
const envFile = resolve(process.cwd(), ".env.server.local");
const secretsToDetect: { name: string; val: string }[] = [];

if (existsSync(envFile)) {
  const content = readFileSync(envFile, "utf8");
  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx !== -1) {
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim();
      const isSecretKey =
        key === "SUPABASE_ACCESS_TOKEN" ||
        key === "SUPABASE_DB_PASSWORD" ||
        key === "MASTER_PASSWORD";
      if (isSecretKey && val.length >= 6) {
        secretsToDetect.push({ name: key, val });
      }
    }
  }
}

const genericPatterns = [
  { name: "Supabase Personal Token", regex: /sbp_[a-zA-Z0-9_\-]{30,}/ },
  { name: "Supabase Secret Token", regex: /sb_secret_[a-zA-Z0-9_\-]{16,}/ },
  { name: "Service Role JWT", regex: /eyJ[a-zA-Z0-9_-]{10,}\.eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}/ },
  { name: "Private Key Header", regex: /-----BEGIN (?:RSA )?PRIVATE KEY-----/ },
];

let violations = 0;

// 2. Scan full git history (git log -p)
console.log("=== SCANNING FULL GIT HISTORY ===");
try {
  const commits = execSync("git log --format=%H", { encoding: "utf8" })
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);

  console.log(`Checking ${commits.length} commits in history...`);
  for (const commit of commits) {
    const diff = execSync(`git show ${commit} -p`, {
      encoding: "utf8",
      maxBuffer: 50 * 1024 * 1024,
    });
    
    // Check known secrets
    for (const { name, val } of secretsToDetect) {
      if (diff.includes(val)) {
        console.error(`ALERT: Secret '${name}' was found in git history at commit ${commit.slice(0, 8)}!`);
        violations++;
      }
    }

    // Check sbp_ tokens
    if (diff.includes("sbp_")) {
      const match = diff.match(/sbp_[a-zA-Z0-9_\-]{30,}/);
      if (match) {
        console.error(`ALERT: 'sbp_' token found in git history at commit ${commit.slice(0, 8)}!`);
        violations++;
      }
    }
  }
  console.log(`Git history scan completed: ${violations} secret leaks detected.`);
} catch (err: any) {
  console.error("Error scanning git history:", err.message);
}

// 3. Scan Config and Dotfiles in Working Tree
console.log("\n=== SCANNING CONFIG & ENVIRONMENT FILES ===");
const configDirs = [".vscode", ".github", "supabase"];
const configFiles = [
  "supabase/config.toml",
  "vercel.json",
  "package.json",
  ".gitignore",
];

for (const f of configFiles) {
  if (existsSync(f)) {
    const text = readFileSync(f, "utf8");
    for (const { name, val } of secretsToDetect) {
      if (text.includes(val)) {
        console.error(`ALERT: Secret '${name}' found in config file ${f}!`);
        violations++;
      }
    }
    for (const pat of genericPatterns) {
      if (pat.name !== "Service Role JWT" && pat.regex.test(text)) {
        console.error(`ALERT: Pattern '${pat.name}' matched in config file ${f}!`);
        violations++;
      }
    }
  }
}

// 4. Scan Entire Working Tree (excluding node_modules, dist, backups, .git, .npm-cache)
console.log("\n=== SCANNING WORKING TREE FILES ===");
function walk(dir: string) {
  const entries = readdirSync(dir);
  for (const entry of entries) {
    if (
      entry === "node_modules" ||
      entry === "dist" ||
      entry === "backups" ||
      entry === ".git" ||
      entry === ".npm-cache" ||
      entry === "test-results"
    ) {
      continue;
    }
    const full = join(dir, entry);
    const stat = statSync(full);
    if (stat.isDirectory()) {
      walk(full);
    } else if (stat.isFile()) {
      // Don't scan local env files themselves
      if (entry.startsWith(".env") && entry.endsWith(".local")) continue;
      if (entry.endsWith(".jpg") || entry.endsWith(".png") || entry.endsWith(".sql")) continue;

      const content = readFileSync(full, "utf8");
      for (const { name, val } of secretsToDetect) {
        if (content.includes(val)) {
          console.error(`ALERT: Secret '${name}' found in working tree file: ${full}!`);
          violations++;
        }
      }
      if (content.includes("sbp_")) {
        const m = content.match(/sbp_[a-zA-Z0-9_\-]{20,}/);
        if (m) {
          console.error(`ALERT: 'sbp_' found in working tree file: ${full}!`);
          violations++;
        }
      }
      if (content.includes("sb_secret_")) {
        const m = content.match(/sb_secret_[a-zA-Z0-9_\-]{16,}/);
        if (m) {
          console.error(`ALERT: 'sb_secret_' found in working tree file: ${full}!`);
          violations++;
        }
      }
    }
  }
}

walk(process.cwd());

console.log("\n=== SECRET SCAN SUMMARY ===");
if (violations > 0) {
  console.error(`FAILED: ${violations} secret violations found!`);
  process.exit(1);
} else {
  console.log("SUCCESS: 0 secrets detected across git history, config files, and working tree.");
}
