import { readdirSync, statSync, readFileSync } from "node:fs";
import { join } from "node:path";

const patterns = [
  { name: "dangerouslySetInnerHTML", regex: /dangerouslySetInnerHTML/ },
  { name: "innerHTML", regex: /\.innerHTML\s*=/ },
  { name: "eval", regex: /\beval\s*\(/ },
  { name: "new Function", regex: /new\s+Function\s*\(/ },
  { name: "document.write", regex: /document\.write/ },
  { name: "target=_blank missing rel", regex: /target=["']_blank["'](?![^>]*rel=)/ },
  { name: "sensitive data in localStorage", regex: /localStorage\.setItem\([^)]*(?:password|secret|token|api[_-]?key)/i },
  { name: "sensitive data in sessionStorage", regex: /sessionStorage\.setItem\([^)]*(?:password|secret|token|api[_-]?key)/i },
  { name: "console.log of sensitive data", regex: /console\.log\([^)]*(?:password|secret|token|api[_-]?key)/i },
];

function walk(dir: string, out: string[] = []): string[] {
  for (const item of readdirSync(dir)) {
    if (item === "node_modules" || item === "dist" || item === ".git") continue;
    const p = join(dir, item);
    if (statSync(p).isDirectory()) {
      walk(p, out);
    } else if (p.endsWith(".ts") || p.endsWith(".tsx") || p.endsWith(".html")) {
      out.push(p);
    }
  }
  return out;
}

const files = walk("src");
files.push("index.html");

let issues = 0;
for (const file of files) {
  const content = readFileSync(file, "utf8");
  for (const pat of patterns) {
    if (pat.regex.test(content)) {
      console.warn(`[WARNING] Pattern '${pat.name}' matched in ${file}`);
      issues++;
    }
  }
}

if (issues === 0) {
  console.log("Security grep passed: 0 dangerous sinks (innerHTML, eval, un-rel blank targets, leaked tokens) found.");
} else {
  console.log(`Security grep found ${issues} warnings to review.`);
}
