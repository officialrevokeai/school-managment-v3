import { execSync } from "node:child_process";
import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import { resolve, join } from "node:path";

// Load secrets silently from .env.server.local for pattern matching
const envFile = resolve(process.cwd(), ".env.server.local");
const secretsToDetect: string[] = [];
if (existsSync(envFile)) {
  const content = readFileSync(envFile, "utf8");
  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx !== -1) {
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim();
      if (
        key === "SUPABASE_ACCESS_TOKEN" ||
        key === "SUPABASE_DB_PASSWORD" ||
        key === "MASTER_PASSWORD"
      ) {
        if (val.length >= 6) {
          secretsToDetect.push(val);
        }
      }
    }
  }
}

// 1. Scan dist/ directory if it exists
const distDir = resolve(process.cwd(), "dist");
if (existsSync(distDir)) {
  function scanDir(dir: string) {
    const entries = readdirSync(dir);
    for (const entry of entries) {
      const fullPath = join(dir, entry);
      const stat = statSync(fullPath);
      if (stat.isDirectory()) {
        scanDir(fullPath);
      } else if (stat.isFile()) {
        const text = readFileSync(fullPath, "utf8");
        if (text.includes("sbp_")) {
          throw new Error(`SECURITY ALERT: 'sbp_' found in dist asset: ${entry}`);
        }
        if (/sb_secret_[a-zA-Z0-9_\-]{16,}/.test(text)) {
          throw new Error(`SECURITY ALERT: 'sb_secret_' found in dist asset: ${entry}`);
        }
        if (text.includes("service_role")) {
          throw new Error(`SECURITY ALERT: 'service_role' found in dist asset: ${entry}`);
        }
        for (const secret of secretsToDetect) {
          if (text.includes(secret)) {
            throw new Error(`SECURITY ALERT: Environment secret found in dist asset: ${entry}`);
          }
        }
      }
    }
  }
  scanDir(distDir);
  console.log("Dist scan passed: 0 secrets or sensitive tokens in distribution assets.");
}

// 2. Scan staged files
try {
  const staged = execSync("git diff --cached --name-only", { encoding: "utf8" })
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);

  for (const file of staged) {
    if (file === "scripts/secret-scan.ts") continue;
    if (file.startsWith(".env") && file !== ".env.example") {
      console.error(`SECRET SCAN REJECTED: Attempted to commit env file: ${file}`);
      process.exit(1);
    }
    try {
      const content = readFileSync(file, "utf8");
      if (/(?:SUPABASE_SERVICE_ROLE_KEY|SUPABASE_ACCESS_TOKEN)\s*=\s*['"][a-zA-Z0-9_\-]{20,}['"]/i.test(content)) {
        console.error(`SECRET SCAN REJECTED: Potential secret key found in ${file}`);
        process.exit(1);
      }
      for (const secret of secretsToDetect) {
        if (content.includes(secret)) {
          console.error(`SECRET SCAN REJECTED: Raw secret detected in staged file: ${file}`);
          process.exit(1);
        }
      }
    } catch {
      // Binary files or deleted files
    }
  }
  console.log("Staged files scan passed: no credentials staged.");
} catch {
  // Ignored if not in git repo or no git
}
