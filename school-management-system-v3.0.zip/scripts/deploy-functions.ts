import { spawnSync } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const TARGET_REF = 'oqsvedpkqgajjrnxbehz';

function loadServerEnv() {
  const envFile = resolve(process.cwd(), '.env.server.local');
  if (!existsSync(envFile)) {
    throw new Error('Missing .env.server.local');
  }
  const content = readFileSync(envFile, 'utf8');
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx !== -1) {
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim();
      process.env[key] = val;
    }
  }
}

loadServerEnv();
process.env.SUPABASE_YES = 'true';

const functionsToDeploy = [
  'import-csv',
  'export-data',
  'whatsapp-webhook',
];

console.log(`Starting deployment of ${functionsToDeploy.length} functions to ${TARGET_REF}...`);

for (const fn of functionsToDeploy) {
  console.log(`Deploying function: ${fn}...`);
  const result = spawnSync('npx.cmd', ['supabase', 'functions', 'deploy', fn, '--project-ref', TARGET_REF, '--no-verify-jwt'], {
    env: process.env,
    encoding: 'utf8',
    shell: true,
  });

  if (result.status !== 0) {
    console.error(`Error deploying ${fn}:`, result.stderr || result.stdout);
    process.exit(1);
  }
  console.log(`Successfully deployed ${fn}`);
}

console.log('All functions deployed successfully.');
