import { readdir, readFile, writeFile, mkdir } from "node:fs/promises";
import { join, relative } from "node:path";
const root = process.cwd();
const files: string[] = [];
async function walk(directory: string): Promise<void> {
  for (const item of await readdir(directory, { withFileTypes: true })) {
    if (
      ["node_modules", ".git", ".npm-cache", "dist", "docs"].includes(item.name)
    )
      continue;
    const path = join(directory, item.name);
    if (item.isDirectory()) await walk(path);
    else if (
      !item.name.endsWith(".tsbuildinfo") &&
      item.name !== "package-lock.json" &&
      (!item.name.startsWith(".env") || item.name === ".env.example")
    )
      files.push(path);
  }
}
await walk(root);
files.push(join(root, "docs", "PHASE_1_VERIFICATION.md"));
files.push(join(root, "docs", "PHASE_2_VERIFICATION.md"));
files.push(join(root, "docs", "ALL_PHASES.md"));
const phase = ["1", "2"].includes(process.argv[2] ?? "")
  ? process.argv[2]
  : "ALL";
const fence = "````";
const output: string[] = [
  `# Phase ${phase} complete source`,
  "",
  "All authored files are included below. Install reproducible dependencies from package-lock.json in the project folder.",
  "",
];
for (const file of files.sort()) {
  const name = relative(root, file).replaceAll("\\", "/");
  const extension = name.split(".").at(-1) ?? "";
  const language =
    extension === "tsx"
      ? "tsx"
      : ["ts", "css", "sql", "json", "html", "svg", "md"].includes(extension)
        ? extension
        : "text";
  output.push(
    `## ${name}`,
    "",
    `${fence}${language}`,
    await readFile(file, "utf8"),
    fence,
    "",
  );
}
await mkdir(join(root, "docs"), { recursive: true });
await writeFile(
  join(root, "docs", `PHASE_${phase}_SOURCE.md`),
  output.join("\n"),
);
console.log(
  `Wrote complete contents of ${files.length} files to docs/PHASE_${phase}_SOURCE.md`,
);
