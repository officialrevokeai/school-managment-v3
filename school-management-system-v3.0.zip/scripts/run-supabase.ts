import { readFileSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';

// Load .env.server.local securely into process.env
process.env.SUPABASE_YES = 'true';
const envFile = resolve(process.cwd(), '.env.server.local');
if (existsSync(envFile)) {
  const content = readFileSync(envFile, 'utf8');
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx !== -1) {
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim();
      process.env[key] = val;
    }
  }
}

const args = process.argv.slice(2);
const isWin = process.platform === 'win32';

const res = spawnSync('npx', ['supabase', ...args], {
  shell: isWin,
  stdio: 'inherit',
  env: process.env,
});

process.exit(res.status ?? 0);
