import { spawn } from "node:child_process";
import autocannon from "autocannon";

async function runLoadTest() {
  console.log("=== Phase T7: Light Load Testing (Autocannon on Production Preview) ===");
  const server = spawn("npx", ["vite", "preview", "--host", "127.0.0.1", "--port", "5174"], {
    shell: true,
  });

  // Give server 3 seconds to spin up
  await new Promise((r) => setTimeout(r, 3000));

  try {
    const result = await autocannon({
      url: "http://127.0.0.1:5174/",
      connections: 30,
      pipelining: 1,
      duration: 10,
    });

    console.log(autocannon.printResult(result));

    const non2xx = result["non2xx"] || 0;
    const avgLatency = result.latency.average;
    console.log(`Requests: ${result.requests.total}, non-2xx: ${non2xx}, avg latency: ${avgLatency}ms`);

    if (result.requests.total === 0 || non2xx > 0) {
      throw new Error(`Load test failed: total=${result.requests.total}, non2xx=${non2xx}`);
    }
    console.log("LOAD TEST PASSED: 0% non-2xx errors under 30 concurrent connections.");
  } finally {
    if (server.pid) {
      try {
        if (process.platform === "win32") {
          spawn("taskkill", ["/pid", server.pid.toString(), "/T", "/F"]);
        } else {
          server.kill("SIGTERM");
        }
      } catch {
        // Ignored
      }
    }
  }
}

runLoadTest().catch((err) => {
  console.error("Load test error:", err);
  process.exit(1);
});
