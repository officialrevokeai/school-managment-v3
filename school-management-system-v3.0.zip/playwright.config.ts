import { defineConfig, devices } from "@playwright/test";
import { resolve } from "node:path";

export default defineConfig({
  testDir: "./tests",
  timeout: 60_000,
  expect: { timeout: 15_000 },
  fullyParallel: false,
  reporter: [["list"], ["html", { open: "never", outputFolder: "playwright-report" }]],
  use: {
    baseURL: process.env.PLAYWRIGHT_BASE_URL || "http://127.0.0.1:5173",
    trace: "off", // Redacted by default for security, enabled on failure for non-auth tests
    video: "off",
    screenshot: "only-on-failure",
    viewport: { width: 1280, height: 720 },
  },
  projects: [
    // 1. Global Auth Setup (Creates per-role storage states in .playwright/)
    {
      name: "auth-setup",
      testMatch: /auth\.setup\.ts/,
    },

    // 2. Desktop Browsers
    {
      name: "chromium-desktop",
      use: {
        ...devices["Desktop Chrome"],
        viewport: { width: 1280, height: 720 },
      },
      dependencies: ["auth-setup"],
    },
    {
      name: "firefox-desktop",
      use: {
        ...devices["Desktop Firefox"],
        viewport: { width: 1280, height: 720 },
      },
      dependencies: ["auth-setup"],
    },
    {
      name: "webkit-desktop",
      use: {
        ...devices["Desktop Safari"],
        viewport: { width: 1280, height: 720 },
      },
      dependencies: ["auth-setup"],
    },

    // 3. Tablet
    {
      name: "tablet-ipad",
      use: {
        ...devices["iPad (gen 7)"],
      },
      dependencies: ["auth-setup"],
    },

    // 4. Mobile Devices
    {
      name: "mobile-pixel7",
      use: {
        ...devices["Pixel 7"],
      },
      dependencies: ["auth-setup"],
    },
    {
      name: "mobile-iphone14",
      use: {
        ...devices["iPhone 14"],
      },
      dependencies: ["auth-setup"],
    },
  ],
  webServer: {
    command: "npm run dev -- --host 127.0.0.1 --port 5173",
    url: "http://127.0.0.1:5173",
    reuseExistingServer: true,
    timeout: 30_000,
  },
});
