export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type Database = {
  public: {
    Tables: {
      schools: {
        Row: {
          id: string;
          name: string;
          code: string;
          status: "Active" | "Suspended" | "Deleted";
          plan: "Starter" | "Growth" | "Enterprise";
          monthly_fee: number;
          owner_email: string;
          settings: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          code: string;
          status?: "Active" | "Suspended" | "Deleted";
          plan?: "Starter" | "Growth" | "Enterprise";
          monthly_fee?: number;
          owner_email: string;
          settings?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          name?: string;
          code?: string;
          status?: "Active" | "Suspended" | "Deleted";
          plan?: "Starter" | "Growth" | "Enterprise";
          monthly_fee?: number;
          owner_email?: string;
          settings?: Json;
          updated_at?: string;
        };
        Relationships: [];
      };
      plans: {
        Row: {
          id: string;
          name: string;
          tier: "Starter" | "Growth" | "Enterprise";
          price: number;
          max_students: number;
          max_branches: number;
          features: Json;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          tier: "Starter" | "Growth" | "Enterprise";
          price?: number;
          max_students?: number;
          max_branches?: number;
          features?: Json;
          created_at?: string;
        };
        Update: {
          name?: string;
          tier?: "Starter" | "Growth" | "Enterprise";
          price?: number;
          max_students?: number;
          max_branches?: number;
          features?: Json;
        };
        Relationships: [];
      };
      branches: {
        Row: {
          id: string;
          school_id: string;
          name: string;
          city: string;
          code: string;
          short_name: string;
          principal_name: string;
          capacity: number;
          status: "Active" | "Inactive";
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          school_id: string;
          name: string;
          city: string;
          code: string;
          short_name?: string;
          principal_name?: string;
          capacity?: number;
          status?: "Active" | "Inactive";
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          name?: string;
          city?: string;
          code?: string;
          short_name?: string;
          principal_name?: string;
          capacity?: number;
          status?: "Active" | "Inactive";
          updated_at?: string;
        };
        Relationships: [];
      };
      profiles: {
        Row: {
          id: string;
          school_id: string;
          branch_ids: string[];
          policy_id: string | null;
          role:
            | "master"
            | "owner"
            | "principal"
            | "teacher"
            | "parent"
            | "student"
            | "accountant";
          name: string;
          email: string;
          phone: string;
          active: boolean;
          must_change_password: boolean;
          metadata: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          school_id: string;
          branch_ids?: string[];
          policy_id?: string | null;
          role:
            | "master"
            | "owner"
            | "principal"
            | "teacher"
            | "parent"
            | "student"
            | "accountant";
          name: string;
          email: string;
          phone?: string;
          active?: boolean;
          must_change_password?: boolean;
          metadata?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          name?: string;
          phone?: string;
          active?: boolean;
          must_change_password?: boolean;
          branch_ids?: string[];
          policy_id?: string | null;
          metadata?: Json;
          updated_at?: string;
        };
        Relationships: [];
      };
      notifications: {
        Row: {
          id: string;
          school_id: string;
          branch_id: string | null;
          user_id: string;
          title: string;
          body: string;
          read: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          school_id: string;
          branch_id?: string | null;
          user_id: string;
          title: string;
          body: string;
          read?: boolean;
          created_at?: string;
        };
        Update: {
          read?: boolean;
        };
        Relationships: [];
      };
      admin_records: {
        Row: {
          id: string;
          school_id: string;
          branch_id: string | null;
          resource: string;
          payload: Json;
          version: number;
          updated_at: string;
        };
        Insert: {
          id: string;
          school_id: string;
          branch_id?: string | null;
          resource: string;
          payload: Json;
          version?: number;
          updated_at?: string;
        };
        Update: {
          payload?: Json;
          version?: number;
          branch_id?: string | null;
          updated_at?: string;
        };
        Relationships: [];
      };
      school_workflows: {
        Row: {
          id: string;
          school_id: string;
          branch_id: string;
          class_id: string | null;
          student_id: string | null;
          author_id: string;
          module: string;
          version: number;
          payload: Json;
          updated_at: string;
        };
        Insert: {
          id: string;
          school_id: string;
          branch_id: string;
          class_id?: string | null;
          student_id?: string | null;
          author_id: string;
          module: string;
          version?: number;
          payload: Json;
          updated_at?: string;
        };
        Update: {
          payload?: Json;
          version?: number;
          updated_at?: string;
        };
        Relationships: [];
      };
      attendance_records: {
        Row: {
          id: string;
          school_id: string;
          branch_id: string;
          class_id: string;
          student_id: string;
          marked_by: string | null;
          date: string;
          status: "Present" | "Absent" | "Late" | "Leave";
          notes: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          school_id: string;
          branch_id: string;
          class_id: string;
          student_id: string;
          marked_by?: string | null;
          date: string;
          status?: "Present" | "Absent" | "Late" | "Leave";
          notes?: string;
          created_at?: string;
        };
        Update: {
          status?: "Present" | "Absent" | "Late" | "Leave";
          notes?: string;
        };
        Relationships: [];
      };
      marks: {
        Row: {
          id: string;
          school_id: string;
          branch_id: string;
          exam_id: string | null;
          class_id: string;
          subject_id: string;
          student_id: string;
          entered_by: string | null;
          score: number;
          maximum: number;
          published: boolean;
          notes: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          school_id: string;
          branch_id: string;
          exam_id?: string | null;
          class_id: string;
          subject_id: string;
          student_id: string;
          entered_by?: string | null;
          score: number;
          maximum: number;
          published?: boolean;
          notes?: string;
          created_at?: string;
        };
        Update: {
          score?: number;
          maximum?: number;
          published?: boolean;
          notes?: string;
        };
        Relationships: [];
      };
      student_fees: {
        Row: {
          id: string;
          school_id: string;
          branch_id: string;
          student_id: string;
          fee_structure_id: string | null;
          title: string;
          amount: number;
          discount: number;
          fine: number;
          paid_amount: number;
          due_date: string;
          status: "Pending" | "Paid" | "Overdue";
          notes: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          school_id: string;
          branch_id: string;
          student_id: string;
          fee_structure_id?: string | null;
          title: string;
          amount: number;
          discount?: number;
          fine?: number;
          paid_amount?: number;
          due_date: string;
          status?: "Pending" | "Paid" | "Overdue";
          notes?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          paid_amount?: number;
          status?: "Pending" | "Paid" | "Overdue";
          notes?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      fee_payments: {
        Row: {
          id: string;
          school_id: string;
          branch_id: string;
          student_fee_id: string;
          student_id: string;
          collected_by: string;
          amount: number;
          payment_method: "Cash" | "UPI" | "Bank_Transfer" | "Card" | "Cheque";
          transaction_ref: string;
          receipt_number: string;
          paid_at: string;
          notes: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          school_id: string;
          branch_id: string;
          student_fee_id: string;
          student_id: string;
          collected_by: string;
          amount: number;
          payment_method?: "Cash" | "UPI" | "Bank_Transfer" | "Card" | "Cheque";
          transaction_ref?: string;
          receipt_number: string;
          paid_at?: string;
          notes?: string;
          created_at?: string;
        };
        Update: {
          notes?: string;
        };
        Relationships: [];
      };
      system_metrics: {
        Row: {
          id: string;
          school_id: string | null;
          metric_name: string;
          value: number;
          unit: string | null;
          metadata: Json;
          recorded_at: string;
        };
        Insert: {
          id?: string;
          school_id?: string | null;
          metric_name: string;
          value: number;
          unit?: string | null;
          metadata?: Json;
          recorded_at?: string;
        };
        Update: {
          id?: string;
          school_id?: string | null;
          metric_name?: string;
          value?: number;
          unit?: string | null;
          metadata?: Json;
          recorded_at?: string;
        };
        Relationships: [];
      };
      security_alerts: {
        Row: {
          id: string;
          school_id: string | null;
          severity: "low" | "medium" | "high" | "critical";
          title: string;
          message: string;
          resolved: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          school_id?: string | null;
          severity: "low" | "medium" | "high" | "critical";
          title: string;
          message: string;
          resolved?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          school_id?: string | null;
          severity?: "low" | "medium" | "high" | "critical";
          title?: string;
          message?: string;
          resolved?: boolean;
          created_at?: string;
        };
        Relationships: [];
      };
      user_consents: {
        Row: {
          id: string;
          school_id: string;
          user_id: string | null;
          phone_number: string | null;
          channel: "whatsapp" | "sms" | "email";
          consented: boolean;
          updated_at: string;
        };
        Insert: {
          id?: string;
          school_id: string;
          user_id?: string | null;
          phone_number?: string | null;
          channel?: "whatsapp" | "sms" | "email";
          consented?: boolean;
          updated_at?: string;
        };
        Update: {
          id?: string;
          school_id?: string;
          user_id?: string | null;
          phone_number?: string | null;
          channel?: "whatsapp" | "sms" | "email";
          consented?: boolean;
          updated_at?: string;
        };
        Relationships: [];
      };
    };
    Views: { [_ in never]: never };
    Functions: {
      get_realtime_monitoring: {
        Args: { p_school_id: string; p_branch_id?: string };
        Returns: Json;
      };
      rollup_school_metrics: { Args: Record<string, never>; Returns: void };
      admin_summary: { Args: { p_scope: Json }; Returns: Json };
      admin_list: {
        Args: { p_resource: string; p_scope: Json; p_options: Json };
        Returns: Json;
      };
      admin_save: {
        Args: { p_resource: string; p_record: Json };
        Returns: Json;
      };
      admin_delete: {
        Args: {
          p_resource: string;
          p_id: string;
          p_scope: Json;
          p_version: number;
        };
        Returns: Json;
      };
      workflow_context: { Args: { p_branch: string }; Returns: Json };
      workflow_list: {
        Args: { p_module: string; p_scope: Json };
        Returns: Json;
      };
      workflow_save: { Args: { p_record: Json }; Returns: Json };
      workflow_remove: {
        Args: { p_id: string; p_version: number };
        Returns: Json;
      };
      workflow_delivery: {
        Args: { p_provider_id: string; p_status: string };
        Returns: Json;
      };
      attendance_mark_bulk: {
        Args: {
          p_class_id: string;
          p_branch_id: string;
          p_date: string;
          p_records: Json;
        };
        Returns: Json;
      };
      marks_upsert_bulk: {
        Args: {
          p_exam_id: string;
          p_class_id: string;
          p_subject_id: string;
          p_branch_id: string;
          p_marks: Json;
        };
        Returns: Json;
      };
      fee_collect_payment: {
        Args: {
          p_student_fee_id: string;
          p_amount: number;
          p_method: string;
          p_notes?: string;
        };
        Returns: Json;
      };
      provision_school_record: {
        Args: { p_school: Json; p_owner_id: string; p_actor: string };
        Returns: Json;
      };
      search_global: { Args: { p_query: string }; Returns: Json };
    };
    Enums: {
      user_role:
        | "master"
        | "owner"
        | "principal"
        | "teacher"
        | "parent"
        | "student"
        | "accountant";
      school_status: "Active" | "Suspended" | "Deleted";
      plan_tier: "Starter" | "Growth" | "Enterprise";
      branch_status: "Active" | "Inactive";
      attendance_status: "Present" | "Absent" | "Late" | "Leave";
      fee_status: "Pending" | "Paid" | "Overdue";
      expense_status: "Pending" | "Approved" | "Paid";
      payment_mode: "Cash" | "UPI" | "Bank_Transfer" | "Card" | "Cheque";
    };
    CompositeTypes: { [_ in never]: never };
  };
};
