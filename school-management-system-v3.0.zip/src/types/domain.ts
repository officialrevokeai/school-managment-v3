export const roles = [
  "owner",
  "principal",
  "teacher",
  "parent",
  "student",
  "accountant",
  "master",
] as const;
export type Role = (typeof roles)[number];
export type Profile = {
  policyId?: string | null;
  id: string;
  name: string;
  email: string;
  role: Role;
  schoolId: string;
  branchIds: string[];
};
export type Branch = {
  id: string;
  school_id: string;
  name: string;
  city: string;
  short_name: string;
};
export type Notification = {
  id: string;
  user_id: string;
  branch_id: string | null;
  title: string;
  body: string;
  created_at: string;
  read: boolean;
};
export type Workspace = {
  id: string;
  name: string;
  description: string;
  category: "Community" | "Academics" | "Operations" | "System";
  permission: import("../lib/permissions").Permission;
  phase: number;
  icon: import("../components/ui/Icon").IconName;
};
export type SignInInput = {
  identifier: string;
  password: string;
  remember: boolean;
  master?: boolean;
};
export type Unsubscribe = () => void;
