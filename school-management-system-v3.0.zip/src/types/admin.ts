import { z } from "zod";
import { permissions } from "../lib/permissions";
const base = {
  id: z.string(),
  schoolId: z.string(),
  branchId: z.string().nullable(),
  version: z.number().int().positive(),
};
export const adminSchemas = {
  analytics: z.object({
    ...base,
    date: z.string(),
    present: z.number().nonnegative(),
    total: z.number().nonnegative(),
  }),
  schools: z.object({
    ...base,
    name: z.string().min(2),
    code: z.string().min(2),
    ownerEmail: z.string().email(),
    plan: z.enum(["Starter", "Growth", "Enterprise"]),
    status: z.enum(["Active", "Suspended", "Deleted"]),
    monthlyFee: z.number().nonnegative(),
    createdAt: z.string(),
  }),
  branches: z.object({
    ...base,
    name: z.string().min(2),
    city: z.string().min(2),
    code: z.string().min(2),
    principal: z.string(),
    capacity: z.number().int().positive(),
    status: z.enum(["Active", "Inactive"]),
  }),
  users: z.object({
    ...base,
    name: z.string().min(2),
    email: z.string().email(),
    role: z.enum(["principal", "teacher", "parent", "student", "accountant"]),
    policyId: z.string().nullable().default(null),
    status: z.enum(["Active", "Inactive"]),
    phone: z.string(),
    joinedAt: z.string(),
  }),
  finance: z.object({
    ...base,
    reference: z.string().min(2),
    description: z.string().min(2),
    kind: z.enum(["Income", "Expense"]),
    category: z.string().min(2),
    amount: z.number().positive(),
    date: z.string(),
    status: z.enum(["Paid", "Pending", "Overdue"]),
  }),
  roles: z.object({
    ...base,
    name: z.string(),
    custom: z.boolean().default(false),
    role: z.enum([
      "owner",
      "principal",
      "teacher",
      "parent",
      "student",
      "accountant",
      "master",
    ]),
    permissions: z.array(z.enum(permissions)),
  }),
  settings: z.object({
    ...base,
    name: z.string().min(2),
    academicYear: z.string(),
    logoPath: z.string(),
    senderNumber: z.string(),
    financeRole: z.enum(["owner", "accountant"]),
    overrideEnabled: z.boolean(),
    requireMfa: z.boolean(),
    sessionMinutes: z.number().min(15).max(480),
    privacyEmail: z.string().email(),
    retentionDays: z.number().min(30).max(3650),
  }),
  templates: z.object({
    ...base,
    name: z.string().min(2),
    category: z.enum(["Attendance", "Fees", "Announcements"]),
    body: z.string().min(10),
    status: z.enum(["Draft", "Pending", "Approved"]),
  }),
  audit: z.object({
    ...base,
    actor: z.string(),
    action: z.string(),
    resource: z.string(),
    details: z.string(),
    createdAt: z.string(),
  }),
};
export type AdminModels = {
  [K in keyof typeof adminSchemas]: z.infer<(typeof adminSchemas)[K]>;
};
export type AdminResource = keyof AdminModels;
export type AdminScope = {
  schoolId: string;
  branchId?: string;
  from?: string;
  to?: string;
};
export type ListOptions = {
  search?: string;
  page?: number;
  pageSize?: number;
  from?: string;
  to?: string;
  filters?: Record<string, string>;
};
export type AdminPage<T> = { rows: T[]; total: number };
export const summarySchema = z.object({
  students: z.number(),
  staff: z.number(),
  income: z.number(),
  expenses: z.number(),
  outstanding: z.number(),
  schools: z.number(),
  active: z.number(),
  mrr: z.number(),
  suspended: z.number(),
  revenue: z.array(
    z.object({
      label: z.string(),
      value: z.number(),
      secondary: z.number().optional(),
    }),
  ),
  enrollment: z.array(z.object({ label: z.string(), value: z.number() })),
  attendance: z
    .array(z.object({ label: z.string(), value: z.number() }))
    .default([]),
});
export type AdminSummary = z.infer<typeof summarySchema>;
export type SchoolInput = {
  name: string;
  code: string;
  ownerEmail: string;
  plan: AdminModels["schools"]["plan"];
  monthlyFee: number;
  password?: string;
};
export type ProvisionedSchool = {
  school: AdminModels["schools"];
  email: string;
  password: string;
};
export interface AdminRepository {
  summary(scope: AdminScope): Promise<AdminSummary>;
  list<K extends AdminResource>(
    resource: K,
    scope: AdminScope,
    options?: ListOptions,
  ): Promise<AdminPage<AdminModels[K]>>;
  save<K extends Exclude<AdminResource, "audit" | "analytics">>(
    resource: K,
    record: AdminModels[K],
  ): Promise<AdminModels[K]>;
  remove<K extends Exclude<AdminResource, "audit" | "schools" | "analytics">>(
    resource: K,
    id: string,
    scope: AdminScope,
    version: number,
  ): Promise<void>;
  provisionSchool(input: SchoolInput): Promise<ProvisionedSchool>;
}
export function parseRecord<K extends AdminResource>(
  resource: K,
  value: unknown,
): AdminModels[K] {
  return adminSchemas[resource].parse(value) as AdminModels[K];
}
