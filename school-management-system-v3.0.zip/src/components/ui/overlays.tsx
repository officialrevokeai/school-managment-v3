import { createPortal } from "react-dom";
import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { NeuButton, NeuInput } from "./primitives";

type OverlayProps = {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
};
function Overlay({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  drawer = false,
}: OverlayProps & { drawer?: boolean }) {
  const titleId = useId();
  const descriptionId = useId();
  const panel = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const root = document.getElementById("root");
    root?.setAttribute("inert", "");
    const timer = setTimeout(() => panel.current?.focus(), 0);
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeRef.current();
      if (event.key !== "Tab") return;
      const nodes = panel.current?.querySelectorAll<HTMLElement>(
        'button:not(:disabled), [href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex="0"]',
      );
      const first = nodes?.[0];
      const last = nodes?.[nodes.length - 1];
      if (!first || !last) {
        event.preventDefault();
        return;
      }
      if (
        event.shiftKey &&
        (document.activeElement === first ||
          document.activeElement === panel.current)
      ) {
        event.preventDefault();
        last.focus();
      } else if (
        !event.shiftKey &&
        (document.activeElement === last ||
          document.activeElement === panel.current)
      ) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", keydown);
    return () => {
      clearTimeout(timer);
      document.body.style.overflow = oldOverflow;
      root?.removeAttribute("inert");
      document.removeEventListener("keydown", keydown);
      previous?.focus();
    };
  }, [open]);
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className={`overlay ${drawer ? "drawer-overlay" : ""}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
        >
          <motion.div
            ref={panel}
            className={`overlay-panel ${drawer ? "drawer-panel" : ""}`}
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            aria-describedby={description ? descriptionId : undefined}
            tabIndex={-1}
            initial={drawer ? { x: 40 } : { y: 18, scale: 0.98 }}
            animate={{ x: 0, y: 0, scale: 1 }}
            exit={drawer ? { x: 40 } : { y: 18, scale: 0.98 }}
            transition={{ duration: 0.2 }}
          >
            <div className="overlay-header">
              <div>
                <h2 id={titleId}>{title}</h2>
                {description && <p id={descriptionId}>{description}</p>}
              </div>
              <NeuButton
                variant="ghost"
                icon="close"
                aria-label="Close dialog"
                onClick={onClose}
              />
            </div>
            <div className="overlay-content">{children}</div>
            {footer && <div className="overlay-footer">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
export function NeuModal(props: OverlayProps) {
  return <Overlay {...props} />;
}
export function NeuDrawer(props: OverlayProps) {
  return <Overlay {...props} drawer />;
}
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  description,
  confirmText,
  loading,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmText?: string;
  loading?: boolean;
}) {
  const [text, setText] = useState("");
  useEffect(() => {
    if (open) setText("");
  }, [open]);
  return (
    <NeuModal
      open={open}
      onClose={loading ? () => undefined : onClose}
      title={title}
      description={description}
      footer={
        <>
          <NeuButton onClick={onClose} disabled={loading}>
            Cancel
          </NeuButton>
          <NeuButton
            className="danger"
            onClick={onConfirm}
            loading={loading}
            disabled={!!confirmText && text !== confirmText}
          >
            Confirm
          </NeuButton>
        </>
      }
    >
      {confirmText && (
        <NeuInput
          id="confirm-action"
          label={`Type “${confirmText}” to confirm`}
          autoComplete="off"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      )}
    </NeuModal>
  );
}
