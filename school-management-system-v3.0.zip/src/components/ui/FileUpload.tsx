import { useRef, useState } from "react";
import { Icon } from "./Icon";
import { NeuButton } from "./primitives";
export function FileUpload({
  onUpload,
  accept = ".pdf,.csv,.png,.jpg,.jpeg",
  maxMB = 5,
  disabled = false,
}: {
  onUpload: (file: File) => Promise<void>;
  accept?: string;
  maxMB?: number;
  disabled?: boolean;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [dragging, setDragging] = useState(false);
  const upload = async (file?: File) => {
    if (!file || busy || disabled) return;
    if (file.size > maxMB * 1024 * 1024) {
      setMessage(`Choose a file smaller than ${maxMB} MB.`);
      return;
    }
    const accepted = accept
      .split(",")
      .some((type) =>
        type.trim().startsWith(".")
          ? file.name.toLowerCase().endsWith(type.trim().toLowerCase())
          : type.trim().endsWith("/*")
            ? file.type.startsWith(type.trim().slice(0, -1))
            : file.type === type.trim(),
      );
    if (!accepted) {
      setMessage("This file type is not supported.");
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      await onUpload(file);
      setMessage(`${file.name} uploaded successfully.`);
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Upload failed. Please try again.",
      );
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  };
  return (
    <div
      className={`file-upload ${dragging ? "dragging" : ""}`}
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        void upload(e.dataTransfer.files[0]);
      }}
    >
      <Icon name="upload" size={28} />
      <b>Drop a file here, or browse</b>
      <small>
        {accept.replaceAll(".", "").toUpperCase()} · up to {maxMB} MB
      </small>
      <input
        ref={input}
        type="file"
        accept={accept}
        onChange={(e) => void upload(e.target.files?.[0])}
        className="sr-only"
        tabIndex={-1}
        aria-hidden="true"
      />
      <NeuButton
        icon="plus"
        loading={busy}
        disabled={disabled}
        onClick={() => input.current?.click()}
      >
        Choose file
      </NeuButton>
      <span role="status">{message}</span>
    </div>
  );
}
