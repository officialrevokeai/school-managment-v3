import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bell,
  BookOpen,
  Building2,
  CalendarDays,
  CalendarCheck,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  CircleHelp,
  Clock3,
  Copy,
  CreditCard,
  Download,
  Ellipsis,
  Eye,
  EyeOff,
  FileText,
  GraduationCap,
  Heart,
  Home,
  LayoutDashboard,
  Layers,
  Loader2,
  LockKeyhole,
  LogOut,
  Mail,
  Menu,
  MessageCircle,
  Monitor,
  Moon,
  Palette,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Sun,
  Upload,
  Users,
  UserRound,
  Wallet,
  X,
  XCircle,
} from "lucide-react";
import type { CSSProperties } from "react";
const icons = {
  "arrow-down": ArrowDown,
  "arrow-left": ArrowLeft,
  "arrow-right": ArrowRight,
  "arrow-up-right": ArrowUpRight,
  bell: Bell,
  book: BookOpen,
  building: Building2,
  calendar: CalendarDays,
  "calendar-check": CalendarCheck,
  check: Check,
  "check-all": CheckCheck,
  down: ChevronDown,
  left: ChevronLeft,
  right: ChevronRight,
  collapse: ChevronsLeft,
  help: CircleHelp,
  clock: Clock3,
  copy: Copy,
  credit: CreditCard,
  download: Download,
  more: Ellipsis,
  eye: Eye,
  "eye-off": EyeOff,
  file: FileText,
  graduation: GraduationCap,
  heart: Heart,
  home: Home,
  grid: LayoutDashboard,
  layers: Layers,
  loading: Loader2,
  lock: LockKeyhole,
  logout: LogOut,
  mail: Mail,
  menu: Menu,
  message: MessageCircle,
  monitor: Monitor,
  moon: Moon,
  palette: Palette,
  plus: Plus,
  search: Search,
  settings: Settings2,
  shield: ShieldCheck,
  sparkles: Sparkles,
  sun: Sun,
  upload: Upload,
  users: Users,
  user: UserRound,
  wallet: Wallet,
  close: X,
  error: XCircle,
};
export type IconName = keyof typeof icons;
export function Icon({
  name,
  size = 20,
  className = "",
  style,
}: {
  name: IconName;
  size?: number;
  className?: string;
  style?: CSSProperties;
}) {
  const Component = icons[name];
  return (
    <Component
      size={size}
      stroke="url(#icon-gradient)"
      strokeWidth={1.8}
      className={`icon ${className}`}
      style={style}
      aria-hidden="true"
    />
  );
}
export function IconGradients() {
  return (
    <svg width="0" height="0" aria-hidden="true" className="gradient-defs">
      <defs>
        <linearGradient id="icon-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4DB8FF" />
          <stop offset="100%" stopColor="#A99BD6" />
        </linearGradient>
      </defs>
    </svg>
  );
}
