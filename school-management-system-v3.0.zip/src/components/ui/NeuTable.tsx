import {
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table";
import { useVirtualizer } from "@tanstack/react-virtual";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { EmptyState } from "./primitives";
type TableProps<T> = {
  data: T[];
  columns: ColumnDef<T, unknown>[];
  label: string;
  rowKey: (row: T) => string;
  renderMobile: (row: T) => ReactNode;
};
export function NeuTable<T>({
  data,
  columns,
  label,
  rowKey,
  renderMobile,
}: TableProps<T>) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const parent = useRef<HTMLDivElement>(null);
  const [mobile, setMobile] = useState(
    () => matchMedia("(max-width: 639px)").matches,
  );
  useEffect(() => {
    const media = matchMedia("(max-width: 639px)");
    const update = () => setMobile(media.matches);
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);
  const table = useReactTable({
    data,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getRowId: rowKey,
  });
  const rows = table.getRowModel().rows;
  const virtual = useVirtualizer({
    count: rows.length,
    getScrollElement: () => parent.current,
    estimateSize: () => (mobile ? 73 : 64),
    overscan: 6,
    enabled: rows.length > 100,
  });
  useEffect(() => {
    virtual.measure();
  }, [mobile, virtual]);
  if (!data.length)
    return (
      <EmptyState
        title="No records found"
        description="Try adjusting your search or filters."
      />
    );
  const displayed =
    rows.length > 100
      ? virtual.getVirtualItems().flatMap((item) => {
          const row = rows[item.index];
          return row ? [{ row, item }] : [];
        })
      : rows.map((row) => ({ row, item: undefined }));
  // Both mobile cards and desktop rows share one bounded virtual scroller.
  return (
    <div
      ref={parent}
      className="table-scroll"
      style={rows.length > 100 ? { height: 480, overflowY: "auto" } : undefined}
    >
      <div className="mobile-table" aria-label={label}>
        {displayed.length > 0 && rows.length > 100 && (
          <div style={{ height: displayed[0]?.item?.start ?? 0 }} />
        )}
        {displayed.map(({ row }) => (
          <article key={row.id}>{renderMobile(row.original)}</article>
        ))}
        {rows.length > 100 && (
          <div
            style={{
              height:
                virtual.getTotalSize() - (displayed.at(-1)?.item?.end ?? 0),
            }}
          />
        )}
      </div>
      <table className="neu-table" aria-label={label}>
        <thead>
          {table.getHeaderGroups().map((group) => (
            <tr key={group.id}>
              {group.headers.map((header) => (
                <th
                  key={header.id}
                  aria-sort={
                    header.column.getIsSorted() === "asc"
                      ? "ascending"
                      : header.column.getIsSorted() === "desc"
                        ? "descending"
                        : undefined
                  }
                >
                  {header.column.getCanSort() ? (
                    <button onClick={header.column.getToggleSortingHandler()}>
                      {flexRender(
                        header.column.columnDef.header,
                        header.getContext(),
                      )}
                      <span aria-hidden="true">↕</span>
                    </button>
                  ) : (
                    flexRender(
                      header.column.columnDef.header,
                      header.getContext(),
                    )
                  )}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {rows.length > 100 && (
            <tr aria-hidden="true">
              <td
                colSpan={columns.length}
                style={{ height: displayed[0]?.item?.start ?? 0, padding: 0 }}
              />
            </tr>
          )}
          {displayed.map(({ row, item }) => (
            <tr key={row.id} style={item ? { height: item.size } : undefined}>
              {row.getVisibleCells().map((cell) => (
                <td key={cell.id}>
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
          {rows.length > 100 && (
            <tr aria-hidden="true">
              <td
                colSpan={columns.length}
                style={{
                  height:
                    virtual.getTotalSize() - (displayed.at(-1)?.item?.end ?? 0),
                  padding: 0,
                }}
              />
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
