import {
  forwardRef,
  useEffect,
  useId,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
} from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Icon, type IconName } from "./Icon";
import { useUI } from "../../store/ui";
import { useTheme } from "../../hooks/useTheme";

export const NeuButton = forwardRef<
  HTMLButtonElement,
  ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: "primary" | "secondary" | "icon" | "ghost";
    loading?: boolean;
    icon?: IconName;
  }
>(function NeuButton(
  {
    variant = "secondary",
    loading,
    icon,
    children,
    className = "",
    disabled,
    ...props
  },
  ref,
) {
  return (
    <button
      ref={ref}
      className={`neu-button ${variant} ${className}`}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...props}
    >
      {loading ? (
        <Icon name="loading" className="spin" />
      ) : icon ? (
        <Icon name={icon} />
      ) : null}
      {children}
    </button>
  );
});
export function NeuCard({
  children,
  className = "",
  ...props
}: HTMLAttributes<HTMLElement>) {
  return (
    <section className={`neu-card ${className}`} {...props}>
      {children}
    </section>
  );
}
export const NeuInput = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & {
    label?: string;
    error?: string;
    hint?: string;
    icon?: IconName;
  }
>(function NeuInput(
  { label, error, hint, icon, id, className = "", ...props },
  ref,
) {
  const inputId = id ?? props.name;
  return (
    <div className={`field ${className}`}>
      {label && <label htmlFor={inputId}>{label}</label>}
      <div className="input-wrap">
        {icon && <Icon name={icon} />}
        <input
          ref={ref}
          id={inputId}
          aria-invalid={!!error}
          aria-describedby={error || hint ? `${inputId}-help` : undefined}
          {...props}
        />
      </div>
      {(error || hint) && (
        <span
          className={error ? "field-error" : "field-hint"}
          id={`${inputId}-help`}
        >
          {error || hint}
        </span>
      )}
    </div>
  );
});
export const NeuSelect = forwardRef<
  HTMLSelectElement,
  SelectHTMLAttributes<HTMLSelectElement> & { label?: string }
>(function NeuSelect({ label, id, children, className = "", ...props }, ref) {
  return (
    <div className={`field ${className}`}>
      {label && <label htmlFor={id}>{label}</label>}
      <div className="select-wrap">
        <select ref={ref} id={id} {...props}>
          {children}
        </select>
        <Icon name="down" size={16} />
      </div>
    </div>
  );
});
export function NeuToggle({
  checked,
  onChange,
  label,
  description,
  disabled,
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  description?: string;
  disabled?: boolean;
}) {
  return (
    <label className={`toggle-row ${disabled ? "disabled" : ""}`}>
      <span>
        <span className="control-label">{label}</span>
        {description && <small>{description}</small>}
      </span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        className={`toggle ${checked ? "on" : ""}`}
        onClick={() => onChange(!checked)}
      >
        <motion.span layout transition={{ duration: 0.18 }} />
      </button>
    </label>
  );
}
export const NeuCheckbox = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & { label: string }
>(function NeuCheckbox({ label, ...props }, ref) {
  return (
    <label className="choice">
      <input ref={ref} type="checkbox" {...props} />
      <span>{label}</span>
    </label>
  );
});
export const NeuRadio = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & { label: string }
>(function NeuRadio({ label, ...props }, ref) {
  return (
    <label className="choice">
      <input ref={ref} type="radio" {...props} />
      <span>{label}</span>
    </label>
  );
});
export function NeuTabs<T extends string>({
  tabs,
  value,
  onChange,
  label = "View",
}: {
  tabs: readonly { value: T; label: string }[];
  value: T;
  onChange: (value: T) => void;
  label?: string;
}) {
  const id = useId();
  return (
    <div className="neu-tabs" role="group" aria-label={label}>
      {tabs.map((tab) => (
        <button
          type="button"
          key={tab.value}
          aria-pressed={value === tab.value}
          className={value === tab.value ? "active" : ""}
          onClick={() => onChange(tab.value)}
        >
          {value === tab.value && (
            <motion.span
              className="tab-indicator"
              layoutId={`tab-${id}`}
              transition={{ duration: 0.18 }}
            />
          )}
          <span>{tab.label}</span>
        </button>
      ))}
    </div>
  );
}
export function NeuBadge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "success" | "accent" | "warning";
}) {
  return <span className={`badge ${tone}`}>{children}</span>;
}
export function NeuAvatar({
  name,
  size = "md",
  "aria-hidden": ariaHidden,
}: {
  name: string;
  size?: "sm" | "md" | "lg";
  "aria-hidden"?: boolean | "true" | "false";
}) {
  return (
    <span
      className={`avatar ${size}`}
      role={ariaHidden ? undefined : "img"}
      aria-label={ariaHidden ? undefined : name}
      aria-hidden={ariaHidden}
    >
      <span aria-hidden="true">
        {name
          .split(" ")
          .map((n) => n[0])
          .slice(0, 2)
          .join("")}
      </span>
    </span>
  );
}
export function NeuProgress({
  value,
  label,
  showValue = true,
}: {
  value: number;
  label: string;
  showValue?: boolean;
}) {
  const safe = Math.min(100, Math.max(0, value));
  return (
    <div className="progress-block">
      <div className="progress-label">
        <span>{label}</span>
        {showValue && <b>{safe}%</b>}
      </div>
      <div
        className="progress-track"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={safe}
        aria-label={label}
      >
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: safe / 100 }}
          transition={{ duration: 0.3 }}
        />
      </div>
    </div>
  );
}
export function StatCard({
  label,
  value,
  suffix = "",
  icon,
  detail,
}: {
  label: string;
  value: number;
  suffix?: string;
  icon: IconName;
  detail?: string;
}) {
  const reduced = useReducedMotion();
  const [count, setCount] = useState(value);
  const previous = useRef(value);
  useEffect(() => {
    if (reduced) {
      setCount(value);
      return;
    }
    const start = performance.now();
    const from = previous.current;
    let frame = 0;
    const tick = (time: number) => {
      const progress = Math.min((time - start) / 350, 1);
      setCount(Math.round(from + (value - from) * progress));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    previous.current = value;
    return () => cancelAnimationFrame(frame);
  }, [value, reduced]);
  return (
    <NeuCard className="stat-card">
      <div className="stat-top">
        <span>{label}</span>
        <span className="icon-tile small">
          <Icon name={icon} />
        </span>
      </div>
      <strong>
        {count.toLocaleString()}
        {suffix}
      </strong>
      {detail && <small>{detail}</small>}
    </NeuCard>
  );
}
export function SearchBar({
  value,
  onChange,
  placeholder = "Search…",
  label = "Search",
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
}) {
  return (
    <div className="search-bar">
      <Icon name="search" size={18} />
      <input
        aria-label={label}
        placeholder={placeholder}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        type="search"
      />
      {value && (
        <NeuButton
          variant="ghost"
          aria-label="Clear search"
          onClick={() => onChange("")}
          icon="close"
        />
      )}
    </div>
  );
}
export function DatePicker({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <NeuInput
      type="date"
      id={label.replaceAll(" ", "-")}
      label={label}
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}
export function Skeleton({
  className = "",
  label = "Loading",
  ...props
}: HTMLAttributes<HTMLDivElement> & {
  className?: string;
  label?: string;
}) {
  return (
    <div
      className={`skeleton ${className}`}
      role="status"
      aria-label={label}
      {...props}
    >
      <span className="sr-only">{label}</span>
    </div>
  );
}
export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <span className="icon-tile">
        <Icon name="layers" size={28} />
      </span>
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  );
}
export function ErrorState({
  title = "We couldn’t load this view",
  description = "Please try again in a moment.",
  onRetry,
}: {
  title?: string;
  description?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="empty-state" role="alert">
      <Icon name="error" size={32} />
      <h3>{title}</h3>
      <p>{description}</p>
      {onRetry && <NeuButton onClick={onRetry}>Try again</NeuButton>}
    </div>
  );
}
export function ThemeToggle() {
  const theme = useTheme();
  const setTheme = useUI((s) => s.setTheme);
  return (
    <NeuButton
      variant="icon"
      icon={theme === "dark" ? "sun" : "moon"}
      title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
    />
  );
}
