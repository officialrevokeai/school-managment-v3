import { useEffect, useState } from "react";
import {
  Link,
  NavLink,
  Outlet,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import {
  NeuAvatar,
  NeuBadge,
  NeuButton,
  NeuSelect,
  SearchBar,
  Skeleton,
  ThemeToggle,
  ErrorState,
} from "../ui/primitives";
import { NeuDrawer, NeuModal } from "../ui/overlays";
import { Icon } from "../ui/Icon";
import { useAuth } from "../../store/auth";
import { useUI } from "../../store/ui";
import { getRepository } from "../../services";
import { homeFor, roleLabels } from "../../lib/permissions";
import { useAccess } from "../../hooks/useAccess";
import { useAdminList } from "../../hooks/useAdmin";
import { useIdleSession } from "../../hooks/useIdleSession";
import { getNavigation, moduleReady } from "../../lib/adminNavigation";
import { queryClient, queryKeys } from "../../lib/query";
import { useDebounce } from "../../hooks/useDebounce";
import { config } from "../../lib/config";
import type { Notification } from "../../types/domain";
import { devTracker } from "../../lib/devTracker";

export default function AppShell() {
  devTracker.logRender("AppShell");
  const profile = useAuth((s) => s.profile)!;
  const branchId = useUI((s) => s.branchId);
  const setBranch = useUI((s) => s.setBranch);
  const collapsed = useUI((s) => s.collapsed);
  const toggleSidebar = useUI((s) => s.toggleSidebar);
  const location = useLocation();
  const navigate = useNavigate();
  useEffect(() => {
    if (typeof window !== "undefined") {
      (window as unknown as { __devNavigate?: typeof navigate }).__devNavigate =
        navigate;
    }
  }, [navigate]);
  const [moreOpen, setMoreOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search);
  const effectiveRole =
    profile.role === "master" && location.pathname.startsWith("/owner")
      ? "owner"
      : profile.role;
  const base = homeFor(effectiveRole);
  const schoolSettings = useAdminList(
    "settings",
    { schoolId: profile.schoolId },
    {},
    effectiveRole === "owner",
  );
  const branding = schoolSettings.data?.rows[0];
  useIdleSession(branding?.sessionMinutes ?? 60);
  const logo = useQuery({
    queryKey: ["school-logo", profile.id, branding?.logoPath],
    queryFn: async () =>
      (await getRepository()).storage.getUrl(branding!.logoPath),
    enabled: !!branding?.logoPath,
  });
  const branches = useQuery({
    queryKey: queryKeys.branches(profile.id),
    queryFn: async () => (await getRepository()).branches.list(),
  });
  const assigned = branches.data ?? [];
  const activeBranch =
    assigned.find((branch) => branch.id === branchId) ?? assigned[0];
  const activeId = activeBranch?.id ?? branchId ?? "";
  useEffect(() => {
    if (activeId && branchId !== activeId) setBranch(activeId);
  }, [activeId, branchId, setBranch]);
  const userInitials = profile.name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("");
  const key = queryKeys.notifications(profile.id, activeId);
  const notifications = useQuery({
    queryKey: key,
    queryFn: async () => (await getRepository()).notifications.list(activeId),
    enabled: !!activeId,
  });
  useEffect(() => {
    if (!activeId) return;
    let active = true;
    let cleanup: (() => void) | undefined;
    void getRepository()
      .then((repository) => {
        if (active)
          cleanup = repository.notifications.subscribe(activeId, () => {
            void queryClient.invalidateQueries({
              queryKey: queryKeys.notifications(profile.id, activeId),
            });
          });
      })
      .catch(() => undefined);
    return () => {
      active = false;
      cleanup?.();
    };
  }, [activeId, profile.id]);
  const markRead = useMutation({
    mutationFn: async (id: string) =>
      (await getRepository()).notifications.markRead(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: key });
      const previous = queryClient.getQueryData<Notification[]>(key);
      queryClient.setQueryData<Notification[]>(key, (old) =>
        old?.map((n) => (n.id === id ? { ...n, read: true } : n)),
      );
      return { previous, key };
    },
    onError: (_error, _id, context) => {
      if (context) queryClient.setQueryData(context.key, context.previous);
      toast.error("Could not update this notification. Please try again.");
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: key }),
  });
  const unread = notifications.data?.filter((item) => !item.read).length ?? 0;
  const showHighlights = useUI((s) => s.inAppUpdates);
  const access = useAccess();
  const availableNav = getNavigation(effectiveRole).filter((item) =>
    access.can(item.permission),
  );
  const activeLabel =
    availableNav.find((item) =>
      item.path
        ? location.pathname === `${base}${item.path}`
        : location.pathname === base,
    )?.label ?? "Workspace";
  const prefetch = (path: string) => {
    if (path === "/directory")
      void import("../../features/workspace/Directory");
    if (path === "/preferences")
      void import("../../features/system/Preferences");
  };
  const navContent = (
    <>
      {(["Workspace", "Management", "System"] as const).map((section) => (
        <div className="nav-section" key={section}>
          <div className="nav-section-label">{section}</div>
          {availableNav
            .filter((item) => item.section === section)
            .map((item) =>
              !moduleReady(profile.role, item.phase) ? (
                <div
                  className="nav-item unavailable"
                  key={item.label}
                  aria-disabled="true"
                  title={`Available in Phase ${item.phase}`}
                >
                  <Icon name={item.icon} />
                  <span>{item.label}</span>
                  <Icon name="lock" size={13} />
                </div>
              ) : (
                <NavLink
                  key={item.label}
                  aria-label={item.label}
                  title={item.label}
                  to={`${base}${item.path}`}
                  end={!item.path}
                  onClick={() => setMoreOpen(false)}
                  onMouseEnter={() => prefetch(item.path)}
                  onFocus={() => prefetch(item.path)}
                  className={({ isActive }) =>
                    `nav-item ${isActive ? "active" : ""}`
                  }
                >
                  <Icon name={item.icon} />
                  <span>{item.label}</span>
                  {item.label === "Overview" && (
                    <span className="nav-active-dot" />
                  )}
                </NavLink>
              ),
            )}
        </div>
      ))}
    </>
  );
  const signOut = async () => {
    try {
      const repository = await getRepository();
      await repository.auth.signOut();
      useAuth.getState().setExpired(false);
      useAuth.getState().setProfile(null);
      queryClient.clear();
      navigate(profile.role === "master" ? "/sys-master" : "/login", {
        replace: true,
      });
    } catch {
      toast.error("Sign out failed. Please try again.");
    }
  };
  return (
    <div className={`app-shell ${collapsed ? "sidebar-collapsed" : ""}`}>
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      <aside className="sidebar">
        <div className="brand-container">
          <Link className="brand" to={base}>
            <span className="brand-mark">
              <Icon name="graduation" size={27} />
            </span>
            <span>campus</span>
          </Link>
          <button
            type="button"
            className="brand-dot brand-dot-button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              navigate("/sys-master/workspace");
            }}
            title="Master Console"
            aria-label="Master Console"
          >
            .
          </button>
        </div>
        <div className="school-identity">
          <span className="school-monogram">
            {logo.data ? (
              <img
                src={logo.data}
                width="28"
                height="28"
                loading="lazy"
                alt="School logo"
              />
            ) : (
              "G"
            )}
          </span>
          <div>
            <b>
              {profile.role === "master"
                ? "Campus Platform"
                : (branding?.name ??
                  (config.mock ? "Greenwood School" : "Your school"))}
            </b>
            <small>School Management v3.0</small>
          </div>
          <Icon name="shield" size={16} />
        </div>
        <nav aria-label="Main navigation">{navContent}</nav>
        <div className="sidebar-bottom">
          <div className="help-card">
            <span className="icon-tile small">
              <Icon name="help" />
            </span>
            <b>A little help?</b>
            <p>
              Your school workspace,
              <br />
              made a little simpler.
            </p>
            <NeuButton variant="ghost" onClick={() => setHelpOpen(true)}>
              Help & getting started
              <Icon name="arrow-up-right" size={15} />
            </NeuButton>
          </div>
          <button
            className="sidebar-account"
            onClick={() => setProfileOpen(true)}
          >
            <NeuAvatar name={profile.name} size="sm" />
            <span>
              <b>{profile.name}</b>
              <small>{roleLabels[profile.role]}</small>
            </span>
            <Icon name="more" size={18} />
          </button>
        </div>
        <NeuButton
          className="sidebar-collapse"
          variant="icon"
          icon={collapsed ? "right" : "collapse"}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          onClick={toggleSidebar}
        />
      </aside>
      <div className="app-main">
        <header className="top-header">
          <div className="header-branch">
            <span className="icon-tile small">
              <Icon name="building" />
            </span>
            {profile.role === "master" ? (
              <b className="platform-label">Platform administration</b>
            ) : branches.isPending ? (
              <Skeleton className="branch-skeleton" />
            ) : branches.isError ? (
              <button
                className="text-button"
                onClick={() => void branches.refetch()}
              >
                Retry campuses
              </button>
            ) : assigned.length ? (
              <NeuSelect
                aria-label="Active campus"
                value={activeId}
                onChange={(event) => {
                  setBranch(event.target.value);
                  toast.success("Campus switched");
                }}
              >
                {assigned.map((branch) => (
                  <option key={branch.id} value={branch.id}>
                    {branch.short_name}
                  </option>
                ))}
              </NeuSelect>
            ) : (
              <span>No campus assigned</span>
            )}
            <NeuBadge>{config.mock ? "Demo" : "Live"}</NeuBadge>
            {profile.role === "master" && (
              <Link
                to="/sys-master/workspace"
                style={{ textDecoration: "none" }}
                title="Switch to SaaS Creator Console"
              >
                <NeuBadge tone="accent">
                  <Icon name="shield" size={13} /> Master Console
                </NeuBadge>
              </Link>
            )}
          </div>
          <div className="header-actions">
            <button
              className="global-search-trigger"
              aria-label="Search your workspace"
              onClick={() => setSearchOpen(true)}
            >
              <Icon name="search" size={18} />
              <span>Search your workspace</span>
              <kbd>⌕</kbd>
            </button>
            <ThemeToggle />
            <div className="notification-trigger">
              <NeuButton
                variant="ghost"
                icon="bell"
                aria-label={`Notifications, ${unread} unread`}
                onClick={() => setNotificationOpen(true)}
              />
              {unread > 0 && showHighlights && <span />}
            </div>
            <span className="header-divider" />
            <button
              className="header-profile"
              aria-label={`${userInitials} - Profile menu for ${profile.name}`}
              onClick={() => setProfileOpen(true)}
            >
              <NeuAvatar name={profile.name} size="sm" aria-hidden="true" />
              <Icon name="down" size={14} aria-hidden="true" />
            </button>
          </div>
        </header>
        <main id="main-content" className="main-content" tabIndex={-1}>
          <div className="breadcrumb">
            <span>
              <Link to={base}>Workspace</Link>
              <Icon name="right" size={13} />
              {activeLabel}
            </span>
            <NeuBadge>
              <Icon name="shield" size={12} />
              {roleLabels[profile.role]}
            </NeuBadge>
          </div>
          {branches.isError && (
            <div className="inline-error" role="alert">
              Campus access could not be loaded.{" "}
              <button
                className="text-button"
                onClick={() => void branches.refetch()}
              >
                Try again
              </button>
            </div>
          )}
          <AnimatePresence initial={false} mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.15 }}
            >
              <Outlet context={{ branches: assigned, activeBranch }} />
            </motion.div>
          </AnimatePresence>
          <footer className="workspace-footer">
            <span>
              Campus v3.0 <i /> Smart · Secure · Connected
            </span>
            <span>
              <span className="status-dot" />{" "}
              {config.mock ? "Demo workspace" : "Secure workspace"}
            </span>
          </footer>
        </main>
      </div>
      <nav className="bottom-nav" aria-label="Mobile navigation">
        {[
          { label: "Home", path: "", icon: "grid" },
          { label: "Directory", path: "/directory", icon: "layers" },
          { label: "You", path: "/preferences", icon: "user" },
        ].map((item) => (
          <NavLink
            key={item.label}
            to={`${base}${item.path}`}
            end={!item.path}
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            <Icon name={item.icon as "grid" | "layers" | "user"} />
            <span>{item.label}</span>
          </NavLink>
        ))}
        <button onClick={() => setMoreOpen(true)}>
          <Icon name="menu" />
          <span>More</span>
        </button>
      </nav>
      <NeuDrawer
        open={moreOpen}
        onClose={() => setMoreOpen(false)}
        title="Your workspace"
      >
        <nav className="drawer-nav" aria-label="More navigation">
          {navContent}
        </nav>
        <NeuButton
          icon="help"
          onClick={() => {
            setMoreOpen(false);
            setHelpOpen(true);
          }}
        >
          Help & getting started
        </NeuButton>
        <div className="mobile-account-actions">
          <NeuAvatar name={profile.name} />
          <div>
            <b>{profile.name}</b>
            <small>{roleLabels[profile.role]}</small>
          </div>
        </div>
        <NeuButton
          icon="logout"
          onClick={() => {
            setMoreOpen(false);
            void signOut();
          }}
        >
          Sign out securely
        </NeuButton>
      </NeuDrawer>
      <NeuDrawer
        open={notificationOpen}
        onClose={() => setNotificationOpen(false)}
        title="Notifications"
        description={`${unread} unread · ${activeBranch?.short_name ?? "Your campus"}`}
      >
        <div className="notification-list">
          {notifications.isPending ? (
            <Skeleton className="card-skeleton" />
          ) : notifications.isError ? (
            <ErrorState
              description="Could not load notifications."
              onRetry={() => void notifications.refetch()}
            />
          ) : notifications.data?.length ? (
            notifications.data.map((item) => (
              <article
                className={item.read ? "notification read" : "notification"}
                key={item.id}
              >
                <span className="icon-tile small">
                  <Icon name={item.read ? "check-all" : "bell"} />
                </span>
                <div>
                  <b>{item.title}</b>
                  <p>{item.body}</p>
                  <small>
                    {formatDistanceToNow(new Date(item.created_at), {
                      addSuffix: true,
                    })}
                  </small>
                  {!item.read && (
                    <button
                      className="text-button"
                      onClick={() => markRead.mutate(item.id)}
                    >
                      Mark as read
                    </button>
                  )}
                </div>
              </article>
            ))
          ) : (
            <p>You’re all caught up.</p>
          )}
        </div>
      </NeuDrawer>
      <NeuModal
        open={profileOpen}
        onClose={() => setProfileOpen(false)}
        title="Your account"
      >
        <div className="profile-summary">
          <NeuAvatar name={profile.name} size="lg" />
          <h3>{profile.name}</h3>
          <p>{profile.email}</p>
          <NeuBadge>{roleLabels[profile.role]}</NeuBadge>
        </div>
        <div className="profile-menu">
          <NeuButton
            icon="settings"
            onClick={() => {
              setProfileOpen(false);
              navigate(`${base}/preferences`);
            }}
          >
            My preferences
            <Icon name="right" size={16} />
          </NeuButton>
          <NeuButton icon="logout" onClick={() => void signOut()}>
            Sign out securely
          </NeuButton>
        </div>
      </NeuModal>
      <NeuModal
        open={searchOpen}
        onClose={() => {
          setSearchOpen(false);
          setSearch("");
        }}
        title="Find your way"
      >
        <SearchBar
          value={search}
          onChange={setSearch}
          placeholder="Search pages and tools…"
          label="Search workspace pages"
        />
        <div className="search-results">
          {availableNav
            .filter(
              (item) =>
                moduleReady(profile.role, item.phase) &&
                item.label
                  .toLowerCase()
                  .includes(debouncedSearch.toLowerCase()),
            )
            .map((item) => (
              <Link
                key={item.label}
                to={`${base}${item.path}`}
                onClick={() => {
                  setSearchOpen(false);
                  setSearch("");
                }}
              >
                <Icon name={item.icon} />
                <span>{item.label}</span>
                <Icon name="arrow-up-right" size={16} />
              </Link>
            ))}
          {!availableNav.some(
            (item) =>
              moduleReady(profile.role, item.phase) &&
              item.label.toLowerCase().includes(debouncedSearch.toLowerCase()),
          ) && <p>No pages found. Try “Overview” or “Preferences”.</p>}
        </div>
      </NeuModal>
      <NeuModal
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        title="Make yourself at home"
        description="A quick guide to your school workspace."
      >
        <ol className="help-steps">
          <li>
            <b>Choose your campus</b>
            <p>
              Use the campus selector at the top. You’ll see only campuses
              assigned to your account.
            </p>
          </li>
          <li>
            <b>Find your tools</b>
            <p>
              The workspace directory explains which modules your role can
              access and their delivery phase.
            </p>
          </li>
          <li>
            <b>Make it yours</b>
            <p>
              Choose your theme and local notification preferences in My
              preferences.
            </p>
          </li>
        </ol>
        <p className="muted">
          For account changes, contact your school administrator.
        </p>
      </NeuModal>
    </div>
  );
}
