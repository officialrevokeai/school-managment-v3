import { Icon } from "../ui/Icon";
export function CampusIllustration({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={`campus-illustration ${compact ? "compact" : ""}`}
      aria-hidden="true"
    >
      <div className="orbit orbit-one" />
      <div className="orbit orbit-two" />
      <div className="floating-tile tile-book">
        <Icon name="book" size={30} />
      </div>
      <div className="floating-tile tile-community">
        <Icon name="users" size={26} />
      </div>
      <div className="floating-tile tile-message">
        <Icon name="message" size={24} />
        <span className="online-dot" />
      </div>
      <div className="campus-platform">
        <div className="campus-building">
          <div className="building-roof">
            <Icon name="graduation" size={42} />
          </div>
          <div className="building-clock">
            <span />
          </div>
          <div className="building-label">CAMPUS</div>
          <div className="building-windows">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <i key={n} />
            ))}
          </div>
          <div className="building-door" />
        </div>
        <div className="campus-tree tree-left">
          <i />
          <span />
        </div>
        <div className="campus-tree tree-right">
          <i />
          <span />
        </div>
        <div className="campus-path" />
      </div>
      <div className="illustration-caption">
        <span className="status-dot" /> Everyone belongs here.
      </div>
    </div>
  );
}
