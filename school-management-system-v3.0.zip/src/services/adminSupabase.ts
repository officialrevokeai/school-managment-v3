import { z } from "zod";
import { client } from "./supabase";
import type { AdminRepository } from "../types/admin";
import { parseRecord, summarySchema } from "../types/admin";
import type { Json } from "../types/database";
const json = (value: unknown): Json =>
  JSON.parse(JSON.stringify(value)) as Json;
export const adminSupabaseRepository: AdminRepository = {
  async summary(scope) {
    const { data, error } = await client.rpc("admin_summary", {
      p_scope: json(scope),
    });
    if (error) throw error;
    return summarySchema.parse(data);
  },
  async list(resource, scope, options = {}) {
    const { data, error } = await client.rpc("admin_list", {
      p_resource: resource,
      p_scope: json(scope),
      p_options: json(options),
    });
    if (error) throw error;
    const page = z
      .object({ rows: z.array(z.unknown()), total: z.number() })
      .parse(data);
    return {
      rows: page.rows.map((value) => parseRecord(resource, value)),
      total: page.total,
    };
  },
  async save(resource, record) {
    const { data, error } = await client.rpc("admin_save", {
      p_resource: resource,
      p_record: json(record),
    });
    if (error) throw error;
    return parseRecord(resource, data);
  },
  async remove(resource, id, scope, version) {
    const { error } = await client.rpc("admin_delete", {
      p_resource: resource,
      p_id: id,
      p_scope: json(scope),
      p_version: version,
    });
    if (error) throw error;
  },
  async provisionSchool(input) {
    const { data, error } = await client.functions.invoke("provision-school", {
      body: input,
    });
    if (error) throw error;
    const result = z
      .object({
        school: z.unknown(),
        email: z.string().email(),
        password: z.string(),
      })
      .parse(data);
    return { ...result, school: parseRecord("schools", result.school) };
  },
};
