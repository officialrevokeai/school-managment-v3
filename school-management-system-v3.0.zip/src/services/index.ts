import { config } from "../lib/config";
import type { Repository } from "./contracts";
let adapter: Promise<Repository> | undefined;
export function getRepository(): Promise<Repository> {
  adapter ??= config.mock
    ? import("../mocks/adapter").then((m) => m.mockRepository)
    : import("./supabase").then((m) => m.supabaseRepository);
  return adapter;
}
