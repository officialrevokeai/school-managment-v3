import { config } from "../lib/config";
import { z } from "zod";
import {
  contextSchema,
  flowSchema,
  type FlowContext,
  type FlowPage,
  type FlowRecord,
  type FlowScope,
  type ModuleKey,
} from "../features/school/model";
export interface WorkflowRepository {
  context(branchId: string): Promise<FlowContext>;
  list(module: ModuleKey | "all", scope: FlowScope): Promise<FlowPage>;
  save(record: FlowRecord): Promise<FlowRecord>;
  remove(record: FlowRecord): Promise<void>;
  subscribe(callback: () => void): () => void;
}
let repository: Promise<WorkflowRepository> | undefined;
export function getWorkflows(): Promise<WorkflowRepository> {
  repository ??= config.mock
    ? import("../mocks/workflows").then((m) => m.mockWorkflows)
    : createLive();
  return repository;
}
async function createLive(): Promise<WorkflowRepository> {
  const { client } = await import("./supabase");
  const json = (value: unknown) =>
    JSON.parse(JSON.stringify(value)) as import("../types/database").Json;
  return {
    async context(branchId) {
      const { data, error } = await client.rpc("workflow_context", {
        p_branch: branchId,
      });
      if (error) throw error;
      return contextSchema.parse(data);
    },
    async list(module, scope) {
      const { data, error } = await client.rpc("workflow_list", {
        p_module: module,
        p_scope: json(scope),
      });
      if (error) throw error;
      return z
        .object({
          rows: z.array(flowSchema),
          total: z.number(),
          counts: z.record(z.string(), z.number()),
        })
        .parse(data);
    },
    async save(record) {
      const { data, error } = await client.rpc("workflow_save", {
        p_record: json(record),
      });
      if (error) throw error;
      return flowSchema.parse(data);
    },
    async remove(record) {
      const { error } = await client.rpc("workflow_remove", {
        p_id: record.id,
        p_version: record.version,
      });
      if (error) throw error;
    },
    subscribe(callback) {
      const channel = client
        .channel(`workflows-${crypto.randomUUID()}`)
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "school_workflows" },
          callback,
        )
        .subscribe();
      return () => {
        void client.removeChannel(channel);
      };
    },
  };
}
