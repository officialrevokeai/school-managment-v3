import { createClient } from "@supabase/supabase-js";
import type { Database } from "../types/database";
import { roles, type Profile } from "../types/domain";
import type { Repository } from "./contracts";
import { config } from "../lib/config";
const fallbackUrl = "https://oqsvedpkqgajjrnxbehz.supabase.co";
const url =
  (import.meta.env.VITE_SUPABASE_URL as string | undefined) || fallbackUrl;
const key =
  ((import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
    import.meta.env.VITE_SUPABASE_ANON_KEY) as string | undefined) ||
  (config.mock ? "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e30.target" : undefined);
if (!url || !key)
  throw new Error(
    "Supabase is not configured. Set the URL and publishable key in .env.local, or enable VITE_USE_MOCK=true.",
  );
const storageKey = "campus.auth.remember";
// Session-only mode never writes access tokens to persistent storage.
const authStorage = {
  getItem: (name: string) =>
    localStorage.getItem(storageKey) === "true"
      ? localStorage.getItem(name)
      : sessionStorage.getItem(name),
  setItem: (name: string, value: string) => {
    (localStorage.getItem(storageKey) === "true"
      ? localStorage
      : sessionStorage
    ).setItem(name, value);
  },
  removeItem: (name: string) => {
    localStorage.removeItem(name);
    sessionStorage.removeItem(name);
  },
};
export const client = createClient<Database>(url, key, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: authStorage,
  },
});
async function getProfile(): Promise<Profile | null> {
  const { data: sessionData, error: sessionError } =
    await client.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) return null;
  const {
    data: { user },
    error: userError,
  } = await client.auth.getUser();
  if (userError) throw userError;
  if (!user) return null;
  const { data, error } = await client
    .from("profiles")
    .select("id,school_id,name,email,role,branch_ids,policy_id")
    .eq("id", user.id)
    .single();
  if (error) throw error;
  const role = roles.find((r) => r === data.role);
  // app_metadata is provisioned by a trusted administrator; user_metadata is never authorization input.
  if (!role || user.app_metadata.role !== role)
    throw new Error(
      "Your school access is not provisioned. Contact your school administrator.",
    );
  return {
    id: data.id,
    schoolId: data.school_id ?? "",
    name: data.name,
    email: data.email,
    role,
    branchIds: data.branch_ids,
    policyId: data.policy_id,
  };
}
export const supabaseRepository: Repository = {
  auth: {
    getProfile,
    async signIn({ identifier, password, remember, master }) {
      if (!identifier.includes("@"))
        throw new Error(
          "Please use your school email address when signing in to the live service.",
        );
      localStorage.setItem(storageKey, String(remember));
      const { error } = await client.auth.signInWithPassword({
        email: identifier,
        password,
      });
      if (error) throw error;
      try {
        const profile = await getProfile();
        if (
          !profile ||
          (master && profile.role !== "master")
        )
          throw new Error("This account cannot access this sign-in page.");
        return profile;
      } catch (error) {
        await client.auth.signOut();
        throw error;
      }
    },
    async verifyMfa(code: string) {
      const { data: factors, error: factorsError } = await client.auth.mfa.listFactors();
      if (factorsError) throw factorsError;
      const totpFactor =
        factors?.totp?.find((f) => f.status === "verified") || factors?.totp?.[0];
      if (totpFactor) {
        const { error: challengeError } = await client.auth.mfa.challengeAndVerify({
          factorId: totpFactor.id,
          code,
        });
        if (challengeError) throw challengeError;
      }
    },
    async signOut() {
      const { error } = await client.auth.signOut();
      if (error) throw error;
    },
    async resetPassword(email) {
      const { error } = await client.auth.resetPasswordForEmail(email, {
        redirectTo: `${config.appUrl}/reset-password`,
      });
      if (error) throw error;
    },
    async updatePassword(password) {
      const { error } = await client.auth.updateUser({ password });
      if (error) throw error;
    },
    onChange(callback) {
      let active = true;
      const timers = new Set<ReturnType<typeof setTimeout>>();
      const {
        data: { subscription },
      } = client.auth.onAuthStateChange((event) => {
        if (event === "SIGNED_OUT") callback(null);
        if (
          event === "SIGNED_IN" ||
          event === "USER_UPDATED" ||
          event === "TOKEN_REFRESHED"
        ) {
          // Keep Supabase calls outside the auth callback to avoid its session lock.
          const timer = setTimeout(() => {
            timers.delete(timer);
            void getProfile()
              .then((profile) => {
                if (active) callback(profile);
              })
              .catch(() => {
                if (active) callback(null);
              });
          }, 0);
          timers.add(timer);
        }
      });
      return () => {
        active = false;
        timers.forEach(clearTimeout);
        subscription.unsubscribe();
      };
    },
  },
  branches: {
    async list() {
      const { data, error } = await client
        .from("branches")
        .select("id,school_id,name,city,short_name")
        .order("name");
      if (error) throw error;
      return data;
    },
  },
  notifications: {
    async list(branchId) {
      const { data, error } = await client
        .from("notifications")
        .select("id,user_id,branch_id,title,body,created_at,read")
        .or(`branch_id.eq.${branchId},branch_id.is.null`)
        .order("created_at", { ascending: false })
        .range(0, 49);
      if (error) throw error;
      return data;
    },
    async markRead(id) {
      const { error } = await client
        .from("notifications")
        .update({ read: true })
        .eq("id", id);
      if (error) throw error;
    },
    subscribe(_branchId, callback) {
      const channel = client
        .channel("my-notifications")
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "notifications" },
          callback,
        )
        .subscribe();
      return () => {
        void client.removeChannel(channel);
      };
    },
  },
  storage: {
    async getUrl(path) {
      const { data, error } = await client.storage
        .from("school-files")
        .createSignedUrl(path, 3600);
      if (error) throw error;
      return data.signedUrl;
    },
    async upload(file, branchId) {
      const profile = await getProfile();
      if (!profile) throw new Error("Sign in to upload files.");
      const path = `${profile.schoolId}/${branchId}/${profile.id}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error } = await client.storage
        .from("school-files")
        .upload(path, file, { upsert: false });
      if (error) throw error;
      return path;
    },
  },
};
