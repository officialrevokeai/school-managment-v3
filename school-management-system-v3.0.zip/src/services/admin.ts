import { config } from "../lib/config";
import type { AdminRepository } from "../types/admin";
let repository: Promise<AdminRepository> | undefined;
export function getAdminRepository(): Promise<AdminRepository> {
  repository ??= config.mock
    ? import("../mocks/adminAdapter").then((m) => m.mockAdminRepository)
    : import("./adminSupabase").then((m) => m.adminSupabaseRepository);
  return repository;
}
