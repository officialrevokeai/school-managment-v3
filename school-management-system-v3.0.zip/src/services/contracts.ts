import type {
  Branch,
  Notification,
  Profile,
  SignInInput,
  Unsubscribe,
} from "../types/domain";
export interface Repository {
  auth: {
    getProfile(): Promise<Profile | null>;
    signIn(input: SignInInput): Promise<Profile>;
    verifyMfa?(code: string): Promise<void>;
    signOut(): Promise<void>;
    resetPassword(email: string): Promise<void>;
    updatePassword(password: string): Promise<void>;
    onChange(callback: (profile: Profile | null) => void): Unsubscribe;
  };
  branches: { list(): Promise<Branch[]> };
  notifications: {
    list(branchId: string): Promise<Notification[]>;
    markRead(id: string): Promise<void>;
    subscribe(branchId: string, callback: () => void): Unsubscribe;
  };
  storage: {
    upload(file: File, branchId: string): Promise<string>;
    getUrl(path: string): Promise<string>;
  };
}
