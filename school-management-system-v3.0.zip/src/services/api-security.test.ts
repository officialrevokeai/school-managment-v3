import { describe, it, expect, beforeAll } from 'vitest';
import { createClient } from '@supabase/supabase-js';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const TARGET_REF = 'oqsvedpkqgajjrnxbehz';
const SUPABASE_URL = `https://${TARGET_REF}.supabase.co`;

function loadEnv() {
  const localEnvFile = resolve(process.cwd(), '.env.local');
  const testEnvFile = resolve(process.cwd(), '.env.test.local');
  const env: Record<string, string> = {};

  for (const file of [localEnvFile, testEnvFile]) {
    if (existsSync(file)) {
      const content = readFileSync(file, 'utf8');
      for (const line of content.split('\n')) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;
        const eqIdx = trimmed.indexOf('=');
        if (eqIdx !== -1) {
          env[trimmed.slice(0, eqIdx).trim()] = trimmed.slice(eqIdx + 1).trim();
        }
      }
    }
  }
  return env;
}

const env = loadEnv();
const PUBLISHABLE_KEY = env.VITE_SUPABASE_PUBLISHABLE_KEY || '';
const isLiveConfigured = env.QA_MODE === 'true' && Boolean(PUBLISHABLE_KEY);
const QA_MASTER_EMAIL = env.QA_MASTER_EMAIL || '';
const QA_MASTER_PASSWORD = env.QA_MASTER_PASSWORD || '';
const QA_OWNER_EMAIL = env.QA_OWNER_EMAIL || '';
const QA_OWNER_PASSWORD = env.QA_OWNER_PASSWORD || '';
const QA_PRINCIPAL_NORTH_EMAIL = env.QA_PRINCIPAL_NORTH_EMAIL || '';
const QA_PRINCIPAL_NORTH_PASSWORD = env.QA_PRINCIPAL_NORTH_PASSWORD || '';
const QA_TEACHER_1_EMAIL = env.QA_TEACHER_1_EMAIL || '';
const QA_TEACHER_1_PASSWORD = env.QA_TEACHER_1_PASSWORD || '';
const QA_SCHOOL_A_ID = env.QA_SCHOOL_A_ID || '';
const QA_SCHOOL_B_ID = env.QA_SCHOOL_B_ID || '';
const QA_BRANCH_1_ID = env.QA_BRANCH_1_ID || '';
const QA_BRANCH_2_ID = env.QA_BRANCH_2_ID || '';
const QA_FEE_INVOICE_ID = env.QA_FEE_INVOICE_ID || '';

describe.skipIf(!isLiveConfigured)('Phase T4: API Security Testing (PostgREST, RPC, Edge Functions, Auth, Storage)', () => {
  let masterToken: string;
  let ownerToken: string;
  let principalToken: string;
  let teacherToken: string;

  beforeAll(async () => {
    expect(env.QA_MODE).toBe('true');
    expect(PUBLISHABLE_KEY).toBeTruthy();

    const authClient = createClient(SUPABASE_URL, PUBLISHABLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    async function signInWithRetry(email: string, pass: string): Promise<string> {
      for (let attempt = 1; attempt <= 4; attempt++) {
        try {
          const res = await authClient.auth.signInWithPassword({
            email,
            password: pass,
          });
          if (res.data?.session?.access_token) {
            return res.data.session.access_token;
          }
          if (attempt === 4) throw res.error || new Error('Auth error');
        } catch (err) {
          if (attempt === 4) throw err;
          await new Promise((r) => setTimeout(r, 1500 * attempt));
        }
      }
      throw new Error(`Failed to sign in ${email}`);
    }

    // Obtain real tokens for QA roles
    masterToken = await signInWithRetry(QA_MASTER_EMAIL, QA_MASTER_PASSWORD);
    ownerToken = await signInWithRetry(QA_OWNER_EMAIL, QA_OWNER_PASSWORD);
    principalToken = await signInWithRetry(QA_PRINCIPAL_NORTH_EMAIL, QA_PRINCIPAL_NORTH_PASSWORD);
    teacherToken = await signInWithRetry(QA_TEACHER_1_EMAIL, QA_TEACHER_1_PASSWORD);
  });

  describe('1. Edge Functions Authentication & JWT Verification', () => {
    const protectedFunctions = [
      'manage-user',
      'set-role-permissions',
      'export-data',
      'create-payment-order',
      'school-whatsapp',
      'create-school',
      'school-admin',
      'record-school-payment',
      'apply-role-template',
    ];

    it('All protected Edge Functions reject calls with no token (401)', async () => {
      for (const fn of protectedFunctions) {
        const res = await fetch(`${SUPABASE_URL}/functions/v1/${fn}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            apikey: PUBLISHABLE_KEY,
          },
          body: JSON.stringify({}),
        });
        expect([401, 403]).toContain(res.status);
      }
    });

    it('Edge Functions reject forged, tampered, and alg=none JWTs (401)', async () => {
      const forgedTokens = [
        'eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiIxMjM0NTYiLCJyb2xlIjoiYXV0aGVudGljYXRlZCIsImFwcF9tZXRhZGF0YSI6eyyb2xlIjoibWFzdGVyIn19.', // alg=none
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTYiLCJleHAiOjE1MTYyMzkwMjJ9.invalidSignatureHere', // invalid sig
        'Bearer invalid-garbage-token-string',
      ];

      for (const token of forgedTokens) {
        const res = await fetch(`${SUPABASE_URL}/functions/v1/manage-user`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            apikey: PUBLISHABLE_KEY,
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ action: 'create' }),
        });
        expect([401, 403]).toContain(res.status);
      }
    });

    it('Health function returns 200 with uniform payload', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/health`, {
        headers: { apikey: PUBLISHABLE_KEY },
      });
      expect(res.status).toBe(200);
      const data = await res.json();
      expect(data.ok).toBe(true);
    });
  });

  describe('2. Edge Function RBAC & Privilege Escalation Defenses', () => {
    it('Teacher cannot call manage-user (403 Forbidden)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/manage-user`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${teacherToken}`,
        },
        body: JSON.stringify({
          action: 'create',
          schoolId: QA_SCHOOL_A_ID,
          name: 'Unauthorized User',
          email: 'unauth@qatest.internal',
          role: 'student',
          branchIds: [QA_BRANCH_1_ID],
          password: 'Password123!@#',
        }),
      });
      expect(res.status).toBe(403);
    });

    it('Principal cannot create an Owner account (403 Forbidden)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/manage-user`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${principalToken}`,
        },
        body: JSON.stringify({
          action: 'create',
          schoolId: QA_SCHOOL_A_ID,
          name: 'Escalated Owner',
          email: 'escalate-owner@qatest.internal',
          role: 'owner',
          branchIds: [QA_BRANCH_1_ID],
          password: 'Password123!@#',
        }),
      });
      expect(res.status).toBe(403);
    });

    it('Principal cannot create users for other schools (403 Cross-Tenant Block)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/manage-user`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${principalToken}`,
        },
        body: JSON.stringify({
          action: 'create',
          schoolId: QA_SCHOOL_B_ID, // School B
          name: 'Cross School Student',
          email: 'cross-student@qatest.internal',
          role: 'student',
          branchIds: [QA_BRANCH_1_ID],
          password: 'Password123!@#',
        }),
      });
      expect(res.status).toBe(403);
    });

    it('Principal cannot assign campus outside assigned branches (403 Campus Scope Block)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/manage-user`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${principalToken}`, // North campus principal
        },
        body: JSON.stringify({
          action: 'create',
          schoolId: QA_SCHOOL_A_ID,
          name: 'South Student',
          email: 'south-student@qatest.internal',
          role: 'student',
          branchIds: [QA_BRANCH_2_ID], // South campus
          password: 'Password123!@#',
        }),
      });
      expect(res.status).toBe(403);
    });

    it('Owner cannot call platform-only create-school (403 Forbidden)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/create-school`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${ownerToken}`,
        },
        body: JSON.stringify({
          name: 'Illicit Academy',
          code: 'ILLICIT-01',
          ownerEmail: 'illicit@qatest.internal',
          ownerPassword: 'Password123!@#',
        }),
      });
      expect(res.status).toBe(403);
    });

    it('Master can access platform administrative functions (not 403 Forbidden)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/school-admin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${masterToken}`,
        },
        body: JSON.stringify({
          schoolId: QA_SCHOOL_A_ID,
          action: 'revoke-sessions',
          payload: {},
        }),
      });
      // Master is authorized (never 401 or 403)
      expect(res.status).not.toBe(403);
      expect(res.status).not.toBe(401);
    });

    it('Malformed bodies trigger Zod validation error 400 Bad Request', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/manage-user`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${ownerToken}`,
        },
        body: JSON.stringify({
          action: 'create',
          schoolId: 'not-a-uuid',
          email: 'invalid-email',
        }),
      });
      expect([400, 422]).toContain(res.status);
    });
  });

  describe('3. Webhook Signature Verification & Idempotency', () => {
    it('Payment webhook rejects requests missing x-payment-signature (401)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/payment-webhook`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: PUBLISHABLE_KEY,
        },
        body: JSON.stringify({
          event: 'payment.captured',
          orderRef: 'ORD-12345',
          paymentId: 'PAY-12345',
          amount: 5000,
          studentFeeId: QA_FEE_INVOICE_ID,
        }),
      });
      expect([401, 403]).toContain(res.status);
    });

    it('Payment webhook rejects forged signatures (401)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/payment-webhook`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: PUBLISHABLE_KEY,
          'x-payment-signature': 'forged_deadbeef1234567890abcdef',
        },
        body: JSON.stringify({
          event: 'payment.captured',
          orderRef: 'ORD-12345',
          paymentId: 'PAY-12345',
          amount: 5000,
          studentFeeId: QA_FEE_INVOICE_ID,
        }),
      });
      expect([401, 403]).toContain(res.status);
    });
  });

  describe('4. PostgREST Resource Embedding & Query Protection', () => {
    it('PostgREST prevents anon from dumping student profiles via embedding', async () => {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/classes?select=*,class_students(*,profiles(*))`, {
        headers: {
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${PUBLISHABLE_KEY}`,
        },
      });
      // Anon has no SELECT on classes or profiles
      if (res.ok) {
        const data = await res.json();
        expect(data.length).toBe(0);
      } else {
        expect([401, 403]).toContain(res.status);
      }
    });

    it('PostgREST caps or handles page size requests properly', async () => {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/plans?limit=10000`, {
        headers: {
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${PUBLISHABLE_KEY}`,
        },
      });
      expect(res.status).toBe(200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
      expect(data.length).toBeLessThanOrEqual(100);
    });
  });

  describe('5. Auth Hardening & Enumeration Protections', () => {
    it('Public self-signup is disabled or rejected', async () => {
      const client = createClient(SUPABASE_URL, PUBLISHABLE_KEY, {
        auth: { persistSession: false },
      });
      const { data, error } = await client.auth.signUp({
        email: `unauthorized_${Date.now()}@qatest.internal`,
        password: 'Password123!@#$',
      });
      if (!error) {
        expect(data.session).toBeNull();
      } else {
        expect(error).toBeDefined();
      }
    });

    it('Password reset for non-existent email returns success message (anti-enumeration)', async () => {
      const client = createClient(SUPABASE_URL, PUBLISHABLE_KEY, {
        auth: { persistSession: false },
      });
      const { error } = await client.auth.resetPasswordForEmail(`nonexistent_${Date.now()}@example.com`);
      // Standard security behavior: does not leak whether email exists
      expect(error).toBeNull();
    });
  });

  describe('6. Storage Bucket Privacy', () => {
    it('school-files storage bucket rejects unauthenticated public reads (400/404/403)', async () => {
      const res = await fetch(`${SUPABASE_URL}/storage/v1/object/public/school-files/test.pdf`);
      // Bucket is private (public = false)
      expect([400, 403, 404]).toContain(res.status);
    });

    it('Storage rejects directory traversal path attacks', async () => {
      const res = await fetch(`${SUPABASE_URL}/storage/v1/object/public/school-files/../../etc/passwd`);
      expect([400, 403, 404]).toContain(res.status);
    });
  });

  describe('7. Cloudflare Security Audit Regression Tests', () => {
    it('SEC-002: import-csv rejects unauthorized cross-branch import attempt by principal (403)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/import-csv`, {
        method: 'POST',
        headers: {
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${principalToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          resource: 'students',
          branchId: QA_BRANCH_2_ID, // Principal North attempting to import into Branch South
          csvContent: 'name,email\nHacker Student,hacker@example.com',
        }),
      });
      expect(res.status).toBe(403);
      const data = await res.json();
      expect(data.error).toMatch(/Branch access denied/i);
    });

    it('SEC-003: export-data blocks cross-branch export when branch is unauthorized (403)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/export-data`, {
        method: 'POST',
        headers: {
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${principalToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          resource: 'students',
          branchId: QA_BRANCH_2_ID, // Principal North attempting to export Branch South
        }),
      });
      expect(res.status).toBe(403);
    });

    it('SEC-004: whatsapp-webhook rejects requests missing signature header (401)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/whatsapp-webhook`, {
        method: 'POST',
        headers: {
          apikey: PUBLISHABLE_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ entry: [] }),
      });
      expect(res.status).toBe(401);
    });

    it('SEC-004: whatsapp-webhook rejects forged signature (403)', async () => {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/whatsapp-webhook`, {
        method: 'POST',
        headers: {
          apikey: PUBLISHABLE_KEY,
          'Content-Type': 'application/json',
          'x-hub-signature-256': 'sha256=0000000000000000000000000000000000000000000000000000000000000000',
        },
        body: JSON.stringify({ entry: [] }),
      });
      expect(res.status).toBe(403);
    });

    it('SEC-005: workflow_list RPC runs cleanly without parent_students table error', async () => {
      const client = createClient(SUPABASE_URL, PUBLISHABLE_KEY, {
        auth: { persistSession: false },
      });
      const { data: signInData } = await client.auth.signInWithPassword({
        email: QA_PRINCIPAL_NORTH_EMAIL,
        password: QA_PRINCIPAL_NORTH_PASSWORD,
      });
      expect(signInData.session).toBeDefined();

      const { data, error } = await client.rpc('workflow_list', {
        p_module: 'all',
        p_scope: { branchId: QA_BRANCH_1_ID, page: 0, pageSize: 10 },
      });
      expect(error).toBeNull();
      expect(data).toHaveProperty('rows');
      expect(data).toHaveProperty('total');
    });
  });
});
