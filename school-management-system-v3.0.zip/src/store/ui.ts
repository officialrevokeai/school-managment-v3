import { create } from "zustand";
import { persist } from "zustand/middleware";
export type ThemeChoice = "light" | "dark" | "system";
type UIState = {
  theme: ThemeChoice;
  branchId: string;
  collapsed: boolean;
  emailUpdates: boolean;
  inAppUpdates: boolean;
  setTheme: (theme: ThemeChoice) => void;
  setBranch: (branchId: string) => void;
  toggleSidebar: () => void;
  setPreference: (key: "emailUpdates" | "inAppUpdates", value: boolean) => void;
};
export const useUI = create<UIState>()(
  persist(
    (set) => ({
      theme: "system",
      branchId: "",
      collapsed: false,
      emailUpdates: true,
      inAppUpdates: true,
      setTheme: (theme) => set({ theme }),
      setBranch: (branchId) =>
        set((s) => (s.branchId === branchId ? s : { ...s, branchId })),
      toggleSidebar: () => set((s) => ({ collapsed: !s.collapsed })),
      setPreference: (key, value) => set({ [key]: value }),
    }),
    { name: "campus-ui-v3" },
  ),
);
