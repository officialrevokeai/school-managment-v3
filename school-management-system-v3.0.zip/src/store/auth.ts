import { create } from "zustand";
import type { Profile } from "../types/domain";
import { useUI } from "./ui";

type AuthState = {
  profile: Profile | null;
  initialized: boolean;
  expired: boolean;
  setProfile: (profile: Profile | null) => void;
  setExpired: (expired: boolean) => void;
};

function isSameProfile(a: Profile | null, b: Profile | null): boolean {
  if (a === b) return true;
  if (!a || !b) return false;
  if (a.id !== b.id || a.role !== b.role || a.schoolId !== b.schoolId)
    return false;
  if (a.branchIds?.length !== b.branchIds?.length) return false;
  return (a.branchIds || []).every((id, idx) => id === b.branchIds?.[idx]);
}

export const useAuth = create<AuthState>((set, get) => ({
  profile: null,
  initialized: false,
  expired: false,
  setProfile: (profile) => {
    const current = get();
    if (current.initialized && isSameProfile(current.profile, profile)) {
      return; // Deduplicate: do not re-notify subscribers on identical profile
    }
    if (profile?.branchIds?.[0] && !useUI.getState().branchId) {
      useUI.getState().setBranch(profile.branchIds[0]);
    }
    set({ profile, initialized: true });
  },
  setExpired: (expired) => set({ expired }),
}));
