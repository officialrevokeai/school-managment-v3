import { useEffect, useRef, useState, useCallback } from "react";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { config } from "../lib/config";
import { useAuth } from "../store/auth";
import { useUI } from "../store/ui";

export type ConnectionStatus = "live" | "reconnecting" | "offline";

export interface PresenceUser {
  id: string;
  name: string;
  role: string;
  email: string;
  onlineAt: string;
}

export interface WhatsAppStreamItem {
  id: string;
  recipient: string;
  status: "Queued" | "Sending" | "Sent" | "Delivered" | "Read" | "Failed";
  template: string;
  body: string;
  created_at: string;
}

export interface AuditFeedItem {
  id: string;
  actor: string;
  action: string;
  resource: string;
  created_at: string;
}

export interface SecurityAlertItem {
  id: string;
  severity: "low" | "medium" | "high" | "critical";
  title: string;
  message: string;
  created_at: string;
}

export interface LiveTelemetryMetrics {
  liveAttendancePct: number;
  liveFeeCollection: number;
  newAdmissions: number;
  apiLatencyMs: number;
  errorRatePct: number;
  edgeFailures: number;
}

export interface MonitoringState {
  status: ConnectionStatus;
  metrics: LiveTelemetryMetrics;
  onlineUsers: PresenceUser[];
  whatsappStream: WhatsAppStreamItem[];
  auditFeed: AuditFeedItem[];
  securityAlerts: SecurityAlertItem[];
  lastUpdated: string;
}

const INITIAL_METRICS: LiveTelemetryMetrics = {
  liveAttendancePct: 94.8,
  liveFeeCollection: 184500,
  newAdmissions: 14,
  apiLatencyMs: 42,
  errorRatePct: 0.01,
  edgeFailures: 0,
};

const MOCK_ONLINE_USERS: PresenceUser[] = [
  {
    id: "usr-1",
    name: "R. Sharma",
    role: "principal",
    email: "principal@greenwood.edu",
    onlineAt: "Just now",
  },
  {
    id: "usr-2",
    name: "A. Patel",
    role: "accountant",
    email: "finance@greenwood.edu",
    onlineAt: "2m ago",
  },
  {
    id: "usr-3",
    name: "S. Rao",
    role: "teacher",
    email: "s.rao@greenwood.edu",
    onlineAt: "4m ago",
  },
  {
    id: "usr-4",
    name: "N. Gupta",
    role: "teacher",
    email: "n.gupta@greenwood.edu",
    onlineAt: "7m ago",
  },
];

const MOCK_WHATSAPP: WhatsAppStreamItem[] = [
  {
    id: "wa-1",
    recipient: "+919876543210",
    status: "Delivered",
    template: "attendance_alert",
    body: "Aarav Sharma was marked present today.",
    created_at: new Date(Date.now() - 60000).toISOString(),
  },
  {
    id: "wa-2",
    recipient: "+919811223344",
    status: "Read",
    template: "fee_receipt",
    body: "Fee receipt for term 1 generated.",
    created_at: new Date(Date.now() - 180000).toISOString(),
  },
  {
    id: "wa-3",
    recipient: "+919922334455",
    status: "Sent",
    template: "circular_update",
    body: "Annual sports day schedule published.",
    created_at: new Date(Date.now() - 320000).toISOString(),
  },
  {
    id: "wa-4",
    recipient: "+919833445566",
    status: "Delivered",
    template: "attendance_alert",
    body: "Diya Verma was marked present today.",
    created_at: new Date(Date.now() - 480000).toISOString(),
  },
];

const MOCK_AUDIT: AuditFeedItem[] = [
  {
    id: "aud-1",
    actor: "R. Sharma",
    action: "ATTENDANCE_MARKED",
    resource: "Grade 10-A",
    created_at: new Date(Date.now() - 90000).toISOString(),
  },
  {
    id: "aud-2",
    actor: "A. Patel",
    action: "FEE_COLLECTED",
    resource: "INV-2026-0891",
    created_at: new Date(Date.now() - 210000).toISOString(),
  },
  {
    id: "aud-3",
    actor: "System",
    action: "AUTOMATION_DISPATCH",
    resource: "WhatsApp Worker",
    created_at: new Date(Date.now() - 360000).toISOString(),
  },
  {
    id: "aud-4",
    actor: "R. Sharma",
    action: "USER_INVITED",
    resource: "Faculty Profile",
    created_at: new Date(Date.now() - 600000).toISOString(),
  },
];

const MOCK_ALERTS: SecurityAlertItem[] = [
  {
    id: "alt-1",
    severity: "low",
    title: "MFA Enrollment Active",
    message: "Owner TOTP MFA verified successfully.",
    created_at: new Date(Date.now() - 720000).toISOString(),
  },
  {
    id: "alt-2",
    severity: "low",
    title: "Role Policy Verified",
    message: "Tenant boundary rules validated for current branch session.",
    created_at: new Date(Date.now() - 1200000).toISOString(),
  },
];

export function useRealtimeMonitoring(_master = false) {
  const profile = useAuth((s) => s.profile);
  const branchId = useUI((s) => s.branchId);

  const [state, setState] = useState<MonitoringState>({
    status: "live",
    metrics: INITIAL_METRICS,
    onlineUsers: MOCK_ONLINE_USERS,
    whatsappStream: MOCK_WHATSAPP,
    auditFeed: MOCK_AUDIT,
    securityAlerts: MOCK_ALERTS,
    lastUpdated: new Date().toLocaleTimeString(),
  });

  // Batching buffer to limit renders to at most 1 per 400ms
  const bufferRef = useRef<Partial<MonitoringState>>({});
  const timerRef = useRef<number | null>(null);

  const flushBuffer = useCallback(() => {
    if (Object.keys(bufferRef.current).length === 0) return;
    const patch = bufferRef.current;
    bufferRef.current = {};
    setState((prev) => ({
      ...prev,
      ...patch,
      lastUpdated: new Date().toLocaleTimeString(),
    }));
  }, []);

  const queueUpdate = useCallback(
    (patch: Partial<MonitoringState>) => {
      bufferRef.current = { ...bufferRef.current, ...patch };
      if (!timerRef.current) {
        timerRef.current = window.setTimeout(() => {
          timerRef.current = null;
          flushBuffer();
        }, 400);
      }
    },
    [flushBuffer],
  );

  useEffect(() => {
    if (!profile) return;

    if (config.mock) {
      // Simulation mode with realistic event pulses
      const interval = setInterval(() => {
        // Occasionally simulate a live WhatsApp delivery or audit item
        const rand = Math.random();
        if (rand > 0.6) {
          const newStatus: WhatsAppStreamItem["status"] =
            rand > 0.85 ? "Read" : "Delivered";
          const newItem: WhatsAppStreamItem = {
            id: `wa-sim-${Date.now()}`,
            recipient: `+9198${Math.floor(10000000 + Math.random() * 90000000)}`,
            status: newStatus,
            template: "attendance_alert",
            body: "Student status notification dispatched.",
            created_at: new Date().toISOString(),
          };
          setState((prev) => ({
            ...prev,
            whatsappStream: [newItem, ...prev.whatsappStream.slice(0, 14)],
          }));
        }
      }, 5000);

      return () => {
        clearInterval(interval);
        if (timerRef.current) clearTimeout(timerRef.current);
      };
    }

    // Live Supabase Realtime mode
    let channel: RealtimeChannel | null = null;
    let reconnectTimeout: number | null = null;
    let backoffDelay = 1000;
    let isCancelled = false;

    async function initRealtime() {
      try {
        const { client } = await import("../services/supabase");

        // 1. Initial snapshot via RPC
        const { data: initialData, error } = await client.rpc(
          "get_realtime_monitoring",
          {
            p_school_id: profile!.schoolId,
            p_branch_id: branchId || undefined,
          },
        );

        if (!isCancelled && initialData && !error) {
          const d = initialData as Record<string, unknown>;
          const apiMetrics = (
            d.api_metrics && typeof d.api_metrics === "object"
              ? d.api_metrics
              : {}
          ) as Record<string, unknown>;
          const rawWhatsapp = Array.isArray(d.whatsapp_stream)
            ? (d.whatsapp_stream as Array<Record<string, unknown>>)
            : [];
          const rawAudit = Array.isArray(d.recent_audit)
            ? (d.recent_audit as Array<Record<string, unknown>>)
            : [];
          const rawAlerts = Array.isArray(d.security_alerts)
            ? (d.security_alerts as Array<Record<string, unknown>>)
            : [];

          queueUpdate({
            status: "live",
            metrics: {
              liveAttendancePct: Number(d.live_attendance_pct ?? 95),
              liveFeeCollection: Number(d.live_fee_collection ?? 0),
              newAdmissions: Number(d.new_admissions ?? 0),
              apiLatencyMs: Number(apiMetrics.latency_ms ?? 42),
              errorRatePct: Number(apiMetrics.error_rate_pct ?? 0.01),
              edgeFailures: Number(apiMetrics.edge_failures ?? 0),
            },
            whatsappStream: rawWhatsapp.map((w) => ({
              id: String(w.id || crypto.randomUUID()),
              recipient: String(w.recipient ?? w.recipient_phone ?? ""),
              status: (w.status as WhatsAppStreamItem["status"]) || "Queued",
              template: String(w.template ?? "alert"),
              body: String(w.body ?? w.message_body ?? ""),
              created_at: String(w.created_at || new Date().toISOString()),
            })),
            auditFeed: rawAudit.map((a) => ({
              id: String(a.id || crypto.randomUUID()),
              actor: String(a.actor ?? a.actor_name ?? "System"),
              action: String(a.action || "UNKNOWN"),
              resource: String(a.resource || "system"),
              created_at: String(a.created_at || new Date().toISOString()),
            })),
            securityAlerts: rawAlerts.map((s) => ({
              id: String(s.id || crypto.randomUUID()),
              severity:
                (s.severity as SecurityAlertItem["severity"]) || "medium",
              title: String(s.title || "Security Notice"),
              message: String(s.message || ""),
              created_at: String(s.created_at || new Date().toISOString()),
            })),
          });
        }

        // 2. Private tenant channel with presence
        const channelTopic = `school:${profile!.schoolId}:monitoring`;
        channel = client.channel(channelTopic, {
          config: {
            presence: { key: profile!.id },
            private: true,
          },
        });

        // Presence state tracking
        channel.on("presence", { event: "sync" }, () => {
          if (!channel) return;
          const presenceState = channel.presenceState();
          const users: PresenceUser[] = [];
          for (const key of Object.keys(presenceState)) {
            const presences = presenceState[key] as unknown as Array<
              Record<string, unknown>
            >;
            if (presences?.[0]) {
              const p = presences[0];
              users.push({
                id: key,
                name: String(p.name || "School Member"),
                role: String(p.role || "staff"),
                email: String(p.email || ""),
                onlineAt: "Online now",
              });
            }
          }
          if (users.length > 0) {
            queueUpdate({ onlineUsers: users });
          }
        });

        // Postgres changes subscription for live events
        channel
          .on(
            "postgres_changes" as never,
            {
              event: "INSERT",
              schema: "public",
              table: "whatsapp_messages",
              filter: `school_id=eq.${profile!.schoolId}`,
            },
            (payload: { new: Record<string, unknown> }) => {
              const newMsg = payload.new;
              setState((prev) => ({
                ...prev,
                whatsappStream: [
                  {
                    id: String(newMsg.id),
                    recipient: String(newMsg.recipient_phone || ""),
                    status:
                      (newMsg.status as WhatsAppStreamItem["status"]) ||
                      "Queued",
                    template: String(newMsg.meta_message_id || "template"),
                    body: String(newMsg.message_body || ""),
                    created_at: String(
                      newMsg.created_at || new Date().toISOString(),
                    ),
                  },
                  ...prev.whatsappStream.slice(0, 14),
                ],
              }));
            },
          )
          .on(
            "postgres_changes" as never,
            {
              event: "UPDATE",
              schema: "public",
              table: "whatsapp_messages",
              filter: `school_id=eq.${profile!.schoolId}`,
            },
            (payload: { new: Record<string, unknown> }) => {
              const updated = payload.new;
              setState((prev) => ({
                ...prev,
                whatsappStream: prev.whatsappStream.map((m) =>
                  m.id === updated.id
                    ? {
                        ...m,
                        status:
                          (updated.status as WhatsAppStreamItem["status"]) ||
                          m.status,
                      }
                    : m,
                ),
              }));
            },
          )
          .on(
            "postgres_changes" as never,
            {
              event: "INSERT",
              schema: "public",
              table: "audit_logs",
              filter: `school_id=eq.${profile!.schoolId}`,
            },
            (payload: { new: Record<string, unknown> }) => {
              const newAudit = payload.new;
              setState((prev) => ({
                ...prev,
                auditFeed: [
                  {
                    id: String(newAudit.id),
                    actor: String(newAudit.actor_name || "System"),
                    action: String(newAudit.action || "LOG"),
                    resource: String(newAudit.resource || "system"),
                    created_at: String(
                      newAudit.created_at || new Date().toISOString(),
                    ),
                  },
                  ...prev.auditFeed.slice(0, 9),
                ],
              }));
            },
          );

        // Subscribe with exponential backoff reconnect
        channel.subscribe(async (status: string) => {
          if (isCancelled) return;
          if (status === "SUBSCRIBED") {
            queueUpdate({ status: "live" });
            backoffDelay = 1000;
            if (channel) {
              await channel.track({
                name: profile!.name,
                role: profile!.role,
                email: profile!.email,
                onlineAt: new Date().toISOString(),
              });
            }
          } else if (
            status === "CHANNEL_ERROR" ||
            status === "TIMED_OUT" ||
            status === "CLOSED"
          ) {
            queueUpdate({ status: "reconnecting" });
            reconnectTimeout = window.setTimeout(() => {
              if (!isCancelled) {
                backoffDelay = Math.min(backoffDelay * 2, 10000);
                initRealtime();
              }
            }, backoffDelay);
          }
        });
      } catch {
        if (!isCancelled) {
          queueUpdate({ status: "reconnecting" });
        }
      }
    }

    initRealtime();

    return () => {
      isCancelled = true;
      if (reconnectTimeout) clearTimeout(reconnectTimeout);
      if (timerRef.current) clearTimeout(timerRef.current);
      if (channel) {
        channel.unsubscribe();
      }
    };
  }, [profile, branchId, queueUpdate]);

  return state;
}
