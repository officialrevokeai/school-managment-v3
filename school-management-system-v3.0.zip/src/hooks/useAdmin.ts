import { useMutation, useQuery } from "@tanstack/react-query";
import { getAdminRepository } from "../services/admin";
import { useAuth } from "../store/auth";
import { queryClient } from "../lib/query";
import { toast } from "sonner";
import type {
  AdminModels,
  AdminResource,
  AdminScope,
  ListOptions,
} from "../types/admin";
export function useAdminList<K extends AdminResource>(
  resource: K,
  scope: AdminScope,
  options: ListOptions = {},
  enabled = true,
) {
  const user = useAuth((s) => s.profile?.id);
  return useQuery({
    queryKey: [
      "admin",
      user,
      resource,
      scope.schoolId,
      scope.branchId ?? "all",
      options,
    ],
    queryFn: async () =>
      (await getAdminRepository()).list(resource, scope, options),
    enabled: !!user && enabled,
  });
}
export async function refreshAdmin() {
  await Promise.all([
    queryClient.invalidateQueries({ queryKey: ["admin"] }),
    queryClient.invalidateQueries({ queryKey: ["branches"] }),
  ]);
}
export function useAdminSave<
  K extends Exclude<AdminResource, "audit" | "analytics">,
>(resource: K) {
  return useMutation({
    mutationFn: async (record: AdminModels[K]) =>
      (await getAdminRepository()).save(resource, record),
    onSuccess: () => {
      void refreshAdmin();
      toast.success("Changes saved");
    },
    onError: (error) =>
      toast.error(
        error instanceof Error ? error.message : "Unable to save changes",
      ),
  });
}
