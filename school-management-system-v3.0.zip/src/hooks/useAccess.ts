import { useAuth } from "../store/auth";
import { useAdminList } from "./useAdmin";
import { hasPermission, type Permission } from "../lib/permissions";
export function useAccess() {
  const profile = useAuth((s) => s.profile);
  const query = useAdminList(
    "roles",
    { schoolId: profile?.schoolId ?? "" },
    { pageSize: 500 },
    !!profile && (profile.role === "owner" || profile.role === "principal"),
  );
  const policy = query.data?.rows.find((row) =>
    profile?.policyId
      ? row.id === profile.policyId
      : row.role === profile?.role && !row.custom,
  );
  return {
    can: (permission: Permission) => {
      if (!profile) return false;
      if (profile.role === "owner" || profile.role === "master")
        return hasPermission(profile.role, permission);
      if (profile.policyId && !policy) return permission === "workspace.read";
      return policy
        ? policy.permissions.includes(permission)
        : hasPermission(profile.role, permission);
    },
  };
}
