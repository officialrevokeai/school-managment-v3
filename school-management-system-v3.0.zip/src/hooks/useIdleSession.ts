import { useEffect } from "react";
import { useAuth } from "../store/auth";
import { getRepository } from "../services";
import { queryClient } from "../lib/query";
export function useIdleSession(minutes: number) {
  const id = useAuth((s) => s.profile?.id);
  useEffect(() => {
    if (!id) return;
    let lastActivity = Date.now();
    let ending = false;
    const activity = () => {
      lastActivity = Date.now();
    };
    const expire = async () => {
      if (ending || Date.now() - lastActivity < minutes * 60000) return;
      ending = true;
      try {
        await (await getRepository()).auth.signOut();
        useAuth.getState().setProfile(null);
        useAuth.getState().setExpired(true);
        queryClient.clear();
      } catch {
        ending = false;
      }
    };
    const interval = setInterval(() => {
      void expire();
    }, 15000);
    window.addEventListener("pointerdown", activity, { passive: true });
    window.addEventListener("keydown", activity);
    return () => {
      clearInterval(interval);
      window.removeEventListener("pointerdown", activity);
      window.removeEventListener("keydown", activity);
    };
  }, [id, minutes]);
}
