import { QueryClient } from "@tanstack/react-query";
import { devTracker } from "./devTracker";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60_000,
      gcTime: 300_000,
      retry: 1,
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
    },
    mutations: { retry: 0 },
  },
});

queryClient.getQueryCache().subscribe((event) => {
  if (event.type === "updated" && event.action?.type === "fetch") {
    devTracker.logQuery(JSON.stringify(event.query.queryKey));
  }
});

if (typeof window !== "undefined") {
  (window as unknown as { __queryClient?: QueryClient }).__queryClient =
    queryClient;
}

export const queryKeys = {
  branches: (user: string) => ["branches", user] as const,
  notifications: (user: string, branch: string) =>
    ["notifications", user, branch] as const,
};
