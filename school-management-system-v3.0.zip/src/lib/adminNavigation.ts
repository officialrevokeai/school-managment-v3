import { navigation, type Permission } from "./permissions";
import type { IconName } from "../components/ui/Icon";
import type { Role } from "../types/domain";
import {
  definition,
  moduleKeys,
  workflowPermission,
} from "../features/school/model";
type Item = {
  label: string;
  path: string;
  icon: IconName;
  permission: Permission;
  phase: number;
  section: "Workspace" | "Management" | "System";
};
export function getNavigation(role: Role): Item[] {
  const original: Item[] = [...navigation];
  const common: Item[] =
    role === "master"
      ? original
      : role === "owner"
        ? original.filter(
            (item) =>
              !["/academics", "/attendance", "/whatsapp", "/child"].includes(
                item.path,
              ),
          )
        : original.filter((item) => item.phase === 1);
  if (role !== "master")
    common.push(
      ...moduleKeys
        .filter((key) => definition(key).readers.includes(role))
        .map((key) => ({
          label: definition(key).title,
          path: `/${key}`,
          icon: definition(key).icon,
          permission: workflowPermission(key, role),
          phase: 5,
          section: "Management" as const,
        })),
    );
  if (role === "master")
    return [
      ...common.filter((item) => item.phase === 1),
      {
        label: "Schools",
        path: "/schools",
        icon: "building",
        permission: "master.manage",
        phase: 2,
        section: "Workspace",
      },
      {
        label: "Revenue",
        path: "/revenue",
        icon: "wallet",
        permission: "master.manage",
        phase: 2,
        section: "Management",
      },
      {
        label: "Global role control",
        path: "/roles",
        icon: "shield",
        permission: "master.manage",
        phase: 2,
        section: "Management",
      },
      {
        label: "Audit trail",
        path: "/audit",
        icon: "file",
        permission: "master.manage",
        phase: 2,
        section: "System",
      },
      {
        label: "Live monitoring",
        path: "/monitoring",
        icon: "monitor",
        permission: "master.manage",
        phase: 2,
        section: "System",
      },
    ];
  return role !== "owner"
    ? common
    : [
        ...common,
        {
          label: "Roles & permissions",
          path: "/roles",
          icon: "shield",
          permission: "system.manage",
          phase: 2,
          section: "Workspace",
        },
        {
          label: "View as",
          path: "/view-as",
          icon: "eye",
          permission: "system.manage",
          phase: 2,
          section: "Management",
        },
        {
          label: "School settings",
          path: "/settings",
          icon: "settings",
          permission: "system.manage",
          phase: 2,
          section: "System",
        },
        {
          label: "Security & privacy",
          path: "/security",
          icon: "lock",
          permission: "system.manage",
          phase: 2,
          section: "System",
        },
        {
          label: "Audit trail",
          path: "/audit",
          icon: "file",
          permission: "system.manage",
          phase: 2,
          section: "System",
        },
        {
          label: "Live monitoring",
          path: "/monitoring",
          icon: "monitor",
          permission: "system.manage",
          phase: 2,
          section: "System",
        },
      ];
}
export function moduleReady(role: Role, phase: number) {
  return phase <= (role === "master" ? 2 : 5);
}
