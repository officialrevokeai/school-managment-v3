export const config = {
  mock:
    import.meta.env.MODE === "test" || import.meta.env.VITE_USE_MOCK === "true",
  appUrl:
    import.meta.env.VITE_APP_URL ||
    (typeof window !== "undefined"
      ? window.location.origin
      : "http://localhost:5173"),
};
