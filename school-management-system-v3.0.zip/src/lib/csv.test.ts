import { describe, expect, it } from "vitest";
import { parseCsv } from "./csv";
describe("CSV import parser", () => {
  it("handles quoted commas, newlines, and escaped quotes", () => {
    expect(
      parseCsv(
        'name,email\r\n"Morgan, Alex",alex@test.edu\r\n"A ""quoted"" name",name@test.edu',
      ),
    ).toEqual([
      ["name", "email"],
      ["Morgan, Alex", "alex@test.edu"],
      ['A "quoted" name', "name@test.edu"],
    ]);
  });
  it("rejects a malformed quoted field", () => {
    expect(() => parseCsv('name\n"unfinished')).toThrow("unclosed quote");
  });
});
