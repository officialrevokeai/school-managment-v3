/**
 * Dev-only tracker for lifecycle, auth, route, render, query, and theme events.
 * Enabled only in development or test modes; zero overhead in production.
 */

export type TrackerMetrics = {
  documentLoads: number;
  routeChanges: string[];
  authEvents: Array<{
    type: string;
    userId?: string | null;
    timestamp: number;
  }>;
  renderCounts: Record<string, number>;
  queryRefetches: Record<string, number>;
  realtimeEvents: Array<{ event: string; channel: string; timestamp: number }>;
  themeChanges: Array<{ from?: string; to: string; timestamp: number }>;
  layoutShifts: number;
};

const STORAGE_KEY = "__campus_doc_loads";

const currentLoads = (() => {
  try {
    const val = parseInt(sessionStorage.getItem(STORAGE_KEY) || "0", 10) + 1;
    sessionStorage.setItem(STORAGE_KEY, val.toString());
    return val;
  } catch {
    return 1;
  }
})();

export const devTracker: TrackerMetrics & {
  logRoute: (pathname: string) => void;
  logAuth: (type: string, userId?: string | null) => void;
  logRender: (component: string) => void;
  logQuery: (queryKey: string) => void;
  logRealtime: (event: string, channel: string) => void;
  logTheme: (to: string, from?: string) => void;
  summary: () => void;
} = {
  documentLoads: currentLoads,
  routeChanges: [],
  authEvents: [],
  renderCounts: {},
  queryRefetches: {},
  realtimeEvents: [],
  themeChanges: [],
  layoutShifts: 0,

  logRoute(pathname: string) {
    this.routeChanges.push(pathname);
    if (import.meta.env.DEV) {
      console.debug(`[Tracker:Route] -> ${pathname}`);
    }
  },

  logAuth(type: string, userId?: string | null) {
    this.authEvents.push({ type, userId, timestamp: Date.now() });
    if (import.meta.env.DEV) {
      console.debug(`[Tracker:Auth] ${type} (${userId ?? "anonymous"})`);
    }
  },

  logRender(component: string) {
    this.renderCounts[component] = (this.renderCounts[component] || 0) + 1;
  },

  logQuery(queryKey: string) {
    this.queryRefetches[queryKey] = (this.queryRefetches[queryKey] || 0) + 1;
    if (import.meta.env.DEV) {
      console.debug(
        `[Tracker:Query] ${queryKey} (fetch #${this.queryRefetches[queryKey]})`,
      );
    }
  },

  logRealtime(event: string, channel: string) {
    this.realtimeEvents.push({ event, channel, timestamp: Date.now() });
    if (import.meta.env.DEV) {
      console.debug(`[Tracker:Realtime] ${event} on ${channel}`);
    }
  },

  logTheme(to: string, from?: string) {
    this.themeChanges.push({ from, to, timestamp: Date.now() });
    if (import.meta.env.DEV) {
      console.debug(`[Tracker:Theme] ${from ?? "default"} -> ${to}`);
    }
  },

  summary() {
    console.table({
      DocumentLoads: this.documentLoads,
      RouteTransitions: this.routeChanges.length,
      AuthEvents: this.authEvents.length,
      TotalComponentsTracked: Object.keys(this.renderCounts).length,
    });
  },
};

if (typeof window !== "undefined") {
  (window as unknown as { __devTracker: typeof devTracker }).__devTracker =
    devTracker;

  // Track layout shifts if PerformanceObserver is available
  if ("PerformanceObserver" in window) {
    try {
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          const shiftEntry = entry as unknown as {
            hadRecentInput?: boolean;
            value?: number;
          };
          if (!shiftEntry.hadRecentInput && shiftEntry.value) {
            devTracker.layoutShifts += shiftEntry.value;
          }
        }
      });
      observer.observe({ type: "layout-shift", buffered: true });
    } catch {
      // not supported in some browser environments
    }
  }
}
