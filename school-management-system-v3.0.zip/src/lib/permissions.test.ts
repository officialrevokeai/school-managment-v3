import { describe, expect, it } from "vitest";
import { hasPermission, homeFor, rolePermissions } from "./permissions";
import { roles } from "../types/domain";
describe("role boundaries", () => {
  it("does not grant master access to owners or other school roles", () => {
    for (const role of roles.filter((r) => r !== "master"))
      expect(hasPermission(role, "master.manage")).toBe(false);
    expect(hasPermission("master", "master.manage")).toBe(true);
  });
  it("keeps financial and academic responsibilities separate", () => {
    expect(hasPermission("teacher", "finance.manage")).toBe(false);
    expect(hasPermission("accountant", "academics.read")).toBe(false);
    expect(hasPermission("principal", "system.manage")).toBe(false);
    expect(hasPermission("parent", "users.manage")).toBe(false);
  });
  it("fails closed for signed-out users", () => {
    for (const permission of rolePermissions.owner)
      expect(hasPermission(undefined, permission)).toBe(false);
  });
  it("redirects every role to its own workspace", () => {
    expect(homeFor("master")).toBe("/sys-master/workspace");
    for (const role of roles.filter((r) => r !== "master"))
      expect(homeFor(role)).toBe(`/${role}`);
  });
});
