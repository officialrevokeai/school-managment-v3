import type { Role } from "../types/domain";
export const permissions = [
  "workspace.read",
  "users.manage",
  "branches.manage",
  "academics.read",
  "attendance.manage",
  "finance.manage",
  "child.read",
  "whatsapp.manage",
  "system.manage",
  "master.manage",
] as const;
export type Permission = (typeof permissions)[number];
export const roleLabels: Record<Role, string> = {
  owner: "Owner / Super Admin",
  principal: "Principal",
  teacher: "Teacher",
  parent: "Parent",
  student: "Student",
  accountant: "Office / Accountant",
  master: "SaaS Creator",
};
export const rolePermissions: Record<Role, readonly Permission[]> = {
  owner: permissions.filter((p) => p !== "master.manage"),
  principal: [
    "workspace.read",
    "users.manage",
    "academics.read",
    "attendance.manage",
  ],
  teacher: ["workspace.read", "academics.read", "attendance.manage"],
  parent: ["workspace.read", "child.read"],
  student: ["workspace.read", "child.read"],
  accountant: ["workspace.read", "finance.manage"],
  master: permissions,
};
export function hasPermission(
  role: Role | undefined,
  permission: Permission,
): boolean {
  return role ? rolePermissions[role].includes(permission) : false;
}
export function homeFor(role: Role) {
  return role === "master" ? "/sys-master/workspace" : `/${role}`;
}
export const navigation = [
  {
    label: "Overview",
    path: "",
    icon: "grid",
    permission: "workspace.read",
    phase: 1,
    section: "Workspace",
  },
  {
    label: "Workspace directory",
    path: "/directory",
    icon: "layers",
    permission: "workspace.read",
    phase: 1,
    section: "Workspace",
  },
  {
    label: "People & access",
    path: "/people",
    icon: "users",
    permission: "users.manage",
    phase: 2,
    section: "Workspace",
  },
  {
    label: "Branches",
    path: "/branches",
    icon: "building",
    permission: "branches.manage",
    phase: 2,
    section: "Workspace",
  },
  {
    label: "Academics",
    path: "/academics",
    icon: "book",
    permission: "academics.read",
    phase: 3,
    section: "Management",
  },
  {
    label: "Attendance",
    path: "/attendance",
    icon: "calendar-check",
    permission: "attendance.manage",
    phase: 3,
    section: "Management",
  },
  {
    label: "My child",
    path: "/child",
    icon: "heart",
    permission: "child.read",
    phase: 4,
    section: "Management",
  },
  {
    label: "Finance",
    path: "/finance",
    icon: "wallet",
    permission: "finance.manage",
    phase: 2,
    section: "Management",
  },
  {
    label: "WhatsApp",
    path: "/whatsapp",
    icon: "message",
    permission: "whatsapp.manage",
    phase: 5,
    section: "Management",
  },
  {
    label: "My preferences",
    path: "/preferences",
    icon: "settings",
    permission: "workspace.read",
    phase: 1,
    section: "System",
  },
] as const;
