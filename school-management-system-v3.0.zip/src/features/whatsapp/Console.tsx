import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { toast } from "sonner";
import { config } from "../../lib/config";
import { useUI } from "../../store/ui";
import { useAuth } from "../../store/auth";
import { queryClient } from "../../lib/query";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuInput,
  NeuSelect,
  ErrorState,
  Skeleton,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { AdminHeading } from "../owner/shared";
import WorkflowPage from "../school/Workspace";
const connectionSchema = z.object({
  connected: z.boolean(),
  message: z.string(),
  templates: z.array(z.object({ name: z.string(), language: z.string() })),
});
async function invoke(operation: string, body: Record<string, string> = {}) {
  const { client } = await import("../../services/supabase");
  const { data, error } = await client.functions.invoke("school-whatsapp", {
    body: { operation, ...body },
  });
  if (error) throw error;
  return data as unknown;
}
export default function Console() {
  const user = useAuth((s) => s.profile)!;
  const branch = useUI((s) => s.branchId);
  const [open, setOpen] = useState(false);
  const [recipient, setRecipient] = useState("");
  const [template, setTemplate] = useState("");
  const [busy, setBusy] = useState(false);
  const status = useQuery({
    queryKey: ["whatsapp-status", user.id],
    queryFn: async () =>
      config.mock
        ? {
            connected: true,
            message: "Demo provider: local delivery simulation",
            templates: [{ name: "school_update", language: "en_US" }],
          }
        : connectionSchema.parse(await invoke("status")),
  });
  const send = async () => {
    if (!/^\+[1-9]\d{7,14}$/.test(recipient)) {
      toast.error("Enter an international phone number.");
      return;
    }
    setBusy(true);
    try {
      const name = template || status.data?.templates[0]?.name || "";
      if (config.mock)
        await (
          await import("../../mocks/workflows")
        ).sendDemoWhatsApp(recipient, name, branch);
      else
        await invoke("send", { recipient, template: name, branchId: branch });
      setOpen(false);
      toast.success(
        config.mock
          ? "Demo message queued; no external message sent"
          : "Message submitted",
      );
      await queryClient.invalidateQueries({ queryKey: ["workflows"] });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Sending failed");
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <AdminHeading
        title="A closer school community"
        description="Approved templates, delivery updates, and smart communication."
      >
        <NeuButton
          variant="primary"
          disabled={!status.data?.connected}
          onClick={() => setOpen(true)}
        >
          Send test template
        </NeuButton>
        <NeuButton
          disabled={config.mock || !status.data?.connected || busy}
          loading={busy}
          onClick={() => {
            setBusy(true);
            void invoke("flush", { branchId: branch })
              .then(() =>
                queryClient.invalidateQueries({ queryKey: ["workflows"] }),
              )
              .catch((error) => toast.error(error.message))
              .finally(() => setBusy(false));
          }}
        >
          Process outbox
        </NeuButton>
      </AdminHeading>
      <NeuCard>
        {status.isPending ? (
          <Skeleton className="line-skeleton" />
        ) : status.isError ? (
          <ErrorState
            description={status.error.message}
            onRetry={() => void status.refetch()}
          />
        ) : (
          <>
            <NeuBadge tone={status.data.connected ? "success" : "warning"}>
              {config.mock
                ? "Demo"
                : status.data.connected
                  ? "Connected"
                  : "Setup required"}
            </NeuBadge>
            <p>{status.data.message}</p>
          </>
        )}
        <p className="module-footnote">
          Live sending requires Meta credentials, approved templates, verified
          recipients, and a webhook. Configure the sender in School settings.
        </p>
      </NeuCard>
      <WorkflowPage module="whatsapp" readOnly />
      <WorkflowPage module="automations" />
      <NeuModal
        open={open}
        onClose={() => !busy && setOpen(false)}
        title="Send a test template"
        description={
          config.mock
            ? "Local simulation; no external message is sent."
            : "Send the selected approved template to this number."
        }
        footer={
          <NeuButton
            variant="primary"
            loading={busy}
            onClick={() => void send()}
          >
            Send template
          </NeuButton>
        }
      >
        <div className="admin-form">
          <NeuInput
            id="wa-recipient"
            label="Recipient number"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
          />
          <NeuSelect
            id="wa-template"
            label="Approved template"
            value={template || status.data?.templates[0]?.name || ""}
            onChange={(e) => setTemplate(e.target.value)}
          >
            {status.data?.templates.map((t) => (
              <option key={t.name} value={t.name}>
                {t.name} · {t.language}
              </option>
            ))}
          </NeuSelect>
        </div>
      </NeuModal>
    </>
  );
}
