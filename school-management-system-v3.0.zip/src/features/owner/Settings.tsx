import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { useAuth } from "../../store/auth";
import { useUI } from "../../store/ui";
import { useAdminList, useAdminSave } from "../../hooks/useAdmin";
import { AdminHeading, QueryState } from "./shared";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuInput,
  NeuSelect,
  NeuToggle,
} from "../../components/ui/primitives";
import { ConfirmDialog } from "../../components/ui/overlays";
import { FileUpload } from "../../components/ui/FileUpload";
import { Icon } from "../../components/ui/Icon";
import { getRepository } from "../../services";
import { adminSchemas, type AdminModels } from "../../types/admin";
import { config } from "../../lib/config";
const schema = adminSchemas.settings.extend({
  senderNumber: z
    .string()
    .regex(
      /^\+[1-9]\d{7,14}$/,
      "Use an international number, such as +919845001234.",
    ),
  academicYear: z.string().min(4, "Enter an academic year."),
});
export default function Settings({ security = false }: { security?: boolean }) {
  const profile = useAuth((s) => s.profile)!;
  const branchId = useUI((s) => s.branchId);
  const query = useAdminList("settings", { schoolId: profile.schoolId });
  const save = useAdminSave("settings");
  const [overrideConfirm, setOverrideConfirm] = useState(false);
  const {
    register,
    reset,
    watch,
    setValue,
    handleSubmit,
    formState: { errors, isDirty },
  } = useForm<AdminModels["settings"]>({ resolver: zodResolver(schema) });
  useEffect(() => {
    if (query.data && !isDirty)
      reset(
        query.data.rows[0] ?? {
          id: crypto.randomUUID(),
          schoolId: profile.schoolId,
          branchId: null,
          version: 1,
          name: "Your school",
          academicYear: "2026–2027",
          logoPath: "",
          senderNumber: "+919000000000",
          financeRole: "accountant",
          overrideEnabled: false,
          requireMfa: false,
          sessionMinutes: 60,
          privacyEmail: profile.email,
          retentionDays: 365,
        },
      );
  }, [query.data, profile, reset, isDirty]);
  const submit = handleSubmit(async (record) => {
    const result = await save.mutateAsync(record);
    reset(result);
  });
  return (
    <>
      <AdminHeading
        title={
          security
            ? "Security, with peace of mind"
            : "Make your school’s workspace its own"
        }
        description={
          security
            ? "Manage session policy, privacy contacts, and access overrides."
            : "Branding, academic year, communication, and financial responsibilities."
        }
      >
        <NeuButton
          variant="primary"
          icon="check"
          loading={save.isPending}
          disabled={!isDirty}
          onClick={() => void submit().catch(() => undefined)}
        >
          Save settings
        </NeuButton>
      </AdminHeading>
      <QueryState query={query}>
        {() => (
          <form className="settings-grid" onSubmit={submit}>
            {!security ? (
              <>
                <NeuCard>
                  <div className="section-heading">
                    <h2>School identity</h2>
                    <Icon name="building" />
                  </div>
                  <div className="admin-form">
                    <NeuInput
                      id="school-name"
                      label="School name"
                      error={errors.name?.message}
                      {...register("name")}
                    />
                    <NeuInput
                      id="academic-year"
                      label="Academic year"
                      error={errors.academicYear?.message}
                      {...register("academicYear")}
                    />
                    <FileUpload
                      accept=".png,.jpg,.jpeg"
                      onUpload={async (file) => {
                        const path = await (
                          await getRepository()
                        ).storage.upload(file, branchId);
                        setValue("logoPath", path, { shouldDirty: true });
                      }}
                    />
                    {watch("logoPath") && (
                      <small>
                        Logo uploaded: {watch("logoPath")?.split("/").at(-1)}
                      </small>
                    )}
                  </div>
                </NeuCard>
                <NeuCard>
                  <div className="section-heading">
                    <h2>School communication</h2>
                    <NeuBadge>Owner access</NeuBadge>
                  </div>
                  <div className="admin-form">
                    <NeuInput
                      id="sender-number"
                      label="WhatsApp sender number"
                      hint="Changing this configuration does not connect or verify a WhatsApp account. Connection is delivered in Phase 5."
                      error={errors.senderNumber?.message}
                      {...register("senderNumber")}
                    />
                    <Link className="neu-button" to="/owner/templates">
                      <Icon name="message" />
                      Manage WhatsApp templates
                    </Link>
                    <NeuSelect
                      id="finance-role"
                      label="Default financial role"
                      {...register("financeRole")}
                    >
                      <option value="accountant">Office / Accountant</option>
                      <option value="owner">Owner only</option>
                    </NeuSelect>
                    <Link className="text-button" to="/owner/people">
                      Assign financial roles in People & access
                      <Icon name="arrow-up-right" size={16} />
                    </Link>
                  </div>
                </NeuCard>
              </>
            ) : (
              <>
                <NeuCard>
                  <div className="section-heading">
                    <h2>Session & access policy</h2>
                    <Icon name="shield" />
                  </div>
                  <div className="admin-form">
                    <NeuSelect
                      id="session-timeout"
                      label="Idle session timeout"
                      {...register("sessionMinutes", { valueAsNumber: true })}
                    >
                      {[15, 30, 60, 120, 240, 480].map((n) => (
                        <option value={n} key={n}>
                          {n} minutes
                        </option>
                      ))}
                    </NeuSelect>
                    <NeuToggle
                      label="Owner permission override"
                      description="Allow the Owner to bypass school module restrictions. Tenant and platform boundaries always apply."
                      checked={watch("overrideEnabled") ?? false}
                      onChange={(value) =>
                        value
                          ? setOverrideConfirm(true)
                          : setValue("overrideEnabled", false, {
                              shouldDirty: true,
                            })
                      }
                    />
                    <div className="info-note">
                      <Icon name="lock" size={18} />
                      <p>
                        Roles come from trusted Auth metadata and provisioned
                        profiles. This screen cannot grant platform
                        administration or access to another school.
                      </p>
                    </div>
                  </div>
                </NeuCard>
                <NeuCard>
                  <div className="section-heading">
                    <h2>Privacy preferences</h2>
                    <Icon name="heart" />
                  </div>
                  <div className="admin-form">
                    <NeuInput
                      label="Privacy contact email"
                      id="privacy-email"
                      type="email"
                      error={errors.privacyEmail?.message}
                      {...register("privacyEmail")}
                    />
                    <NeuInput
                      label="Requested retention period (days)"
                      id="retention-days"
                      type="number"
                      hint="Records are retained until your administrator applies the retention policy. This preference does not schedule deletion."
                      error={errors.retentionDays?.message}
                      {...register("retentionDays", { valueAsNumber: true })}
                    />
                    <NeuBadge tone="success">
                      Private storage · tenant-scoped data
                    </NeuBadge>
                    <div style={{ marginTop: 12 }}>
                      <NeuButton
                        type="button"
                        icon="download"
                        onClick={async () => {
                          try {
                            if (config.mock) {
                              toast.success("School archive export simulated.");
                            } else {
                              const { client } = await import(
                                "../../services/supabase"
                              );
                              const { data } = await client.functions.invoke(
                                "export-data",
                                {
                                  body: { resource: "all", format: "json" },
                                },
                              );
                              if (data?.data?.downloadUrl) {
                                window.open(data.data.downloadUrl, "_blank");
                                toast.success(
                                  "School archive export ready (valid 15 minutes).",
                                );
                              }
                            }
                          } catch (err: unknown) {
                            toast.error(
                              err instanceof Error
                                ? err.message
                                : "Export failed",
                            );
                          }
                        }}
                      >
                        Export entire school archive
                      </NeuButton>
                    </div>
                    <p className="module-footnote">
                      {config.mock
                        ? "You are in a local demonstration workspace. Use fictional data only."
                        : "Use the audit trail to review access and configuration changes."}
                    </p>
                  </div>
                </NeuCard>
              </>
            )}
            <button type="submit" className="sr-only" tabIndex={-1}>
              Save settings
            </button>
          </form>
        )}
      </QueryState>
      <ConfirmDialog
        open={overrideConfirm}
        onClose={() => setOverrideConfirm(false)}
        title="Enable the Owner override?"
        description="This setting grants broad access within your school. It does not bypass database tenancy or platform restrictions. Save the settings to apply it."
        confirmText="ENABLE OVERRIDE"
        onConfirm={() => {
          setValue("overrideEnabled", true, { shouldDirty: true });
          setOverrideConfirm(false);
        }}
      />
    </>
  );
}
