import type { ReactNode } from "react";
import {
  NeuBadge,
  NeuButton,
  Skeleton,
  ErrorState,
} from "../../components/ui/primitives";
import type { UseQueryResult } from "@tanstack/react-query";
import type { AdminPage } from "../../types/admin";
export function AdminHeading({
  eyebrow = "SCHOOL MANAGEMENT",
  title,
  description,
  children,
}: {
  eyebrow?: string;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      <div className="admin-heading-actions">{children}</div>
    </div>
  );
}
export function QueryState<T>({
  query,
  children,
}: {
  query: UseQueryResult<AdminPage<T>, Error>;
  children: (data: AdminPage<T>) => ReactNode;
}) {
  if (query.isPending)
    return (
      <div className="admin-loading">
        <Skeleton className="title-skeleton" />
        <Skeleton className="hero-skeleton" />
      </div>
    );
  if (query.isError)
    return (
      <ErrorState
        description={query.error.message}
        onRetry={() => void query.refetch()}
      />
    );
  return children(query.data);
}
export function Pagination({
  page,
  setPage,
  total,
  size = 12,
}: {
  page: number;
  setPage: (page: number) => void;
  total: number;
  size?: number;
}) {
  return (
    <div className="pagination">
      <span>
        {total ? page * size + 1 : 0}–{Math.min((page + 1) * size, total)} of{" "}
        {total}
      </span>
      <NeuButton
        variant="ghost"
        icon="left"
        aria-label="Previous page"
        disabled={page === 0}
        onClick={() => setPage(page - 1)}
      />
      <NeuBadge>Page {page + 1}</NeuBadge>
      <NeuButton
        variant="ghost"
        icon="right"
        aria-label="Next page"
        disabled={(page + 1) * size >= total}
        onClick={() => setPage(page + 1)}
      />
    </div>
  );
}
