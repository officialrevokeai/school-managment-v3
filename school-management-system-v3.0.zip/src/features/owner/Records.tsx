import { useMemo, useState, useCallback } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import type { ColumnDef } from "@tanstack/react-table";
import { toast } from "sonner";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuCheckbox,
  NeuInput,
  NeuSelect,
  SearchBar,
  DatePicker,
} from "../../components/ui/primitives";
import { NeuModal, ConfirmDialog } from "../../components/ui/overlays";
import { NeuTable } from "../../components/ui/NeuTable";
import { FileUpload } from "../../components/ui/FileUpload";
import { Icon } from "../../components/ui/Icon";
import { useAuth } from "../../store/auth";
import { useDebounce } from "../../hooks/useDebounce";
import { useAdminList, refreshAdmin } from "../../hooks/useAdmin";
import { getAdminRepository } from "../../services/admin";
import { parseRecord, type AdminModels } from "../../types/admin";
import { downloadCsv, money, parseCsv } from "../../lib/csv";
import { config } from "../../lib/config";
import { AdminHeading, Pagination, QueryState } from "./shared";
type Resource = "branches" | "users" | "finance" | "templates" | "schools";
type Field = {
  key: string;
  label: string;
  type?: "number" | "date" | "email";
  options?: readonly string[];
  required?: boolean;
};
const fields: Record<Resource, Field[]> = {
  branches: [
    { key: "name", label: "Campus name", required: true },
    { key: "city", label: "City", required: true },
    { key: "code", label: "Campus code", required: true },
    { key: "principal", label: "Principal" },
    { key: "capacity", label: "Capacity", type: "number", required: true },
    { key: "status", label: "Status", options: ["Active", "Inactive"] },
  ],
  users: [
    { key: "name", label: "Full name", required: true },
    { key: "email", label: "School email", type: "email", required: true },
    {
      key: "role",
      label: "Role",
      options: ["student", "teacher", "parent", "principal", "accountant"],
    },
    { key: "branchId", label: "Campus", required: true },
    { key: "policyId", label: "Custom role policy" },
    { key: "phone", label: "Phone" },
    { key: "status", label: "Status", options: ["Active", "Inactive"] },
  ],
  finance: [
    { key: "reference", label: "Reference", required: true },
    { key: "description", label: "Description", required: true },
    { key: "kind", label: "Transaction type", options: ["Income", "Expense"] },
    { key: "category", label: "Category", required: true },
    { key: "amount", label: "Amount (INR)", type: "number", required: true },
    { key: "date", label: "Transaction date", type: "date", required: true },
    { key: "branchId", label: "Campus", required: true },
    {
      key: "status",
      label: "Payment status",
      options: ["Paid", "Pending", "Overdue"],
    },
  ],
  templates: [
    { key: "name", label: "Template name", required: true },
    {
      key: "category",
      label: "Category",
      options: ["Attendance", "Fees", "Announcements"],
    },
    { key: "body", label: "Message body", required: true },
  ],
  schools: [
    { key: "name", label: "School name", required: true },
    { key: "code", label: "School code", required: true },
    {
      key: "ownerEmail",
      label: "Owner login email",
      type: "email",
      required: true,
    },
    {
      key: "plan",
      label: "Plan",
      options: ["Starter", "Growth", "Enterprise"],
    },
    {
      key: "monthlyFee",
      label: "Monthly subscription (INR)",
      type: "number",
      required: true,
    },
  ],
};
const titles: Record<Resource, [string, string, string]> = {
  branches: [
    "Every campus, connected",
    "Manage campus details and capacity across your school.",
    "Add campus",
  ],
  users: [
    "Your school community",
    "Manage directory records, campus assignments, and financial roles.",
    "Add person",
  ],
  finance: [
    "Clarity in every transaction",
    "Review income, expenses, outstanding balances, and financial reports.",
    "Add transaction",
  ],
  templates: [
    "Words that keep you connected",
    "Edit your school’s WhatsApp templates. Modified templates return to Draft for approval.",
    "New template",
  ],
  schools: [
    "Schools, connected at scale",
    "Manage subscriptions and access across your platform.",
    "Create school",
  ],
};
function getValue(record: object, key: string): string {
  const value = Object.entries(record).find(([name]) => name === key)?.[1];
  return typeof value === "string" || typeof value === "number"
    ? String(value)
    : "";
}
export default function Records({ resource }: { resource: Resource }) {
  const profile = useAuth((s) => s.profile)!;
  const scope = { schoolId: profile.schoolId };
  const [search, setSearch] = useState("");
  const debounced = useDebounce(search);
  const [page, setPage] = useState(0);
  const [editing, setEditing] = useState<AdminModels[Resource] | "new" | null>(
    null,
  );
  const [pendingDelete, setPendingDelete] = useState<
    AdminModels[Resource] | null
  >(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [importRows, setImportRows] = useState<AdminModels["users"][]>([]);
  const [receipt, setReceipt] = useState<{
    email: string;
    password: string;
  } | null>(null);
  const [action, setAction] = useState<{
    school: AdminModels["schools"];
    status: AdminModels["schools"]["status"];
  } | null>(null);
  const [statusFilter, setStatusFilter] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const filters = {
    ...(statusFilter ? { status: statusFilter } : {}),
    ...(roleFilter ? { role: roleFilter } : {}),
  };
  const query = useAdminList(resource, scope, {
    search: debounced,
    page,
    pageSize: 12,
    filters,
    from,
    to,
  });
  const campuses = useAdminList(
    "branches",
    scope,
    { pageSize: 500 },
    resource !== "schools",
  );
  const policies = useAdminList(
    "roles",
    scope,
    { pageSize: 500 },
    resource === "users",
  );
  const formSchema = useMemo(
    () =>
      z
        .record(z.string(), z.string())
        .superRefine((values: Record<string, string>, context) => {
          for (const field of fields[resource]) {
            const value = values[field.key]?.trim() ?? "";
            if (field.required && !value)
              context.addIssue({
                code: "custom",
                path: [field.key],
                message: `${field.label} is required.`,
              });
            if (field.key === "body" && value.length < 10)
              context.addIssue({
                code: "custom",
                path: [field.key],
                message: "Enter a message with at least 10 characters.",
              });
            if (
              field.type === "email" &&
              !z.string().email().safeParse(value).success
            )
              context.addIssue({
                code: "custom",
                path: [field.key],
                message: "Enter a valid email address.",
              });
            if (
              field.type === "number" &&
              (!Number.isFinite(Number(value)) ||
                Number(value) < (field.key === "monthlyFee" ? 0 : 1))
            )
              context.addIssue({
                code: "custom",
                path: [field.key],
                message: "Enter a valid positive amount.",
              });
          }
        }),
    [resource],
  );
  const {
    register,
    reset,
    setValue,
    watch,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<Record<string, string>>({ resolver: zodResolver(formSchema) });
  const openEditor = useCallback(
    (record: AdminModels[Resource] | "new") => {
      const defaults: Record<string, string> = {};
      for (const field of fields[resource])
        defaults[field.key] =
          record === "new"
            ? (field.options?.[0] ??
              (field.key === "branchId"
                ? (campuses.data?.rows[0]?.id ?? "")
                : field.key === "date"
                  ? new Date().toISOString().slice(0, 10)
                  : ""))
            : getValue(record, field.key);
      reset(defaults);
      setEditing(record);
    },
    [resource, campuses.data, reset],
  );
  const submit = handleSubmit(async (values) => {
    try {
      const repository = await getAdminRepository();
      if (resource === "schools" && editing === "new") {
        const result = await repository.provisionSchool({
          name: values.name!,
          code: values.code!,
          ownerEmail: values.ownerEmail!,
          plan: z.enum(["Starter", "Growth", "Enterprise"]).parse(values.plan),
          monthlyFee: Number(values.monthlyFee),
        });
        setReceipt({ email: result.email, password: result.password });
      } else {
        const numeric = Object.fromEntries(
          fields[resource]
            .filter((field) => field.type === "number")
            .map((field) => [field.key, Number(values[field.key])]),
        );
        const existing =
          editing !== "new" && editing
            ? editing
            : {
                id: crypto.randomUUID(),
                schoolId: profile.schoolId,
                branchId: null,
                version: 1,
                joinedAt: new Date().toISOString().slice(0, 10),
                createdAt: new Date().toISOString().slice(0, 10),
              };
        const record = parseRecord(resource, {
          ...existing,
          ...values,
          ...numeric,
          ...(resource === "users"
            ? { policyId: values.policyId || null }
            : {}),
          ...(resource === "templates" ? { status: "Draft" } : {}),
          ...(resource === "branches" ? { branchId: existing.id } : {}),
        });
        await repository.save(resource, record);
      }
      toast.success(
        resource === "schools" && editing === "new"
          ? "School and owner login created"
          : "Record saved",
      );
      setEditing(null);
      await refreshAdmin();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Unable to save this record",
      );
    }
  });
  const remove = async () => {
    if (!pendingDelete || resource === "schools") return;
    setBusy(true);
    try {
      await (
        await getAdminRepository()
      ).remove(
        resource,
        pendingDelete.id,
        { schoolId: pendingDelete.schoolId },
        pendingDelete.version,
      );
      setPendingDelete(null);
      setSelected([]);
      await refreshAdmin();
      toast.success("Record deleted");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Unable to delete this record",
      );
    } finally {
      setBusy(false);
    }
  };
  const bulkStatus = async (status: "Active" | "Inactive") => {
    setBusy(true);
    const records =
      query.data?.rows.filter((row) => selected.includes(row.id)) ?? [];
    const results = await Promise.allSettled(
      records.map(async (row) =>
        (await getAdminRepository()).save(
          "users",
          parseRecord("users", { ...row, status }),
        ),
      ),
    );
    const failed = results.filter((r) => r.status === "rejected").length;
    toast[failed ? "error" : "success"](
      `${results.length - failed} records updated${failed ? `; ${failed} failed. Refresh and retry.` : ""}`,
    );
    setSelected([]);
    setBusy(false);
    await refreshAdmin();
  };
  const exportAll = async () => {
    setBusy(true);
    try {
      const rows: AdminModels[Resource][] = [];
      const repo = await getAdminRepository();
      let index = 0;
      let total = 1;
      while (rows.length < total) {
        const result = await repo.list(resource, scope, {
          search: debounced,
          page: index++,
          pageSize: 500,
          filters,
          from,
          to,
        });
        rows.push(...result.rows);
        total = result.total;
        if (!result.rows.length) break;
      }
      downloadCsv(
        `campus-${resource}.csv`,
        fields[resource].map((f) => f.label),
        rows.map((row) => fields[resource].map((f) => getValue(row, f.key))),
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Export failed");
    } finally {
      setBusy(false);
    }
  };
  const exportEverything = async () => {
    setBusy(true);
    try {
      if (config.mock) {
        const repo = await getAdminRepository();
        const [branches, users, finance] = await Promise.all([
          repo.list("branches", scope, { page: 0, pageSize: 500 }),
          repo.list("users", scope, { page: 0, pageSize: 500 }),
          repo.list("finance", scope, { page: 0, pageSize: 500 }),
        ]);
        const archive = {
          exportedAt: new Date().toISOString(),
          schoolId: profile.schoolId,
          branches: branches.rows,
          users: users.rows,
          finance: finance.rows,
        };
        const blob = new Blob([JSON.stringify(archive, null, 2)], {
          type: "application/json",
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `school-archive-${profile.schoolId.slice(0, 8)}.json`;
        link.click();
        URL.revokeObjectURL(url);
        toast.success("Complete school archive exported.");
      } else {
        const { client } = await import("../../services/supabase");
        const { data, error } = await client.functions.invoke("export-data", {
          body: { resource: "all", format: "json" },
        });
        if (error || !data?.ok)
          throw new Error(data?.error || error?.message || "Export failed");
        if (data.data?.downloadUrl) {
          window.open(data.data.downloadUrl, "_blank");
          toast.success("Complete school archive ready (valid 15 minutes).");
        }
      }
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Export failed");
    } finally {
      setBusy(false);
    }
  };
  const importCsv = async (file: File) => {
    const parsed = parseCsv(await file.text());
    const header =
      parsed.shift()?.map((h) => h.replace(/^\uFEFF/, "").trim()) ?? [];
    for (const required of ["name", "email", "role", "branchId"])
      if (!header.includes(required))
        throw new Error(`Missing CSV column: ${required}`);
    if (parsed.length > 250)
      throw new Error("Import at most 250 records per file.");
    const seen = new Set<string>();
    const records = parsed.map((row, index) => {
      const values = Object.fromEntries(
        header.map((key, i) => [key, row[i] ?? ""]),
      );
      try {
        const record = parseRecord("users", {
          id: crypto.randomUUID(),
          schoolId: profile.schoolId,
          branchId: null,
          version: 1,
          phone: "",
          status: "Active",
          joinedAt: new Date().toISOString().slice(0, 10),
          ...values,
        });
        if (!campuses.data?.rows.some((b) => b.id === record.branchId))
          throw new Error("Campus is not part of this school.");
        if (seen.has(record.email.toLowerCase()))
          throw new Error("Duplicate email in this file.");
        seen.add(record.email.toLowerCase());
        return record;
      } catch (error) {
        throw new Error(
          `Row ${index + 2}: ${error instanceof Error ? error.message : "Invalid record"}`,
          { cause: error },
        );
      }
    });
    setImportRows(records);
  };
  const confirmImport = async () => {
    setBusy(true);
    let success = 0;
    const failures: string[] = [];
    const repository = await getAdminRepository();
    for (let i = 0; i < importRows.length; i += 5) {
      const results = await Promise.allSettled(
        importRows
          .slice(i, i + 5)
          .map((record) => repository.save("users", record)),
      );
      results.forEach((result) => {
        if (result.status === "fulfilled") success++;
        else
          failures.push(
            result.reason instanceof Error
              ? result.reason.message
              : "Unknown error",
          );
      });
    }
    await refreshAdmin();
    setBusy(false);
    setImportRows([]);
    setImportOpen(false);
    toast[failures.length ? "error" : "success"](
      `${success} imported. ${failures.length ? `${failures.length} failed: ${failures[0]}` : "All records saved."}`,
    );
  };
  const columns = useMemo<ColumnDef<AdminModels[Resource], unknown>[]>(() => {
    const result: ColumnDef<AdminModels[Resource], unknown>[] = [];
    if (resource === "users")
      result.push({
        id: "select",
        header: () => (
          <NeuCheckbox
            label="All"
            checked={
              !!query.data?.rows.length &&
              query.data.rows.every((row) => selected.includes(row.id))
            }
            onChange={(e) =>
              setSelected(
                e.target.checked
                  ? (query.data?.rows.map((row) => row.id) ?? [])
                  : [],
              )
            }
          />
        ),
        cell: ({ row }) => (
          <NeuCheckbox
            label=""
            aria-label={`Select ${getValue(row.original, "name")}`}
            checked={selected.includes(row.original.id)}
            onChange={(e) =>
              setSelected((old) =>
                e.target.checked
                  ? [...old, row.original.id]
                  : old.filter((id) => id !== row.original.id),
              )
            }
          />
        ),
      });
    const visible =
      resource === "finance"
        ? ["description", "amount", "status"]
        : resource === "schools"
          ? ["name", "plan", "status"]
          : resource === "users"
            ? ["name", "role", "status"]
            : resource === "branches"
              ? ["name", "city", "status"]
              : ["name", "category", "status"];
    visible.forEach((key) =>
      result.push({
        id: key,
        accessorFn: (row) => getValue(row, key),
        header: key[0]!.toUpperCase() + key.slice(1),
        cell: ({ row }) =>
          key === "status" ? (
            <NeuBadge
              tone={
                getValue(row.original, key) === "Active" ||
                getValue(row.original, key) === "Paid" ||
                getValue(row.original, key) === "Approved"
                  ? "success"
                  : "warning"
              }
            >
              {getValue(row.original, key)}
            </NeuBadge>
          ) : key === "amount" ? (
            money(Number(getValue(row.original, key)))
          ) : (
            <span className="record-cell">
              <b>{getValue(row.original, key)}</b>
              {key === "name" && (
                <small>
                  {getValue(
                    row.original,
                    resource === "users" ? "email" : "code",
                  )}
                </small>
              )}
            </span>
          ),
      }),
    );
    result.push({
      id: "actions",
      header: "Actions",
      cell: ({ row }) => (
        <div className="table-actions">
          <NeuButton
            variant="ghost"
            aria-label={`Edit ${getValue(row.original, "name") || getValue(row.original, "reference")}`}
            onClick={() => openEditor(row.original)}
          >
            Edit
          </NeuButton>
          {resource === "schools" ? (
            <>
              <NeuButton
                variant="ghost"
                onClick={() =>
                  setAction({
                    school: parseRecord("schools", row.original),
                    status:
                      getValue(row.original, "status") === "Active"
                        ? "Suspended"
                        : "Active",
                  })
                }
              >
                {getValue(row.original, "status") === "Active"
                  ? "Revoke"
                  : "Restore"}
              </NeuButton>
              <NeuButton
                variant="ghost"
                onClick={() =>
                  setAction({
                    school: parseRecord("schools", row.original),
                    status: "Deleted",
                  })
                }
              >
                Remove access
              </NeuButton>
            </>
          ) : (
            <NeuButton
              variant="ghost"
              icon="close"
              aria-label="Delete record"
              onClick={() => setPendingDelete(row.original)}
            />
          )}
        </div>
      ),
    });
    return result;
  }, [resource, query.data, selected, openEditor]);
  return (
    <>
      <AdminHeading
        eyebrow={
          resource === "schools"
            ? "PLATFORM ADMINISTRATION"
            : "YOUR SCHOOL, CONNECTED"
        }
        title={titles[resource][0]}
        description={titles[resource][1]}
      >
        <NeuButton
          icon="download"
          loading={busy}
          onClick={() => void exportAll()}
        >
          Export
        </NeuButton>
        {profile.role === "owner" && (
          <NeuButton
            icon="download"
            loading={busy}
            onClick={() => void exportEverything()}
          >
            Export everything
          </NeuButton>
        )}
        {resource === "users" && (
          <NeuButton icon="upload" onClick={() => setImportOpen(true)}>
            Import CSV
          </NeuButton>
        )}
        <NeuButton
          variant="primary"
          icon="plus"
          onClick={() => openEditor("new")}
        >
          {titles[resource][2]}
        </NeuButton>
      </AdminHeading>
      <NeuCard className={resource === "users" ? "people-table" : ""}>
        <div className="records-toolbar">
          <SearchBar
            value={search}
            onChange={(value) => {
              setSearch(value);
              setPage(0);
              setSelected([]);
            }}
            placeholder={`Search ${resource}…`}
            label={`Search ${resource}`}
          />
          <NeuSelect
            aria-label="Filter status"
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setPage(0);
              setSelected([]);
            }}
          >
            <option value="">All statuses</option>
            {(resource === "finance"
              ? ["Paid", "Pending", "Overdue"]
              : resource === "schools"
                ? ["Active", "Suspended", "Deleted"]
                : resource === "templates"
                  ? ["Draft", "Pending", "Approved"]
                  : ["Active", "Inactive"]
            ).map((status) => (
              <option key={status} value={status}>
                {status}
              </option>
            ))}
          </NeuSelect>
          {resource === "users" && (
            <NeuSelect
              aria-label="Filter role"
              value={roleFilter}
              onChange={(e) => {
                setRoleFilter(e.target.value);
                setPage(0);
                setSelected([]);
              }}
            >
              <option value="">All roles</option>
              {["student", "teacher", "parent", "principal", "accountant"].map(
                (role) => (
                  <option key={role} value={role}>
                    {role}
                  </option>
                ),
              )}
            </NeuSelect>
          )}
          {resource === "finance" && (
            <>
              <DatePicker
                label="From date"
                value={from}
                onChange={(value) => {
                  setFrom(value);
                  setPage(0);
                }}
              />
              <DatePicker
                label="To date"
                value={to}
                onChange={(value) => {
                  setTo(value);
                  setPage(0);
                }}
              />
            </>
          )}
          <NeuBadge>{query.data?.total ?? 0} records</NeuBadge>
          {selected.length > 0 && (
            <div className="bulk-actions">
              <span>{selected.length} selected</span>
              <NeuButton
                disabled={busy}
                onClick={() => void bulkStatus("Active")}
              >
                Activate
              </NeuButton>
              <NeuButton
                disabled={busy}
                onClick={() => void bulkStatus("Inactive")}
              >
                Deactivate
              </NeuButton>
            </div>
          )}
        </div>
        <QueryState query={query}>
          {(data) => (
            <>
              <NeuTable
                data={data.rows}
                columns={columns}
                label={titles[resource][0]}
                rowKey={(row) => row.id}
                renderMobile={(row) => (
                  <div className="record-mobile">
                    <div>
                      <b>
                        {getValue(row, "name") || getValue(row, "description")}
                      </b>
                      <small>
                        {getValue(row, "email") ||
                          getValue(row, "city") ||
                          getValue(row, "category")}
                      </small>
                    </div>
                    <NeuBadge>{getValue(row, "status")}</NeuBadge>
                    <NeuButton variant="ghost" onClick={() => openEditor(row)}>
                      Edit
                    </NeuButton>
                    {resource === "schools" ? (
                      <>
                        <NeuButton
                          variant="ghost"
                          onClick={() =>
                            setAction({
                              school: parseRecord("schools", row),
                              status:
                                getValue(row, "status") === "Active"
                                  ? "Suspended"
                                  : "Active",
                            })
                          }
                        >
                          {getValue(row, "status") === "Active"
                            ? "Revoke"
                            : "Restore"}
                        </NeuButton>
                        <NeuButton
                          variant="ghost"
                          onClick={() =>
                            setAction({
                              school: parseRecord("schools", row),
                              status: "Deleted",
                            })
                          }
                        >
                          Remove access
                        </NeuButton>
                      </>
                    ) : (
                      <NeuButton
                        variant="ghost"
                        aria-label="Delete record"
                        icon="close"
                        onClick={() => setPendingDelete(row)}
                      />
                    )}
                    {resource === "users" && (
                      <NeuCheckbox
                        label="Select"
                        checked={selected.includes(row.id)}
                        onChange={(e) =>
                          setSelected((old) =>
                            e.target.checked
                              ? [...old, row.id]
                              : old.filter((id) => id !== row.id),
                          )
                        }
                      />
                    )}
                  </div>
                )}
              />
              <Pagination page={page} setPage={setPage} total={data.total} />
            </>
          )}
        </QueryState>
      </NeuCard>
      {resource === "users" && (
        <p className="module-footnote">
          Directory records describe your community. Existing linked accounts
          receive role and campus changes on their next token refresh. New login
          invitations require your school’s trusted Auth provisioning process.
        </p>
      )}
      <NeuModal
        open={!!editing}
        onClose={() => !isSubmitting && setEditing(null)}
        title={`${editing === "new" ? "Create" : "Edit"} ${resource === "users" ? "directory record" : resource === "branches" ? "campus" : resource === "finance" ? "transaction" : resource === "schools" ? "school" : "template"}`}
        description={
          resource === "schools" && editing === "new"
            ? "Create a school and a dedicated owner login. Save the generated credentials securely."
            : "Changes are recorded in your audit history."
        }
        footer={
          <>
            <NeuButton onClick={() => setEditing(null)} disabled={isSubmitting}>
              Cancel
            </NeuButton>
            <NeuButton
              variant="primary"
              loading={isSubmitting}
              onClick={() => void submit()}
            >
              Save changes
            </NeuButton>
          </>
        }
      >
        <form className="admin-form" onSubmit={submit}>
          {fields[resource].map((field) =>
            field.options ||
            field.key === "branchId" ||
            field.key === "policyId" ? (
              <NeuSelect
                key={field.key}
                id={`edit-${field.key}`}
                label={field.label}
                {...register(
                  field.key,
                  field.key === "role"
                    ? { onChange: () => setValue("policyId", "") }
                    : undefined,
                )}
              >
                {(field.key === "policyId"
                  ? [
                      { value: "", label: "Standard role policy" },
                      ...(policies.data?.rows
                        .filter(
                          (policy) =>
                            policy.custom && policy.role === watch("role"),
                        )
                        .map((policy) => ({
                          value: policy.id,
                          label: policy.name,
                        })) ?? []),
                    ]
                  : field.key === "branchId"
                    ? (campuses.data?.rows.map((b) => ({
                        value: b.id,
                        label: b.name,
                      })) ?? [])
                    : field.options!.map((value) => ({ value, label: value }))
                ).map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </NeuSelect>
            ) : field.key === "body" ? (
              <div className="field" key={field.key}>
                <label htmlFor="edit-body">Message body</label>
                <textarea
                  id="edit-body"
                  rows={6}
                  aria-invalid={!!errors.body}
                  {...register("body")}
                />
                {errors.body?.message && (
                  <span className="field-error">{errors.body.message}</span>
                )}
              </div>
            ) : (
              <NeuInput
                key={field.key}
                id={`edit-${field.key}`}
                label={field.label}
                type={field.type ?? "text"}
                error={errors[field.key]?.message}
                readOnly={
                  resource === "schools" &&
                  editing !== "new" &&
                  ["code", "ownerEmail"].includes(field.key)
                }
                {...register(field.key)}
              />
            ),
          )}
          <button type="submit" className="sr-only" tabIndex={-1}>
            Save
          </button>
        </form>
      </NeuModal>
      <ConfirmDialog
        open={!!pendingDelete}
        onClose={() => setPendingDelete(null)}
        onConfirm={() => void remove()}
        title="Delete this record?"
        description="This removes the record and writes an audit event. This action cannot be undone in the app."
        confirmText={
          pendingDelete
            ? getValue(pendingDelete, "name") ||
              getValue(pendingDelete, "reference")
            : ""
        }
        loading={busy}
      />
      <ConfirmDialog
        open={!!action}
        onClose={() => setAction(null)}
        title={
          action?.status === "Suspended"
            ? "Revoke school access?"
            : action?.status === "Deleted"
              ? "Remove school access?"
              : "Restore school access?"
        }
        description="The school’s records are retained. Suspended schools cannot sign in or read protected data."
        confirmText={action?.school.code}
        loading={busy}
        onConfirm={() => {
          if (!action) return;
          setBusy(true);
          void getAdminRepository()
            .then((repo) =>
              repo.save("schools", { ...action.school, status: action.status }),
            )
            .then(async () => {
              setAction(null);
              await refreshAdmin();
              toast.success("School access updated");
            })
            .catch((error) =>
              toast.error(
                error instanceof Error ? error.message : "Update failed",
              ),
            )
            .finally(() => setBusy(false));
        }}
      />
      <NeuModal
        open={importOpen}
        onClose={() => !busy && setImportOpen(false)}
        title="Import your school community"
        description="CSV columns: name,email,role,branchId,phone,status. Required: name,email,role,branchId. Up to 250 rows."
        footer={
          importRows.length > 0 && (
            <NeuButton
              variant="primary"
              loading={busy}
              onClick={() => void confirmImport()}
            >
              Import {importRows.length} validated records
            </NeuButton>
          )
        }
      >
        <NeuButton
          variant="ghost"
          onClick={() =>
            downloadCsv(
              "people-import-template.csv",
              ["name", "email", "role", "branchId", "phone", "status"],
              [
                [
                  "Sample Student",
                  "student@example.edu",
                  "student",
                  campuses.data?.rows[0]?.id ?? "",
                  "",
                  "Active",
                ],
              ],
            )
          }
        >
          Download CSV template
          <Icon name="download" size={16} />
        </NeuButton>
        <FileUpload accept=".csv" onUpload={importCsv} />
        {importRows.length > 0 && (
          <div className="import-preview">
            <b>{importRows.length} records validated</b>
            {importRows.slice(0, 5).map((row) => (
              <p key={row.id}>
                {row.name} · {row.email}
              </p>
            ))}
          </div>
        )}
      </NeuModal>
      <NeuModal
        open={!!receipt}
        onClose={() => setReceipt(null)}
        title="Your school is ready"
        description="These credentials are shown once. Copy them before closing."
      >
        {receipt && (
          <div className="credentials">
            <NeuInput
              label="Owner login"
              id="new-owner-email"
              readOnly
              value={receipt.email}
            />
            <NeuInput
              label="Generated password"
              id="new-owner-password"
              readOnly
              value={receipt.password}
            />
            <NeuButton
              icon="copy"
              onClick={() => {
                void navigator.clipboard
                  .writeText(
                    `Email: ${receipt.email}\nPassword: ${receipt.password}`,
                  )
                  .then(() => toast.success("Credentials copied"))
                  .catch(() =>
                    toast.error("Select and copy the credentials manually."),
                  );
              }}
            >
              Copy credentials
            </NeuButton>
          </div>
        )}
      </NeuModal>
    </>
  );
}
