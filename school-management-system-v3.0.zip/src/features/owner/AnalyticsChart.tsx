import { memo } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useReducedMotion } from "framer-motion";
export type ChartPoint = { label: string; value: number; secondary?: number };
function AnalyticsChart({
  data,
  kind = "area",
  valueLabel = "Amount",
  secondaryLabel,
}: {
  data: ChartPoint[];
  kind?: "area" | "bar";
  valueLabel?: string;
  secondaryLabel?: string;
}) {
  const reduced = useReducedMotion();
  const shared = (
    <>
      <CartesianGrid
        vertical={false}
        stroke="var(--line)"
        strokeDasharray="3 5"
      />
      <XAxis
        dataKey="label"
        tick={{ fill: "var(--muted)", fontSize: 10 }}
        axisLine={false}
        tickLine={false}
      />
      <YAxis
        tick={{ fill: "var(--muted)", fontSize: 10 }}
        axisLine={false}
        tickLine={false}
        width={45}
      />
      <Tooltip
        contentStyle={{
          background: "var(--base)",
          border: "1px solid var(--line)",
          borderRadius: 12,
          color: "var(--text)",
          fontSize: 12,
        }}
      />
    </>
  );
  return (
    <div
      className="analytics-chart"
      role="img"
      aria-label={`${valueLabel} chart. ${data.map((point) => `${point.label}: ${point.value}${point.secondary !== undefined ? `, ${secondaryLabel}: ${point.secondary}` : ""}`).join("; ")}`}
    >
      <ResponsiveContainer width="100%" height="100%">
        {kind === "bar" ? (
          <BarChart data={data}>
            {shared}
            <Bar
              dataKey="value"
              name={valueLabel}
              fill="#7BAFD9"
              radius={[4, 4, 0, 0]}
              isAnimationActive={!reduced}
              animationDuration={300}
            />
            {secondaryLabel && (
              <Bar
                dataKey="secondary"
                name={secondaryLabel}
                fill="#A99BD6"
                radius={[4, 4, 0, 0]}
                isAnimationActive={!reduced}
                animationDuration={300}
              />
            )}
          </BarChart>
        ) : (
          <AreaChart data={data}>
            {shared}
            <defs>
              <linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#7BAFD9" stopOpacity={0.3} />
                <stop offset="100%" stopColor="#7BAFD9" stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey="value"
              name={valueLabel}
              stroke="#7BAFD9"
              fill="url(#chart-fill)"
              strokeWidth={2}
              isAnimationActive={!reduced}
              animationDuration={300}
            />
            {secondaryLabel && (
              <Area
                type="monotone"
                dataKey="secondary"
                name={secondaryLabel}
                stroke="#A99BD6"
                fill="transparent"
                strokeWidth={2}
                isAnimationActive={!reduced}
                animationDuration={300}
              />
            )}
          </AreaChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
export default memo(AnalyticsChart);
