import { useState } from "react";
import { roleLabels } from "../../lib/permissions";
import type { Role } from "../../types/domain";
import { moduleKeys, definition, type ModuleKey } from "../school/model";
import WorkflowPage from "../school/Workspace";
import { AdminHeading } from "./shared";
import { NeuBadge, NeuSelect } from "../../components/ui/primitives";
export default function ViewAs() {
  const [role, setRole] = useState<Role>("principal");
  const [selected, setSelected] = useState<ModuleKey>("admissions");
  const available = moduleKeys.filter((key) =>
    definition(key).readers.includes(role),
  );
  const module = available.includes(selected) ? selected : available[0]!;
  return (
    <>
      <AdminHeading
        title="A different view. The same community."
        description="Read-only role workspace previews using your authorized Owner campus scope."
      >
        <NeuSelect
          aria-label="Preview role"
          value={role}
          onChange={(e) => setRole(e.target.value as Role)}
        >
          {(["principal", "teacher", "parent", "accountant"] as const).map(
            (value) => (
              <option key={value} value={value}>
                {roleLabels[value]}
              </option>
            ),
          )}
        </NeuSelect>
        <NeuSelect
          aria-label="Preview module"
          value={module}
          onChange={(e) => setSelected(e.target.value as ModuleKey)}
        >
          {available.map((key) => (
            <option value={key} key={key}>
              {definition(key).title}
            </option>
          ))}
        </NeuSelect>
      </AdminHeading>
      <div className="readonly-banner">
        <NeuBadge>READ ONLY</NeuBadge>
        <p>
          Your Owner session stays active. This preview does not impersonate
          another account or change data.
        </p>
      </div>
      <WorkflowPage module={module} readOnly />
    </>
  );
}
