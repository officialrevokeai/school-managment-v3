import { lazy, Suspense, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useAdminList } from "../../hooks/useAdmin";
import { getAdminRepository } from "../../services/admin";
import { useAuth } from "../../store/auth";
import { useUI } from "../../store/ui";
import { AdminHeading } from "./shared";
import {
  NeuBadge,
  NeuCard,
  NeuSelect,
  Skeleton,
  StatCard,
  ErrorState,
} from "../../components/ui/primitives";
import { Icon, type IconName } from "../../components/ui/Icon";
import { money } from "../../lib/csv";
import { homeFor } from "../../lib/permissions";
const Chart = lazy(() => import("./AnalyticsChart"));
export default function Dashboard({ master = false }: { master?: boolean }) {
  const profile = useAuth((s) => s.profile)!;
  const branch = useUI((s) => s.branchId);
  const [campus, setCampus] = useState("all");
  const scope = {
    schoolId: profile.schoolId,
    ...(campus === "current" && branch ? { branchId: branch } : {}),
  };
  const query = useQuery({
    queryKey: ["admin", profile.id, "summary", scope],
    queryFn: async () => (await getAdminRepository()).summary(scope),
  });
  const audit = useAdminList(
    "audit",
    { schoolId: profile.schoolId },
    { pageSize: 5 },
  );
  const base = homeFor(profile.role);
  const data = query.data;
  const shortcuts: [string, string, IconName][] = master
    ? [
        ["schools", "Manage schools", "building"],
        ["roles", "Global role control", "shield"],
        ["revenue", "School-wise revenue", "wallet"],
        ["monitoring", "Live operations", "monitor"],
      ]
    : [
        ["branches", "Manage campuses", "building"],
        ["roles", "Roles & permissions", "shield"],
        ["monitoring", "Live operations", "monitor"],
        ["settings", "School settings", "settings"],
        ["view-as", "View as another role", "eye"],
      ];
  return (
    <>
      <AdminHeading
        eyebrow={master ? "PLATFORM OVERVIEW" : "YOUR SCHOOL, AT A GLANCE"}
        title={
          master
            ? "A bigger picture. A better platform."
            : `Welcome back, ${profile.name.split(" ")[0]}`
        }
        description={
          master
            ? "School subscriptions and platform health, in one place."
            : "A clear view of your school community and financial performance."
        }
      >
        {!master && (
          <NeuSelect
            aria-label="Dashboard campus scope"
            value={campus}
            onChange={(e) => setCampus(e.target.value)}
          >
            <option value="all">All assigned campuses</option>
            <option value="current">Selected campus</option>
          </NeuSelect>
        )}
        <Link
          className="neu-button primary"
          to={`${base}/${master ? "schools" : "people"}`}
        >
          <Icon name="plus" />
          {master ? "Manage schools" : "Manage community"}
        </Link>
      </AdminHeading>
      {query.isPending ? (
        <div style={{ minHeight: 480 }}>
          <div className="admin-stat-grid">
            <Skeleton className="card-skeleton" style={{ height: 110 }} />
            <Skeleton className="card-skeleton" style={{ height: 110 }} />
            <Skeleton className="card-skeleton" style={{ height: 110 }} />
            <Skeleton className="card-skeleton" style={{ height: 110 }} />
          </div>
          <div className="dashboard-main-grid" style={{ marginTop: 24 }}>
            <Skeleton className="card-skeleton" style={{ height: 320 }} />
            <Skeleton className="card-skeleton" style={{ height: 320 }} />
          </div>
        </div>
      ) : query.isError || !data ? (
        <ErrorState
          description={query.error?.message}
          onRetry={() => void query.refetch()}
        />
      ) : (
        <>
          <div className="admin-stat-grid">
            {master ? (
              <>
                <StatCard
                  label="Schools on platform"
                  value={data.schools}
                  icon="building"
                  detail="Registered schools"
                />
                <StatCard
                  label="Active subscriptions"
                  value={data.active}
                  icon="shield"
                  detail="Schools with active access"
                />
                <StatCard
                  label="Monthly recurring revenue"
                  value={data.mrr}
                  suffix=" INR"
                  icon="wallet"
                  detail="Contracted subscriptions"
                />
                <StatCard
                  label="Access suspended"
                  value={data.suspended}
                  icon="lock"
                  detail="Retained for audit history"
                />
              </>
            ) : (
              <>
                <StatCard
                  label="Students enrolled"
                  value={data.students}
                  icon="graduation"
                  detail="Active directory records"
                />
                <StatCard
                  label="Staff & faculty"
                  value={data.staff}
                  icon="users"
                  detail="Your connected school community"
                />
                <StatCard
                  label="Fees collected"
                  value={data.income}
                  suffix=" INR"
                  icon="wallet"
                  detail="Paid income entries"
                />
                <StatCard
                  label="Outstanding fees"
                  value={data.outstanding}
                  suffix=" INR"
                  icon="clock"
                  detail="Pending and overdue income"
                />
              </>
            )}
          </div>
          <div className="dashboard-main-grid">
            <NeuCard>
              <div className="section-heading">
                <div>
                  <h2>{master ? "Revenue by school" : "Income & expenses"}</h2>
                  <p>
                    {master
                      ? "Top 10 monthly subscription commitments"
                      : "Last six months · paid transactions"}
                  </p>
                </div>
                <NeuBadge>INR</NeuBadge>
              </div>
              <Suspense fallback={<Skeleton className="chart-skeleton" />}>
                <Chart
                  data={data.revenue}
                  valueLabel={master ? "Subscription" : "Income"}
                  secondaryLabel={master ? undefined : "Expenses"}
                  kind={master ? "bar" : "area"}
                />
              </Suspense>
              {!master && (
                <div className="chart-summary">
                  <span>
                    Net income <b>{money(data.income - data.expenses)}</b>
                  </span>
                  <span>
                    Expenses <b>{money(data.expenses)}</b>
                  </span>
                </div>
              )}
            </NeuCard>
            <NeuCard>
              <div className="section-heading">
                <div>
                  <h2>{master ? "Subscription mix" : "Campus enrollment"}</h2>
                  <p>
                    {master
                      ? "Active plans across your platform"
                      : "Active students from your directory"}
                  </p>
                </div>
                <Icon name="building" />
              </div>
              <Suspense fallback={<Skeleton className="chart-skeleton" />}>
                <Chart
                  kind="bar"
                  data={data.enrollment}
                  valueLabel={master ? "Schools" : "Students"}
                />
              </Suspense>
            </NeuCard>
          </div>
          {!master && (
            <NeuCard>
              <div className="section-heading">
                <div>
                  <h2>Attendance at a glance</h2>
                  <p>
                    Monthly recorded attendance summaries · percentage present
                  </p>
                </div>
                <NeuBadge>%</NeuBadge>
              </div>
              {data.attendance.length ? (
                <Suspense fallback={<Skeleton className="chart-skeleton" />}>
                  <Chart data={data.attendance} valueLabel="Attendance (%)" />
                </Suspense>
              ) : (
                <p className="module-footnote">
                  No attendance summaries have been recorded for this campus.
                </p>
              )}
            </NeuCard>
          )}
          <div className="dashboard-main-grid">
            <NeuCard>
              <div className="section-heading">
                <div>
                  <h2>Recent activity</h2>
                  <p>A clear trail of changes across your workspace.</p>
                </div>
                <Link className="text-button" to={`${base}/audit`}>
                  View audit trail
                  <Icon name="arrow-right" size={15} />
                </Link>
              </div>
              {audit.isPending ? (
                <Skeleton className="card-skeleton" />
              ) : audit.isError ? (
                <ErrorState
                  description="Activity could not be loaded."
                  onRetry={() => void audit.refetch()}
                />
              ) : (
                audit.data?.rows.map((item) => (
                  <div className="activity-row" key={item.id}>
                    <span className="icon-tile small">
                      <Icon name="shield" />
                    </span>
                    <div>
                      <b>{item.action}</b>
                      <small>
                        {item.actor} · {item.resource}
                      </small>
                    </div>
                    <time>
                      {new Date(item.createdAt).toLocaleDateString("en-IN")}
                    </time>
                  </div>
                ))
              )}
            </NeuCard>
            <NeuCard className="owner-shortcuts">
              <h2>A few useful shortcuts</h2>
              <p>Keep your school moving.</p>
              {shortcuts.map(([path, label, icon]) => (
                <Link key={path} to={`${base}/${path}`}>
                  <Icon name={icon} />
                  <span>{label}</span>
                  <Icon name="arrow-up-right" size={16} />
                </Link>
              ))}
            </NeuCard>
          </div>
        </>
      )}
    </>
  );
}
