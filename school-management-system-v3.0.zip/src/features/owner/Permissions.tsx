import { useEffect, useState } from "react";
import { useAdminList, refreshAdmin } from "../../hooks/useAdmin";
import { useAuth } from "../../store/auth";
import { getAdminRepository } from "../../services/admin";
import {
  permissions,
  roleLabels,
  rolePermissions,
  type Permission,
} from "../../lib/permissions";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuCheckbox,
  NeuInput,
  NeuSelect,
} from "../../components/ui/primitives";
import { ConfirmDialog, NeuModal } from "../../components/ui/overlays";
import { AdminHeading, QueryState } from "./shared";
import type { AdminModels } from "../../types/admin";
import { toast } from "sonner";
export const platformScope = "00000000-0000-0000-0000-000000000000";
export default function Permissions({ master = false }: { master?: boolean }) {
  const profile = useAuth((s) => s.profile)!;
  const schoolId = master ? platformScope : profile.schoolId;
  const query = useAdminList("roles", { schoolId }, { pageSize: 50 });
  const [draft, setDraft] = useState<AdminModels["roles"][]>([]);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [roleName, setRoleName] = useState("");
  const [baseRole, setBaseRole] = useState<
    "teacher" | "principal" | "parent" | "student" | "accountant"
  >("teacher");
  const [dirty, setDirty] = useState(false);
  useEffect(() => {
    if (query.data && !dirty)
      setDraft(
        query.data.rows.length
          ? query.data.rows
          : (
              [
                "owner",
                "principal",
                "teacher",
                "parent",
                "student",
                "accountant",
              ] as const
            ).map((role) => ({
              id: crypto.randomUUID(),
              schoolId,
              branchId: null,
              version: 1,
              name: roleLabels[role],
              custom: false,
              role,
              permissions: [...rolePermissions[role]],
            })),
      );
  }, [query.data, dirty, schoolId]);
  const toggle = (id: string, permission: Permission) => {
    setDirty(true);
    setDraft((old) =>
      old.map((row) =>
        row.id === id
          ? {
              ...row,
              permissions: row.permissions.includes(permission)
                ? row.permissions.filter((p) => p !== permission)
                : [...row.permissions, permission],
            }
          : row,
      ),
    );
  };
  const save = async () => {
    setBusy(true);
    const records = draft.filter((row) => row.role !== "owner");
    const results = await Promise.allSettled(
      records.map(async (row) =>
        (await getAdminRepository()).save("roles", row),
      ),
    );
    const failed = results.filter((r) => r.status === "rejected").length;
    setBusy(false);
    setConfirm(false);
    setDirty(false);
    await refreshAdmin();
    toast[failed ? "error" : "success"](
      failed
        ? `${failed} role policies could not be saved. Refresh before retrying.`
        : "Role policies saved",
    );
  };
  return (
    <>
      <AdminHeading
        eyebrow={master ? "GLOBAL ROLE CONTROL" : "ACCESS, WITH INTENTION"}
        title={
          master
            ? "Set the platform’s role defaults"
            : "The right access, for every role"
        }
        description="School data always remains scoped to assigned campuses. Owner and platform privileges cannot be granted through this editor."
      >
        <NeuButton icon="plus" onClick={() => setCreateOpen(true)}>
          Create role
        </NeuButton>
        <NeuButton
          disabled={!dirty}
          variant="primary"
          icon="shield"
          onClick={() => setConfirm(true)}
        >
          Review & save
        </NeuButton>
      </AdminHeading>
      <QueryState query={query}>
        {() => (
          <NeuCard>
            <div
              className="permission-matrix"
              role="group"
              aria-label="Role permission matrix"
            >
              {draft.map((row) => (
                <section key={row.id} className="permission-role">
                  <div className="section-heading">
                    <h2>{row.name}</h2>
                    {row.role === "owner" && (
                      <NeuBadge>Full access · protected</NeuBadge>
                    )}
                  </div>
                  {permissions
                    .filter((p) => p !== "master.manage")
                    .map((permission) => (
                      <NeuCheckbox
                        key={permission}
                        label={permission.replaceAll(".", " · ")}
                        checked={row.permissions.includes(permission)}
                        disabled={
                          row.role === "owner" ||
                          permission === "workspace.read"
                        }
                        onChange={() => toggle(row.id, permission)}
                      />
                    ))}
                </section>
              ))}
            </div>
          </NeuCard>
        )}
      </QueryState>
      <p className="module-footnote">
        These policies configure school module access. Database RLS remains
        authoritative; future modules must use these policies in their data
        authorization. Platform defaults apply when provisioning new schools.
      </p>
      <NeuModal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Create a school role"
        description="Use a standard role as the foundation, then choose its permissions."
        footer={
          <NeuButton
            variant="primary"
            disabled={roleName.trim().length < 2}
            onClick={() => {
              setDraft((old) => [
                ...old,
                {
                  id: crypto.randomUUID(),
                  schoolId,
                  branchId: null,
                  version: 1,
                  name: roleName.trim(),
                  role: baseRole,
                  custom: true,
                  permissions: [...rolePermissions[baseRole]],
                },
              ]);
              setDirty(true);
              setCreateOpen(false);
              setRoleName("");
            }}
          >
            Add role to matrix
          </NeuButton>
        }
      >
        <div className="admin-form">
          <NeuInput
            id="custom-role-name"
            label="Role name"
            value={roleName}
            onChange={(e) => setRoleName(e.target.value)}
          />
          <NeuSelect
            id="custom-role-base"
            label="Base role"
            value={baseRole}
            onChange={(e) => setBaseRole(e.target.value as typeof baseRole)}
          >
            {(
              [
                "teacher",
                "principal",
                "parent",
                "student",
                "accountant",
              ] as const
            ).map((role) => (
              <option value={role} key={role}>
                {roleLabels[role]}
              </option>
            ))}
          </NeuSelect>
        </div>
      </NeuModal>
      <ConfirmDialog
        open={confirm}
        onClose={() => setConfirm(false)}
        title="Save role policies?"
        description="Review the permissions before saving. These changes affect this school’s access policy and are recorded in the audit trail."
        confirmText="SAVE ACCESS"
        loading={busy}
        onConfirm={() => void save()}
      />
    </>
  );
}
