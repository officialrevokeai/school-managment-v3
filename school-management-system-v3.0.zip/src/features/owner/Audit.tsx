import { useState } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { useAuth } from "../../store/auth";
import { useAdminList } from "../../hooks/useAdmin";
import { useDebounce } from "../../hooks/useDebounce";
import { AdminHeading, Pagination, QueryState } from "./shared";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  DatePicker,
  SearchBar,
} from "../../components/ui/primitives";
import { NeuTable } from "../../components/ui/NeuTable";
import { getAdminRepository } from "../../services/admin";
import { downloadCsv } from "../../lib/csv";
import type { AdminModels } from "../../types/admin";
import { toast } from "sonner";
const columns: ColumnDef<AdminModels["audit"], unknown>[] = [
  { accessorKey: "actor", header: "User" },
  { accessorKey: "action", header: "Action" },
  {
    accessorKey: "resource",
    header: "Module",
    cell: (info) => <NeuBadge>{String(info.getValue())}</NeuBadge>,
  },
  {
    accessorKey: "createdAt",
    header: "Date",
    cell: (info) => new Date(String(info.getValue())).toLocaleString("en-IN"),
  },
];
export default function Audit() {
  const profile = useAuth((s) => s.profile)!;
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [page, setPage] = useState(0);
  const [busy, setBusy] = useState(false);
  const debounced = useDebounce(search);
  const scope = { schoolId: profile.schoolId };
  const query = useAdminList("audit", scope, {
    search: debounced,
    from,
    to,
    page,
    pageSize: 12,
  });
  const exportAll = async () => {
    setBusy(true);
    try {
      const rows: AdminModels["audit"][] = [];
      const repository = await getAdminRepository();
      let total = 1;
      let index = 0;
      while (rows.length < total) {
        const result = await repository.list("audit", scope, {
          search: debounced,
          from,
          to,
          page: index++,
          pageSize: 500,
        });
        rows.push(...result.rows);
        total = result.total;
        if (!result.rows.length) break;
      }
      downloadCsv(
        "school-audit.csv",
        ["User", "Action", "Module", "Details", "Date"],
        rows.map((row) => [
          row.actor,
          row.action,
          row.resource,
          row.details,
          row.createdAt,
        ]),
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Export failed");
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <AdminHeading
        title="Every change tells a story"
        description="An append-only record of administrative activity. Search by user, action, or module."
      >
        <NeuButton
          icon="download"
          loading={busy}
          onClick={() => void exportAll()}
        >
          Export filtered audit
        </NeuButton>
      </AdminHeading>
      <NeuCard>
        <div className="audit-filters">
          <SearchBar
            value={search}
            onChange={(value) => {
              setSearch(value);
              setPage(0);
            }}
            placeholder="User, action, or module…"
          />
          <DatePicker
            label="From date"
            value={from}
            onChange={(value) => {
              setFrom(value);
              setPage(0);
            }}
          />
          <DatePicker
            label="To date"
            value={to}
            onChange={(value) => {
              setTo(value);
              setPage(0);
            }}
          />
        </div>
        <QueryState query={query}>
          {(data) => (
            <>
              <NeuTable
                data={data.rows}
                columns={columns}
                label="Audit events"
                rowKey={(row) => row.id}
                renderMobile={(row) => (
                  <div>
                    <b>{row.action}</b>
                    <p>
                      {row.actor} · {row.resource}
                    </p>
                    <small>
                      {new Date(row.createdAt).toLocaleString("en-IN")}
                    </small>
                  </div>
                )}
              />
              <Pagination page={page} setPage={setPage} total={data.total} />
            </>
          )}
        </QueryState>
      </NeuCard>
    </>
  );
}
