import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../store/auth";
import { homeFor } from "../../lib/permissions";
import { AdminHeading } from "./shared";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  StatCard,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { useRealtimeMonitoring } from "../../hooks/useRealtimeMonitoring";

export default function Monitoring({ master = false }: { master?: boolean }) {
  const profile = useAuth((s) => s.profile)!;
  const base = homeFor(profile.role);
  const stream = useRealtimeMonitoring(master);
  const [filterChannel, setFilterChannel] = useState<string>("all");

  const filteredWhatsApp =
    filterChannel === "all"
      ? stream.whatsappStream
      : stream.whatsappStream.filter(
          (m) => m.status.toLowerCase() === filterChannel,
        );

  return (
    <>
      <AdminHeading
        eyebrow="REAL-TIME TELEMETRY"
        title={
          master
            ? "Platform Operations & Telemetry"
            : "Live School Operations & Telemetry"
        }
        description="Continuous monitoring of school activities, connected members, WhatsApp delivery streams, and edge system health."
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <NeuBadge tone={stream.status === "live" ? "success" : "warning"}>
            <span
              style={{
                display: "inline-block",
                width: 8,
                height: 8,
                borderRadius: "50%",
                backgroundColor:
                  stream.status === "live"
                    ? "#10b981"
                    : stream.status === "reconnecting"
                      ? "#f59e0b"
                      : "#ef4444",
                marginRight: 6,
              }}
            />
            {stream.status === "live"
              ? "Live Stream"
              : stream.status === "reconnecting"
                ? "Reconnecting..."
                : "Offline"}
          </NeuBadge>
          <NeuButton
            variant="secondary"
            onClick={() => window.location.reload()}
          >
            Refresh
          </NeuButton>
        </div>
      </AdminHeading>

      {/* Top 4 Stat Cards */}
      <div className="admin-stat-grid">
        <StatCard
          label="Online Members"
          value={stream.onlineUsers.length}
          icon="users"
          detail="Active Realtime Presence sessions"
        />
        <StatCard
          label="Live Attendance"
          value={stream.metrics.liveAttendancePct}
          suffix="%"
          icon="calendar"
          detail="Today's attendance present rate"
        />
        <StatCard
          label="Live Fee Collection"
          value={stream.metrics.liveFeeCollection}
          suffix=" INR"
          icon="wallet"
          detail="Fees settled today"
        />
        <StatCard
          label="New Admissions"
          value={stream.metrics.newAdmissions}
          icon="graduation"
          detail="Admissions processed (last 7 days)"
        />
      </div>

      {/* Second Row: System Telemetry & WhatsApp Stream */}
      <div className="dashboard-main-grid" style={{ marginTop: 20 }}>
        {/* API & Edge Health */}
        <NeuCard>
          <div className="section-heading">
            <div>
              <h2>API & System Telemetry</h2>
              <p>Edge functions latency, error budgets, and database health.</p>
            </div>
            <NeuBadge tone="neutral">p95 / 24h</NeuBadge>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 14,
              margin: "16px 0",
            }}
          >
            <div
              className="neu-card-inset"
              style={{ padding: "14px 16px", borderRadius: 12 }}
            >
              <small
                style={{ color: "var(--text-secondary)", display: "block" }}
              >
                API Latency (p95)
              </small>
              <div
                style={{
                  fontSize: "1.4rem",
                  fontWeight: 700,
                  color: "var(--text-primary)",
                  marginTop: 4,
                }}
              >
                {stream.metrics.apiLatencyMs} ms
              </div>
              <small style={{ color: "#10b981" }}>
                Normal response profile
              </small>
            </div>

            <div
              className="neu-card-inset"
              style={{ padding: "14px 16px", borderRadius: 12 }}
            >
              <small
                style={{ color: "var(--text-secondary)", display: "block" }}
              >
                API Error Rate
              </small>
              <div
                style={{
                  fontSize: "1.4rem",
                  fontWeight: 700,
                  color: "var(--text-primary)",
                  marginTop: 4,
                }}
              >
                {(stream.metrics.errorRatePct * 100).toFixed(2)}%
              </div>
              <small style={{ color: "#10b981" }}>Well within 0.1% SLO</small>
            </div>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 14,
              marginBottom: 16,
            }}
          >
            <div
              className="neu-card-inset"
              style={{ padding: "14px 16px", borderRadius: 12 }}
            >
              <small
                style={{ color: "var(--text-secondary)", display: "block" }}
              >
                Edge Function Failures
              </small>
              <div
                style={{
                  fontSize: "1.4rem",
                  fontWeight: 700,
                  color: "var(--text-primary)",
                  marginTop: 4,
                }}
              >
                {stream.metrics.edgeFailures}
              </div>
              <small style={{ color: "var(--text-secondary)" }}>
                Dead-letter threshold: 3
              </small>
            </div>

            <div
              className="neu-card-inset"
              style={{ padding: "14px 16px", borderRadius: 12 }}
            >
              <small
                style={{ color: "var(--text-secondary)", display: "block" }}
              >
                Postgres Realtime
              </small>
              <div
                style={{
                  fontSize: "1.4rem",
                  fontWeight: 700,
                  color: "var(--text-primary)",
                  marginTop: 4,
                }}
              >
                Subscribed
              </div>
              <small style={{ color: "#10b981" }}>
                Private school-scoped topic
              </small>
            </div>
          </div>

          <div className="chart-summary">
            <span>
              Security boundaries: <b>RLS Enabled</b>
            </span>
            <span>
              Heartbeat: <b>{stream.lastUpdated}</b>
            </span>
          </div>
        </NeuCard>

        {/* WhatsApp Delivery Stream */}
        <NeuCard>
          <div className="section-heading">
            <div>
              <h2>WhatsApp Delivery Stream</h2>
              <p>Live outbox message status transitions.</p>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              {["all", "delivered", "read"].map((tab) => (
                <button
                  key={tab}
                  className={`neu-chip ${filterChannel === tab ? "active" : ""}`}
                  onClick={() => setFilterChannel(tab)}
                  style={{
                    textTransform: "capitalize",
                    fontSize: "0.8rem",
                    padding: "4px 10px",
                  }}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 10,
              marginTop: 14,
              maxHeight: 320,
              overflowY: "auto",
            }}
          >
            {filteredWhatsApp.length === 0 ? (
              <p className="module-footnote">
                No recent WhatsApp transmissions found.
              </p>
            ) : (
              filteredWhatsApp.map((msg) => (
                <div
                  key={msg.id}
                  className="activity-row"
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <div
                    style={{ display: "flex", alignItems: "center", gap: 12 }}
                  >
                    <span className="icon-tile small">
                      <Icon name="message" />
                    </span>
                    <div>
                      <b style={{ display: "block", fontSize: "0.9rem" }}>
                        {msg.recipient}
                      </b>
                      <small style={{ color: "var(--text-secondary)" }}>
                        {msg.template} ·{" "}
                        {msg.body.length > 38
                          ? msg.body.slice(0, 38) + "..."
                          : msg.body}
                      </small>
                    </div>
                  </div>
                  <div
                    style={{ display: "flex", alignItems: "center", gap: 8 }}
                  >
                    <NeuBadge
                      tone={
                        msg.status === "Read"
                          ? "success"
                          : msg.status === "Delivered"
                            ? "neutral"
                            : msg.status === "Failed"
                              ? "warning"
                              : "accent"
                      }
                    >
                      {msg.status}
                    </NeuBadge>
                    <time
                      style={{
                        fontSize: "0.75rem",
                        color: "var(--text-secondary)",
                      }}
                    >
                      {new Date(msg.created_at).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </time>
                  </div>
                </div>
              ))
            )}
          </div>
        </NeuCard>
      </div>

      {/* Third Row: Audit Feed & Security Alerts */}
      <div className="dashboard-main-grid" style={{ marginTop: 20 }}>
        {/* Live Audit Feed */}
        <NeuCard>
          <div className="section-heading">
            <div>
              <h2>Audit Activity Stream</h2>
              <p>Real-time log of administrative and workflow operations.</p>
            </div>
            <Link className="text-button" to={`${base}/audit`}>
              Full Audit Trail
              <Icon name="arrow-right" size={15} />
            </Link>
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 10,
              marginTop: 14,
            }}
          >
            {stream.auditFeed.map((item) => (
              <div key={item.id} className="activity-row">
                <span className="icon-tile small">
                  <Icon name="shield" />
                </span>
                <div>
                  <b>{item.action}</b>
                  <small>
                    {item.actor} · {item.resource}
                  </small>
                </div>
                <time>
                  {new Date(item.created_at).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </time>
              </div>
            ))}
          </div>
        </NeuCard>

        {/* Security Alerts */}
        <NeuCard>
          <div className="section-heading">
            <div>
              <h2>Security Alerts & Anomalies</h2>
              <p>
                System posture, access controls, and rate limit observations.
              </p>
            </div>
            <NeuBadge tone="success">Protected</NeuBadge>
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 12,
              marginTop: 14,
            }}
          >
            {stream.securityAlerts.map((alert) => (
              <div
                key={alert.id}
                className="neu-card-inset"
                style={{
                  padding: 14,
                  borderRadius: 12,
                  display: "flex",
                  gap: 12,
                  alignItems: "flex-start",
                }}
              >
                <span
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    width: 28,
                    height: 28,
                    borderRadius: "50%",
                    backgroundColor:
                      alert.severity === "high" || alert.severity === "critical"
                        ? "#fee2e2"
                        : "#e0e7ff",
                    color:
                      alert.severity === "high" || alert.severity === "critical"
                        ? "#dc2626"
                        : "#4f46e5",
                    flexShrink: 0,
                  }}
                >
                  <Icon name="lock" size={14} />
                </span>
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <b style={{ fontSize: "0.9rem" }}>{alert.title}</b>
                    <time
                      style={{
                        fontSize: "0.75rem",
                        color: "var(--text-secondary)",
                      }}
                    >
                      {new Date(alert.created_at).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </time>
                  </div>
                  <p
                    style={{
                      margin: "4px 0 0",
                      fontSize: "0.85rem",
                      color: "var(--text-secondary)",
                    }}
                  >
                    {alert.message}
                  </p>
                </div>
              </div>
            ))}

            <div className="info-note" style={{ marginTop: 8 }}>
              <Icon name="shield" size={18} />
              <p>
                Row Level Security strictly isolates each tenant. No
                cross-tenant telemetry is visible outside platform admin
                boundaries.
              </p>
            </div>
          </div>
        </NeuCard>
      </div>

      {/* Fourth Row: Online Users via Realtime Presence */}
      <NeuCard style={{ marginTop: 20 }}>
        <div className="section-heading">
          <div>
            <h2>Active Connected Members (Presence)</h2>
            <p>Team members and faculty currently active in the workspace.</p>
          </div>
          <NeuBadge tone="neutral">
            {stream.onlineUsers.length} Connected
          </NeuBadge>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
            gap: 14,
            marginTop: 14,
          }}
        >
          {stream.onlineUsers.map((user) => (
            <div
              key={user.id}
              className="neu-card-inset"
              style={{
                padding: "12px 16px",
                borderRadius: 12,
                display: "flex",
                alignItems: "center",
                gap: 12,
              }}
            >
              <div style={{ position: "relative" }}>
                <div
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: "50%",
                    backgroundColor: "var(--bg-secondary)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: 700,
                    fontSize: "0.85rem",
                  }}
                >
                  {user.name
                    .split(" ")
                    .map((w) => w[0])
                    .join("")
                    .slice(0, 2)
                    .toUpperCase()}
                </div>
                <span
                  style={{
                    position: "absolute",
                    bottom: 0,
                    right: 0,
                    width: 10,
                    height: 10,
                    borderRadius: "50%",
                    backgroundColor: "#10b981",
                    border: "2px solid var(--bg-surface)",
                  }}
                />
              </div>
              <div style={{ overflow: "hidden" }}>
                <b
                  style={{
                    display: "block",
                    fontSize: "0.85rem",
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                  }}
                >
                  {user.name}
                </b>
                <small
                  style={{
                    color: "var(--text-secondary)",
                    display: "block",
                    textTransform: "capitalize",
                  }}
                >
                  {user.role} · {user.onlineAt}
                </small>
              </div>
            </div>
          ))}
        </div>
      </NeuCard>
    </>
  );
}
