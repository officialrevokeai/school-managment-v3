import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../store/auth";
import { useAccess } from "../../hooks/useAccess";
import { getNavigation, moduleReady } from "../../lib/adminNavigation";
import { homeFor } from "../../lib/permissions";
import {
  NeuBadge,
  NeuCard,
  SearchBar,
  EmptyState,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { AdminHeading } from "../owner/shared";
export default function Directory() {
  const user = useAuth((s) => s.profile)!;
  const { can } = useAccess();
  const [search, setSearch] = useState("");
  const tools = getNavigation(user.role).filter(
    (item) =>
      item.path &&
      !["/directory", "/components", "/preferences"].includes(item.path) &&
      moduleReady(user.role, item.phase) &&
      item.label.toLowerCase().includes(search.toLowerCase()),
  );
  return (
    <>
      <AdminHeading
        title="Your workspace directory"
        description="Find the tools that support your school day."
      />
      <SearchBar
        value={search}
        onChange={setSearch}
        placeholder="Find a workspace…"
      />
      <div className="directory-grid" style={{ marginTop: 24 }}>
        {tools.map((tool) => (
          <NeuCard key={tool.path}>
            <div className="section-heading">
              <Icon name={tool.icon} size={28} />
              <NeuBadge>
                {can(tool.permission) ? "Available" : "Restricted"}
              </NeuBadge>
            </div>
            <h3>{tool.label}</h3>
            <p className="module-footnote">
              {tool.section} · access tailored to your role
            </p>
            {can(tool.permission) ? (
              <Link
                className="neu-button"
                to={`${homeFor(user.role)}${tool.path}`}
              >
                Open workspace
                <Icon name="arrow-right" size={16} />
              </Link>
            ) : (
              <span className="muted">
                Contact your school administrator for access.
              </span>
            )}
          </NeuCard>
        ))}
      </div>
      {!tools.length && (
        <EmptyState
          title="No matching workspaces"
          description="Try another search term."
        />
      )}
    </>
  );
}
