import { Link } from "react-router-dom";
import { Icon } from "../../components/ui/Icon";
import { useAuth } from "../../store/auth";
import { homeFor } from "../../lib/permissions";
export default function StatusPage({
  status,
}: {
  status: "401" | "403" | "404";
}) {
  const profile = useAuth((s) => s.profile);
  const content = {
    "401": [
      "Let’s get you signed in",
      "Sign in securely to access your school workspace.",
    ],
    "403": [
      "This space is restricted",
      "Your role or campus assignment doesn’t grant access to this workspace.",
    ],
    "404": [
      "A little off the timetable",
      "We couldn’t find this page. Your workspace is just a click away.",
    ],
  }[status];
  return (
    <div className="status-page">
      <span className="icon-tile">
        <Icon name={status === "404" ? "search" : "lock"} size={32} />
      </span>
      <span className="eyebrow">{status}</span>
      <h1>{content[0]}</h1>
      <p>{content[1]}</p>
      <Link
        className="neu-button primary"
        to={profile ? homeFor(profile.role) : "/login"}
      >
        <Icon name="arrow-left" size={18} />
        {profile ? "Back to my workspace" : "Go to sign in"}
      </Link>
    </div>
  );
}
