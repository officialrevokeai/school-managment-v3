import {
  NeuAvatar,
  NeuBadge,
  NeuCard,
  NeuRadio,
  NeuToggle,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { useUI, type ThemeChoice } from "../../store/ui";
import { useAuth } from "../../store/auth";
import { roleLabels } from "../../lib/permissions";
import { toast } from "sonner";
export default function Preferences() {
  const { theme, setTheme, emailUpdates, inAppUpdates, setPreference } =
    useUI();
  const profile = useAuth((s) => s.profile)!;
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">MAKE IT YOURS</div>
          <h1>A workspace that feels like you</h1>
          <p>A few thoughtful preferences for your everyday.</p>
        </div>
        <NeuBadge tone="success">
          <Icon name="check" size={13} />
          Saved automatically
        </NeuBadge>
      </div>
      <div className="preferences-grid">
        <NeuCard>
          <div className="section-heading">
            <h2>Your profile</h2>
            <Icon name="user" />
          </div>
          <div className="profile-summary">
            <NeuAvatar name={profile.name} size="lg" />
            <h3>{profile.name}</h3>
            <p>{profile.email}</p>
            <NeuBadge>{roleLabels[profile.role]}</NeuBadge>
          </div>
          <div className="info-note">
            <Icon name="lock" size={17} />
            <p>
              Your school manages your profile, role, and campus assignments.
              Contact your administrator to request a change.
            </p>
          </div>
        </NeuCard>
        <div className="preference-stack">
          <NeuCard>
            <div className="section-heading">
              <div>
                <h2>A familiar look</h2>
                <p>Choose the light that works for you.</p>
              </div>
              <Icon name="palette" />
            </div>
            <div className="theme-options">
              {(
                [
                  { value: "light", label: "Light", icon: "sun" },
                  { value: "dark", label: "Dark", icon: "moon" },
                  { value: "system", label: "Use system", icon: "monitor" },
                ] as const
              ).map((option) => (
                <div
                  className={`theme-option ${theme === option.value ? "selected" : ""}`}
                  key={option.value}
                >
                  <Icon name={option.icon} size={26} />
                  <NeuRadio
                    name="theme"
                    label={option.label}
                    checked={theme === option.value}
                    onChange={() => setTheme(option.value as ThemeChoice)}
                  />
                </div>
              ))}
            </div>
          </NeuCard>
          <NeuCard>
            <div className="section-heading">
              <div>
                <h2>Your notification preferences</h2>
                <p>Saved on this device for your next visit.</p>
              </div>
              <Icon name="bell" />
            </div>
            <NeuToggle
              checked={inAppUpdates}
              onChange={(value) => {
                setPreference("inAppUpdates", value);
                toast.success("Preference saved on this device");
              }}
              label="In-app notification highlights"
              description="Show unread highlights in your workspace."
            />
            <NeuToggle
              checked={emailUpdates}
              onChange={(value) => {
                setPreference("emailUpdates", value);
                toast.success("Preference saved on this device");
              }}
              label="Email update preference"
              description="Your preference is saved locally; email delivery settings arrive with system controls."
            />
          </NeuCard>
        </div>
      </div>
    </>
  );
}
