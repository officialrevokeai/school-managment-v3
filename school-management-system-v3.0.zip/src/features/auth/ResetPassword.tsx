import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useNavigate } from "react-router-dom";
import {
  NeuButton,
  NeuCard,
  NeuInput,
  ThemeToggle,
} from "../../components/ui/primitives";
import { getRepository } from "../../services";
import { useAuth } from "../../store/auth";
const schema = z
  .object({
    password: z
      .string()
      .min(12, "Use at least 12 characters.")
      .regex(/[A-Z]/, "Include an uppercase letter.")
      .regex(/[0-9]/, "Include a number."),
    confirm: z.string(),
  })
  .refine((value) => value.password === value.confirm, {
    path: ["confirm"],
    message: "The passwords do not match.",
  });
export default function ResetPassword() {
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<z.infer<typeof schema>>({ resolver: zodResolver(schema) });
  return (
    <main className="full-screen">
      <NeuCard className="reset-card">
        <div className="section-heading">
          <h1>Set a new password</h1>
          <ThemeToggle />
        </div>
        <p>Open the secure link from your reset email first.</p>
        <form
          onSubmit={handleSubmit(async (values) => {
            try {
              const repository = await getRepository();
              await repository.auth.updatePassword(values.password);
              useAuth.getState().setProfile(null);
              await repository.auth.signOut();
              navigate("/login", { replace: true });
            } catch (reason) {
              setError(
                reason instanceof Error
                  ? reason.message
                  : "Unable to reset your password.",
              );
            }
          })}
        >
          <NeuInput
            label="New password"
            id="new-password"
            autoComplete="new-password"
            type="password"
            error={errors.password?.message}
            {...register("password")}
          />
          <NeuInput
            label="Confirm password"
            id="confirm-password"
            autoComplete="new-password"
            type="password"
            error={errors.confirm?.message}
            {...register("confirm")}
          />
          {error && (
            <p role="alert" className="field-error">
              {error}
            </p>
          )}
          <NeuButton type="submit" variant="primary" loading={isSubmitting}>
            Save password
          </NeuButton>
        </form>
      </NeuCard>
    </main>
  );
}
