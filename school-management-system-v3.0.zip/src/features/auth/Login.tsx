import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCheckbox,
  NeuInput,
  ThemeToggle,
  NeuBadge,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { Icon } from "../../components/ui/Icon";
import { getRepository } from "../../services";
import { useAuth } from "../../store/auth";
import { config } from "../../lib/config";
import { homeFor, roleLabels } from "../../lib/permissions";
import type { Role } from "../../types/domain";
import { queryClient } from "../../lib/query";
import { CampusIllustration } from "../../components/layout/CampusIllustration";
const schema = z.object({
  identifier: z.string().trim().min(1, "Enter your school email or code."),
  password: z.string().min(1, "Enter your password."),
  remember: z.boolean(),
});
type Form = z.infer<typeof schema>;
export default function Login({ master = false }: { master?: boolean }) {
  const [visible, setVisible] = useState(false);
  const [error, setError] = useState("");
  const [reset, setReset] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [sending, setSending] = useState(false);
  const [demoRole, setDemoRole] = useState<Role>(master ? "master" : "owner");
  const [submittingRedirect, setSubmittingRedirect] = useState(false);
  const profile = useAuth((s) => s.profile);
  const navigate = useNavigate();
  const location = useLocation();
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { identifier: "", password: "", remember: true },
  });

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "m") {
        e.preventDefault();
        toast.info(master ? "Switching to School Login..." : "Opening Master Panel...");
        navigate(master ? "/login" : "/sys-master");
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [master, navigate]);
  if (
    profile &&
    !isSubmitting &&
    !submittingRedirect
  ) {
    const destination = master || profile.role !== "master" ? homeFor(profile.role) : "/owner";
    return <Navigate to={destination} replace />;
  }
  const submit = handleSubmit(async (values) => {
    setError("");
    try {
      setSubmittingRedirect(true);
      const repository = await getRepository();
      const signedIn = await repository.auth.signIn({ ...values, master });
      queryClient.clear();
      useAuth.getState().setProfile(signedIn);
      const from = (location.state as { from?: unknown } | null)?.from;
      const home = master || signedIn.role !== "master" ? homeFor(signedIn.role) : "/owner";
      navigate(
        typeof from === "string" &&
          (from === home || from.startsWith(`${home}/`))
          ? from
          : home,
        { replace: true },
      );
    } catch (reason) {
      setSubmittingRedirect(false);
      setError(
        reason instanceof Error
          ? reason.message
          : "Unable to sign in. Please try again.",
      );
    }
  });
  const fillDemo = () => {
    setValue("identifier", `${demoRole}@greenwood.edu`, {
      shouldValidate: true,
    });
    setValue("password", "Campus@2026", { shouldValidate: true });
    setError("");
  };
  const sendReset = async () => {
    const result = z.string().email().safeParse(resetEmail);
    if (!result.success) {
      toast.error("Enter a valid school email address.");
      return;
    }
    setSending(true);
    try {
      await (await getRepository()).auth.resetPassword(result.data);
      toast.success("If this email is registered, a reset link is on its way.");
      setReset(false);
    } catch (reason) {
      toast.error(
        reason instanceof Error
          ? reason.message
          : "Unable to send reset email.",
      );
    } finally {
      setSending(false);
    }
  };
  return (
    <main className="login-page">
      <div className="login-top">
        <div className="brand-container">
          <a href="/" className="brand" aria-label="Campus home">
            <span className="brand-mark">
              <Icon name="graduation" size={27} />
            </span>
            <span>campus</span>
          </a>
          <button
            type="button"
            className="brand-dot brand-dot-button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              toast.info(master ? "Switching to School Login..." : "Opening Master Panel...");
              navigate(master ? "/login" : "/sys-master");
            }}
            title={master ? "School Login" : "Master Portal"}
            aria-label={master ? "Switch to School Login" : "Access Master Portal"}
          >
            .
          </button>
        </div>
        <div className="login-top-right">
          <span className="version-label">SCHOOL MANAGEMENT v3.0</span>
          <ThemeToggle />
        </div>
      </div>
      <div className="login-layout">
        <section className="login-story">
          <NeuBadge tone="accent">
            <Icon name="sparkles" size={14} /> A little less admin. A lot more
            possibility.
          </NeuBadge>
          <h1>
            Great schools.
            <br />
            Connected <span>communities.</span>
          </h1>
          <p>
            One thoughtful workspace for the people
            <br className="desktop-break" /> who make your school extraordinary.
          </p>
          <CampusIllustration />
          <div className="story-bottom">
            <div className="avatar-stack">
              <span>SW</span>
              <span>JW</span>
              <span>PS</span>
              <span>AM</span>
            </div>
            <div>
              <b>Built around your school community</b>
              <small>Every role. Every campus. One connected place.</small>
            </div>
          </div>
        </section>
        <section className="login-form-side">
          <motion.div
            className="login-card neu-card"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="icon-tile login-symbol">
              <Icon name={master ? "shield" : "graduation"} size={30} />
            </span>
            <div className="login-heading">
              <div className="eyebrow">
                {master ? "PLATFORM ADMINISTRATION" : "YOUR SCHOOL, CONNECTED"}
              </div>
              <h2>{master ? "Creator sign in" : "Welcome back"}</h2>
              <p>
                {master
                  ? "Secure access for platform administrators."
                  : "A good day at school starts here."}
              </p>
            </div>
            <motion.form
              onSubmit={submit}
              noValidate
              animate={error ? { x: [0, -4, 4, -3, 3, 0] } : { x: 0 }}
              transition={{ duration: 0.25 }}
            >
              <NeuInput
                label={config.mock ? "School email or code" : "School email"}
                id="identifier"
                icon="mail"
                placeholder={
                  config.mock ? "you@school.edu or GW-001" : "you@school.edu"
                }
                autoComplete="username"
                error={errors.identifier?.message}
                {...register("identifier")}
              />
              <div className="password-field">
                <NeuInput
                  label="Password"
                  id="password"
                  icon="lock"
                  type={visible ? "text" : "password"}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  error={errors.password?.message}
                  {...register("password")}
                />
                <NeuButton
                  type="button"
                  variant="ghost"
                  icon={visible ? "eye-off" : "eye"}
                  aria-label={visible ? "Hide password" : "Show password"}
                  onClick={() => setVisible(!visible)}
                />
              </div>
              <div className="login-options">
                <NeuCheckbox label="Remember me" {...register("remember")} />
                <button
                  type="button"
                  className="text-button"
                  onClick={() => setReset(true)}
                >
                  Forgot password?
                </button>
              </div>
              {error && (
                <div className="form-error" role="alert">
                  <Icon name="error" size={18} />
                  {error}
                </div>
              )}
              <NeuButton
                type="submit"
                variant="primary"
                className="login-submit"
                loading={isSubmitting}
              >
                Sign in to your workspace
                <Icon name="arrow-right" size={18} />
              </NeuButton>
            </motion.form>
            <div className="secure-note">
              <Icon name="shield" size={16} /> Secure access. Just for your
              school.
            </div>
            {config.mock && (
              <div className="demo-box">
                <div>
                  <NeuBadge>DEMO WORKSPACE</NeuBadge>
                  <span>Take a look around</span>
                </div>
                <div className="demo-controls">
                  <select
                    aria-label="Demo role"
                    value={demoRole}
                    onChange={(e) => setDemoRole(e.target.value as Role)}
                  >
                    {(master
                      ? (["master"] as const)
                      : ([
                          "owner",
                          "principal",
                          "teacher",
                          "parent",
                          "student",
                          "accountant",
                        ] as const)
                    ).map((role) => (
                      <option key={role} value={role}>
                        {roleLabels[role]}
                      </option>
                    ))}
                  </select>
                  <NeuButton type="button" variant="ghost" onClick={fillDemo}>
                    Use demo
                    <Icon name="arrow-up-right" size={16} />
                  </NeuButton>
                </div>
                <small>Demo password: Campus@2026</small>
              </div>
            )}
          </motion.div>
          <p className="login-help">
            Trouble signing in?{" "}
            <button
              className="text-button"
              onClick={() =>
                toast.info(
                  "Contact your school office to check your email, role, and campus assignment.",
                )
              }
            >
              Contact your school administrator
              <Icon name="arrow-up-right" size={13} />
            </button>
          </p>
        </section>
      </div>
      <footer className="login-footer">
        <span>
          Smart <i /> Secure <i /> Connected
        </span>
        <span>Made for better school days.</span>
        <span className="footer-copyright">
          © {new Date().getFullYear()} Campus
          <button
            type="button"
            className="hidden-master-btn"
            onClick={() => {
              toast.info(master ? "Switching to School Login..." : "Opening Master Panel...");
              navigate(master ? "/login" : "/sys-master");
            }}
            aria-label={master ? "Standard School Login" : "Platform Master Portal"}
            title={master ? "School Login" : "Master Portal"}
          >
            <Icon name={master ? "graduation" : "shield"} size={11} />
          </button>
        </span>
      </footer>
      <NeuModal
        open={reset}
        onClose={() => setReset(false)}
        title="Let’s get you back in"
        description="Enter your school email and we’ll send you a secure password reset link."
        footer={
          <NeuButton
            variant="primary"
            loading={sending}
            onClick={() => void sendReset()}
          >
            Send reset link
            <Icon name="arrow-right" size={16} />
          </NeuButton>
        }
      >
        <NeuInput
          id="reset-email"
          label="School email"
          type="email"
          value={resetEmail}
          onChange={(e) => setResetEmail(e.target.value)}
          placeholder="you@school.edu"
        />
      </NeuModal>
    </main>
  );
}
