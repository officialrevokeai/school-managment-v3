import { useState } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCard,
  NeuBadge,
  NeuSelect,
  SearchBar,
  DatePicker,
  Skeleton,
  ErrorState,
} from "../../components/ui/primitives";
import { NeuTable } from "../../components/ui/NeuTable";
import { AdminHeading, Pagination } from "../owner/shared";
import { getAdminRepository } from "../../services/admin";
import { useAuth } from "../../store/auth";
import { downloadCsv } from "../../lib/csv";
import type { AdminModels } from "../../types/admin";

const columns: ColumnDef<AdminModels["audit"], unknown>[] = [
  {
    accessorKey: "actor",
    header: "Actor",
    cell: ({ getValue }) => <b>{String(getValue())}</b>,
  },
  {
    accessorKey: "action",
    header: "Action",
    cell: ({ getValue }) => {
      const act = String(getValue());
      const tone =
        act.includes("Deleted") || act.includes("Suspend")
          ? "warning"
          : act.includes("Created") || act.includes("Login")
            ? "success"
            : "neutral";
      return <NeuBadge tone={tone}>{act}</NeuBadge>;
    },
  },
  {
    accessorKey: "resource",
    header: "Target Resource",
    cell: ({ getValue }) => <code>{String(getValue())}</code>,
  },
  {
    accessorKey: "details",
    header: "Details",
    cell: ({ getValue }) => (
      <span className="muted" style={{ fontSize: 11 }}>
        {String(getValue())}
      </span>
    ),
  },
  {
    accessorKey: "createdAt",
    header: "Timestamp",
    cell: ({ getValue }) => (
      <time style={{ fontSize: 11, color: "var(--muted)" }}>
        {new Date(String(getValue())).toLocaleString()}
      </time>
    ),
  },
];

export default function PlatformAudit() {
  const profile = useAuth((s) => s.profile)!;

  const [search, setSearch] = useState("");
  const [actionFilter, setActionFilter] = useState("all");
  const [from, setFrom] = useState("2025-01-01");
  const [to, setTo] = useState("2026-12-31");
  const [page, setPage] = useState(0);
  const [exporting, setExporting] = useState(false);

  const query = useQuery({
    queryKey: [
      "admin",
      profile.id,
      "platform-audit-logs",
      search,
      actionFilter,
      from,
      to,
      page,
    ],
    queryFn: async () => {
      const repo = await getAdminRepository();
      const filters: Record<string, string> = {};
      if (actionFilter !== "all") filters.action = actionFilter;
      return repo.list(
        "audit",
        { schoolId: "" },
        {
          search,
          page,
          pageSize: 15,
          from,
          to,
          filters,
        },
      );
    },
  });

  const exportAuditCsv = async () => {
    setExporting(true);
    try {
      const repo = await getAdminRepository();
      const result = await repo.list(
        "audit",
        { schoolId: "" },
        {
          search,
          page: 0,
          pageSize: 500,
          from,
          to,
        },
      );

      downloadCsv(
        "platform-audit-logs.csv",
        ["Actor", "Action", "Resource", "Details", "Timestamp"],
        result.rows.map((r) => [
          r.actor,
          r.action,
          r.resource,
          r.details,
          r.createdAt,
        ]),
      );
      toast.success("Platform audit log exported to CSV");
    } catch {
      toast.error("Export failed");
    } finally {
      setExporting(false);
    }
  };

  return (
    <>
      <AdminHeading
        eyebrow="AUDIT TRAIL"
        title="Platform immutable audit log"
        description="Append-only cryptographic record of all administrative actions, provisionings, credential regenerations, and authentication events."
      >
        <NeuButton
          variant="secondary"
          icon="download"
          loading={exporting}
          onClick={() => void exportAuditCsv()}
        >
          Export Audit Trail
        </NeuButton>
      </AdminHeading>

      <div className="records-toolbar" style={{ marginTop: 24 }}>
        <SearchBar
          value={search}
          onChange={(val) => {
            setSearch(val);
            setPage(0);
          }}
          placeholder="Filter by actor, details, or target ID…"
        />
        <NeuSelect
          label="Action Type"
          value={actionFilter}
          onChange={(e) => {
            setActionFilter(e.target.value);
            setPage(0);
          }}
        >
          <option value="all">All Actions</option>
          <option value="Created">Created</option>
          <option value="Updated">Updated</option>
          <option value="Deleted">Deleted</option>
          <option value="Login">Login / Session</option>
          <option value="Suspended">Suspension</option>
        </NeuSelect>
        <DatePicker
          label="From"
          value={from}
          onChange={(v) => {
            setFrom(v);
            setPage(0);
          }}
        />
        <DatePicker
          label="To"
          value={to}
          onChange={(v) => {
            setTo(v);
            setPage(0);
          }}
        />
      </div>

      <NeuCard style={{ marginTop: 20 }}>
        {query.isPending ? (
          <Skeleton className="chart-skeleton" />
        ) : query.isError ? (
          <ErrorState
            title="Failed to load audit logs"
            description={query.error.message}
            onRetry={() => void query.refetch()}
          />
        ) : (
          <>
            <NeuTable
              data={query.data?.rows ?? []}
              columns={columns}
              rowKey={(r) => r.id}
              label="Platform Audit Logs"
              renderMobile={(r) => (
                <div
                  style={{ display: "flex", flexDirection: "column", gap: 6 }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <b>{r.actor}</b>
                    <NeuBadge tone="neutral">{r.action}</NeuBadge>
                  </div>
                  <div className="muted" style={{ fontSize: 11 }}>
                    Resource: <code>{r.resource}</code>
                  </div>
                  <div className="muted" style={{ fontSize: 11 }}>
                    {r.details}
                  </div>
                  <time className="muted" style={{ fontSize: 10 }}>
                    {new Date(r.createdAt).toLocaleString()}
                  </time>
                </div>
              )}
            />
            <Pagination
              page={page}
              setPage={setPage}
              total={query.data?.total ?? 0}
            />
          </>
        )}
      </NeuCard>
    </>
  );
}
