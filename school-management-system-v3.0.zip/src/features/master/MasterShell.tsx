import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  NeuAvatar,
  NeuBadge,
  NeuButton,
  ThemeToggle,
} from "../../components/ui/primitives";
import { Icon, type IconName } from "../../components/ui/Icon";
import { getRepository } from "../../services";
import { useAuth } from "../../store/auth";
import { devTracker } from "../../lib/devTracker";

interface MasterNavItem {
  to: string;
  label: string;
  icon: IconName;
  exact?: boolean;
}

const navItems: MasterNavItem[] = [
  { to: "/sys-master/workspace", label: "Overview", icon: "grid", exact: true },
  { to: "/sys-master/workspace/schools", label: "Schools", icon: "building" },
  {
    to: "/sys-master/workspace/create-school",
    label: "Create School",
    icon: "plus",
  },
  { to: "/sys-master/workspace/revenue", label: "Revenue", icon: "wallet" },
  {
    to: "/sys-master/workspace/plans",
    label: "Plans & Billing",
    icon: "credit",
  },
  { to: "/sys-master/workspace/roles", label: "Global Roles", icon: "shield" },
  {
    to: "/sys-master/workspace/monitoring",
    label: "Live Monitoring",
    icon: "monitor",
  },
  { to: "/sys-master/workspace/audit", label: "Audit Logs", icon: "file" },
  {
    to: "/sys-master/workspace/settings",
    label: "Platform Security",
    icon: "settings",
  },
];

export default function MasterShell() {
  devTracker.logRender("MasterShell");
  const profile = useAuth((s) => s.profile);
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      (window as unknown as { __devNavigate?: typeof navigate }).__devNavigate =
        navigate;
    }
  }, [navigate]);

  const handleSignOut = async () => {
    const repository = await getRepository();
    await repository.auth.signOut();
    useAuth.getState().setProfile(null);
    navigate("/sys-master/login");
  };

  return (
    <div className={`shell-frame ${collapsed ? "sidebar-collapsed" : ""}`}>
      {/* Laptop / Tablet Sidebar */}
      <aside
        className={`sidebar ${collapsed ? "collapsed" : ""}`}
        aria-label="Master Console Navigation"
      >
        <div className="sidebar-top">
          <Link to="/sys-master/workspace" className="school-identity">
            <span className="school-badge-icon" aria-hidden="true">
              <Icon name="shield" size={18} />
            </span>
            {!collapsed && (
              <div>
                <b>Platform Master</b>
                <small className="muted">SaaS Engine v3.0</small>
              </div>
            )}
          </Link>
          <NeuButton
            variant="icon"
            className="sidebar-collapse"
            onClick={() => setCollapsed(!collapsed)}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            icon={collapsed ? "right" : "collapse"}
          />
        </div>

        <nav>
          <div className="nav-section">
            {!collapsed && (
              <div className="nav-section-label">PLATFORM CONTROL</div>
            )}
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.exact}
                className={({ isActive }) =>
                  `nav-item ${isActive ? "active" : ""}`
                }
                title={item.label}
              >
                <Icon name={item.icon} size={18} />
                {!collapsed && <span>{item.label}</span>}
                <span className="nav-active-dot" />
              </NavLink>
            ))}
          </div>
        </nav>

        <div className="sidebar-bottom">
          <div className="sidebar-account">
            <NeuAvatar name={profile?.name || "Master Admin"} size="sm" />
            {!collapsed && (
              <div>
                <b>{profile?.name || "Master"}</b>
                <small className="muted">{profile?.email}</small>
              </div>
            )}
            <NeuButton
              variant="icon"
              icon="logout"
              title="Sign Out"
              aria-label="Sign Out"
              onClick={() => void handleSignOut()}
            />
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="app-main">
        <header className="top-header">
          <div className="header-branch">
            <NeuBadge tone="accent">MASTER CONSOLE</NeuBadge>
            <span className="version-label">ISOLATED TENANT ROOT</span>
          </div>

          <div className="header-actions">
            <div
              className="live-status-pill"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                fontSize: 11,
                color: "var(--muted)",
              }}
            >
              <span
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: "50%",
                  background: "#10b981",
                  display: "inline-block",
                }}
              />
              <span>Platform Healthy</span>
            </div>
            <Link
              to="/owner"
              style={{ textDecoration: "none" }}
              title="Switch to School Owner Dashboard"
            >
              <NeuBadge tone="accent">
                <Icon name="building" size={13} /> Owner Dashboard
              </NeuBadge>
            </Link>
            <ThemeToggle />
          </div>
        </header>

        <main className="content-canvas" id="main-content">
          <Outlet />
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="bottom-nav" aria-label="Mobile Navigation">
        <NavLink
          to="/sys-master/workspace"
          end
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          <Icon name="grid" size={18} />
          <span>Overview</span>
        </NavLink>
        <NavLink
          to="/sys-master/workspace/schools"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          <Icon name="building" size={18} />
          <span>Schools</span>
        </NavLink>
        <NavLink
          to="/sys-master/workspace/create-school"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          <Icon name="plus" size={18} />
          <span>Create</span>
        </NavLink>
        <NavLink
          to="/sys-master/workspace/revenue"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          <Icon name="wallet" size={18} />
          <span>Revenue</span>
        </NavLink>
        <NavLink
          to="/sys-master/workspace/monitoring"
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          <Icon name="monitor" size={18} />
          <span>Live</span>
        </NavLink>
      </nav>
    </div>
  );
}
