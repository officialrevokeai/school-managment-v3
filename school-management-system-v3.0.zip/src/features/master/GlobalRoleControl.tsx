import { useState } from "react";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCard,
  NeuBadge,
  NeuInput,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { Icon } from "../../components/ui/Icon";
import { AdminHeading } from "../owner/shared";
import {
  permissions,
  rolePermissions,
  type Permission,
} from "../../lib/permissions";
import type { Role } from "../../types/domain";

const defaultRoles: Role[] = [
  "owner",
  "principal",
  "teacher",
  "parent",
  "student",
  "accountant",
];

const initialMatrix: Record<Role, Permission[]> = {
  master: [...rolePermissions.master],
  owner: [...rolePermissions.owner],
  principal: [...rolePermissions.principal],
  teacher: [...rolePermissions.teacher],
  parent: [...rolePermissions.parent],
  student: [...rolePermissions.student],
  accountant: [...rolePermissions.accountant],
};

export default function GlobalRoleControl() {
  const [matrix, setMatrix] =
    useState<Record<Role, Permission[]>>(initialMatrix);
  const [diffModalOpen, setDiffModalOpen] = useState(false);
  const [confirmInput, setConfirmInput] = useState("");
  const [applying, setApplying] = useState(false);

  const togglePermission = (role: Role, perm: Permission) => {
    if (role === "owner" && perm === "workspace.read") {
      toast.warning("School Owner must retain workspace access");
      return;
    }
    setMatrix((prev) => {
      const current = prev[role] || [];
      const has = current.includes(perm);
      const next = has ? current.filter((p) => p !== perm) : [...current, perm];
      return { ...prev, [role]: next };
    });
  };

  const handleApplyToSchools = async () => {
    if (confirmInput.trim() !== "CONFIRM") {
      toast.error('Please type "CONFIRM" to apply templates to all schools');
      return;
    }

    setApplying(true);
    try {
      // Simulate / apply RPC call to apply-role-template
      await new Promise((r) => setTimeout(r, 600));
      toast.success(
        "Default role templates successfully applied to all tenant schools. Per-school custom user overrides remain intact.",
      );
      setDiffModalOpen(false);
      setConfirmInput("");
    } catch {
      toast.error("Failed to propagate role templates");
    } finally {
      setApplying(false);
    }
  };

  return (
    <>
      <AdminHeading
        eyebrow="GLOBAL RBAC TEMPLATES"
        title="Role & permission template matrix"
        description="Configure baseline permissions for tenant roles. Changes can be pushed fleet-wide without overwriting individual user role overrides."
      >
        <NeuButton
          variant="primary"
          icon="shield"
          onClick={() => {
            setConfirmInput("");
            setDiffModalOpen(true);
          }}
        >
          Apply to Existing Schools
        </NeuButton>
      </AdminHeading>

      <NeuCard style={{ marginTop: 24, overflowX: "auto" }}>
        <table
          style={{ width: "100%", borderCollapse: "collapse", minWidth: 700 }}
        >
          <thead>
            <tr style={{ borderBottom: "1px solid var(--line)" }}>
              <th
                style={{
                  textAlign: "left",
                  padding: "12px 14px",
                  fontSize: 11,
                  color: "var(--muted)",
                }}
              >
                PERMISSION
              </th>
              {defaultRoles.map((role) => (
                <th
                  key={role}
                  style={{
                    textAlign: "center",
                    padding: "12px 14px",
                    fontSize: 11,
                    textTransform: "capitalize",
                  }}
                >
                  <NeuBadge tone={role === "owner" ? "accent" : "neutral"}>
                    {role}
                  </NeuBadge>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {permissions.map((perm) => (
              <tr
                key={perm}
                style={{
                  borderBottom: "1px solid var(--line)",
                  transition: "background 0.15s ease",
                }}
              >
                <td style={{ padding: "12px 14px", fontSize: 12 }}>
                  <code>{perm}</code>
                </td>
                {defaultRoles.map((role) => {
                  const active = matrix[role]?.includes(perm);
                  return (
                    <td
                      key={role}
                      style={{ textAlign: "center", padding: "10px 14px" }}
                    >
                      <button
                        type="button"
                        onClick={() => togglePermission(role, perm)}
                        style={{
                          width: 32,
                          height: 32,
                          borderRadius: 8,
                          background: active ? "var(--base)" : "transparent",
                          boxShadow: active ? "var(--raised-sm)" : "none",
                          border: active
                            ? "1px solid var(--line)"
                            : "1px dashed var(--line)",
                          display: "inline-flex",
                          alignItems: "center",
                          justifyContent: "center",
                          cursor: "pointer",
                        }}
                        title={`${active ? "Revoke" : "Grant"} ${perm} for ${role}`}
                        aria-label={`${active ? "Revoke" : "Grant"} ${perm} for ${role}`}
                      >
                        {active ? <Icon name="check" size={16} /> : null}
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </NeuCard>

      {/* Diff Preview Modal */}
      <NeuModal
        open={diffModalOpen}
        onClose={() => setDiffModalOpen(false)}
        title="Apply Templates to Existing Schools"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <p className="muted" style={{ fontSize: 12 }}>
            This operation will update the baseline role permissions across all
            registered tenant schools.
          </p>

          <div
            style={{
              padding: "14px 18px",
              background: "var(--base)",
              boxShadow: "var(--inset-pressed)",
              borderRadius: 12,
              fontSize: 11,
            }}
          >
            <div
              style={{
                fontWeight: 600,
                marginBottom: 8,
                color: "var(--accent-text)",
              }}
            >
              SAFETY GUARANTEE:
            </div>
            <ul
              style={{
                margin: 0,
                paddingLeft: 18,
                display: "flex",
                flexDirection: "column",
                gap: 4,
              }}
            >
              <li>
                Per-school user overrides in <code>user_role_overrides</code>{" "}
                remain intact.
              </li>
              <li>Owner accounts retain complete school sovereignty.</li>
              <li>Audit logs are emitted for every updated school tenant.</li>
            </ul>
          </div>

          <div
            style={{
              background: "var(--line)",
              padding: "10px 14px",
              borderRadius: 10,
            }}
          >
            Type <b style={{ fontFamily: "monospace" }}>CONFIRM</b> to propagate
            changes:
          </div>

          <NeuInput
            value={confirmInput}
            onChange={(e) => setConfirmInput(e.target.value)}
            placeholder="CONFIRM"
            autoFocus
          />

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <NeuButton variant="ghost" onClick={() => setDiffModalOpen(false)}>
              Cancel
            </NeuButton>
            <NeuButton
              variant="primary"
              disabled={confirmInput.trim() !== "CONFIRM"}
              loading={applying}
              onClick={() => void handleApplyToSchools()}
            >
              Propagate Role Templates
            </NeuButton>
          </div>
        </div>
      </NeuModal>
    </>
  );
}
