import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCard,
  NeuInput,
  NeuSelect,
  NeuToggle,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { AdminHeading } from "../owner/shared";
import { getAdminRepository } from "../../services/admin";
import type { AdminModels, ProvisionedSchool } from "../../types/admin";

export default function CreateSchool() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Form fields
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [city, setCity] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [plan, setPlan] = useState<AdminModels["schools"]["plan"]>("Growth");
  const [monthlyFee, setMonthlyFee] = useState<number>(5000);
  const [expiryDate, setExpiryDate] = useState<string>(
    new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10),
  );
  const [ownerName, setOwnerName] = useState("");
  const [ownerEmail, setOwnerEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [forceChangePassword, setForceChangePassword] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Success dialog
  const [createdResult, setCreatedResult] = useState<ProvisionedSchool | null>(
    null,
  );
  const [successModalOpen, setSuccessModalOpen] = useState(false);

  // Auto-generate slug from name if empty
  const handleNameChange = (val: string) => {
    setName(val);
    if (!code || code === name.toLowerCase().replace(/[^a-z0-9]/g, "-")) {
      setCode(
        val
          .toLowerCase()
          .trim()
          .replace(/[^a-z0-9]/g, "-")
          .replace(/-+/g, "-")
          .slice(0, 20),
      );
    }
  };

  // Password strength calculation
  const getPasswordStrength = (pwd: string) => {
    if (!pwd) return { score: 0, label: "Empty", tone: "neutral" };
    let score = 0;
    if (pwd.length >= 8) score++;
    if (pwd.length >= 12) score++;
    if (/[A-Z]/.test(pwd)) score++;
    if (/[0-9]/.test(pwd)) score++;
    if (/[^A-Za-z0-9]/.test(pwd)) score++;
    if (score <= 2) return { score, label: "Weak", tone: "danger" };
    if (score <= 4) return { score, label: "Good", tone: "warning" };
    return { score, label: "Strong", tone: "success" };
  };

  const strength = getPasswordStrength(password);

  const generateStrongPassword = () => {
    const chars =
      "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%&*";
    let gen = "";
    for (let i = 0; i < 16; i++) {
      gen += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setPassword(`Campus!${gen}`);
    toast.info("Strong password generated");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim() || !ownerEmail.trim()) {
      toast.error("Please fill in all required fields");
      return;
    }

    setSubmitting(true);
    try {
      const repo = await getAdminRepository();
      const result = await repo.provisionSchool({
        name: name.trim(),
        code: code.trim(),
        ownerEmail: ownerEmail.trim().toLowerCase(),
        plan,
        monthlyFee,
        password: password.trim() || undefined,
      });

      const finalResult: ProvisionedSchool = {
        ...result,
        password: password.trim() || result.password,
      };

      setCreatedResult(finalResult);
      setSuccessModalOpen(true);
      void queryClient.invalidateQueries({ queryKey: ["admin"] });
      toast.success(`School "${name}" provisioned atomically!`);
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "School provisioning failed",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <AdminHeading
        eyebrow="ONBOARDING WORKFLOW"
        title="Create new school tenant"
        description="Atomically provisions the organization, default branch, default RBAC roles from templates, owner Auth credentials, and subscription."
      />

      <form onSubmit={handleSubmit} style={{ maxWidth: 800, marginTop: 24 }}>
        <NeuCard>
          <h2>Organization Details</h2>
          <p className="muted" style={{ fontSize: 12, marginBottom: 20 }}>
            Legal identity and unique tenant identifier.
          </p>

          <div
            style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}
          >
            <NeuInput
              label="School Name *"
              id="school-name"
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="e.g. Greenwood International"
              required
            />
            <NeuInput
              label="Unique Tenant Slug / Code *"
              id="school-code"
              value={code}
              onChange={(e) =>
                setCode(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))
              }
              placeholder="e.g. greenwood"
              required
            />
            <NeuInput
              label="City / Campus Location"
              id="school-city"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="e.g. New Delhi"
            />
            <NeuInput
              label="Contact Phone"
              id="school-phone"
              value={contactPhone}
              onChange={(e) => setContactPhone(e.target.value)}
              placeholder="+91 98765 43210"
            />
          </div>
        </NeuCard>

        <NeuCard style={{ marginTop: 20 }}>
          <h2>Subscription & Plan</h2>
          <p className="muted" style={{ fontSize: 12, marginBottom: 20 }}>
            Pricing tier and initial contract duration.
          </p>

          <div
            style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}
          >
            <NeuSelect
              label="Subscription Tier"
              id="plan-tier"
              value={plan}
              onChange={(e) => {
                const p = e.target.value as AdminModels["schools"]["plan"];
                setPlan(p);
                if (p === "Starter") setMonthlyFee(0);
                else if (p === "Growth") setMonthlyFee(5000);
                else if (p === "Enterprise") setMonthlyFee(15000);
              }}
            >
              <option value="Starter">
                Starter (Free / Trial, up to 250 students)
              </option>
              <option value="Growth">
                Growth (5,000 INR/mo, up to 1,500 students)
              </option>
              <option value="Enterprise">
                Enterprise (15,000 INR/mo, unlimited)
              </option>
            </NeuSelect>

            <NeuInput
              label="Monthly Contract Fee (INR)"
              id="monthly-fee"
              type="number"
              value={monthlyFee}
              onChange={(e) => setMonthlyFee(Number(e.target.value))}
              min={0}
            />

            <NeuInput
              label="Trial / Subscription Expiry Date"
              id="expiry-date"
              type="date"
              value={expiryDate}
              onChange={(e) => setExpiryDate(e.target.value)}
            />
          </div>
        </NeuCard>

        <NeuCard style={{ marginTop: 20 }}>
          <h2>Initial School Owner Account</h2>
          <p className="muted" style={{ fontSize: 12, marginBottom: 20 }}>
            The primary owner administrator account created in Supabase Auth.
          </p>

          <div
            style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}
          >
            <NeuInput
              label="Owner Full Name"
              id="owner-name"
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              placeholder="Dr. Eleanor Vance"
            />

            <NeuInput
              label="Owner Email Address *"
              id="owner-email"
              type="email"
              value={ownerEmail}
              onChange={(e) => setOwnerEmail(e.target.value)}
              placeholder="owner@school.edu"
              required
            />
          </div>

          <div style={{ marginTop: 16 }}>
            <div className="password-field">
              <NeuInput
                label="Owner Initial Password"
                id="owner-password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Leave blank to auto-generate secure password"
              />
              <NeuButton
                type="button"
                variant="ghost"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                icon={showPassword ? "eye-off" : "eye"}
              />
            </div>

            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginTop: 8,
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  fontSize: 11,
                }}
              >
                <span className="muted">Strength:</span>
                <b
                  style={{
                    color:
                      strength.tone === "success"
                        ? "#10b981"
                        : strength.tone === "warning"
                          ? "#f59e0b"
                          : "#ef4444",
                  }}
                >
                  {strength.label}
                </b>
              </div>
              <NeuButton
                type="button"
                variant="secondary"
                icon="sparkles"
                onClick={generateStrongPassword}
              >
                Generate Strong Password
              </NeuButton>
            </div>
          </div>

          <div style={{ marginTop: 20 }}>
            <NeuToggle
              label="Force password change on first login"
              description="Requires the school owner to set a personal password upon signing into the school portal."
              checked={forceChangePassword}
              onChange={setForceChangePassword}
            />
          </div>
        </NeuCard>

        <div
          style={{
            display: "flex",
            gap: 14,
            justifyContent: "flex-end",
            marginTop: 24,
            marginBottom: 40,
          }}
        >
          <NeuButton
            type="button"
            variant="ghost"
            onClick={() => navigate("/sys-master/workspace/schools")}
          >
            Cancel
          </NeuButton>
          <NeuButton
            type="submit"
            variant="primary"
            loading={submitting}
            icon="arrow-right"
          >
            Atomically Provision School
          </NeuButton>
        </div>
      </form>

      {/* One-Time Credentials Success Modal */}
      <NeuModal
        open={successModalOpen}
        onClose={() => {
          setSuccessModalOpen(false);
          navigate("/sys-master/workspace/schools");
        }}
        title="School Provisioned Successfully"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <p className="muted" style={{ fontSize: 12 }}>
            The school organization and primary owner account have been created.
            Copy these credentials now. Plaintext passwords are not stored in
            any database.
          </p>

          <div
            style={{
              padding: "16px 20px",
              background: "var(--base)",
              boxShadow: "var(--inset-pressed)",
              borderRadius: 14,
              display: "flex",
              flexDirection: "column",
              gap: 12,
              fontFamily: "monospace",
              fontSize: 13,
            }}
          >
            <div>
              <span className="muted">School Name:</span>{" "}
              <b>{createdResult?.school.name}</b>
            </div>
            <div>
              <span className="muted">School Slug:</span>{" "}
              <b>{createdResult?.school.code}</b>
            </div>
            <div>
              <span className="muted">Owner Email:</span>{" "}
              <b>{createdResult?.email}</b>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div>
                <span className="muted">Password:</span>{" "}
                <b>{createdResult?.password}</b>
              </div>
              <NeuButton
                variant="ghost"
                icon="copy"
                title="Copy Password"
                onClick={() => {
                  if (createdResult?.password) {
                    void navigator.clipboard.writeText(createdResult.password);
                    toast.success("Password copied to clipboard");
                  }
                }}
              />
            </div>
            <div>
              <span className="muted">Login Portal URL:</span>{" "}
              <b>{window.location.origin}/login</b>
            </div>
          </div>

          <div
            style={{
              display: "flex",
              gap: 10,
              justifyContent: "flex-end",
              marginTop: 10,
            }}
          >
            <NeuButton
              variant="secondary"
              icon="copy"
              onClick={() => {
                const text = `Campus Platform Credentials\nSchool: ${createdResult?.school.name} (${createdResult?.school.code})\nOwner Email: ${createdResult?.email}\nPassword: ${createdResult?.password}\nLogin URL: ${window.location.origin}/login`;
                void navigator.clipboard.writeText(text);
                toast.success("All credentials copied to clipboard");
              }}
            >
              Copy All Details
            </NeuButton>
            <NeuButton
              variant="primary"
              onClick={() => {
                setSuccessModalOpen(false);
                navigate("/sys-master/workspace/schools");
              }}
            >
              Done & View Schools
            </NeuButton>
          </div>
        </div>
      </NeuModal>
    </>
  );
}
