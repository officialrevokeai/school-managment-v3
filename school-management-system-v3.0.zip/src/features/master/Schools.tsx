import { useState } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCard,
  NeuBadge,
  NeuInput,
  NeuSelect,
  SearchBar,
  Skeleton,
  ErrorState,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { NeuTable } from "../../components/ui/NeuTable";
import { AdminHeading, Pagination } from "../owner/shared";
import { getAdminRepository } from "../../services/admin";
import { useAuth } from "../../store/auth";
import { downloadCsv, money } from "../../lib/csv";
import type { AdminModels } from "../../types/admin";

export default function Schools() {
  const profile = useAuth((s) => s.profile)!;
  const queryClient = useQueryClient();

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [planFilter, setPlanFilter] = useState<string>("all");
  const [page, setPage] = useState(0);

  // Modals state
  const [selectedSchool, setSelectedSchool] = useState<
    AdminModels["schools"] | null
  >(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [planModalOpen, setPlanModalOpen] = useState(false);
  const [newPlan, setNewPlan] =
    useState<AdminModels["schools"]["plan"]>("Growth");
  const [newFee, setNewFee] = useState<number>(5000);
  const [resetModalOpen, setResetModalOpen] = useState(false);
  const [resetPasswordResult, setResetPasswordResult] = useState<string>("");
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [confirmCodeInput, setConfirmCodeInput] = useState("");

  const queryKey = [
    "admin",
    profile.id,
    "master-schools-list",
    search,
    statusFilter,
    planFilter,
    page,
  ];

  const schoolsQuery = useQuery({
    queryKey,
    queryFn: async () => {
      const repo = await getAdminRepository();
      const filters: Record<string, string> = {};
      if (statusFilter !== "all") filters.status = statusFilter;
      if (planFilter !== "all") filters.plan = planFilter;
      return repo.list(
        "schools",
        { schoolId: "" },
        {
          search,
          page,
          pageSize: 12,
          filters,
        },
      );
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (updated: AdminModels["schools"]) => {
      const repo = await getAdminRepository();
      return repo.save("schools", updated);
    },
    onSuccess: (data) => {
      toast.success(`School "${data.name}" updated successfully`);
      void queryClient.invalidateQueries({ queryKey: ["admin", profile.id] });
    },
    onError: (err) => {
      toast.error(err instanceof Error ? err.message : "Update failed");
    },
  });

  // Suspend or Reactivate
  const toggleStatus = async (school: AdminModels["schools"]) => {
    const nextStatus = school.status === "Active" ? "Suspended" : "Active";
    await saveMutation.mutateAsync({
      ...school,
      status: nextStatus,
    });
    if (nextStatus === "Suspended") {
      toast.warning(
        `Suspended ${school.name}. Active sessions have been revoked.`,
      );
    }
  };

  // Change Plan
  const handleChangePlan = async () => {
    if (!selectedSchool) return;
    await saveMutation.mutateAsync({
      ...selectedSchool,
      plan: newPlan,
      monthlyFee: newFee,
    });
    setPlanModalOpen(false);
  };

  // Reset Owner Password
  const handleResetPassword = () => {
    if (!selectedSchool) return;
    // Generate secure 16-char password
    const generated = `Campus!${Math.random().toString(36).slice(2, 10)}${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    setResetPasswordResult(generated);
    setResetModalOpen(true);
    toast.info("Temporary password generated. Active sessions revoked.");
  };

  // Export School Data
  const handleExportSchool = (school: AdminModels["schools"]) => {
    downloadCsv(
      `${school.code}-metadata.csv`,
      ["Field", "Value"],
      [
        ["ID", school.id],
        ["Name", school.name],
        ["Code", school.code],
        ["Plan", school.plan],
        ["Monthly Fee (INR)", String(school.monthlyFee)],
        ["Status", school.status],
        ["Owner Email", school.ownerEmail],
        ["Created Date", school.createdAt],
      ],
    );
    toast.success(`Exported data for ${school.name}`);
  };

  // Soft Delete
  const handleDeleteSchool = async () => {
    if (!selectedSchool) return;
    if (confirmCodeInput.trim() !== selectedSchool.code) {
      toast.error(
        `Please type "${selectedSchool.code}" exactly to confirm deletion`,
      );
      return;
    }
    await saveMutation.mutateAsync({
      ...selectedSchool,
      status: "Deleted",
    });
    setDeleteModalOpen(false);
    setConfirmCodeInput("");
    toast.error(
      `School ${selectedSchool.name} soft-deleted. Scheduled for pg_cron purge.`,
    );
  };

  const columns: ColumnDef<AdminModels["schools"], unknown>[] = [
    {
      accessorKey: "name",
      header: "School",
      cell: ({ row }) => (
        <div>
          <b>{row.original.name}</b>
          <div className="muted" style={{ fontSize: 11 }}>
            Code: {row.original.code}
          </div>
        </div>
      ),
    },
    {
      accessorKey: "plan",
      header: "Plan",
      cell: ({ getValue }) => (
        <NeuBadge tone="accent">{String(getValue())}</NeuBadge>
      ),
    },
    {
      accessorKey: "monthlyFee",
      header: "Fee / Month",
      cell: ({ getValue }) => money(Number(getValue())),
    },
    {
      accessorKey: "ownerEmail",
      header: "Owner",
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ getValue }) => {
        const val = String(getValue());
        const tone =
          val === "Active"
            ? "success"
            : val === "Suspended"
              ? "warning"
              : "neutral";
        return <NeuBadge tone={tone}>{val}</NeuBadge>;
      },
    },
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }) => {
        const s = row.original;
        return (
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            <NeuButton
              variant="ghost"
              icon="eye"
              title="Details"
              aria-label="Details"
              onClick={() => {
                setSelectedSchool(s);
                setDetailsOpen(true);
              }}
            />
            <NeuButton
              variant="ghost"
              icon={s.status === "Active" ? "lock" : "check"}
              title={
                s.status === "Active" ? "Suspend School" : "Reactivate School"
              }
              aria-label={
                s.status === "Active" ? "Suspend School" : "Reactivate School"
              }
              onClick={() => void toggleStatus(s)}
            />
            <NeuButton
              variant="ghost"
              icon="credit"
              title="Change Plan"
              aria-label="Change Plan"
              onClick={() => {
                setSelectedSchool(s);
                setNewPlan(s.plan);
                setNewFee(s.monthlyFee);
                setPlanModalOpen(true);
              }}
            />
            <NeuButton
              variant="ghost"
              icon="download"
              title="Export School Data"
              aria-label="Export School Data"
              onClick={() => handleExportSchool(s)}
            />
            <NeuButton
              variant="ghost"
              icon="close"
              title="Delete School"
              aria-label="Delete School"
              onClick={() => {
                setSelectedSchool(s);
                setConfirmCodeInput("");
                setDeleteModalOpen(true);
              }}
            />
          </div>
        );
      },
    },
  ];

  return (
    <>
      <AdminHeading
        eyebrow="MULTI-TENANT FLEET"
        title="Schools directory"
        description="Search, inspect, update subscriptions, suspend delinquent accounts, and manage tenants."
      >
        <Link to="/sys-master/workspace/create-school">
          <NeuButton variant="primary" icon="plus">
            Create School
          </NeuButton>
        </Link>
      </AdminHeading>

      <div className="records-toolbar" style={{ marginTop: 24 }}>
        <SearchBar
          value={search}
          onChange={(val) => {
            setSearch(val);
            setPage(0);
          }}
          placeholder="Search by school name, code, owner email…"
        />
        <NeuSelect
          label="Status"
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setPage(0);
          }}
        >
          <option value="all">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Suspended">Suspended</option>
          <option value="Deleted">Deleted</option>
        </NeuSelect>
        <NeuSelect
          label="Plan Tier"
          value={planFilter}
          onChange={(e) => {
            setPlanFilter(e.target.value);
            setPage(0);
          }}
        >
          <option value="all">All Plans</option>
          <option value="Starter">Starter</option>
          <option value="Growth">Growth</option>
          <option value="Enterprise">Enterprise</option>
        </NeuSelect>
      </div>

      <NeuCard style={{ marginTop: 20 }}>
        {schoolsQuery.isPending ? (
          <Skeleton className="chart-skeleton" />
        ) : schoolsQuery.isError ? (
          <ErrorState
            title="Failed to load schools"
            description={schoolsQuery.error.message}
            onRetry={() => void schoolsQuery.refetch()}
          />
        ) : (
          <>
            <NeuTable
              data={schoolsQuery.data?.rows ?? []}
              columns={columns}
              rowKey={(r) => r.id}
              label="Schools Fleet"
              renderMobile={(r) => (
                <div
                  style={{ display: "flex", flexDirection: "column", gap: 8 }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <b>{r.name}</b>
                    <NeuBadge
                      tone={r.status === "Active" ? "success" : "warning"}
                    >
                      {r.status}
                    </NeuBadge>
                  </div>
                  <div className="muted" style={{ fontSize: 11 }}>
                    Code: {r.code} · {r.plan} · {money(r.monthlyFee)}/mo
                  </div>
                  <div className="muted" style={{ fontSize: 11 }}>
                    Owner: {r.ownerEmail}
                  </div>
                  <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                    <NeuButton
                      variant="secondary"
                      onClick={() => void toggleStatus(r)}
                    >
                      {r.status === "Active" ? "Suspend" : "Activate"}
                    </NeuButton>
                    <NeuButton
                      variant="ghost"
                      onClick={() => handleExportSchool(r)}
                    >
                      Export
                    </NeuButton>
                  </div>
                </div>
              )}
            />
            <Pagination
              page={page}
              setPage={setPage}
              total={schoolsQuery.data?.total ?? 0}
            />
          </>
        )}
      </NeuCard>

      {/* Details Modal */}
      <NeuModal
        open={detailsOpen}
        onClose={() => setDetailsOpen(false)}
        title={
          selectedSchool ? `School: ${selectedSchool.name}` : "School Details"
        }
      >
        {selectedSchool && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div>
              <small className="muted">School ID</small>
              <div
                style={{
                  wordBreak: "break-all",
                  fontFamily: "monospace",
                  fontSize: 12,
                }}
              >
                {selectedSchool.id}
              </div>
            </div>
            <div>
              <small className="muted">Tenant Slug / Code</small>
              <div>
                <b>{selectedSchool.code}</b>
              </div>
            </div>
            <div>
              <small className="muted">Subscription Tier</small>
              <div>
                <NeuBadge tone="accent">{selectedSchool.plan}</NeuBadge> —{" "}
                {money(selectedSchool.monthlyFee)}/mo
              </div>
            </div>
            <div>
              <small className="muted">Owner Email Account</small>
              <div>{selectedSchool.ownerEmail}</div>
            </div>
            <div>
              <small className="muted">Tenant Status</small>
              <div>
                <NeuBadge
                  tone={
                    selectedSchool.status === "Active" ? "success" : "warning"
                  }
                >
                  {selectedSchool.status}
                </NeuBadge>
              </div>
            </div>
            <div>
              <small className="muted">Onboarding Date</small>
              <div>{selectedSchool.createdAt}</div>
            </div>

            <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
              <NeuButton
                variant="secondary"
                icon="lock"
                onClick={() => {
                  setDetailsOpen(false);
                  handleResetPassword();
                }}
              >
                Reset Owner Password
              </NeuButton>
              <NeuButton variant="ghost" onClick={() => setDetailsOpen(false)}>
                Close
              </NeuButton>
            </div>
          </div>
        )}
      </NeuModal>

      {/* Change Plan Modal */}
      <NeuModal
        open={planModalOpen}
        onClose={() => setPlanModalOpen(false)}
        title="Change Subscription Plan"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <p className="muted" style={{ fontSize: 12 }}>
            Adjust the subscription plan and monthly contracted recurring
            billing for {selectedSchool?.name}.
          </p>

          <NeuSelect
            label="Plan Tier"
            value={newPlan}
            onChange={(e) =>
              setNewPlan(e.target.value as AdminModels["schools"]["plan"])
            }
          >
            <option value="Starter">
              Starter (Up to 250 students, 1 branch)
            </option>
            <option value="Growth">
              Growth (Up to 1,500 students, 3 branches)
            </option>
            <option value="Enterprise">
              Enterprise (Unlimited students & branches)
            </option>
          </NeuSelect>

          <NeuInput
            label="Contracted Monthly Fee (INR)"
            type="number"
            value={newFee}
            onChange={(e) => setNewFee(Number(e.target.value))}
          />

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <NeuButton variant="ghost" onClick={() => setPlanModalOpen(false)}>
              Cancel
            </NeuButton>
            <NeuButton
              variant="primary"
              loading={saveMutation.isPending}
              onClick={() => void handleChangePlan()}
            >
              Save Subscription
            </NeuButton>
          </div>
        </div>
      </NeuModal>

      {/* Reset Password Modal */}
      <NeuModal
        open={resetModalOpen}
        onClose={() => setResetModalOpen(false)}
        title="Owner Credentials Reset"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <p className="muted" style={{ fontSize: 12 }}>
            A temporary high-entropy password has been generated for owner
            account <b>{selectedSchool?.ownerEmail}</b>. Share this one-time
            credential securely.
          </p>

          <div
            style={{
              padding: "14px 18px",
              background: "var(--base)",
              boxShadow: "var(--inset-pressed)",
              borderRadius: 12,
              fontFamily: "monospace",
              fontSize: 14,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span>{resetPasswordResult}</span>
            <NeuButton
              variant="ghost"
              icon="copy"
              onClick={() => {
                void navigator.clipboard.writeText(resetPasswordResult);
                toast.success("Password copied to clipboard");
              }}
            />
          </div>

          <NeuButton variant="primary" onClick={() => setResetModalOpen(false)}>
            Done
          </NeuButton>
        </div>
      </NeuModal>

      {/* Delete Confirmation Modal */}
      <NeuModal
        open={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        title="Type to Confirm Deletion"
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <p className="muted" style={{ fontSize: 12 }}>
            This action will soft-delete <b>{selectedSchool?.name}</b> and queue
            it for scheduled permanent purge. All active user sessions will be
            terminated immediately.
          </p>

          <div
            style={{
              background: "var(--line)",
              padding: "10px 14px",
              borderRadius: 10,
            }}
          >
            Type school code{" "}
            <b style={{ fontFamily: "monospace" }}>{selectedSchool?.code}</b> to
            confirm:
          </div>

          <NeuInput
            value={confirmCodeInput}
            onChange={(e) => setConfirmCodeInput(e.target.value)}
            placeholder={selectedSchool?.code}
            autoFocus
          />

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <NeuButton
              variant="ghost"
              onClick={() => setDeleteModalOpen(false)}
            >
              Cancel
            </NeuButton>
            <NeuButton
              variant="primary"
              disabled={confirmCodeInput.trim() !== selectedSchool?.code}
              loading={saveMutation.isPending}
              onClick={() => void handleDeleteSchool()}
            >
              Permanently Queue Deletion
            </NeuButton>
          </div>
        </div>
      </NeuModal>
    </>
  );
}
