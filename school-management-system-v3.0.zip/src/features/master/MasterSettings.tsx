import { useState } from "react";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCard,
  NeuBadge,
  NeuInput,
  NeuToggle,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { AdminHeading } from "../owner/shared";

interface MasterSession {
  id: string;
  ip: string;
  device: string;
  location: string;
  lastActive: string;
  isCurrent: boolean;
}

const mockSessions: MasterSession[] = [
  {
    id: "sess-1",
    ip: "103.21.144.12",
    device: "Chrome / Windows (Current)",
    location: "New Delhi, IN",
    lastActive: "Just now",
    isCurrent: true,
  },
  {
    id: "sess-2",
    ip: "49.36.120.4",
    device: "Safari / macOS",
    location: "Bengaluru, IN",
    lastActive: "2 days ago",
    isCurrent: false,
  },
];

export default function MasterSettings() {
  // Feature flags
  const [flags, setFlags] = useState({
    whatsapp: true,
    onlinePayments: true,
    biometrics: false,
    aiReportCards: true,
    maintenanceMode: false,
  });

  // Announcement
  const [announcementTitle, setAnnouncementTitle] = useState("");
  const [announcementBody, setAnnouncementBody] = useState("");
  const [broadcasting, setBroadcasting] = useState(false);

  // Sessions
  const [sessions, setSessions] = useState<MasterSession[]>(mockSessions);

  // Add Master Admin modal
  const [addAdminModalOpen, setAddAdminModalOpen] = useState(false);
  const [newAdminEmail, setNewAdminEmail] = useState("");
  const [newAdminName, setNewAdminName] = useState("");
  const [newAdminPassword, setNewAdminPassword] = useState("");
  const [addingAdmin, setAddingAdmin] = useState(false);

  const toggleFlag = (key: keyof typeof flags) => {
    setFlags((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      toast.success(`Platform setting "${key}" updated`);
      return next;
    });
  };

  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementTitle.trim() || !announcementBody.trim()) {
      toast.error("Please enter announcement title and message");
      return;
    }

    setBroadcasting(true);
    try {
      await new Promise((r) => setTimeout(r, 600));
      toast.success(
        `Broadcast announcement sent to all school owners: "${announcementTitle}"`,
      );
      setAnnouncementTitle("");
      setAnnouncementBody("");
    } catch {
      toast.error("Broadcast failed");
    } finally {
      setBroadcasting(false);
    }
  };

  const handleRevokeSession = (id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
    toast.success("Master session revoked immediately");
  };

  const handleAddMasterAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminEmail.trim() || !newAdminPassword.trim()) {
      toast.error("Please fill in email and password");
      return;
    }

    setAddingAdmin(true);
    try {
      await new Promise((r) => setTimeout(r, 700));
      toast.success(
        `Added new Master Admin account for ${newAdminEmail}. MFA TOTP enrollment required on first login.`,
      );
      setAddAdminModalOpen(false);
      setNewAdminEmail("");
      setNewAdminName("");
      setNewAdminPassword("");
    } catch {
      toast.error("Failed to add master admin");
    } finally {
      setAddingAdmin(false);
    }
  };

  return (
    <>
      <AdminHeading
        eyebrow="PLATFORM GOVERNANCE"
        title="Settings & security configuration"
        description="Feature flag switches, fleet broadcast announcements, active master sessions, maintenance mode, and secondary master admin provisioning."
      />

      {/* Feature Flags */}
      <NeuCard style={{ marginTop: 24 }}>
        <h2>Global Platform Feature Flags</h2>
        <p className="muted" style={{ fontSize: 12, marginBottom: 20 }}>
          Enable or disable core subsystems fleet-wide.
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <NeuToggle
            label="WhatsApp Cloud API Gateway"
            description="Allows school tenants to send automated outbox messages and attendance notifications."
            checked={flags.whatsapp}
            onChange={() => toggleFlag("whatsapp")}
          />
          <NeuToggle
            label="Online Fee Payment Engine"
            description="Enables integrated Razorpay & Stripe checkouts on parent fee invoices."
            checked={flags.onlinePayments}
            onChange={() => toggleFlag("onlinePayments")}
          />
          <NeuToggle
            label="Biometric & RFID Attendance Integration"
            description="Enables hardware gateway ingestion for automated student attendance recording."
            checked={flags.biometrics}
            onChange={() => toggleFlag("biometrics")}
          />
          <NeuToggle
            label="AI Report Card & Progress Summaries"
            description="Enables automated grading narrative generation via LLM worker."
            checked={flags.aiReportCards}
            onChange={() => toggleFlag("aiReportCards")}
          />
          <NeuToggle
            label="Platform Maintenance Mode"
            description="Displays a maintenance banner on all school login portals and restricts non-owner writes."
            checked={flags.maintenanceMode}
            onChange={() => toggleFlag("maintenanceMode")}
          />
        </div>
      </NeuCard>

      {/* Platform Announcement to School Owners */}
      <NeuCard style={{ marginTop: 24 }}>
        <h2>Broadcast Announcement to All School Owners</h2>
        <p className="muted" style={{ fontSize: 12, marginBottom: 16 }}>
          Pushes an urgent in-app banner and dashboard notification to all
          tenant owners.
        </p>

        <form
          onSubmit={handleBroadcast}
          style={{ display: "flex", flexDirection: "column", gap: 14 }}
        >
          <NeuInput
            label="Announcement Title"
            value={announcementTitle}
            onChange={(e) => setAnnouncementTitle(e.target.value)}
            placeholder="e.g. Scheduled Infrastructure Maintenance Window"
            required
          />

          <div className="field">
            <label htmlFor="announcement-body">Announcement Body</label>
            <textarea
              id="announcement-body"
              value={announcementBody}
              onChange={(e) => setAnnouncementBody(e.target.value)}
              placeholder="Provide clear details and timelines for all school administrators…"
              rows={4}
              style={{
                width: "100%",
                background: "transparent",
                border: "1px solid var(--line)",
                borderRadius: 12,
                padding: "12px 14px",
                color: "var(--text)",
                boxShadow: "var(--inset-pressed)",
              }}
              required
            />
          </div>

          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <NeuButton
              type="submit"
              variant="primary"
              icon="arrow-right"
              loading={broadcasting}
            >
              Broadcast to Fleet
            </NeuButton>
          </div>
        </form>
      </NeuCard>

      {/* Active Master Sessions */}
      <NeuCard style={{ marginTop: 24 }}>
        <h2>Active Master Admin Sessions</h2>
        <p className="muted" style={{ fontSize: 12, marginBottom: 16 }}>
          Authenticated sessions with platform-wide administrative privileges.
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {sessions.map((sess) => (
            <div
              key={sess.id}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "12px 16px",
                borderRadius: 12,
                boxShadow: "var(--raised-sm)",
                border: "1px solid var(--line)",
                flexWrap: "wrap",
                gap: 10,
              }}
            >
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <b>{sess.device}</b>
                  {sess.isCurrent && (
                    <NeuBadge tone="success">Current Session</NeuBadge>
                  )}
                </div>
                <div className="muted" style={{ fontSize: 11, marginTop: 4 }}>
                  IP: {sess.ip} · Location: {sess.location} · Last active:{" "}
                  {sess.lastActive}
                </div>
              </div>

              {!sess.isCurrent && (
                <NeuButton
                  variant="ghost"
                  icon="close"
                  onClick={() => handleRevokeSession(sess.id)}
                >
                  Revoke
                </NeuButton>
              )}
            </div>
          ))}
        </div>
      </NeuCard>

      {/* Master Admin Management */}
      <NeuCard style={{ marginTop: 24 }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div>
            <h2>Secondary Master Administrators</h2>
            <p className="muted" style={{ fontSize: 12 }}>
              Only existing Master Admins with verified MFA can authorize new
              platform operators.
            </p>
          </div>
          <NeuButton
            variant="secondary"
            icon="plus"
            onClick={() => setAddAdminModalOpen(true)}
          >
            Add Master Admin
          </NeuButton>
        </div>
      </NeuCard>

      {/* Add Master Admin Modal */}
      <NeuModal
        open={addAdminModalOpen}
        onClose={() => setAddAdminModalOpen(false)}
        title="Add Platform Master Administrator"
      >
        <form
          onSubmit={handleAddMasterAdmin}
          style={{ display: "flex", flexDirection: "column", gap: 16 }}
        >
          <p className="muted" style={{ fontSize: 12 }}>
            Master Admins possess unconstrained platform capabilities. Hardware
            token or TOTP MFA enrollment will be enforced on first login.
          </p>

          <NeuInput
            label="Full Name"
            value={newAdminName}
            onChange={(e) => setNewAdminName(e.target.value)}
            placeholder="John Doe"
            required
          />

          <NeuInput
            label="Email Address"
            type="email"
            value={newAdminEmail}
            onChange={(e) => setNewAdminEmail(e.target.value)}
            placeholder="admin@platform.com"
            required
          />

          <NeuInput
            label="Temporary Initial Password"
            type="password"
            value={newAdminPassword}
            onChange={(e) => setNewAdminPassword(e.target.value)}
            placeholder="••••••••••••"
            required
          />

          <div
            style={{
              display: "flex",
              gap: 10,
              justifyContent: "flex-end",
              marginTop: 10,
            }}
          >
            <NeuButton
              variant="ghost"
              onClick={() => setAddAdminModalOpen(false)}
            >
              Cancel
            </NeuButton>
            <NeuButton variant="primary" type="submit" loading={addingAdmin}>
              Provision Master Admin
            </NeuButton>
          </div>
        </form>
      </NeuModal>
    </>
  );
}
