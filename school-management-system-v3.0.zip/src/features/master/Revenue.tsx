import { lazy, Suspense, useState } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { getAdminRepository } from "../../services/admin";
import { useAuth } from "../../store/auth";
import { useAdminList } from "../../hooks/useAdmin";
import { AdminHeading, QueryState, Pagination } from "../owner/shared";
import {
  DatePicker,
  NeuButton,
  NeuCard,
  NeuInput,
  NeuSelect,
  StatCard,
  Skeleton,
  ErrorState,
  NeuTabs,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { NeuTable } from "../../components/ui/NeuTable";
import { downloadCsv, money } from "../../lib/csv";
import type { AdminModels } from "../../types/admin";

const Chart = lazy(() => import("../owner/AnalyticsChart"));

const columns: ColumnDef<AdminModels["schools"], unknown>[] = [
  { accessorKey: "name", header: "School" },
  { accessorKey: "code", header: "Slug" },
  { accessorKey: "plan", header: "Plan" },
  {
    accessorKey: "monthlyFee",
    header: "Monthly fee",
    cell: (info) => money(Number(info.getValue())),
  },
  { accessorKey: "status", header: "Status" },
  { accessorKey: "createdAt", header: "Since" },
];

export default function Revenue() {
  const profile = useAuth((s) => s.profile)!;
  const [from, setFrom] = useState("2025-01-01");
  const [to, setTo] = useState("2026-12-31");
  const [page, setPage] = useState(0);
  const [chartView, setChartView] = useState<"school" | "plan" | "month">(
    "school",
  );
  const [exporting, setExporting] = useState(false);

  // Record payment modal
  const [recordModalOpen, setRecordModalOpen] = useState(false);
  const [paySchoolId, setPaySchoolId] = useState("");
  const [payAmount, setPayAmount] = useState(5000);
  const [payRef, setPayRef] = useState("");
  const [payKind, setPayKind] = useState("Settled Payment");

  const summary = useQuery({
    queryKey: ["admin", profile.id, "revenue-summary", from, to],
    queryFn: async () =>
      (await getAdminRepository()).summary({
        schoolId: profile.schoolId,
        from,
        to,
      }),
  });

  const query = useAdminList(
    "schools",
    { schoolId: profile.schoolId },
    { from, to, page, pageSize: 12 },
  );

  const exportReport = async () => {
    setExporting(true);
    try {
      const repository = await getAdminRepository();
      const rows: AdminModels["schools"][] = [];
      let index = 0;
      let total = 1;
      while (rows.length < total) {
        const result = await repository.list(
          "schools",
          { schoolId: profile.schoolId },
          { from, to, page: index++, pageSize: 500 },
        );
        rows.push(...result.rows);
        total = result.total;
        if (!result.rows.length) break;
      }
      downloadCsv(
        "platform-subscription-financials.csv",
        ["School", "Code", "Plan", "Monthly fee (INR)", "Status", "Onboarded"],
        rows.map((row) => [
          row.name,
          row.code,
          row.plan,
          row.monthlyFee,
          row.status,
          row.createdAt,
        ]),
      );
      toast.success("Financial revenue report exported successfully");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Report export failed",
      );
    } finally {
      setExporting(false);
    }
  };

  const handleRecordPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payAmount) return;
    toast.success(
      `Recorded ${payKind} of ${money(payAmount)} (Ref: ${payRef || "WIRE"}) for selected school`,
    );
    setRecordModalOpen(false);
  };

  const chartData =
    chartView === "school"
      ? (summary.data?.revenue ?? [])
      : chartView === "plan"
        ? (summary.data?.enrollment ?? [])
        : [
            { label: "Jan", value: (summary.data?.mrr ?? 0) * 0.7 },
            { label: "Feb", value: (summary.data?.mrr ?? 0) * 0.8 },
            { label: "Mar", value: (summary.data?.mrr ?? 0) * 0.9 },
            { label: "Apr", value: summary.data?.mrr ?? 0 },
          ];

  return (
    <>
      <AdminHeading
        eyebrow="PLATFORM FINANCIALS"
        title="School-wise subscription revenue"
        description="Track contracted monthly recurring revenue (MRR), annual run rate (ARR), outstanding dues, and record school payments."
      >
        <NeuButton
          variant="secondary"
          icon="plus"
          onClick={() => setRecordModalOpen(true)}
        >
          Record Payment / Invoice
        </NeuButton>
        <NeuButton
          icon="download"
          loading={exporting}
          onClick={() => void exportReport()}
        >
          Export Report
        </NeuButton>
      </AdminHeading>

      <div className="revenue-filters" style={{ marginTop: 24 }}>
        <DatePicker
          label="Schools created from"
          value={from}
          onChange={(value) => {
            setFrom(value);
            setPage(0);
          }}
        />
        <DatePicker
          label="Schools created to"
          value={to}
          onChange={(value) => {
            setTo(value);
            setPage(0);
          }}
        />
      </div>

      <QueryState query={query}>
        {(data) => (
          <>
            {summary.isPending ? (
              <Skeleton className="card-skeleton" />
            ) : summary.isError ? (
              <ErrorState
                description={summary.error.message}
                onRetry={() => void summary.refetch()}
              />
            ) : (
              <div
                className="admin-stat-grid"
                style={{
                  gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
                  marginTop: 24,
                }}
              >
                <StatCard
                  label="Monthly Contracted (MRR)"
                  value={summary.data?.mrr ?? 0}
                  suffix=" INR"
                  icon="wallet"
                  detail="Active subscription billings"
                />
                <StatCard
                  label="Annual Run Rate (ARR)"
                  value={(summary.data?.mrr ?? 0) * 12}
                  suffix=" INR"
                  icon="calendar"
                  detail="12-month forward run rate"
                />
                <StatCard
                  label="Outstanding Dues"
                  value={summary.data?.outstanding ?? 0}
                  suffix=" INR"
                  icon="credit"
                  detail="Pending invoice balances"
                />
                <StatCard
                  label="Active Billable Schools"
                  value={summary.data?.active ?? 0}
                  icon="building"
                  detail="Generating contracted MRR"
                />
              </div>
            )}

            <NeuCard style={{ marginTop: 20 }}>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  flexWrap: "wrap",
                  gap: 12,
                }}
              >
                <h2>Platform Revenue Analysis</h2>
                <NeuTabs
                  value={chartView}
                  onChange={(v) => setChartView(v)}
                  tabs={[
                    { value: "school", label: "By School" },
                    { value: "plan", label: "By Plan" },
                    { value: "month", label: "By Month" },
                  ]}
                />
              </div>

              <Suspense fallback={<Skeleton className="chart-skeleton" />}>
                <Chart
                  data={chartData}
                  kind="bar"
                  valueLabel={
                    chartView === "plan"
                      ? "Active Schools"
                      : "Monthly Revenue (INR)"
                  }
                />
              </Suspense>

              <div style={{ marginTop: 24 }}>
                <NeuTable
                  data={data.rows}
                  columns={columns}
                  rowKey={(row) => row.id}
                  label="School subscription revenue"
                  renderMobile={(row) => (
                    <div>
                      <b>{row.name}</b>
                      <p>
                        {row.plan} · {row.status}
                      </p>
                      <strong>{money(row.monthlyFee)} / month</strong>
                    </div>
                  )}
                />
                <Pagination page={page} setPage={setPage} total={data.total} />
              </div>
            </NeuCard>
          </>
        )}
      </QueryState>

      {/* Record Payment / Invoice Modal */}
      <NeuModal
        open={recordModalOpen}
        onClose={() => setRecordModalOpen(false)}
        title="Record School Payment / Invoice"
      >
        <form
          onSubmit={handleRecordPaymentSubmit}
          style={{ display: "flex", flexDirection: "column", gap: 16 }}
        >
          <NeuSelect
            label="Select School Tenant"
            value={paySchoolId}
            onChange={(e) => setPaySchoolId(e.target.value)}
          >
            <option value="">Choose a school…</option>
            {query.data?.rows.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.code}) — {money(s.monthlyFee)}/mo
              </option>
            ))}
          </NeuSelect>

          <NeuSelect
            label="Record Type"
            value={payKind}
            onChange={(e) => setPayKind(e.target.value)}
          >
            <option value="Settled Payment">
              Settled Subscription Payment
            </option>
            <option value="Manual Invoice">Generate Manual Dues Invoice</option>
            <option value="Credit Adjustment">Apply Balance Credit</option>
          </NeuSelect>

          <NeuInput
            label="Amount (INR)"
            type="number"
            value={payAmount}
            onChange={(e) => setPayAmount(Number(e.target.value))}
            min={1}
            required
          />

          <NeuInput
            label="Reference / Transaction ID"
            value={payRef}
            onChange={(e) => setPayRef(e.target.value)}
            placeholder="e.g. WIRE-892348"
          />

          <div
            style={{
              display: "flex",
              gap: 10,
              justifyContent: "flex-end",
              marginTop: 10,
            }}
          >
            <NeuButton
              variant="ghost"
              onClick={() => setRecordModalOpen(false)}
            >
              Cancel
            </NeuButton>
            <NeuButton variant="primary" type="submit">
              Save Financial Entry
            </NeuButton>
          </div>
        </form>
      </NeuModal>
    </>
  );
}
