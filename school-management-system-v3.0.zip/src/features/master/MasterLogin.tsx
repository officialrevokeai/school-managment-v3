import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCard,
  NeuInput,
  ThemeToggle,
  NeuBadge,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { getRepository } from "../../services";
import { useAuth } from "../../store/auth";
import type { Profile } from "../../types/domain";
import StatusPage from "../workspace/StatusPage";

export default function MasterLogin() {
  const isMasterEnabled = import.meta.env.VITE_ENABLE_MASTER !== "false";
  const profile = useAuth((s) => s.profile);
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [totpCode, setTotpCode] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [step, setStep] = useState<"credentials" | "totp">("credentials");
  const [pendingProfile, setPendingProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(false);

  // Set noindex dynamically
  useEffect(() => {
    let meta = document.querySelector('meta[name="robots"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "robots");
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", "noindex, nofollow");
  }, []);

  // If already signed in as master, navigate to workspace
  useEffect(() => {
    if (!isMasterEnabled) return;
    if (profile) {
      if (profile.role === "master") {
        const dest =
          (location.state as { from?: string })?.from ||
          "/sys-master/workspace";
        navigate(dest, { replace: true });
      } else {
        // Non-master hitting master login gets normal 404
        navigate("/404", { replace: true });
      }
    }
  }, [profile, navigate, location, isMasterEnabled]);

  // If master is disabled in build/environment, return standard 404
  if (!isMasterEnabled) {
    return <StatusPage status="404" />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Please enter email and password");
      return;
    }

    if (step === "credentials") {
      setLoading(true);
      try {
        const repository = await getRepository();
        const authedProfile = await repository.auth.signIn({
          identifier: email,
          password,
          remember: true,
          master: true,
        });
        // Check if user has active TOTP MFA enrolled
        let hasMfa = false;
        try {
          const { client } = await import("../../services/supabase");
          const { data: factors } = await client.auth.mfa.listFactors();
          hasMfa = Boolean(factors?.totp?.some((f) => f.status === "verified"));
        } catch {
          hasMfa = false;
        }

        if (hasMfa) {
          setPendingProfile(authedProfile);
          setStep("totp");
          toast.info("Enter TOTP MFA Authenticator Code to confirm identity");
        } else {
          useAuth.getState().setProfile(authedProfile);
          toast.success("Welcome, Master Admin.");
          navigate("/sys-master/workspace", { replace: true });
        }
      } catch (err) {
        toast.error(
          err instanceof Error ? err.message : "Authentication failed",
        );
      } finally {
        setLoading(false);
      }
    } else {
      if (!totpCode || totpCode.trim().length < 6) {
        toast.error("Please enter a valid 6-digit TOTP code");
        return;
      }
      setLoading(true);
      try {
        const repository = await getRepository();
        if (repository.auth.verifyMfa) {
          await repository.auth.verifyMfa(totpCode.trim());
        }
        // Finalize MFA verification: activate profile in store only after MFA succeeds
        if (pendingProfile) {
          useAuth.getState().setProfile(pendingProfile);
        }
        toast.success("Identity verified. Welcome, Master Admin.");
        navigate("/sys-master/workspace", { replace: true });
      } catch (err) {
        toast.error(
          err instanceof Error
            ? err.message
            : "Invalid TOTP authentication code",
        );
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div
      className="login-root"
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        padding: "20px",
      }}
    >
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          maxWidth: 1180,
          width: "100%",
          margin: "0 auto 30px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span className="icon-tile" style={{ width: 36, height: 36 }}>
            <Icon name="shield" size={20} />
          </span>
          <span style={{ fontWeight: 600, fontSize: 14 }}>Campus Platform</span>
        </div>
        <ThemeToggle />
      </header>

      <div
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <NeuCard
          className="login-card"
          style={{ maxWidth: 440, width: "100%" }}
        >
          <div className="login-heading">
            <NeuBadge tone="accent">PLATFORM SOVEREIGNTY</NeuBadge>
            <h2>Master Console</h2>
            <p className="muted">
              {step === "credentials"
                ? "Restricted creator access for multi-tenant SaaS management."
                : "Two-Factor TOTP Authenticator challenge required."}
            </p>
          </div>

          <form
            onSubmit={handleSubmit}
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 16,
              marginTop: 24,
            }}
          >
            {step === "credentials" ? (
              <>
                <NeuInput
                  label="Master Account Email"
                  type="email"
                  name="identifier"
                  id="master-email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="master@platform.com"
                  required
                  autoFocus
                />
                <div className="password-field">
                  <NeuInput
                    label="Master Password"
                    type={showPassword ? "text" : "password"}
                    name="password"
                    id="master-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    required
                  />
                  <NeuButton
                    type="button"
                    variant="ghost"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={
                      showPassword ? "Hide password" : "Show password"
                    }
                    icon={showPassword ? "eye-off" : "eye"}
                  />
                </div>
              </>
            ) : (
              <NeuInput
                label="6-Digit TOTP Authenticator Code"
                type="text"
                id="totp-code"
                value={totpCode}
                onChange={(e) =>
                  setTotpCode(e.target.value.replace(/\D/g, "").slice(0, 6))
                }
                placeholder="000 000"
                maxLength={6}
                required
                autoFocus
              />
            )}

            <NeuButton
              type="submit"
              variant="primary"
              className="login-submit"
              loading={loading}
              icon="arrow-right"
            >
              {step === "credentials"
                ? "Authenticate Master"
                : "Confirm TOTP & Enter"}
            </NeuButton>

            {step === "totp" && (
              <NeuButton
                type="button"
                variant="ghost"
                onClick={() => setStep("credentials")}
                disabled={loading}
              >
                Back to credentials
              </NeuButton>
            )}
          </form>

          <div className="secure-note" style={{ marginTop: 20 }}>
            <Icon name="lock" size={14} />
            <span>MFA Protected · Hardware Token & Claims Enforcement</span>
          </div>
        </NeuCard>
      </div>
    </div>
  );
}
