import { lazy, Suspense } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import {
  NeuButton,
  NeuCard,
  StatCard,
  Skeleton,
  ErrorState,
  NeuBadge,
} from "../../components/ui/primitives";
import { Icon } from "../../components/ui/Icon";
import { AdminHeading } from "../owner/shared";
import { getAdminRepository } from "../../services/admin";
import { useAuth } from "../../store/auth";
import { money } from "../../lib/csv";

const Chart = lazy(() => import("../owner/AnalyticsChart"));

export default function Overview() {
  const profile = useAuth((s) => s.profile)!;

  const summaryQuery = useQuery({
    queryKey: ["admin", profile.id, "master-overview-summary"],
    queryFn: async () => {
      const repo = await getAdminRepository();
      return repo.summary({ schoolId: "" });
    },
  });

  const schoolsQuery = useQuery({
    queryKey: ["admin", profile.id, "master-schools-all"],
    queryFn: async () => {
      const repo = await getAdminRepository();
      return repo.list(
        "schools",
        { schoolId: "" },
        { pageSize: 500 },
      );
    },
  });

  const schools = schoolsQuery.data?.rows ?? [];
  const activeSchools = schools.filter((s) => s.status === "Active");
  const suspendedSchools = schools.filter((s) => s.status === "Suspended");
  const trialSchools = schools.filter((s) => s.plan === "Starter");
  const now = new Date();
  const currentMonthPrefix = now.toISOString().slice(0, 7);
  const newSchoolsThisMonth = schools.filter((s) =>
    s.createdAt.startsWith(currentMonthPrefix),
  );

  const mrr = summaryQuery.data?.mrr ?? 0;
  const arr = mrr * 12;
  const aggregateStudents = summaryQuery.data?.students ?? 0;
  const aggregateUsers = aggregateStudents + (summaryQuery.data?.staff ?? 0);

  // Expiring soon simulation / mock
  const expiringSoon = activeSchools.slice(0, 3).map((s, idx) => ({
    ...s,
    daysLeft: 14 + idx * 7,
    expiresAt: new Date(Date.now() + (14 + idx * 7) * 86400000)
      .toISOString()
      .slice(0, 10),
  }));

  return (
    <>
      <AdminHeading
        eyebrow="SAAS PLATFORM ENGINE"
        title="Platform creator overview"
        description="Global health, multi-tenant fleet status, recurring revenue run rate, and high-level tenant analytics."
      >
        <Link to="/sys-master/workspace/create-school">
          <NeuButton variant="primary" icon="plus">
            Create School
          </NeuButton>
        </Link>
      </AdminHeading>

      {summaryQuery.isPending ? (
        <div className="admin-stat-grid">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <Skeleton key={i} className="card-skeleton" />
          ))}
        </div>
      ) : summaryQuery.isError ? (
        <ErrorState
          title="Failed to load platform KPIs"
          description={summaryQuery.error.message}
          onRetry={() => void summaryQuery.refetch()}
        />
      ) : (
        <>
          {/* Main 8 KPI Cards */}
          <div
            className="admin-stat-grid"
            style={{ gridTemplateColumns: "repeat(4, minmax(0, 1fr))" }}
          >
            <StatCard
              label="Active schools"
              value={activeSchools.length}
              icon="building"
              detail="Live tenant organizations"
            />
            <StatCard
              label="Trial / Starter"
              value={trialSchools.length}
              icon="layers"
              detail="Free tier onboarding"
            />
            <StatCard
              label="Suspended schools"
              value={suspendedSchools.length}
              icon="lock"
              detail="Delinquent or frozen"
            />
            <StatCard
              label="New this month"
              value={newSchoolsThisMonth.length}
              icon="plus"
              detail="Recent tenant onboardings"
            />
            <StatCard
              label="Contracted MRR"
              value={mrr}
              suffix=" INR"
              icon="wallet"
              detail="Monthly recurring revenue"
            />
            <StatCard
              label="Annual run rate (ARR)"
              value={arr}
              suffix=" INR"
              icon="calendar"
              detail="12x MRR projection"
            />
            <StatCard
              label="Total students (fleet)"
              value={aggregateStudents}
              icon="graduation"
              detail="Privacy-safe aggregate count"
            />
            <StatCard
              label="Total platform users"
              value={aggregateUsers}
              icon="users"
              detail="Total active accounts"
            />
          </div>

          {/* Revenue Trend Chart & Platform Health */}
          <div className="dashboard-main-grid">
            <NeuCard>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <div>
                  <h2>Platform Revenue Distribution</h2>
                  <p className="muted" style={{ fontSize: 12 }}>
                    Monthly subscription contract value across top schools.
                  </p>
                </div>
                <Link to="/sys-master/workspace/revenue">
                  <NeuButton variant="ghost" icon="arrow-right">
                    Full Financials
                  </NeuButton>
                </Link>
              </div>

              <Suspense fallback={<Skeleton className="chart-skeleton" />}>
                <Chart
                  data={summaryQuery.data?.revenue ?? []}
                  kind="bar"
                  valueLabel="Monthly subscription (INR)"
                />
              </Suspense>
            </NeuCard>

            <NeuCard>
              <h2>Live Platform Health</h2>
              <p className="muted" style={{ fontSize: 12, marginBottom: 16 }}>
                Real-time heartbeat across database, auth, and edge functions.
              </p>

              <div
                style={{ display: "flex", flexDirection: "column", gap: 12 }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "10px 0",
                    borderBottom: "1px solid var(--line)",
                  }}
                >
                  <span
                    style={{ display: "flex", alignItems: "center", gap: 8 }}
                  >
                    <Icon name="monitor" size={16} />
                    <b>Postgres 17 Engine</b>
                  </span>
                  <NeuBadge tone="success">Operational · 12ms</NeuBadge>
                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "10px 0",
                    borderBottom: "1px solid var(--line)",
                  }}
                >
                  <span
                    style={{ display: "flex", alignItems: "center", gap: 8 }}
                  >
                    <Icon name="lock" size={16} />
                    <b>Auth Service & MFA</b>
                  </span>
                  <NeuBadge tone="success">Operational</NeuBadge>
                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "10px 0",
                    borderBottom: "1px solid var(--line)",
                  }}
                >
                  <span
                    style={{ display: "flex", alignItems: "center", gap: 8 }}
                  >
                    <Icon name="sparkles" size={16} />
                    <b>11 Edge Functions</b>
                  </span>
                  <NeuBadge tone="success">Active (100% Up)</NeuBadge>
                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "10px 0",
                  }}
                >
                  <span
                    style={{ display: "flex", alignItems: "center", gap: 8 }}
                  >
                    <Icon name="message" size={16} />
                    <b>Realtime Broadcast Channels</b>
                  </span>
                  <NeuBadge tone="accent">Connected</NeuBadge>
                </div>
              </div>
            </NeuCard>
          </div>

          {/* Expiring Soon Table */}
          <NeuCard style={{ marginTop: 24 }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 16,
              }}
            >
              <div>
                <h2>Subscribers Expiring Soon (30 Days)</h2>
                <p className="muted" style={{ fontSize: 12 }}>
                  Schools requiring manual renewal intervention or quota
                  extension.
                </p>
              </div>
              <Link to="/sys-master/workspace/plans">
                <NeuButton variant="secondary" icon="credit">
                  Manage Subscriptions
                </NeuButton>
              </Link>
            </div>

            {expiringSoon.length === 0 ? (
              <p className="muted">
                No school subscriptions expiring in the next 30 days.
              </p>
            ) : (
              <div
                style={{ display: "flex", flexDirection: "column", gap: 10 }}
              >
                {expiringSoon.map((school) => (
                  <div
                    key={school.id}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      padding: "12px 16px",
                      borderRadius: 12,
                      boxShadow: "var(--inset-pressed)",
                      flexWrap: "wrap",
                      gap: 12,
                    }}
                  >
                    <div>
                      <b>{school.name}</b> ({school.code})
                      <div className="muted" style={{ fontSize: 11 }}>
                        Plan: {school.plan} · {money(school.monthlyFee)}/mo ·
                        Owner: {school.ownerEmail}
                      </div>
                    </div>
                    <div
                      style={{ display: "flex", alignItems: "center", gap: 12 }}
                    >
                      <NeuBadge
                        tone={school.daysLeft < 15 ? "warning" : "neutral"}
                      >
                        {school.daysLeft} days remaining
                      </NeuBadge>
                      <Link to="/sys-master/workspace/plans">
                        <NeuButton variant="secondary" icon="arrow-right">
                          Extend
                        </NeuButton>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </NeuCard>
        </>
      )}
    </>
  );
}
