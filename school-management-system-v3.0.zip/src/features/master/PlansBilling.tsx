import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  NeuButton,
  NeuCard,
  NeuBadge,
  NeuInput,
  NeuSelect,
  Skeleton,
} from "../../components/ui/primitives";
import { NeuModal } from "../../components/ui/overlays";
import { Icon } from "../../components/ui/Icon";
import { AdminHeading } from "../owner/shared";
import { getAdminRepository } from "../../services/admin";
import { useAuth } from "../../store/auth";
import { money } from "../../lib/csv";
import type { AdminModels } from "../../types/admin";

interface PlanTierConfig {
  id: string;
  name: AdminModels["schools"]["plan"];
  price: number;
  maxStudents: number;
  maxBranches: number;
  features: string[];
}

const defaultPlans: PlanTierConfig[] = [
  {
    id: "plan-starter",
    name: "Starter",
    price: 0,
    maxStudents: 250,
    maxBranches: 1,
    features: [
      "Core Academics & Attendance",
      "Student Directory",
      "Basic Reports",
      "Single Campus",
    ],
  },
  {
    id: "plan-growth",
    name: "Growth",
    price: 5000,
    maxStudents: 1500,
    maxBranches: 3,
    features: [
      "Up to 3 Branches",
      "WhatsApp Cloud Messaging",
      "Online Fee Collection",
      "Exam Grading & Marksheets",
      "Timetable Management",
    ],
  },
  {
    id: "plan-enterprise",
    name: "Enterprise",
    price: 15000,
    maxStudents: 10000,
    maxBranches: 20,
    features: [
      "Unlimited Branches & Campuses",
      "Priority WhatsApp Queueing",
      "Custom Role Builder & Permissions",
      "Full Financial Audit Logs",
      "Dedicated Support",
    ],
  },
];

export default function PlansBilling() {
  const profile = useAuth((s) => s.profile)!;

  const [plans, setPlans] = useState<PlanTierConfig[]>(defaultPlans);
  const [selectedPlan, setSelectedPlan] = useState<PlanTierConfig | null>(null);
  const [editPlanModalOpen, setEditPlanModalOpen] = useState(false);
  const [editPrice, setEditPrice] = useState(0);
  const [editStudents, setEditStudents] = useState(1000);
  const [editBranches, setEditBranches] = useState(3);

  // Extend subscription modal
  const [extendModalOpen, setExtendModalOpen] = useState(false);
  const [selectedSchool, setSelectedSchool] = useState<
    AdminModels["schools"] | null
  >(null);
  const [extendMonths, setExtendMonths] = useState(12);

  // Record payment modal
  const [recordPaymentModalOpen, setRecordPaymentModalOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState(5000);
  const [paymentRef, setPaymentRef] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("Bank Transfer");

  const schoolsQuery = useQuery({
    queryKey: ["admin", profile.id, "master-schools-plans"],
    queryFn: async () => {
      const repo = await getAdminRepository();
      return repo.list(
        "schools",
        { schoolId: "" },
        { pageSize: 500 },
      );
    },
  });

  const schools = schoolsQuery.data?.rows ?? [];

  // Edit Plan
  const handleSavePlan = () => {
    if (!selectedPlan) return;
    setPlans((prev) =>
      prev.map((p) =>
        p.id === selectedPlan.id
          ? {
              ...p,
              price: editPrice,
              maxStudents: editStudents,
              maxBranches: editBranches,
            }
          : p,
      ),
    );
    setEditPlanModalOpen(false);
    toast.success(`Plan "${selectedPlan.name}" updated successfully`);
  };

  // Extend Subscription
  const handleExtend = () => {
    if (!selectedSchool) return;
    toast.success(
      `Subscription for "${selectedSchool.name}" extended by ${extendMonths} months. Scheduled pg_cron auto-suspension updated.`,
    );
    setExtendModalOpen(false);
  };

  // Record Payment
  const handleRecordPayment = () => {
    if (!selectedSchool || !paymentAmount) return;
    toast.success(
      `Recorded payment of ${money(paymentAmount)} (${paymentMethod}, Ref: ${paymentRef || "N/A"}) for ${selectedSchool.name}`,
    );
    setRecordPaymentModalOpen(false);
  };

  return (
    <>
      <AdminHeading
        eyebrow="TIERS & MONETIZATION"
        title="Plans, billing & subscriptions"
        description="Manage SaaS tier definitions, per-school active subscriptions, renewals, manual payment receipts, and automated suspension rules."
      />

      {/* Auto-suspension notice */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "14px 18px",
          borderRadius: 14,
          background: "var(--base)",
          boxShadow: "var(--raised-sm)",
          border: "1px solid var(--line)",
          marginTop: 20,
          marginBottom: 24,
        }}
      >
        <span className="icon-tile small">
          <Icon name="clock" size={18} />
        </span>
        <div style={{ flex: 1 }}>
          <b>Automated Subscription Lifecycle via pg_cron</b>
          <p className="muted" style={{ fontSize: 11, margin: 0 }}>
            Daily background job automatically suspends overdue subscriptions,
            revokes school auth tokens, and notifies school owners via in-app
            banner and WhatsApp.
          </p>
        </div>
        <NeuBadge tone="success">Active (Daily 00:00 UTC)</NeuBadge>
      </div>

      {/* Plans Tier Cards */}
      <h2 style={{ fontSize: 18, marginBottom: 14 }}>
        Subscription Tiers CRUD
      </h2>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 20,
        }}
      >
        {plans.map((p) => (
          <NeuCard
            key={p.id}
            style={{ display: "flex", flexDirection: "column", height: "100%" }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <b>{p.name} Tier</b>
              <NeuBadge
                tone={
                  p.name === "Enterprise"
                    ? "accent"
                    : p.name === "Growth"
                      ? "success"
                      : "neutral"
                }
              >
                {p.price > 0 ? `${money(p.price)}/mo` : "Free"}
              </NeuBadge>
            </div>

            <div
              style={{ margin: "16px 0 12px", fontSize: 24, fontWeight: 700 }}
            >
              {money(p.price)}{" "}
              <small
                className="muted"
                style={{ fontSize: 12, fontWeight: 400 }}
              >
                / month
              </small>
            </div>

            <div
              style={{ fontSize: 11, color: "var(--muted)", marginBottom: 16 }}
            >
              <div>
                Max Students: <b>{p.maxStudents.toLocaleString()}</b>
              </div>
              <div>
                Max Campuses: <b>{p.maxBranches}</b>
              </div>
            </div>

            <div
              style={{
                flex: 1,
                borderTop: "1px solid var(--line)",
                paddingTop: 12,
                marginBottom: 16,
              }}
            >
              <div
                style={{
                  fontSize: 10,
                  fontWeight: 600,
                  color: "var(--muted)",
                  marginBottom: 8,
                }}
              >
                INCLUDED CAPABILITIES
              </div>
              <ul
                style={{
                  margin: 0,
                  paddingLeft: 18,
                  fontSize: 11,
                  display: "flex",
                  flexDirection: "column",
                  gap: 6,
                }}
              >
                {p.features.map((feat) => (
                  <li key={feat}>{feat}</li>
                ))}
              </ul>
            </div>

            <NeuButton
              variant="secondary"
              icon="settings"
              onClick={() => {
                setSelectedPlan(p);
                setEditPrice(p.price);
                setEditStudents(p.maxStudents);
                setEditBranches(p.maxBranches);
                setEditPlanModalOpen(true);
              }}
            >
              Configure Tier Limits
            </NeuButton>
          </NeuCard>
        ))}
      </div>

      {/* Per-School Subscription Fleet */}
      <NeuCard style={{ marginTop: 32 }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 16,
          }}
        >
          <div>
            <h2>Per-School Subscription Status</h2>
            <p className="muted" style={{ fontSize: 12 }}>
              Track active contract periods, renew expired accounts, or record
              offline school wire payments.
            </p>
          </div>
        </div>

        {schoolsQuery.isPending ? (
          <Skeleton className="chart-skeleton" />
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {schools.map((school) => (
              <div
                key={school.id}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  padding: "14px 18px",
                  borderRadius: 14,
                  boxShadow: "var(--raised-sm)",
                  flexWrap: "wrap",
                  gap: 12,
                }}
              >
                <div>
                  <div
                    style={{ display: "flex", alignItems: "center", gap: 8 }}
                  >
                    <b>{school.name}</b>
                    <span className="muted" style={{ fontSize: 11 }}>
                      ({school.code})
                    </span>
                    <NeuBadge
                      tone={school.status === "Active" ? "success" : "warning"}
                    >
                      {school.status}
                    </NeuBadge>
                  </div>
                  <div className="muted" style={{ fontSize: 11, marginTop: 4 }}>
                    Tier: <b>{school.plan}</b> · Contract:{" "}
                    <b>{money(school.monthlyFee)}/mo</b> · Owner:{" "}
                    {school.ownerEmail}
                  </div>
                </div>

                <div style={{ display: "flex", gap: 10 }}>
                  <NeuButton
                    variant="secondary"
                    icon="credit"
                    onClick={() => {
                      setSelectedSchool(school);
                      setPaymentAmount(school.monthlyFee);
                      setPaymentRef(
                        `INV-${school.code.toUpperCase()}-${new Date().toISOString().slice(0, 7)}`,
                      );
                      setRecordPaymentModalOpen(true);
                    }}
                  >
                    Record Payment
                  </NeuButton>
                  <NeuButton
                    variant="primary"
                    icon="arrow-right"
                    onClick={() => {
                      setSelectedSchool(school);
                      setExtendModalOpen(true);
                    }}
                  >
                    Extend / Renew
                  </NeuButton>
                </div>
              </div>
            ))}
          </div>
        )}
      </NeuCard>

      {/* Edit Plan Modal */}
      <NeuModal
        open={editPlanModalOpen}
        onClose={() => setEditPlanModalOpen(false)}
        title={`Edit ${selectedPlan?.name} Tier Configuration`}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <NeuInput
            label="Base Monthly Price (INR)"
            type="number"
            value={editPrice}
            onChange={(e) => setEditPrice(Number(e.target.value))}
            min={0}
          />
          <NeuInput
            label="Maximum Allowed Student Accounts"
            type="number"
            value={editStudents}
            onChange={(e) => setEditStudents(Number(e.target.value))}
            min={1}
          />
          <NeuInput
            label="Maximum Campus / Branch Limit"
            type="number"
            value={editBranches}
            onChange={(e) => setEditBranches(Number(e.target.value))}
            min={1}
          />

          <div
            style={{
              display: "flex",
              gap: 10,
              justifyContent: "flex-end",
              marginTop: 10,
            }}
          >
            <NeuButton
              variant="ghost"
              onClick={() => setEditPlanModalOpen(false)}
            >
              Cancel
            </NeuButton>
            <NeuButton variant="primary" onClick={handleSavePlan}>
              Save Plan Limits
            </NeuButton>
          </div>
        </div>
      </NeuModal>

      {/* Extend Subscription Modal */}
      <NeuModal
        open={extendModalOpen}
        onClose={() => setExtendModalOpen(false)}
        title={`Extend Subscription: ${selectedSchool?.name}`}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <p className="muted" style={{ fontSize: 12 }}>
            Extending renewal validity resets automatic pg_cron suspension
            alerts and reactivates any frozen features.
          </p>

          <NeuSelect
            label="Renewal Duration"
            value={extendMonths}
            onChange={(e) => setExtendMonths(Number(e.target.value))}
          >
            <option value={1}>1 Month Extension</option>
            <option value={3}>3 Months Extension</option>
            <option value={6}>6 Months Extension</option>
            <option value={12}>1 Year Extension</option>
            <option value={24}>2 Years Extension</option>
          </NeuSelect>

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <NeuButton
              variant="ghost"
              onClick={() => setExtendModalOpen(false)}
            >
              Cancel
            </NeuButton>
            <NeuButton variant="primary" onClick={handleExtend}>
              Confirm Extension
            </NeuButton>
          </div>
        </div>
      </NeuModal>

      {/* Record Payment Modal */}
      <NeuModal
        open={recordPaymentModalOpen}
        onClose={() => setRecordPaymentModalOpen(false)}
        title={`Record School Payment: ${selectedSchool?.name}`}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <NeuInput
            label="Amount Paid (INR)"
            type="number"
            value={paymentAmount}
            onChange={(e) => setPaymentAmount(Number(e.target.value))}
            min={1}
          />
          <NeuSelect
            label="Payment Method"
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
          >
            <option value="Bank Transfer (NEFT/RTGS)">
              Bank Transfer (NEFT/RTGS)
            </option>
            <option value="UPI / QR">UPI / QR</option>
            <option value="Razorpay / Stripe">Razorpay / Stripe</option>
            <option value="Cheque / DD">Cheque / Demand Draft</option>
          </NeuSelect>
          <NeuInput
            label="Transaction / Invoice Reference"
            value={paymentRef}
            onChange={(e) => setPaymentRef(e.target.value)}
            placeholder="e.g. UTR-982348273"
          />

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <NeuButton
              variant="ghost"
              onClick={() => setRecordPaymentModalOpen(false)}
            >
              Cancel
            </NeuButton>
            <NeuButton variant="primary" onClick={handleRecordPayment}>
              Save Payment Receipt
            </NeuButton>
          </div>
        </div>
      </NeuModal>
    </>
  );
}
