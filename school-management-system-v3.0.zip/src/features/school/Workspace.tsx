import { lazy, Suspense, useEffect, useMemo, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { toast } from "sonner";
import { create } from "zustand";
import { getWorkflows } from "../../services/workflows";
import { getRepository } from "../../services";
import { useAuth } from "../../store/auth";
import { useUI } from "../../store/ui";
import { queryClient } from "../../lib/query";
import { config } from "../../lib/config";
import { useDebounce } from "../../hooks/useDebounce";
import { downloadCsv, money } from "../../lib/csv";
import {
  NeuBadge,
  NeuButton,
  NeuCard,
  NeuInput,
  NeuSelect,
  SearchBar,
  Skeleton,
  ErrorState,
  EmptyState,
  StatCard,
  DatePicker,
} from "../../components/ui/primitives";
import { NeuModal, ConfirmDialog } from "../../components/ui/overlays";
import { NeuTable } from "../../components/ui/NeuTable";
import { FileUpload } from "../../components/ui/FileUpload";
import { Icon } from "../../components/ui/Icon";
import { AdminHeading, Pagination } from "../owner/shared";
import {
  definition,
  moduleKeys,
  validateFlow,
  type ModuleKey,
  type FlowRecord,
  type FlowPage,
} from "./model";
const Chart = lazy(() => import("../owner/AnalyticsChart"));
const selection = create<{
  student: string;
  classroom: string;
  setStudent: (value: string) => void;
  setClass: (value: string) => void;
}>((set) => ({
  student: "",
  classroom: "",
  setStudent: (student) => set({ student }),
  setClass: (classroom) => set({ classroom }),
}));
const today = () => new Date().toISOString().slice(0, 10);
function useWorkspace() {
  const user = useAuth((s) => s.profile)!;
  const branch = useUI((s) => s.branchId);
  const chosen = selection();
  const context = useQuery({
    queryKey: ["workflow-context", user.id, branch],
    queryFn: async () => (await getWorkflows()).context(branch),
    enabled: !!branch,
  });
  const family = ["parent", "student"].includes(user.role);
  const student =
    context.data?.students.find((s) => s.id === chosen.student) ??
    context.data?.students[0];
  const classroom =
    context.data?.classes.find((c) => c.id === chosen.classroom) ??
    context.data?.classes[0];
  return { user, branch, context, chosen, student, classroom, family };
}
function ScopeBar() {
  const { user, context, chosen, student, classroom, family } = useWorkspace();
  return (
    <div className="flow-scope">
      {context.isPending ? (
        <Skeleton className="branch-skeleton" />
      ) : context.isError ? (
        <ErrorState
          description={context.error.message}
          onRetry={() => void context.refetch()}
        />
      ) : family ? (
        <NeuSelect
          aria-label="Selected child"
          value={student?.id ?? ""}
          onChange={(e) => chosen.setStudent(e.target.value)}
        >
          {context.data.students.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </NeuSelect>
      ) : user.role !== "accountant" && context.data.classes.length > 0 ? (
        <NeuSelect
          aria-label="Selected class"
          value={classroom?.id ?? ""}
          onChange={(e) => chosen.setClass(e.target.value)}
        >
          {context.data.classes.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </NeuSelect>
      ) : null}
      <NeuBadge>
        {family
          ? "Only your family’s records"
          : user.role === "teacher"
            ? "Assigned classes only"
            : "Assigned campus"}
      </NeuBadge>
    </div>
  );
}
export function useFlow(
  module: ModuleKey | "all",
  search = "",
  page = 0,
  pageSize = 12,
  filters: { date?: string; title?: string; subject?: string } = {},
) {
  const workspace = useWorkspace();
  const { user, branch, student, classroom, family } = workspace;
  const scopedClass =
    module !== "all" &&
    !["classes", "admissions"].includes(module) &&
    definition(module).classroom;
  const scope = {
    branchId: branch,
    ...(family && student
      ? { studentId: student.id, classId: student.classId }
      : scopedClass && classroom
        ? { classId: classroom.id }
        : {}),
    search,
    page,
    pageSize,
    ...filters,
  };
  const key = ["workflows", user.id, module, scope] as const;
  const query = useQuery({
    queryKey: key,
    queryFn: async () => (await getWorkflows()).list(module, scope),
    enabled: !!branch && !workspace.context.isPending,
  });
  useEffect(() => {
    let live = true;
    let off: (() => void) | undefined;
    void getWorkflows().then((repo) => {
      if (live)
        off = repo.subscribe(() => {
          void queryClient.invalidateQueries({
            queryKey: ["workflows", user.id],
          });
        });
    });
    return () => {
      live = false;
      off?.();
    };
  }, [user.id]);
  const mutation = useMutation({
    mutationFn: async (record: FlowRecord) =>
      (await getWorkflows()).save(record),
    onMutate: async (record) => {
      await queryClient.cancelQueries({ queryKey: key });
      const previous = queryClient.getQueryData<FlowPage>(key);
      queryClient.setQueryData<FlowPage>(key, (old) =>
        old
          ? {
              ...old,
              rows: [record, ...old.rows.filter((r) => r.id !== record.id)],
            }
          : old,
      );
      return { previous };
    },
    onError: (error, _record, context) => {
      if (context) queryClient.setQueryData(key, context.previous);
      toast.error(error.message);
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ["workflows", user.id] });
      void queryClient.invalidateQueries({ queryKey: ["admin"] });
      void queryClient.invalidateQueries({ queryKey: ["workflow-context"] });
    },
  });
  return { ...workspace, query, mutation };
}
function safe(value: unknown) {
  return String(value ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ] ?? c,
  );
}
function downloadRecord(row: FlowRecord, name: string) {
  const content = `<!doctype html><html lang="en"><meta charset="utf-8"><title>${safe(name)}</title><style>body{font:16px system-ui;max-width:760px;margin:60px auto;padding:20px}h1{border-bottom:2px solid #647dba;padding-bottom:20px}dt{font-weight:600;margin-top:16px}dd{margin:6px 0;color:#435063}</style><h1>${safe(name)}</h1><p>School Management System v3.0 · ${safe(row.id)}</p><dl>${Object.entries(
    row.data,
  )
    .map(([key, value]) => `<dt>${safe(key)}</dt><dd>${safe(value)}</dd>`)
    .join(
      "",
    )}</dl><p>Record updated ${safe(row.updatedAt)}. ${config.mock ? "Demonstration document." : ""}</p></html>`;
  const url = URL.createObjectURL(
    new Blob([content], { type: "text/html;charset=utf-8" }),
  );
  const link = document.createElement("a");
  link.href = url;
  link.download = `${row.module}-${row.id}.html`;
  link.click();
  URL.revokeObjectURL(url);
}
export function SchoolHome() {
  const flow = useFlow("all", "", 0, 8);
  const { user, query } = flow;
  const available = moduleKeys.filter((key) =>
    definition(key).readers.includes(user.role),
  );
  return (
    <>
      <AdminHeading
        title={
          user.role === "teacher"
            ? "Your classroom, connected"
            : user.role === "principal"
              ? "A clear view of your school"
              : user.role === "accountant"
                ? "Every school day, accounted for"
                : "Growing together, every day"
        }
        description={`Welcome, ${user.name.split(" ")[0]}. Your role and campus keep the right information close.`}
      />
      <ScopeBar />
      {query.isPending ? (
        <div className="admin-stat-grid" style={{ minHeight: 120 }}>
          <Skeleton className="card-skeleton" style={{ height: 110 }} />
          <Skeleton className="card-skeleton" style={{ height: 110 }} />
          <Skeleton className="card-skeleton" style={{ height: 110 }} />
          <Skeleton className="card-skeleton" style={{ height: 110 }} />
        </div>
      ) : query.isError ? (
        <ErrorState
          description={query.error.message}
          onRetry={() => void query.refetch()}
        />
      ) : (
        <>
          <div className="admin-stat-grid">
            {(user.role === "accountant"
              ? ["fees", "expenses", "payroll", "reconciliation"]
              : ["attendance", "assignments", "marks", "announcements"]
            ).map((key) => (
              <StatCard
                key={key}
                label={definition(key as ModuleKey).title}
                value={query.data.counts[key] ?? 0}
                icon={definition(key as ModuleKey).icon}
                detail="Accessible records"
              />
            ))}
          </div>
          <div className="directory-grid">
            {available.map((key) => (
              <Link to={`/${user.role}/${key}`} key={key}>
                <NeuCard className="flow-tool">
                  <Icon name={definition(key).icon} size={26} />
                  <h3>{definition(key).title}</h3>
                  <p>{definition(key).description}</p>
                  <span className="text-button">
                    Open workspace <Icon name="arrow-right" size={16} />
                  </span>
                </NeuCard>
              </Link>
            ))}
          </div>
          <NeuCard>
            <h2>Recent updates</h2>
            {query.data.rows.map((row) => (
              <Link
                className="activity-row"
                to={`/${user.role}/${row.module}`}
                key={row.id}
              >
                <Icon name={definition(row.module).icon} />
                <div>
                  <b>
                    {String(row.data.title ?? definition(row.module).title)}
                  </b>
                  <small>
                    {String(row.data.date ?? "")} ·{" "}
                    {String(row.data.status ?? definition(row.module).title)}
                  </small>
                </div>
                <Icon name="arrow-up-right" size={16} />
              </Link>
            ))}
          </NeuCard>
        </>
      )}
    </>
  );
}
export default function WorkflowPage({
  module,
  readOnly = false,
}: {
  module: ModuleKey;
  readOnly?: boolean;
}) {
  const moduleDef = definition(module);
  const [search, setSearch] = useState("");
  const debounced = useDebounce(search);
  const [page, setPage] = useState(0);
  const flow = useFlow(module, debounced, page);
  const { user, query, mutation, context, branch, family, student, classroom } =
    flow;
  const editable = !readOnly && moduleDef.writers.includes(user.role);
  const [editing, setEditing] = useState<FlowRecord | "new" | null>(null);
  const [removing, setRemoving] = useState<FlowRecord | null>(null);
  const [payment, setPayment] = useState<FlowRecord | null>(null);
  const [busy, setBusy] = useState(false);
  const [filePath, setFilePath] = useState("");
  const [studentId, setStudentId] = useState("");
  const [fileClass, setFileClass] = useState("");
  const schema = useMemo(
    () =>
      z
        .record(z.string(), z.string())
        .superRefine((values: Record<string, string>, ctx) => {
          for (const field of moduleDef.fields) {
            if (field.required && !values[field.key]?.trim())
              ctx.addIssue({
                code: "custom",
                path: [field.key],
                message: `${field.label} is required.`,
              });
            if (
              field.type === "number" &&
              values[field.key] !== "" &&
              values[field.key] !== undefined &&
              (!Number.isFinite(Number(values[field.key])) ||
                Number(values[field.key]) < 0)
            )
              ctx.addIssue({
                code: "custom",
                path: [field.key],
                message: "Enter a nonnegative number.",
              });
          }
        }),
    [moduleDef.fields],
  );
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<Record<string, string>>({ resolver: zodResolver(schema) });
  const open = useCallback(
    (row: FlowRecord | "new") => {
      reset(
        Object.fromEntries(
          moduleDef.fields.map((field) => [
            field.key,
            row === "new"
              ? (field.options?.[0] ?? (field.type === "date" ? today() : ""))
              : String(row.data[field.key] ?? ""),
          ]),
        ),
      );
      setStudentId(
        row === "new"
          ? module === "leaves" && user.role === "teacher"
            ? ""
            : (student?.id ?? "")
          : (row.studentId ?? ""),
      );
      setFileClass(row === "new" ? (classroom?.id ?? "") : (row.classId ?? ""));
      setFilePath(row === "new" ? "" : String(row.data.filePath ?? ""));
      setEditing(row);
    },
    [moduleDef.fields, reset, module, user.role, student?.id, classroom?.id],
  );
  const submit = handleSubmit(async (values) => {
    try {
      const data: FlowRecord["data"] = { ...values };
      for (const field of moduleDef.fields)
        if (field.type === "number")
          data[field.key] = Number(values[field.key] ?? 0);
      if (filePath) data.filePath = filePath;
      if (module === "leaves" && ["teacher", "parent"].includes(user.role))
        data.status = "Requested";
      if (module === "privacy" && user.role !== "owner")
        data.status = "Requested";
      if (module === "marks" && data.status === "Published")
        data.publishedAt = new Date().toISOString();
      const record = validateFlow({
        ...(editing && editing !== "new"
          ? editing
          : {
              id: crypto.randomUUID(),
              schoolId: user.schoolId,
              branchId: branch,
              classId: null,
              studentId: null,
              authorId: user.id,
              module,
              version: 1,
              updatedAt: new Date().toISOString(),
            }),
        classId: moduleDef.classroom
          ? fileClass || null
          : moduleDef.student
            ? (context.data?.students.find((s) => s.id === studentId)
                ?.classId ?? null)
            : null,
        studentId: moduleDef.student ? studentId || null : null,
        data,
      });
      if (module === "classes" && editing === "new") record.classId = record.id;
      await mutation.mutateAsync(record);
      setEditing(null);
      toast.success("Record saved");
    } catch (error) {
      if (error instanceof Error) toast.error(error.message);
    }
  });
  const exportRows = async () => {
    setBusy(true);
    try {
      const repository = await getWorkflows();
      const rows: FlowRecord[] = [];
      let count = 1,
        index = 0;
      while (rows.length < count) {
        const result = await repository.list(module, {
          branchId: branch,
          ...(family && student
            ? { studentId: student.id, classId: student.classId }
            : moduleDef.classroom && classroom
              ? { classId: classroom.id }
              : {}),
          search: debounced,
          page: index++,
          pageSize: 500,
        });
        rows.push(...result.rows);
        count = result.total;
        if (!result.rows.length) break;
      }
      downloadCsv(
        `campus-${module}.csv`,
        ["Student", ...moduleDef.fields.map((f) => f.label)],
        rows.map((row) => [
          context.data?.students.find((s) => s.id === row.studentId)?.name ??
            "",
          ...moduleDef.fields.map((f) => String(row.data[f.key] ?? "")),
        ]),
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Export failed");
    } finally {
      setBusy(false);
    }
  };
  const columns = useMemo<ColumnDef<FlowRecord, unknown>[]>(
    () => [
      ...(moduleDef.student
        ? [
            {
              id: "student",
              header: "Student",
              accessorFn: (row: FlowRecord) =>
                context.data?.students.find((s) => s.id === row.studentId)
                  ?.name ?? "Staff / school",
            },
          ]
        : []),
      ...moduleDef.fields
        .filter((field, index) => index < 3 || field.key === "status")
        .map((field) => ({
          id: field.key,
          header: field.label,
          accessorFn: (row: FlowRecord) => String(row.data[field.key] ?? ""),
        })),
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => (
          <NeuButton variant="ghost" onClick={() => open(row.original)}>
            {editable ? "Edit" : "Details"}
          </NeuButton>
        ),
      },
    ],
    [editable, context.data, moduleDef.fields, moduleDef.student, open],
  );
  return (
    <>
      <AdminHeading title={moduleDef.title} description={moduleDef.description}>
        <NeuButton
          icon="download"
          loading={busy}
          onClick={() => void exportRows()}
        >
          Export
        </NeuButton>
        {editable && (
          <NeuButton variant="primary" icon="plus" onClick={() => open("new")}>
            Add record
          </NeuButton>
        )}
      </AdminHeading>
      <ScopeBar />
      {readOnly && (
        <div className="readonly-banner">
          <Icon name="lock" />
          Your role can review this area. Changes are restricted.
        </div>
      )}
      {module === "attendance" && editable ? (
        <AttendanceGrid />
      ) : module === "marks" && editable ? (
        <Gradebook />
      ) : (
        <>
          <div className="records-toolbar">
            <SearchBar
              value={search}
              onChange={(value) => {
                setSearch(value);
                setPage(0);
              }}
              placeholder={`Search ${moduleDef.title.toLowerCase()}…`}
            />
            <NeuBadge>{query.data?.total ?? 0} records</NeuBadge>
          </div>
          {query.isPending ? (
            <Skeleton className="hero-skeleton" />
          ) : query.isError ? (
            <ErrorState
              description={query.error.message}
              onRetry={() => void query.refetch()}
            />
          ) : (
            <>
              {module === "admissions" && (
                <div
                  className="admission-pipeline"
                  aria-label="Admissions pipeline for this page"
                >
                  {moduleDef.fields
                    .find((field) => field.key === "status")
                    ?.options?.map((stage) => (
                      <NeuCard key={stage}>
                        <h3>{stage}</h3>
                        <NeuBadge>
                          {
                            query.data.rows.filter(
                              (row) => row.data.status === stage,
                            ).length
                          }
                        </NeuBadge>
                        {query.data.rows
                          .filter((row) => row.data.status === stage)
                          .map((row) => (
                            <NeuButton
                              key={row.id}
                              variant="ghost"
                              onClick={() => open(row)}
                            >
                              {String(row.data.applicant ?? row.data.title)}
                            </NeuButton>
                          ))}
                      </NeuCard>
                    ))}
                </div>
              )}
              <NeuCard>
                <NeuTable
                  data={query.data.rows}
                  columns={columns}
                  rowKey={(row) => row.id}
                  label={moduleDef.title}
                  renderMobile={(row) => (
                    <div className="record-mobile">
                      <div>
                        <b>
                          {String(
                            row.data.title ??
                              context.data?.students.find(
                                (s) => s.id === row.studentId,
                              )?.name ??
                              moduleDef.title,
                          )}
                        </b>
                        <small>
                          {String(row.data.date ?? "")} ·{" "}
                          {String(row.data.status ?? row.data.notes ?? "")}
                        </small>
                        {row.data.amount !== undefined && (
                          <strong>
                            {money(
                              Math.max(
                                0,
                                Number(row.data.amount) -
                                  Number(row.data.discount ?? 0) +
                                  Number(row.data.fine ?? 0),
                              ),
                            )}
                          </strong>
                        )}
                      </div>
                      <NeuButton variant="ghost" onClick={() => open(row)}>
                        {editable ? "Edit" : "Details"}
                      </NeuButton>
                      {["fees", "certificates", "marks"].includes(module) && (
                        <NeuButton
                          variant="ghost"
                          icon="download"
                          aria-label="Download document"
                          onClick={() =>
                            downloadRecord(
                              row,
                              String(row.data.title ?? moduleDef.title),
                            )
                          }
                        />
                      )}
                    </div>
                  )}
                />
                <Pagination
                  page={page}
                  setPage={setPage}
                  total={query.data.total}
                />
              </NeuCard>
            </>
          )}
        </>
      )}
      {module === "marks" && !editable && query.data && (
        <NeuCard>
          <h2>Learning progress</h2>
          <Suspense fallback={<Skeleton className="chart-skeleton" />}>
            <Chart
              data={query.data.rows.map((row) => ({
                label: String(row.data.subject ?? "Assessment"),
                value: Number(row.data.maximum)
                  ? Math.round(
                      (Number(row.data.score) / Number(row.data.maximum)) * 100,
                    )
                  : 0,
              }))}
              valueLabel="Score (%)"
            />
          </Suspense>
        </NeuCard>
      )}
      <NeuModal
        open={!!editing}
        onClose={() => !mutation.isPending && setEditing(null)}
        title={`${editing === "new" ? "Create" : editable ? "Edit" : "View"} · ${moduleDef.title}`}
        footer={
          <>
            {editing !== "new" && editing && (
              <NeuButton
                icon="download"
                onClick={() =>
                  downloadRecord(
                    editing,
                    String(editing.data.title ?? moduleDef.title),
                  )
                }
              >
                Download
              </NeuButton>
            )}
            {editing &&
              editing !== "new" &&
              module === "fees" &&
              family &&
              editing.data.status !== "Paid" && (
                <NeuButton
                  variant="primary"
                  onClick={() => setPayment(editing)}
                >
                  Pay fee
                </NeuButton>
              )}
            {editable && (
              <>
                <NeuButton
                  variant="primary"
                  loading={mutation.isPending}
                  onClick={() => void submit()}
                >
                  Save
                </NeuButton>
                {editing !== "new" &&
                  editing &&
                  ["owner", "principal", "accountant"].includes(user.role) &&
                  !["privacy", "whatsapp"].includes(module) && (
                    <NeuButton
                      onClick={() => {
                        setRemoving(editing);
                        setEditing(null);
                      }}
                    >
                      Delete
                    </NeuButton>
                  )}
              </>
            )}
          </>
        }
      >
        <form className="admin-form" onSubmit={submit}>
          {moduleDef.student && (
            <NeuSelect
              id="flow-student"
              label="Student"
              disabled={!editable}
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
            >
              {module === "leaves" && <option value="">Staff leave</option>}
              {context.data?.students.map((s) => (
                <option value={s.id} key={s.id}>
                  {s.name}
                </option>
              ))}
            </NeuSelect>
          )}
          {moduleDef.classroom && (
            <NeuSelect
              id="flow-class"
              label="Class"
              disabled={!editable}
              value={fileClass}
              onChange={(e) => setFileClass(e.target.value)}
            >
              {context.data?.classes.map((c) => (
                <option value={c.id} key={c.id}>
                  {c.name}
                </option>
              ))}
            </NeuSelect>
          )}
          {moduleDef.fields.map((field) =>
            field.type === "select" ? (
              <NeuSelect
                key={field.key}
                label={field.label}
                id={`flow-${field.key}`}
                disabled={!editable}
                {...register(field.key)}
              >
                {field.options
                  ?.filter(
                    (option) =>
                      !(
                        field.key === "status" &&
                        ((module === "leaves" &&
                          ["teacher", "parent"].includes(user.role)) ||
                          (module === "privacy" && user.role !== "owner"))
                      ) || option === "Requested",
                  )
                  .filter(
                    (option) =>
                      !(
                        module === "lessons" &&
                        user.role === "teacher" &&
                        option === "Approved"
                      ),
                  )
                  .map((option) => (
                    <option value={option} key={option}>
                      {option}
                    </option>
                  ))}
              </NeuSelect>
            ) : field.type === "textarea" ? (
              <div className="field" key={field.key}>
                <label htmlFor={`flow-${field.key}`}>{field.label}</label>
                <textarea
                  id={`flow-${field.key}`}
                  readOnly={!editable}
                  rows={5}
                  {...register(field.key)}
                />
              </div>
            ) : (
              <NeuInput
                key={field.key}
                id={`flow-${field.key}`}
                label={field.label}
                type={
                  field.type === "number" || field.type === "date"
                    ? field.type
                    : "text"
                }
                readOnly={!editable}
                error={errors[field.key]?.message}
                {...register(field.key)}
              />
            ),
          )}
          {module === "lessons" && editable && (
            <FileUpload
              onUpload={async (file) => {
                setFilePath(
                  await (await getRepository()).storage.upload(file, branch),
                );
              }}
            />
          )}
          {filePath && (
            <NeuButton
              icon="download"
              type="button"
              onClick={() => {
                void getRepository()
                  .then((repo) => repo.storage.getUrl(filePath))
                  .then((url) =>
                    window.open(url, "_blank", "noopener,noreferrer"),
                  )
                  .catch((error) =>
                    toast.error(
                      error instanceof Error
                        ? error.message
                        : "Download failed",
                    ),
                  );
              }}
            >
              Open study material
            </NeuButton>
          )}
          {!editable && module === "fees" && (
            <p>
              Net due:{" "}
              {money(
                Math.max(
                  0,
                  Number(
                    editing && editing !== "new" ? editing.data.amount : 0,
                  ) -
                    Number(
                      editing && editing !== "new"
                        ? (editing.data.discount ?? 0)
                        : 0,
                    ) +
                    Number(
                      editing && editing !== "new"
                        ? (editing.data.fine ?? 0)
                        : 0,
                    ),
                ),
              )}
            </p>
          )}
        </form>
      </NeuModal>
      <ConfirmDialog
        open={!!removing}
        onClose={() => setRemoving(null)}
        title="Delete this record?"
        description="This deletes the selected record. Type DELETE to confirm."
        confirmText="DELETE"
        loading={busy}
        onConfirm={() => {
          if (!removing) return;
          setBusy(true);
          void getWorkflows()
            .then((repo) => repo.remove(removing))
            .then(() => {
              setRemoving(null);
              void query.refetch();
              toast.success("Record deleted");
            })
            .catch((error) => toast.error(error.message))
            .finally(() => setBusy(false));
        }}
      />
      <NeuModal
        open={!!payment}
        onClose={() => setPayment(null)}
        title="School fee payment"
        description={
          config.mock
            ? "This is a local demo payment. No money will be charged."
            : "Online payment requires a configured payment gateway. Contact the school office for payment instructions."
        }
      >
        {payment && (
          <>
            <h2>
              {money(
                Math.max(
                  0,
                  Number(payment.data.amount) -
                    Number(payment.data.discount ?? 0) +
                    Number(payment.data.fine ?? 0),
                ),
              )}
            </h2>
            <p>{String(payment.data.title)}</p>
            {config.mock && (
              <NeuButton
                variant="primary"
                loading={busy}
                onClick={() => {
                  setBusy(true);
                  void import("../../mocks/workflows")
                    .then((m) => m.payDemoFee(payment))
                    .then((saved) => {
                      setPayment(null);
                      setEditing(null);
                      void query.refetch();
                      downloadRecord(saved, "Demo payment receipt");
                      toast.success("Demo payment recorded; no money charged");
                    })
                    .catch((error) => toast.error(error.message))
                    .finally(() => setBusy(false));
                }}
              >
                Simulate demo payment
              </NeuButton>
            )}
          </>
        )}
      </NeuModal>
    </>
  );
}
function AttendanceGrid() {
  const [date, setDate] = useState(today());
  const flow = useFlow("attendance", "", 0, 500, { date });
  const [bulk, setBulk] = useState(false);
  const roster =
    flow.context.data?.students.filter(
      (s) => s.classId === flow.classroom?.id,
    ) ?? [];
  const save = async (id: string, status: string) => {
    const existing = flow.query.data?.rows.find(
      (r) => r.studentId === id && r.data.date === date,
    );
    const student = roster.find((s) => s.id === id)!;
    await flow.mutation.mutateAsync({
      ...existing,
      id: existing?.id ?? crypto.randomUUID(),
      schoolId: flow.user.schoolId,
      branchId: flow.branch,
      classId: student.classId,
      studentId: id,
      authorId: existing?.authorId ?? flow.user.id,
      module: "attendance",
      version: existing?.version ?? 1,
      updatedAt: new Date().toISOString(),
      data: { date, status, notes: "" },
    });
  };
  return (
    <NeuCard>
      <div className="section-heading">
        <DatePicker label="Attendance date" value={date} onChange={setDate} />
        <NeuButton
          variant="primary"
          loading={bulk}
          onClick={async () => {
            setBulk(true);
            let failed = 0;
            for (const student of roster)
              try {
                await save(student.id, "Present");
              } catch {
                failed++;
              }
            setBulk(false);
            toast[failed ? "error" : "success"](
              failed
                ? `${failed} records failed. Retry those students.`
                : "All students marked present",
            );
          }}
        >
          Mark all present
        </NeuButton>
      </div>
      {flow.query.isPending ? (
        <Skeleton className="card-skeleton" />
      ) : flow.query.isError ? (
        <ErrorState
          description={flow.query.error.message}
          onRetry={() => void flow.query.refetch()}
        />
      ) : !roster.length ? (
        <EmptyState
          title="No assigned students"
          description="Your administrator can assign students and classes."
        />
      ) : (
        <div className="attendance-grid">
          {roster.map((student) => {
            const current = flow.query.data?.rows.find(
              (r) => r.studentId === student.id && r.data.date === date,
            );
            return (
              <article key={student.id}>
                <b>{student.name}</b>
                <div>
                  {["Present", "Absent", "Late", "Leave"].map((status) => (
                    <button
                      type="button"
                      disabled={bulk || flow.mutation.isPending}
                      aria-pressed={current?.data.status === status}
                      key={status}
                      onClick={() =>
                        void save(student.id, status).catch(() => undefined)
                      }
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </NeuCard>
  );
}
function Gradebook() {
  const [exam, setExam] = useState("Term assessment");
  const [subject, setSubject] = useState("Mathematics");
  const flow = useFlow("marks", "", 0, 500, { title: exam, subject });
  const [maximum, setMaximum] = useState(100);
  const [scores, setScores] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const students =
    flow.context.data?.students.filter(
      (s) => s.classId === flow.classroom?.id,
    ) ?? [];
  const save = async (status: string) => {
    if (
      maximum <= 0 ||
      students.some((s) => {
        const n = Number(
          scores[s.id] ??
            flow.query.data?.rows.find(
              (r) =>
                r.studentId === s.id &&
                r.data.title === exam &&
                r.data.subject === subject,
            )?.data.score ??
            0,
        );
        return !Number.isFinite(n) || n < 0 || n > maximum;
      })
    ) {
      toast.error("Check the marks and maximum score.");
      return;
    }
    setBusy(true);
    let failed = 0;
    for (const student of students) {
      const old = flow.query.data?.rows.find(
        (r) =>
          r.studentId === student.id &&
          r.data.title === exam &&
          r.data.subject === subject,
      );
      try {
        await flow.mutation.mutateAsync({
          ...old,
          id: old?.id ?? crypto.randomUUID(),
          schoolId: flow.user.schoolId,
          branchId: flow.branch,
          classId: student.classId,
          studentId: student.id,
          authorId: old?.authorId ?? flow.user.id,
          module: "marks",
          version: old?.version ?? 1,
          updatedAt: new Date().toISOString(),
          data: {
            title: exam,
            subject,
            date: today(),
            score: Number(scores[student.id] ?? old?.data.score ?? 0),
            maximum,
            status,
            notes: feedback[student.id] ?? String(old?.data.notes ?? ""),
          },
        });
      } catch {
        failed++;
      }
    }
    setBusy(false);
    toast[failed ? "error" : "success"](
      failed
        ? `${failed} marks could not be saved.`
        : status === "Published"
          ? "Results published"
          : "Draft marks saved",
    );
  };
  return (
    <NeuCard>
      <div className="gradebook-toolbar">
        <NeuInput
          id="exam-title"
          label="Assessment"
          value={exam}
          onChange={(e) => setExam(e.target.value)}
        />
        <NeuInput
          id="exam-subject"
          label="Subject"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />
        <NeuInput
          id="exam-maximum"
          label="Maximum"
          type="number"
          value={maximum}
          onChange={(e) => setMaximum(Number(e.target.value))}
        />
      </div>
      <p className="module-footnote">
        Use Tab or the arrow keys to move between marks. Publishing makes
        results visible to the student’s family.
      </p>
      {flow.query.isPending ? (
        <Skeleton className="card-skeleton" />
      ) : flow.query.isError ? (
        <ErrorState
          description={flow.query.error.message}
          onRetry={() => void flow.query.refetch()}
        />
      ) : (
        <div className="grade-grid">
          {students.map((student, index) => {
            const old = flow.query.data?.rows.find(
              (r) =>
                r.studentId === student.id &&
                r.data.title === exam &&
                r.data.subject === subject,
            );
            return (
              <label key={student.id}>
                <span>{student.name}</span>
                <input
                  aria-label={`Marks for ${student.name}`}
                  type="number"
                  min="0"
                  max={maximum}
                  data-mark-row={index}
                  value={scores[student.id] ?? String(old?.data.score ?? "")}
                  onChange={(e) =>
                    setScores((old) => ({
                      ...old,
                      [student.id]: e.target.value,
                    }))
                  }
                  onKeyDown={(e) => {
                    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
                      e.preventDefault();
                      document
                        .querySelector<HTMLInputElement>(
                          `[data-mark-row="${index + (e.key === "ArrowDown" ? 1 : -1)}"]`,
                        )
                        ?.focus();
                    }
                  }}
                />
                <small>{String(old?.data.status ?? "Not saved")}</small>
                <input
                  aria-label={`Feedback for ${student.name}`}
                  placeholder="Feedback"
                  value={feedback[student.id] ?? String(old?.data.notes ?? "")}
                  onChange={(e) =>
                    setFeedback((old) => ({
                      ...old,
                      [student.id]: e.target.value,
                    }))
                  }
                />
              </label>
            );
          })}
        </div>
      )}
      <div className="component-row">
        <NeuButton
          disabled={busy || !students.length}
          onClick={() => void save("Draft")}
        >
          Save drafts
        </NeuButton>
        <NeuButton
          variant="primary"
          loading={busy}
          disabled={!students.length}
          onClick={() => void save("Published")}
        >
          Publish results
        </NeuButton>
      </div>
    </NeuCard>
  );
}
