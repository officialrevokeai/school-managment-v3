import { z } from "zod";
import type { Role } from "../../types/domain";
import type { IconName } from "../../components/ui/Icon";
import type { Permission } from "../../lib/permissions";
export type Field = {
  key: string;
  label: string;
  type?: "text" | "number" | "date" | "select" | "textarea";
  options?: string[];
  required?: boolean;
};
export type Module = {
  title: string;
  description: string;
  icon: IconName;
  readers: Role[];
  writers: Role[];
  fields: Field[];
  student?: boolean;
  classroom?: boolean;
};
const academic: Role[] = ["owner", "principal", "teacher"];
const family: Role[] = [...academic, "parent", "student"];
const office: Role[] = ["owner", "accountant"];
const title: Field = { key: "title", label: "Title", required: true };
const date: Field = {
  key: "date",
  label: "Date",
  type: "date",
  required: true,
};
const notes: Field = { key: "notes", label: "Details", type: "textarea" };
const amount: Field = {
  key: "amount",
  label: "Amount (INR)",
  type: "number",
  required: true,
};
const status = (options: string[]): Field => ({
  key: "status",
  label: "Status",
  type: "select",
  options,
  required: true,
});
export const modules = {
  activity: {
    title: "My activity",
    description: "Your append-only workflow audit history.",
    icon: "shield",
    readers: [...family, "accountant"],
    writers: [],
    fields: [title, date, notes],
  },
  admissions: {
    classroom: true,
    title: "Admissions & transfers",
    description:
      "Move applications through review, admission, and campus transfer.",
    icon: "users",
    readers: ["owner", "principal", "accountant"],
    writers: ["owner", "principal"],
    fields: [
      title,
      { key: "applicant", label: "Applicant name", required: true },
      date,
      status(["Applied", "Review", "Admitted", "Transferred", "Declined"]),
      notes,
    ],
  },
  classes: {
    title: "Classes & subjects",
    description:
      "Organize subjects, class groups, and teaching responsibilities.",
    icon: "book",
    readers: academic,
    writers: ["owner", "principal"],
    classroom: true,
    fields: [
      title,
      { key: "subject", label: "Subject", required: true },
      { key: "teacher", label: "Teacher", required: true },
      { key: "room", label: "Room" },
      notes,
    ],
  },
  timetable: {
    title: "Timetable",
    description: "Your classes, rooms, and school day in one place.",
    icon: "calendar",
    readers: family,
    writers: ["owner", "principal"],
    classroom: true,
    fields: [
      title,
      date,
      { key: "start", label: "Start time (HH:MM)", required: true },
      { key: "end", label: "End time (HH:MM)", required: true },
      { key: "room", label: "Room" },
      notes,
    ],
  },
  attendance: {
    title: "Attendance",
    description:
      "Mark your assigned class quickly and review daily attendance.",
    icon: "calendar-check",
    readers: family,
    writers: academic,
    student: true,
    classroom: true,
    fields: [date, status(["Present", "Absent", "Late", "Leave"]), notes],
  },
  assignments: {
    title: "Homework & assignments",
    description: "Share homework, classwork, and assignment deadlines.",
    icon: "book",
    readers: family,
    writers: academic,
    classroom: true,
    fields: [
      title,
      {
        key: "kind",
        label: "Type",
        type: "select",
        options: ["Homework", "Classwork", "Assignment"],
      },
      date,
      { key: "due", label: "Due date", type: "date", required: true },
      notes,
    ],
  },
  marks: {
    title: "Exams & marks",
    description:
      "Enter marks, publish results, and follow each learner’s progress.",
    icon: "graduation",
    readers: family,
    writers: academic,
    student: true,
    classroom: true,
    fields: [
      title,
      { key: "subject", label: "Subject", required: true },
      date,
      { key: "score", label: "Marks obtained", type: "number", required: true },
      {
        key: "maximum",
        label: "Maximum marks",
        type: "number",
        required: true,
      },
      status(["Draft", "Published"]),
      notes,
    ],
  },
  lessons: {
    title: "Lessons & study material",
    description: "Upload learning resources and review lesson plans.",
    icon: "file",
    readers: family,
    writers: academic,
    classroom: true,
    fields: [title, date, status(["Draft", "Submitted", "Approved"]), notes],
  },
  performance: {
    title: "Teacher performance",
    description: "Record classroom observations and constructive feedback.",
    icon: "users",
    readers: ["owner", "principal"],
    writers: ["owner", "principal"],
    fields: [
      title,
      { key: "teacher", label: "Teacher name", required: true },
      date,
      { key: "rating", label: "Rating (1–5)", type: "number", required: true },
      notes,
    ],
  },
  meetings: {
    title: "Meetings",
    description: "Plan meetings, record minutes, and track follow-up actions.",
    icon: "calendar",
    readers: academic,
    writers: ["owner", "principal"],
    fields: [
      title,
      date,
      { key: "time", label: "Time" },
      { key: "attendees", label: "Attendees" },
      notes,
    ],
  },
  announcements: {
    title: "Announcements",
    description: "School and class updates for your community.",
    icon: "bell",
    readers: family,
    writers: academic,
    classroom: true,
    fields: [title, date, notes],
  },
  reports: {
    title: "Reports to Owner",
    description: "Send daily and weekly school-operation summaries.",
    icon: "file",
    readers: ["owner", "principal"],
    writers: ["owner", "principal"],
    fields: [
      title,
      {
        key: "period",
        label: "Reporting period",
        type: "select",
        options: ["Daily", "Weekly"],
      },
      date,
      status(["Draft", "Submitted", "Reviewed"]),
      notes,
    ],
  },
  leaves: {
    title: "Leave requests",
    description: "Request leave and follow its approval status.",
    icon: "calendar",
    readers: family,
    writers: [...academic, "parent"],
    student: true,
    fields: [
      title,
      date,
      { key: "until", label: "Until", type: "date", required: true },
      status(["Requested", "Approved", "Declined"]),
      notes,
    ],
  },
  messages: {
    title: "Messages",
    description:
      "Send in-app updates to families using approved communication channels.",
    icon: "message",
    readers: family,
    writers: academic,
    student: true,
    fields: [title, date, notes],
  },
  calendar: {
    title: "School calendar",
    description: "Holidays, examination dates, and school events.",
    icon: "calendar",
    readers: [...family, "accountant"],
    writers: ["owner", "principal"],
    fields: [
      title,
      date,
      {
        key: "kind",
        label: "Event type",
        type: "select",
        options: ["Holiday", "Exam", "Event"],
      },
      notes,
    ],
  },
  fees: {
    title: "Fees & receipts",
    description:
      "Fee structures, scholarships, fines, receipts, and outstanding balances.",
    icon: "wallet",
    readers: [...office, "parent", "student"],
    writers: office,
    student: true,
    fields: [
      title,
      date,
      { key: "due", label: "Due date", type: "date", required: true },
      amount,
      {
        key: "discount",
        label: "Discount / scholarship (INR)",
        type: "number",
      },
      { key: "fine", label: "Fine (INR)", type: "number" },
      status(["Pending", "Paid", "Overdue"]),
      notes,
    ],
  },
  expenses: {
    title: "Expenses & invoices",
    description: "Track vendors, invoices, payments, and expense approvals.",
    icon: "credit",
    readers: [...office, "principal"],
    writers: office,
    fields: [
      title,
      { key: "vendor", label: "Vendor", required: true },
      { key: "invoice", label: "Invoice reference", required: true },
      date,
      amount,
      status(["Pending", "Approved", "Paid"]),
      notes,
    ],
  },
  payroll: {
    title: "Staff payroll",
    description: "Prepare salary records and track payouts.",
    icon: "wallet",
    readers: office,
    writers: office,
    fields: [
      title,
      { key: "employee", label: "Staff member", required: true },
      date,
      amount,
      { key: "deduction", label: "Deductions (INR)", type: "number" },
      status(["Draft", "Approved", "Paid"]),
      notes,
    ],
  },
  certificates: {
    title: "Certificates",
    description: "Prepare and download school-issued certificates.",
    icon: "file",
    readers: [...office, "parent", "student"],
    writers: office,
    student: true,
    fields: [
      title,
      date,
      {
        key: "kind",
        label: "Certificate type",
        type: "select",
        options: ["Bonafide", "Transfer", "Fee statement", "Achievement"],
      },
      status(["Draft", "Issued"]),
      notes,
    ],
  },
  reconciliation: {
    title: "Financial reconciliation",
    description:
      "Compare school records with statements and resolve differences.",
    icon: "check-all",
    readers: office,
    writers: office,
    fields: [
      title,
      date,
      {
        key: "ledger",
        label: "Ledger balance (INR)",
        type: "number",
        required: true,
      },
      {
        key: "statement",
        label: "Statement balance (INR)",
        type: "number",
        required: true,
      },
      status(["Open", "Reconciled"]),
      notes,
    ],
  },
  privacy: {
    title: "Privacy & consent",
    description: "Manage consent and submit data export or deletion requests.",
    icon: "shield",
    readers: [...family, "accountant"],
    writers: [...family, "accountant"],
    fields: [
      title,
      {
        key: "kind",
        label: "Request type",
        type: "select",
        options: [
          "Consent granted",
          "Consent withdrawn",
          "Data export",
          "Data deletion",
        ],
      },
      date,
      status(["Requested", "Acknowledged", "Completed"]),
      notes,
    ],
  },
  whatsapp: {
    title: "WhatsApp delivery log",
    description:
      "Review queued, delivered, read, and failed template messages.",
    icon: "message",
    readers: ["owner"],
    writers: ["owner"],
    student: true,
    fields: [
      title,
      {
        key: "recipient",
        label: "Recipient number (+country code)",
        required: true,
      },
      { key: "template", label: "Approved template name", required: true },
      date,
      status(["Queued", "Sent", "Delivered", "Read", "Failed"]),
      notes,
    ],
  },
  automations: {
    title: "Communication automations",
    description:
      "Enable absence alerts, fee reminders, result updates, and announcements.",
    icon: "settings",
    readers: ["owner"],
    writers: ["owner"],
    fields: [
      title,
      {
        key: "event",
        label: "Trigger",
        type: "select",
        options: [
          "Absence",
          "Fee reminder",
          "Result published",
          "Announcement",
        ],
      },
      { key: "template", label: "Approved template name", required: true },
      status(["Enabled", "Disabled"]),
      notes,
    ],
  },
  notifications: {
    title: "Notification preferences",
    description: "Choose which WhatsApp updates you want to receive.",
    icon: "bell",
    readers: ["parent", "student"],
    writers: ["parent", "student"],
    fields: [
      title,
      {
        key: "event",
        label: "Update category",
        type: "select",
        options: ["Attendance", "Fees", "Results", "Announcements"],
      },
      status(["Enabled", "Disabled"]),
    ],
  },
} satisfies Record<string, Module>;
export type ModuleKey = keyof typeof modules;
export const moduleKeys = Object.keys(modules) as ModuleKey[];
export function definition(key: ModuleKey): Module {
  return modules[key];
}
export function workflowPermission(key: ModuleKey, role: Role): Permission {
  if (
    ["privacy", "notifications", "leaves", "calendar", "activity"].includes(key)
  )
    return "workspace.read";
  if (["parent", "student"].includes(role)) return "child.read";
  if (key === "expenses" && role === "principal") return "workspace.read";
  if (
    ["fees", "expenses", "payroll", "certificates", "reconciliation"].includes(
      key,
    )
  )
    return "finance.manage";
  if (["whatsapp", "automations"].includes(key)) return "whatsapp.manage";
  if (key === "admissions") return "users.manage";
  return "academics.read";
}
export const flowSchema = z.object({
  id: z.string(),
  schoolId: z.string(),
  branchId: z.string(),
  classId: z.string().nullable(),
  studentId: z.string().nullable(),
  authorId: z.string(),
  module: z.enum(moduleKeys as [ModuleKey, ...ModuleKey[]]),
  version: z.number().int().positive(),
  data: z.record(
    z.string(),
    z.union([z.string(), z.number(), z.boolean(), z.null()]),
  ),
  updatedAt: z.string(),
});
export type FlowRecord = z.infer<typeof flowSchema>;
export const contextSchema = z.object({
  students: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      classId: z.string(),
      branchId: z.string(),
    }),
  ),
  classes: z.array(
    z.object({ id: z.string(), name: z.string(), branchId: z.string() }),
  ),
});
export type FlowContext = z.infer<typeof contextSchema>;
export type FlowScope = {
  date?: string;
  title?: string;
  subject?: string;
  branchId: string;
  classId?: string;
  studentId?: string;
  search?: string;
  page?: number;
  pageSize?: number;
};
export type FlowPage = {
  rows: FlowRecord[];
  total: number;
  counts: Record<string, number>;
};
export function validateFlow(record: FlowRecord) {
  const parsed = flowSchema.parse(record);
  const config = definition(parsed.module);
  for (const field of config.fields) {
    const value = parsed.data[field.key];
    if (
      field.required &&
      (value === undefined || value === null || String(value).trim() === "")
    )
      throw new Error(`${field.label} is required.`);
    if (
      field.type === "number" &&
      value !== undefined &&
      (!Number.isFinite(Number(value)) || Number(value) < 0)
    )
      throw new Error(`${field.label} must be a nonnegative number.`);
    if (field.options && value && !field.options.includes(String(value)))
      throw new Error(`Invalid ${field.label.toLowerCase()}.`);
  }
  if (
    parsed.module === "marks" &&
    (Number(parsed.data.maximum) <= 0 ||
      Number(parsed.data.score) > Number(parsed.data.maximum))
  )
    throw new Error("Marks must be between zero and the maximum.");
  if (
    parsed.module === "performance" &&
    (Number(parsed.data.rating) < 1 || Number(parsed.data.rating) > 5)
  )
    throw new Error("Rating must be between 1 and 5.");
  if (parsed.data.until && String(parsed.data.until) < String(parsed.data.date))
    throw new Error("The end date must follow the start date.");
  if (
    parsed.module === "fees" &&
    Number(parsed.data.discount ?? 0) > Number(parsed.data.amount)
  )
    throw new Error("Discount cannot exceed the fee.");
  return parsed;
}
