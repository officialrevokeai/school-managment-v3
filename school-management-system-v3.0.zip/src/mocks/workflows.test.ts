import { beforeEach, describe, expect, it } from "vitest";
import { mockRepository } from "./adapter";
import { mockWorkflows, payDemoFee } from "./workflows";
function storage(): Storage {
  const map = new Map<string, string>();
  return {
    get length() {
      return map.size;
    },
    clear: () => map.clear(),
    getItem: (k) => map.get(k) ?? null,
    key: (i) => [...map.keys()][i] ?? null,
    removeItem: (k) => {
      map.delete(k);
    },
    setItem: (k, v) => {
      map.set(k, v);
    },
  };
}
beforeEach(() => {
  globalThis.localStorage = storage();
  globalThis.sessionStorage = storage();
});
const login = (role: string) =>
  mockRepository.auth.signIn({
    identifier: `${role}@greenwood.edu`,
    password: "Campus@2026",
    remember: false,
  });
describe("Class and child workflow isolation", () => {
  it("confines a teacher to their class and denies forged class writes", async () => {
    await login("teacher");
    expect((await mockWorkflows.context("north")).classes).toHaveLength(1);
    const page = await mockWorkflows.list("attendance", {
      branchId: "north",
      pageSize: 500,
    });
    expect(page.rows.every((r) => r.classId === "class-8a")).toBe(true);
    const row = page.rows[0]!;
    await expect(
      mockWorkflows.save({ ...row, classId: "class-9b" }),
    ).rejects.toThrow("assigned classes");
  });
  it("limits families to their children and makes demo payments idempotent", async () => {
    await login("parent");
    const context = await mockWorkflows.context("north");
    expect(context.students).toHaveLength(2);
    const fees = await mockWorkflows.list("fees", {
      branchId: "north",
      pageSize: 500,
    });
    expect(
      fees.rows.every((r) =>
        context.students.some((s) => s.id === r.studentId),
      ),
    ).toBe(true);
    const paid = await payDemoFee(fees.rows[0]!);
    expect(paid.data.status).toBe("Paid");
    expect((await payDemoFee(paid)).version).toBe(paid.version);
    await expect(
      mockWorkflows.save({ ...paid, data: { ...paid.data, amount: 16000 } }),
    ).rejects.toThrow("cannot edit");
  });
  it("keeps unpublished grades private and financial users outside academics", async () => {
    await login("teacher");
    const marks = (
      await mockWorkflows.list("marks", { branchId: "north" })
    ).rows.find((r) => r.studentId === "learner-1")!;
    await mockWorkflows.save({
      ...marks,
      data: { ...marks.data, status: "Draft" },
    });
    await login("parent");
    expect(
      (
        await mockWorkflows.list("marks", { branchId: "north", pageSize: 500 })
      ).rows.every((r) => r.data.status === "Published"),
    ).toBe(true);
    await login("accountant");
    expect(
      (await mockWorkflows.list("marks", { branchId: "north" })).rows,
    ).toHaveLength(0);
    expect(
      (await mockWorkflows.list("fees", { branchId: "north" })).total,
    ).toBeGreaterThan(0);
  });
});
