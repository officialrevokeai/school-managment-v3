import type { AdminModels, AdminResource } from "../types/admin";
import { parseRecord } from "../types/admin";
import { branches } from "./data";
import { roleLabels, rolePermissions } from "../lib/permissions";
import { z } from "zod";
const key = "campus-admin-v2";
type RecordSet = { [K in AdminResource]: AdminModels[K][] };
function seed(): RecordSet {
  const core = { schoolId: "greenwood", branchId: null, version: 1 };
  return {
    analytics: branches.flatMap((branch) =>
      Array.from({ length: 6 }, (_, i) => ({
        ...core,
        id: `attendance-${branch.id}-${i}`,
        branchId: branch.id,
        date: `2026-${String(i + 5).padStart(2, "0")}-01`,
        present: [182, 190, 186, 194, 188, 196][i]!,
        total: 200,
      })),
    ),
    schools: [
      {
        ...core,
        id: "greenwood",
        name: "Greenwood International School",
        code: "GW-001",
        ownerEmail: "owner@greenwood.edu",
        plan: "Enterprise",
        status: "Active",
        monthlyFee: 24900,
        createdAt: "2025-04-01",
      },
      {
        ...core,
        schoolId: "oakridge",
        id: "oakridge",
        name: "Oakridge Academy",
        code: "OA-002",
        ownerEmail: "admin@oakridge.edu",
        plan: "Growth",
        status: "Active",
        monthlyFee: 12900,
        createdAt: "2026-02-15",
      },
      {
        ...core,
        schoolId: "riverside",
        id: "riverside",
        name: "Riverside Public School",
        code: "RP-003",
        ownerEmail: "admin@riverside.edu",
        plan: "Starter",
        status: "Suspended",
        monthlyFee: 5900,
        createdAt: "2026-06-01",
      },
    ],
    branches: branches.map((branch, i) => ({
      ...core,
      id: branch.id,
      branchId: branch.id,
      name: branch.short_name,
      city: branch.city,
      code: ["GW-N", "GW-C", "GW-E"][i]!,
      principal: ["Sarah Williams", "Daniel Brown", "Emma Taylor"][i]!,
      capacity: [1200, 900, 600][i]!,
      status: "Active",
    })),
    users: Array.from({ length: 36 }, (_, i) => {
      const role = (
        [
          "student",
          "teacher",
          "parent",
          "student",
          "accountant",
          "principal",
        ] as const
      )[i % 6]!;
      const names = [
        "Aarav Sharma",
        "James Wilson",
        "Priya Sharma",
        "Maya Patel",
        "Olivia Davis",
        "Sarah Williams",
        "Noah Carter",
        "Amelia Chen",
        "Ethan Brooks",
        "Isla Thomas",
        "Liam Harris",
        "Sofia Lewis",
      ];
      const name = `${names[i % names.length]}${i >= names.length ? ` ${Math.floor(i / names.length) + 1}` : ""}`;
      return {
        ...core,
        id: `person-${i}`,
        branchId: ["north", "central", "east"][i % 3]!,
        name,
        policyId: null,
        email: `${name.toLowerCase().replaceAll(" ", ".")}@greenwood.edu`,
        role,
        status: i % 11 === 0 ? "Inactive" : "Active",
        phone: `+91 98${String(31000000 + i)}`,
        joinedAt: `2026-0${(i % 9) + 1}-12`,
      };
    }),
    finance: Array.from({ length: 30 }, (_, i) => ({
      ...core,
      id: `entry-${i}`,
      branchId: ["north", "central", "east"][i % 3]!,
      reference: `GW-2026-${String(i + 1).padStart(4, "0")}`,
      description:
        i % 4 === 0
          ? "Campus maintenance"
          : i % 4 === 1
            ? "Tuition fee collection"
            : i % 4 === 2
              ? "Term fee collection"
              : "Learning resources",
      kind: i % 4 === 0 || i % 4 === 3 ? "Expense" : "Income",
      category:
        i % 4 === 0 ? "Maintenance" : i % 4 === 3 ? "Supplies" : "Tuition",
      amount: [18000, 75000, 62000, 8500][i % 4]!,
      date: `2026-${String(5 + (i % 6)).padStart(2, "0")}-${String(1 + (i % 25)).padStart(2, "0")}`,
      status: i % 9 === 0 ? "Overdue" : i % 7 === 0 ? "Pending" : "Paid",
    })),
    roles: (Object.keys(rolePermissions) as (keyof typeof rolePermissions)[])
      .filter((role) => role !== "master")
      .map((role) => ({
        ...core,
        id: `role-${role}`,
        name: roleLabels[role],
        custom: false,
        role,
        permissions: [...rolePermissions[role]],
      })),
    settings: [
      {
        ...core,
        id: "settings-greenwood",
        name: "Greenwood International School",
        academicYear: "2026–2027",
        logoPath: "",
        senderNumber: "+919845001234",
        financeRole: "accountant",
        overrideEnabled: false,
        requireMfa: false,
        sessionMinutes: 60,
        privacyEmail: "privacy@greenwood.edu",
        retentionDays: 365,
      },
    ],
    templates: [
      {
        ...core,
        id: "template-fees",
        name: "Gentle fee reminder",
        category: "Fees",
        body: "Hello {{parent_name}}, a friendly reminder that {{amount}} is due for {{student_name}} on {{due_date}}. Thank you, Greenwood School.",
        status: "Approved",
      },
      {
        ...core,
        id: "template-attendance",
        name: "Daily absence update",
        category: "Attendance",
        body: "Hello {{parent_name}}, {{student_name}} was marked absent today. Please contact the school office if you have any questions.",
        status: "Approved",
      },
    ],
    audit: [
      {
        ...core,
        id: "audit-welcome",
        actor: "System",
        action: "Workspace initialized",
        resource: "system",
        details: "Phase 2 demonstration workspace initialized.",
        createdAt: "2026-10-31T08:00:00Z",
      },
    ],
  };
}
export function readRecords(): RecordSet {
  const raw = localStorage.getItem(key);
  if (!raw) {
    const initial = seed();
    writeRecords(initial);
    return initial;
  }
  const parsed: unknown = JSON.parse(raw);
  const object = z.record(z.string(), z.array(z.unknown())).parse(parsed);
  const result = seed();
  for (const resource of Object.keys(result) as AdminResource[]) {
    const list = object[resource] ?? result[resource];
    const records = Array.isArray(list)
      ? list.map((row: unknown) => parseRecord(resource, row))
      : [];
    Object.assign(result, { [resource]: records });
  }
  return result;
}
export function writeRecords(records: RecordSet) {
  localStorage.setItem(key, JSON.stringify(records));
}
export const provisionedAccountSchema = z.object({
  email: z.string().email(),
  hash: z.string(),
  salt: z.string(),
  profile: z.object({
    id: z.string(),
    name: z.string(),
    email: z.string().email(),
    role: z.literal("owner"),
    schoolId: z.string(),
    branchIds: z.array(z.string()),
  }),
});
export async function hashPassword(password: string, salt: string) {
  const hash = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`${salt}:${password}`),
  );
  return Array.from(new Uint8Array(hash))
    .map((n) => n.toString(16).padStart(2, "0"))
    .join("");
}
export function readProvisionedAccounts() {
  return z
    .array(provisionedAccountSchema)
    .parse(JSON.parse(localStorage.getItem("campus-demo-accounts") ?? "[]"));
}
