import { z } from "zod";
import type { Notification, Profile, Role } from "../types/domain";
import { roles } from "../types/domain";
import type { Repository } from "../services/contracts";
import { demoProfile } from "./data";
import {
  readRecords as readAdminRecords,
  readProvisionedAccounts,
  hashPassword,
} from "./adminStorage";
const key = "campus-demo-session";
const profileSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string().email(),
  role: z.enum(roles),
  schoolId: z.string(),
  branchIds: z.array(z.string()),
  policyId: z.string().nullable().optional(),
});
const pause = () => new Promise<void>((resolve) => setTimeout(resolve, 280));
export function readProfile(): Profile | null {
  try {
    const raw = localStorage.getItem(key) ?? sessionStorage.getItem(key);
    const profile = raw ? profileSchema.parse(JSON.parse(raw)) : null;
    if (profile && profile.role !== "master") {
      const records = readAdminRecords();
      if (
        records.schools.find((s) => s.id === profile.schoolId)?.status !==
        "Active"
      )
        return null;
      if (profile.role !== "owner") {
        const linked = records.users.find(
          (u) =>
            u.email.toLowerCase() === profile.email.toLowerCase() &&
            u.schoolId === profile.schoolId,
        );
        if (linked) {
          if (linked.status !== "Active") return null;
          return {
            ...profile,
            role: linked.role,
            policyId: linked.policyId,
            branchIds: linked.branchId ? [linked.branchId] : [],
          };
        }
      }
    }
    return profile;
  } catch {
    localStorage.removeItem(key);
    sessionStorage.removeItem(key);
    return null;
  }
}
const listeners = new Set<(profile: Profile | null) => void>();
const events = new Set<() => void>();
const notifications = new Map<string, Notification[]>();
function current() {
  const profile = readProfile();
  if (!profile) throw new Error("Please sign in to continue.");
  return profile;
}
export const mockRepository: Repository = {
  auth: {
    async getProfile() {
      await pause();
      const profile = readProfile();
      if (profile && profile.role !== "master") {
        if (
          readAdminRecords().schools.find((s) => s.id === profile.schoolId)
            ?.status !== "Active"
        )
          return null;
      }
      return profile;
    },
    async signIn({ identifier, password, remember, master }) {
      await pause();
      const normalized = identifier.toLowerCase().trim();
      const role =
        normalized === "gw-001" ? "owner" : (normalized.split("@")[0] as Role);
      const account = readProvisionedAccounts().find(
        (a) => a.email === normalized,
      );
      const validProvisioned =
        account &&
        !master &&
        (await hashPassword(password, account.salt)) === account.hash;
      if (
        !validProvisioned &&
        (!roles.includes(role) ||
          (normalized !== "gw-001" && normalized !== `${role}@greenwood.edu`) ||
          password !== "Campus@2026" ||
          (master ? role !== "master" : role === "master"))
      )
        throw new Error("The email, school code, or password is incorrect.");
      const profile = validProvisioned ? account.profile : demoProfile(role);
      if (
        profile.role !== "master" &&
        readAdminRecords().schools.find((s) => s.id === profile.schoolId)
          ?.status !== "Active"
      )
        throw new Error(
          "Access to this school has been suspended. Contact your platform administrator.",
        );
      if (profile.role === "owner")
        profile.branchIds = readAdminRecords()
          .branches.filter(
            (b) => b.schoolId === profile.schoolId && b.status === "Active",
          )
          .map((b) => b.id);
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
      (remember ? localStorage : sessionStorage).setItem(
        key,
        JSON.stringify(profile),
      );
      listeners.forEach((fn) => fn(profile));
      return profile;
    },
    async verifyMfa(code: string) {
      if (!code || code.length < 6) throw new Error("Invalid TOTP authentication code");
    },
    async signOut() {
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
      listeners.forEach((fn) => fn(null));
    },
    async resetPassword() {
      await pause();
      throw new Error(
        "Demo accounts use Campus@2026. Password emails are available in Supabase mode.",
      );
    },
    async updatePassword() {
      await pause();
      throw new Error("Demo passwords cannot be changed.");
    },
    onChange(callback) {
      listeners.add(callback);
      const sync = (event: StorageEvent) => {
        if (event.key === key || event.key === "campus-admin-v2")
          callback(readProfile());
      };
      window.addEventListener("storage", sync);
      return () => {
        listeners.delete(callback);
        window.removeEventListener("storage", sync);
      };
    },
  },
  branches: {
    async list() {
      await pause();
      const profile = current();
      return readAdminRecords()
        .branches.filter(
          (b) =>
            b.schoolId === profile.schoolId &&
            b.status === "Active" &&
            (profile.role === "owner" ||
              profile.role === "master" ||
              profile.branchIds.includes(b.id)),
        )
        .map((b) => ({
          id: b.id,
          school_id: b.schoolId,
          name: b.name,
          short_name: b.name,
          city: b.city,
        }));
    },
  },
  notifications: {
    async list(branchId) {
      await pause();
      const profile = current();
      if (
        !profile.branchIds.includes(branchId) &&
        !(
          profile.role === "owner" &&
          readAdminRecords().branches.some(
            (b) => b.id === branchId && b.schoolId === profile.schoolId,
          )
        )
      )
        throw new Error("You do not have access to this campus.");
      const scoped = `${profile.id}:${branchId}`;
      if (!notifications.has(scoped))
        notifications.set(scoped, [
          {
            id: `${scoped}-welcome`,
            user_id: profile.id,
            branch_id: branchId,
            title: "Your workspace is ready",
            body: "Explore your workspace, personalize your theme, and find everything in one place.",
            created_at: new Date().toISOString(),
            read: false,
          },
          {
            id: `${scoped}-access`,
            user_id: profile.id,
            branch_id: branchId,
            title: "Access tailored to your role",
            body: "Your assigned campuses and permissions keep school information in the right hands.",
            created_at: new Date(Date.now() - 3_600_000).toISOString(),
            read: false,
          },
        ]);
      return structuredClone(notifications.get(scoped) ?? []);
    },
    async markRead(id) {
      await pause();
      const profile = current();
      for (const list of notifications.values()) {
        const item = list.find((n) => n.id === id && n.user_id === profile.id);
        if (item) item.read = true;
      }
      events.forEach((fn) => fn());
    },
    subscribe(_branchId, callback) {
      events.add(callback);
      return () => {
        events.delete(callback);
      };
    },
  },
  storage: {
    async getUrl(path) {
      const value = localStorage.getItem(`campus-demo-file:${path}`);
      if (!value)
        throw new Error(
          "This demo file is no longer available. Upload it again.",
        );
      return value;
    },
    async upload(file, branchId) {
      await pause();
      const user = current();
      if (
        !user.branchIds.includes(branchId) &&
        !(
          user.role === "owner" &&
          readAdminRecords().branches.some(
            (b) => b.schoolId === user.schoolId && b.id === branchId,
          )
        )
      )
        throw new Error("Campus access denied.");
      if (file.size > 5 * 1024 * 1024)
        throw new Error("File exceeds the 5 MB limit.");
      const bytes = new Uint8Array(await file.arrayBuffer());
      let binary = "";
      for (let i = 0; i < bytes.length; i += 16384)
        binary += String.fromCharCode(...bytes.slice(i, i + 16384));
      const path = `demo://${branchId}/${crypto.randomUUID()}/${encodeURIComponent(file.name)}`;
      localStorage.setItem(
        `campus-demo-file:${path}`,
        `data:${file.type};base64,${btoa(binary)}`,
      );
      return path;
    },
  },
};
