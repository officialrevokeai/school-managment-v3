import type { Branch, Profile, Role, Workspace } from "../types/domain";
export const branches: Branch[] = [
  {
    id: "north",
    school_id: "greenwood",
    name: "Greenwood · North Campus",
    short_name: "North Campus",
    city: "Bengaluru",
  },
  {
    id: "central",
    school_id: "greenwood",
    name: "Greenwood · Central Campus",
    short_name: "Central Campus",
    city: "Bengaluru",
  },
  {
    id: "east",
    school_id: "greenwood",
    name: "Greenwood · East Campus",
    short_name: "East Campus",
    city: "Whitefield",
  },
];
const names: Record<Role, string> = {
  owner: "Alex Morgan",
  principal: "Sarah Williams",
  teacher: "James Wilson",
  parent: "Priya Sharma",
  student: "Aarav Sharma",
  accountant: "Olivia Davis",
  master: "Jordan Lee",
};
export function demoProfile(role: Role): Profile {
  return {
    id: `demo-${role}`,
    name: names[role],
    email: `${role}@greenwood.edu`,
    role,
    schoolId: "greenwood",
    branchIds:
      role === "owner" || role === "master"
        ? branches.map((b) => b.id)
        : ["north"],
  };
}
export const workspaces: Workspace[] = [
  {
    id: "people",
    name: "People & access",
    description: "A connected directory of students, families, and staff.",
    category: "Community",
    permission: "users.manage",
    phase: 2,
    icon: "users",
  },
  {
    id: "branches",
    name: "Branches & campuses",
    description: "Every campus, connected through one workspace.",
    category: "Operations",
    permission: "branches.manage",
    phase: 2,
    icon: "building",
  },
  {
    id: "academics",
    name: "Learning & academics",
    description: "Classes, subjects, timetables, and learning journeys.",
    category: "Academics",
    permission: "academics.read",
    phase: 3,
    icon: "book",
  },
  {
    id: "attendance",
    name: "Attendance",
    description: "Stay close to your school community, every day.",
    category: "Academics",
    permission: "attendance.manage",
    phase: 3,
    icon: "calendar-check",
  },
  {
    id: "finance",
    name: "Fees & finance",
    description: "Bring clarity to fees, expenses, and school accounts.",
    category: "Operations",
    permission: "finance.manage",
    phase: 2,
    icon: "wallet",
  },
  {
    id: "child",
    name: "My child’s journey",
    description: "Follow learning, attendance, and important milestones.",
    category: "Community",
    permission: "child.read",
    phase: 4,
    icon: "heart",
  },
  {
    id: "whatsapp",
    name: "Communication",
    description: "Keep families in the loop with thoughtful messaging.",
    category: "Community",
    permission: "whatsapp.manage",
    phase: 5,
    icon: "message",
  },
  {
    id: "system",
    name: "School settings",
    description: "Make your school’s workspace feel like your own.",
    category: "System",
    permission: "system.manage",
    phase: 5,
    icon: "settings",
  },
];
