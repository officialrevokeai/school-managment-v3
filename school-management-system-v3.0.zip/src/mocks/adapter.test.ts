// These tests exercise the adapter's isolation contract with a small Web Storage implementation.
import { beforeEach, describe, expect, it } from "vitest";
import { mockRepository } from "./adapter";
function memoryStorage(): Storage {
  const map = new Map<string, string>();
  return {
    get length() {
      return map.size;
    },
    clear: () => map.clear(),
    getItem: (key) => map.get(key) ?? null,
    key: (index) => [...map.keys()][index] ?? null,
    removeItem: (key) => {
      map.delete(key);
    },
    setItem: (key, value) => {
      map.set(key, value);
    },
  };
}
beforeEach(() => {
  globalThis.localStorage = memoryStorage();
  globalThis.sessionStorage = memoryStorage();
});
describe("mock repository security contract", () => {
  it("rejects incorrect credentials and master accounts on the normal login", async () => {
    await expect(
      mockRepository.auth.signIn({
        identifier: "owner@greenwood.edu",
        password: "wrong",
        remember: true,
      }),
    ).rejects.toThrow();
    await expect(
      mockRepository.auth.signIn({
        identifier: "master@greenwood.edu",
        password: "Campus@2026",
        remember: true,
      }),
    ).rejects.toThrow();
  });
  it("isolates an assigned teacher from other campuses", async () => {
    await mockRepository.auth.signIn({
      identifier: "teacher@greenwood.edu",
      password: "Campus@2026",
      remember: false,
    });
    expect((await mockRepository.branches.list()).map((b) => b.id)).toEqual([
      "north",
    ]);
    await expect(mockRepository.notifications.list("central")).rejects.toThrow(
      "access",
    );
    expect(localStorage.getItem("campus-demo-session")).toBeNull();
  });
  it("does not expose one account’s notifications to another", async () => {
    await mockRepository.auth.signIn({
      identifier: "owner@greenwood.edu",
      password: "Campus@2026",
      remember: true,
    });
    const owner = await mockRepository.notifications.list("north");
    await mockRepository.auth.signIn({
      identifier: "parent@greenwood.edu",
      password: "Campus@2026",
      remember: false,
    });
    const parent = await mockRepository.notifications.list("north");
    expect(parent.every((n) => n.user_id === "demo-parent")).toBe(true);
    expect(parent.some((n) => n.id === owner[0]?.id)).toBe(false);
  });
  it("restores a remembered session and clears it on sign out", async () => {
    const signedIn = await mockRepository.auth.signIn({
      identifier: "GW-001",
      password: "Campus@2026",
      remember: true,
    });
    expect(await mockRepository.auth.getProfile()).toEqual(signedIn);
    await mockRepository.auth.signOut();
    expect(await mockRepository.auth.getProfile()).toBeNull();
  });
});
