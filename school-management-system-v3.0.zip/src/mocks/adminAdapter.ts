import type {
  AdminModels,
  AdminRepository,
  AdminResource,
  AdminScope,
} from "../types/admin";
import { parseRecord } from "../types/admin";
import {
  readRecords,
  writeRecords,
  hashPassword,
  readProvisionedAccounts,
} from "./adminStorage";
import { readProfile } from "./adapter";
const pause = () => new Promise<void>((resolve) => setTimeout(resolve, 180));
function actor() {
  const profile = readProfile();
  if (!profile) throw new Error("Sign in to continue.");
  if (
    profile.role !== "master" &&
    readRecords().schools.find((s) => s.id === profile.schoolId)?.status !==
      "Active"
  )
    throw new Error("School access is suspended.");
  return profile;
}
function authorize(resource: AdminResource, scope: AdminScope, write = false) {
  const user = actor();
  if (resource === "schools") {
    if (user.role !== "master") throw new Error("Platform access is required.");
  } else if (user.role === "master") {
    if (
      (resource !== "roles" && resource !== "audit") ||
      (resource === "roles" &&
        scope.schoolId !== "00000000-0000-0000-0000-000000000000")
    )
      throw new Error("Open a school account to manage school operations.");
  } else if (
    user.schoolId !== scope.schoolId ||
    (user.role !== "owner" &&
      (write || !["roles", "branches"].includes(resource)))
  )
    throw new Error("You do not have permission for this school operation.");
  if (
    scope.branchId &&
    user.role !== "owner" &&
    user.role !== "master" &&
    !user.branchIds.includes(scope.branchId)
  )
    throw new Error("Campus access denied.");
  return user;
}
function audit(
  resource: string,
  action: string,
  schoolId: string,
  detail: string,
) {
  const user = actor();
  const records = readRecords();
  records.audit.unshift({
    id: crypto.randomUUID(),
    schoolId,
    branchId: null,
    version: 1,
    actor: user.name,
    action,
    resource,
    details: detail,
    createdAt: new Date().toISOString(),
  });
  writeRecords(records);
}
export const mockAdminRepository: AdminRepository = {
  async summary(scope) {
    await pause();
    const user = actor();
    if (user.role !== "owner" && user.role !== "master")
      throw new Error("Administrative access required.");
    if (user.role === "owner" && user.schoolId !== scope.schoolId)
      throw new Error("School access denied.");
    const all = readRecords();
    const subscriptionSchools = all.schools.filter(
      (s) =>
        (!scope.from || s.createdAt.slice(0, 10) >= scope.from) &&
        (!scope.to || s.createdAt.slice(0, 10) <= scope.to),
    );
    const financial = all.finance.filter(
      (r) =>
        r.schoolId === scope.schoolId &&
        (!scope.branchId || r.branchId === scope.branchId),
    );
    const people = all.users.filter(
      (r) =>
        r.schoolId === scope.schoolId &&
        (!scope.branchId || r.branchId === scope.branchId) &&
        r.status === "Active",
    );
    const total = (kind: string, paid: boolean) =>
      financial
        .filter(
          (r) =>
            r.kind === kind &&
            (paid ? r.status === "Paid" : r.status !== "Paid"),
        )
        .reduce((n, r) => n + r.amount, 0);
    return {
      students: people.filter((r) => r.role === "student").length,
      attendance:
        user.role === "master"
          ? []
          : [
              ...new Set(
                all.analytics
                  .filter(
                    (r) =>
                      r.schoolId === scope.schoolId &&
                      (!scope.branchId || r.branchId === scope.branchId),
                  )
                  .map((r) => r.date),
              ),
            ]
              .sort()
              .map((date) => {
                const entries = all.analytics.filter(
                  (r) =>
                    r.schoolId === scope.schoolId &&
                    r.date === date &&
                    (!scope.branchId || r.branchId === scope.branchId),
                );
                const present = entries.reduce((n, r) => n + r.present, 0);
                const count = entries.reduce((n, r) => n + r.total, 0);
                return {
                  label: new Date(date).toLocaleString("en", {
                    month: "short",
                  }),
                  value: count ? Math.round((present / count) * 1000) / 10 : 0,
                };
              }),
      staff: people.filter((r) =>
        ["teacher", "principal", "accountant"].includes(r.role),
      ).length,
      income: total("Income", true),
      expenses: total("Expense", true),
      outstanding: total("Income", false),
      schools: subscriptionSchools.length,
      active: subscriptionSchools.filter((s) => s.status === "Active").length,
      mrr: subscriptionSchools
        .filter((s) => s.status === "Active")
        .reduce((n, s) => n + s.monthlyFee, 0),
      suspended: subscriptionSchools.filter((s) => s.status !== "Active")
        .length,
      revenue:
        user.role === "master"
          ? [...subscriptionSchools]
              .sort((a, b) => b.monthlyFee - a.monthlyFee)
              .slice(0, 10)
              .map((s) => ({
                label: s.code,
                value: s.status === "Active" ? s.monthlyFee : 0,
              }))
          : Array.from({ length: 6 }, (_, i) => {
              const date = new Date();
              date.setDate(1);
              date.setMonth(date.getMonth() - 5 + i);
              const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
              const matching = financial.filter(
                (r) => r.date.startsWith(key) && r.status === "Paid",
              );
              return {
                label: date.toLocaleString("en", { month: "short" }),
                value: matching
                  .filter((r) => r.kind === "Income")
                  .reduce((n, r) => n + r.amount, 0),
                secondary: matching
                  .filter((r) => r.kind === "Expense")
                  .reduce((n, r) => n + r.amount, 0),
              };
            }),
      enrollment:
        user.role === "master"
          ? ["Starter", "Growth", "Enterprise"].map((plan) => ({
              label: plan,
              value: subscriptionSchools.filter(
                (s) => s.plan === plan && s.status === "Active",
              ).length,
            }))
          : all.branches
              .filter(
                (b) =>
                  b.schoolId === scope.schoolId &&
                  (!scope.branchId || b.id === scope.branchId),
              )
              .map((b) => ({
                label: b.code,
                value: people.filter(
                  (p) => p.branchId === b.id && p.role === "student",
                ).length,
              })),
    };
  },
  async list(resource, scope, options = {}) {
    await pause();
    const user = authorize(resource, scope);
    let rows = readRecords()[resource].filter(
      (row) =>
        resource === "schools" ||
        (user.role === "master" && resource === "audit") ||
        row.schoolId === scope.schoolId,
    );
    if (scope.branchId && resource !== "roles" && resource !== "settings")
      rows = rows.filter((row) => row.branchId === scope.branchId);
    if (options.filters)
      rows = rows.filter((row) =>
        Object.entries(options.filters ?? {}).every(([key, value]) =>
          Object.entries(row).some(
            ([field, fieldValue]) => field === key && fieldValue === value,
          ),
        ),
      );
    if (options.search)
      rows = rows.filter((row) =>
        JSON.stringify(row)
          .toLowerCase()
          .includes(options.search!.toLowerCase()),
      );
    if (options.from)
      rows = rows.filter((row) => {
        const date =
          "date" in row ? row.date : "createdAt" in row ? row.createdAt : "";
        return date.slice(0, 10) >= options.from!;
      });
    if (options.to)
      rows = rows.filter((row) => {
        const date =
          "date" in row ? row.date : "createdAt" in row ? row.createdAt : "";
        return date.slice(0, 10) <= options.to!;
      });
    const page = options.page ?? 0;
    const size = Math.min(options.pageSize ?? 50, 500);
    return {
      rows: rows.slice(page * size, (page + 1) * size),
      total: rows.length,
    };
  },
  async save(resource, input) {
    await pause();
    authorize(resource, { schoolId: input.schoolId }, true);
    const record = parseRecord(resource, input);
    if (resource === "roles" && "role" in record && record.role === "owner")
      throw new Error("Owner access cannot be reduced by a school policy.");
    if (
      resource === "roles" &&
      "permissions" in record &&
      record.permissions.includes("master.manage") &&
      actor().role !== "master"
    )
      throw new Error("Schools cannot grant platform access.");
    const records = readRecords();
    if (
      record.branchId &&
      resource !== "branches" &&
      !records.branches.some(
        (b) => b.id === record.branchId && b.schoolId === record.schoolId,
      )
    )
      throw new Error("Campus is outside this school.");
    if (
      resource === "users" &&
      "policyId" in record &&
      record.policyId &&
      !records.roles.some(
        (p) =>
          p.id === record.policyId &&
          p.schoolId === record.schoolId &&
          p.role === record.role,
      )
    )
      throw new Error("Role policy is outside this school or base role.");
    const list = records[resource];
    const index = list.findIndex((row) => row.id === record.id);
    const previous = list[index];
    if (
      resource === "schools" &&
      previous &&
      "ownerEmail" in record &&
      "ownerEmail" in previous &&
      (record.ownerEmail !== previous.ownerEmail ||
        record.code !== previous.code)
    )
      throw new Error(
        "Login identity changes require trusted Auth administration.",
      );
    if (
      previous &&
      (previous.schoolId !== record.schoolId ||
        previous.version !== record.version)
    )
      throw new Error("This record changed. Refresh before saving again.");
    if (
      resource === "users" &&
      "email" in record &&
      records.users.some(
        (u) =>
          u.email.toLowerCase() === record.email.toLowerCase() &&
          u.id !== record.id &&
          u.schoolId === record.schoolId,
      )
    )
      throw new Error("This email already exists in the school directory.");
    const saved = { ...record, version: previous ? previous.version + 1 : 1 };
    if (index >= 0) list.splice(index, 1, saved);
    else list.unshift(saved);
    writeRecords(records);
    audit(
      resource,
      previous ? "Updated" : "Created",
      record.schoolId,
      `${resource} record ${record.id}`,
    );
    return saved as AdminModels[typeof resource];
  },
  async remove(resource, id, scope, version) {
    await pause();
    authorize(resource, scope, true);
    const records = readRecords();
    const record = records[resource].find(
      (item) => item.id === id && item.schoolId === scope.schoolId,
    );
    if (!record || record.version !== version)
      throw new Error("This record changed. Refresh and try again.");
    if (resource === "branches" && records.users.some((u) => u.branchId === id))
      throw new Error(
        "Move the people assigned to this campus before deleting it.",
      );
    if (resource === "roles" && "role" in record && record.role === "owner")
      throw new Error("Owner access cannot be deleted.");
    Object.assign(records, {
      [resource]: records[resource].filter((item) => item.id !== id),
    });
    writeRecords(records);
    audit(
      resource,
      "Deleted",
      scope.schoolId,
      `Deleted ${resource} record ${id}`,
    );
  },
  async provisionSchool(input) {
    await pause();
    authorize("schools", { schoolId: "platform" }, true);
    const records = readRecords();
    if (
      records.schools.some(
        (s) =>
          s.code.toLowerCase() === input.code.toLowerCase() ||
          s.ownerEmail.toLowerCase() === input.ownerEmail.toLowerCase(),
      )
    )
      throw new Error("This school code or owner email is already registered.");
    const id = crypto.randomUUID();
    const branch = crypto.randomUUID();
    const profile = {
      id: crypto.randomUUID(),
      name: `${input.name} Owner`,
      email: input.ownerEmail,
      role: "owner" as const,
      schoolId: id,
      branchIds: [branch],
    };
    const password =
      input.password ||
      `Campus!${crypto.randomUUID().replaceAll("-", "").slice(0, 16)}`;
    const salt = crypto.randomUUID();
    const accounts = readProvisionedAccounts();
    accounts.push({
      email: input.ownerEmail.toLowerCase(),
      hash: await hashPassword(password, salt),
      salt,
      profile,
    });
    localStorage.setItem("campus-demo-accounts", JSON.stringify(accounts));
    const school = parseRecord("schools", {
      ...input,
      id,
      schoolId: id,
      branchId: null,
      version: 1,
      status: "Active",
      createdAt: new Date().toISOString().slice(0, 10),
    });
    records.schools.unshift(school);
    records.branches.push({
      id: branch,
      schoolId: id,
      branchId: branch,
      version: 1,
      name: "Main Campus",
      city: "Unassigned",
      code: `${input.code}-MAIN`,
      principal: "",
      capacity: 1000,
      status: "Active",
    });
    const roleDefaults = records.roles.filter(
      (r) => r.schoolId === "00000000-0000-0000-0000-000000000000",
    );
    records.roles.push(
      ...(roleDefaults.length
        ? roleDefaults
        : records.roles.filter((r) => r.schoolId === "greenwood" && !r.custom)
      ).map((r) => ({
        ...r,
        id: crypto.randomUUID(),
        schoolId: id,
        version: 1,
      })),
    );
    records.settings.push({
      id: crypto.randomUUID(),
      schoolId: id,
      branchId: null,
      version: 1,
      name: input.name,
      academicYear: "2026–2027",
      logoPath: "",
      senderNumber: "+919000000000",
      financeRole: "accountant",
      overrideEnabled: false,
      requireMfa: false,
      sessionMinutes: 60,
      privacyEmail: input.ownerEmail,
      retentionDays: 365,
    });
    writeRecords(records);
    audit("schools", "Provisioned school", id, input.name);
    return { school, email: input.ownerEmail, password };
  },
};
