import { beforeEach, describe, expect, it } from "vitest";
import { mockRepository } from "./adapter";
import { mockAdminRepository } from "./adminAdapter";
function storage(): Storage {
  const values = new Map<string, string>();
  return {
    get length() {
      return values.size;
    },
    clear: () => values.clear(),
    getItem: (key) => values.get(key) ?? null,
    key: (index) => [...values.keys()][index] ?? null,
    removeItem: (key) => {
      values.delete(key);
    },
    setItem: (key, value) => {
      values.set(key, value);
    },
  };
}
beforeEach(() => {
  globalThis.localStorage = storage();
  globalThis.sessionStorage = storage();
});
async function signIn(role: string) {
  return mockRepository.auth.signIn({
    identifier: `${role}@greenwood.edu`,
    password: "Campus@2026",
    remember: false,
    master: role === "master",
  });
}
describe("Phase 2 mock administration", () => {
  it("denies school administration to teachers and cross-school writes to owners", async () => {
    await signIn("teacher");
    await expect(
      mockAdminRepository.list("finance", { schoolId: "greenwood" }),
    ).rejects.toThrow("permission");
    await signIn("owner");
    await expect(
      mockAdminRepository.save("branches", {
        id: crypto.randomUUID(),
        schoolId: "oakridge",
        branchId: null,
        version: 1,
        name: "Foreign campus",
        city: "Delhi",
        code: "OA-X",
        principal: "",
        capacity: 100,
        status: "Active",
      }),
    ).rejects.toThrow("permission");
  });
  it("persists a custom role and rejects a stale update", async () => {
    await signIn("owner");
    const created = await mockAdminRepository.save("roles", {
      id: crypto.randomUUID(),
      schoolId: "greenwood",
      branchId: null,
      version: 1,
      name: "Finance Coordinator",
      role: "accountant",
      custom: true,
      permissions: ["workspace.read", "finance.manage"],
    });
    const updated = await mockAdminRepository.save("roles", {
      ...created,
      name: "Senior Finance Coordinator",
    });
    expect(updated.version).toBe(2);
    await expect(mockAdminRepository.save("roles", created)).rejects.toThrow(
      "changed",
    );
    expect(
      (
        await mockAdminRepository.list("audit", { schoolId: "greenwood" })
      ).rows.some((row) => row.resource === "roles"),
    ).toBe(true);
  });
  it("creates usable owner credentials and blocks a suspended school", async () => {
    await signIn("master");
    const provisioned = await mockAdminRepository.provisionSchool({
      name: "Test Valley School",
      code: "TV-QA",
      ownerEmail: "owner@testvalley.edu",
      plan: "Growth",
      monthlyFee: 12900,
    });
    await mockRepository.auth.signOut();
    const owner = await mockRepository.auth.signIn({
      identifier: provisioned.email,
      password: provisioned.password,
      remember: false,
    });
    expect(owner.schoolId).toBe(provisioned.school.id);
    expect(await mockRepository.branches.list()).toHaveLength(1);
    expect(
      (await mockAdminRepository.list("settings", { schoolId: owner.schoolId }))
        .rows[0]?.name,
    ).toBe("Test Valley School");
    await signIn("master");
    await mockAdminRepository.save("schools", {
      ...provisioned.school,
      status: "Suspended",
    });
    await mockRepository.auth.signOut();
    await expect(
      mockRepository.auth.signIn({
        identifier: provisioned.email,
        password: provisioned.password,
        remember: false,
      }),
    ).rejects.toThrow("suspended");
  });
});
