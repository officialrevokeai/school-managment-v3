import {
  definition,
  flowSchema,
  validateFlow,
  type FlowRecord,
  type ModuleKey,
  type FlowContext,
} from "../features/school/model";
import type { WorkflowRepository } from "../services/workflows";
import { readProfile } from "./adapter";
import { readRecords, writeRecords } from "./adminStorage";
const key = "campus-workflows-v1";
const changes = new Set<() => void>();
export const mockStudents = Array.from({ length: 18 }, (_, i) => ({
  id: `learner-${i + 1}`,
  name:
    [
      "Aarav Sharma",
      "Ananya Sharma",
      "Maya Patel",
      "Noah Carter",
      "Amelia Chen",
      "Ethan Brooks",
    ][i % 6]! + (i > 5 ? ` ${Math.floor(i / 6) + 1}` : ""),
  classId: i < 12 ? "class-8a" : "class-9b",
  branchId: "north",
}));
const classrooms = [
  { id: "class-8a", name: "Grade 8 · A", branchId: "north" },
  { id: "class-9b", name: "Grade 9 · B", branchId: "north" },
];
function actor() {
  const user = readProfile();
  if (!user || user.role === "master")
    throw new Error("School access required.");
  return user;
}
function identity(): FlowContext {
  const user = actor();
  const rows = records().filter((r) => r.schoolId === user.schoolId);
  const base = user.schoolId === "greenwood" ? mockStudents : [];
  const admitted = rows
    .filter(
      (r) =>
        r.module === "admissions" &&
        ["Admitted", "Transferred"].includes(String(r.data.status)) &&
        r.classId,
    )
    .map((r) => ({
      id: r.id,
      name: String(r.data.applicant),
      classId: r.classId!,
      branchId: r.branchId,
    }));
  const allStudents = [...base, ...admitted];
  const allClasses = [
    ...(user.schoolId === "greenwood" ? classrooms : []),
    ...rows
      .filter((r) => r.module === "classes")
      .map((r) => ({
        id: r.classId ?? r.id,
        name: String(r.data.title),
        branchId: r.branchId,
      })),
  ];
  const students =
    user.role === "parent"
      ? base.slice(0, 2)
      : user.role === "student"
        ? base.slice(0, 1)
        : user.role === "teacher"
          ? allStudents.filter((s) => s.classId === "class-8a")
          : allStudents;
  return {
    students,
    classes:
      user.role === "teacher"
        ? allClasses.filter((c) => c.id === "class-8a")
        : ["parent", "student"].includes(user.role)
          ? allClasses.filter((c) => students.some((s) => s.classId === c.id))
          : allClasses,
  };
}
function seed(): FlowRecord[] {
  const date = new Date().toISOString().slice(0, 10);
  const create = (
    module: ModuleKey,
    data: FlowRecord["data"],
    studentId: string | null = null,
    classId: string | null = "class-8a",
  ): FlowRecord => ({
    id: crypto.randomUUID(),
    schoolId: "greenwood",
    branchId: "north",
    classId,
    studentId,
    authorId: "demo-teacher",
    module,
    version: 1,
    data,
    updatedAt: new Date().toISOString(),
  });
  const rows: FlowRecord[] = [
    create("timetable", {
      title: "Mathematics",
      date,
      start: "09:00",
      end: "09:45",
      room: "Room 204",
    }),
    create("timetable", {
      title: "English",
      date,
      start: "10:00",
      end: "10:45",
      room: "Room 204",
    }),
    create("assignments", {
      title: "Fractions in everyday life",
      kind: "Homework",
      date,
      due: date,
      notes: "Complete exercises 1–8. Show your working.",
    }),
    create("announcements", {
      title: "A day of discovery",
      date,
      notes: "Science exhibition on Friday. Families are warmly invited.",
    }),
    create(
      "calendar",
      {
        title: "Annual sports day",
        date,
        kind: "Event",
        notes: "School grounds · 9 AM",
      },
      null,
      null,
    ),
    create("lessons", {
      title: "Introduction to algebra",
      date,
      status: "Approved",
      notes: "Learning objective: simplify expressions.",
    }),
    create(
      "admissions",
      {
        title: "Grade 8 admission",
        applicant: "Rohan Kapoor",
        date,
        status: "Review",
        notes: "Entrance assessment complete.",
      },
      null,
      null,
    ),
    create(
      "performance",
      {
        title: "Classroom observation",
        teacher: "James Wilson",
        date,
        rating: 4,
        notes: "Clear explanations and thoughtful feedback.",
      },
      null,
      null,
    ),
    create(
      "meetings",
      {
        title: "Academic review",
        date,
        time: "15:00",
        attendees: "Principal and department heads",
        notes: "Review learner support plans.",
      },
      null,
      null,
    ),
    create(
      "reports",
      {
        title: "Weekly school summary",
        period: "Weekly",
        date,
        status: "Submitted",
        notes: "Academic activities and operational updates.",
      },
      null,
      null,
    ),
    create(
      "expenses",
      {
        title: "Learning materials",
        vendor: "Scholastic Supplies",
        invoice: "INV-026",
        date,
        amount: 18000,
        status: "Pending",
        notes: "Term resources",
      },
      null,
      null,
    ),
    create(
      "payroll",
      {
        title: "October salary",
        employee: "James Wilson",
        date,
        amount: 42000,
        deduction: 1800,
        status: "Approved",
      },
      null,
      null,
    ),
    create(
      "reconciliation",
      {
        title: "October bank reconciliation",
        date,
        ledger: 760000,
        statement: 760000,
        status: "Reconciled",
      },
      null,
      null,
    ),
  ];
  for (const student of mockStudents) {
    rows.push(
      create(
        "attendance",
        { date, status: "Present" },
        student.id,
        student.classId,
      ),
      create(
        "marks",
        {
          title: "Term assessment",
          subject: "Mathematics",
          date,
          score: 72 + (Number(student.id.split("-")[1]) % 22),
          maximum: 100,
          status: "Published",
          notes: "Good progress.",
        },
        student.id,
        student.classId,
      ),
      create(
        "fees",
        {
          title: "Term tuition",
          date,
          due: date,
          amount: 15000,
          discount: student.id === "learner-1" ? 1000 : 0,
          fine: 0,
          status: "Pending",
        },
        student.id,
        student.classId,
      ),
      create(
        "certificates",
        {
          title: "Student bonafide certificate",
          date,
          kind: "Bonafide",
          status: "Issued",
          notes: "A registered student of Greenwood School.",
        },
        student.id,
        student.classId,
      ),
    );
  }
  for (const event of [
    "Absence",
    "Fee reminder",
    "Result published",
    "Announcement",
  ])
    rows.push(
      create(
        "automations",
        { title: event, event, template: "school_update", status: "Enabled" },
        null,
        null,
      ),
    );
  return rows;
}
function records() {
  const raw = localStorage.getItem(key);
  if (raw) return flowSchema.array().parse(JSON.parse(raw));
  const rows = seed();
  localStorage.setItem(key, JSON.stringify(rows));
  return rows;
}
function persist(rows: FlowRecord[]) {
  localStorage.setItem(key, JSON.stringify(rows));
  changes.forEach((fn) => fn());
}
function canRead(row: FlowRecord) {
  const user = actor();
  if (
    row.schoolId !== user.schoolId ||
    (user.role !== "owner" && !user.branchIds.includes(row.branchId)) ||
    !definition(row.module).readers.includes(user.role)
  )
    return false;
  if (
    ["privacy", "notifications", "activity"].includes(row.module) &&
    user.role !== "owner"
  )
    return row.authorId === user.id;
  if (user.role === "teacher")
    return row.module === "leaves"
      ? row.authorId === user.id
      : row.classId === "class-8a";
  if (user.role === "parent" || user.role === "student") {
    const own = identity().students;
    const scoped = row.studentId
      ? own.some((s) => s.id === row.studentId)
      : row.classId
        ? own.some((s) => s.classId === row.classId)
        : ["calendar", "announcements"].includes(row.module);
    return (
      scoped &&
      (row.module !== "marks" || row.data.status === "Published") &&
      (row.module !== "certificates" || row.data.status === "Issued") &&
      (row.module !== "lessons" || row.data.status === "Approved")
    );
  }
  return true;
}
export const mockWorkflows: WorkflowRepository = {
  async context(branchId) {
    const user = actor();
    if (user.role !== "owner" && !user.branchIds.includes(branchId))
      throw new Error("Campus access denied.");
    const context = identity();
    return {
      students: context.students.filter((s) => s.branchId === branchId),
      classes: context.classes.filter((c) => c.branchId === branchId),
    };
  },
  async list(module, scope) {
    const visible = records().filter(
      (row) =>
        canRead(row) &&
        row.branchId === scope.branchId &&
        (!scope.classId || row.classId === scope.classId || !row.classId) &&
        (!scope.studentId ||
          row.studentId === scope.studentId ||
          !row.studentId),
    );
    const counts: Record<string, number> = {};
    visible.forEach((row) => {
      counts[row.module] = (counts[row.module] ?? 0) + 1;
    });
    const rows = visible
      .filter(
        (row) =>
          (module === "all" || row.module === module) &&
          (!scope.date || row.data.date === scope.date) &&
          (!scope.title || row.data.title === scope.title) &&
          (!scope.subject || row.data.subject === scope.subject) &&
          (!scope.search ||
            JSON.stringify(row.data)
              .toLowerCase()
              .includes(scope.search.toLowerCase())),
      )
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    const page = scope.page ?? 0,
      size = Math.min(scope.pageSize ?? 12, 500);
    return {
      rows: structuredClone(rows.slice(page * size, (page + 1) * size)),
      total: rows.length,
      counts,
    };
  },
  async save(input) {
    const row = validateFlow(input);
    const user = actor();
    const rows = records();
    const old = rows.find((r) => r.id === row.id);
    if (
      row.schoolId !== user.schoolId ||
      (user.role !== "owner" && !user.branchIds.includes(row.branchId)) ||
      !definition(row.module).writers.includes(user.role)
    )
      throw new Error("You cannot edit this workflow.");
    if (
      old &&
      (!canRead(old) ||
        old.version !== row.version ||
        old.module !== row.module ||
        old.branchId !== row.branchId ||
        old.authorId !== row.authorId)
    )
      throw new Error("Record changed or access denied. Refresh and retry.");
    if (!old && row.authorId !== user.id) throw new Error("Invalid author.");
    if (
      user.role === "teacher" &&
      !(["leaves"].includes(row.module) && row.authorId === user.id) &&
      row.classId !== "class-8a"
    )
      throw new Error("Only your assigned classes can be edited.");
    if (
      row.studentId &&
      !identity().students.some(
        (s) =>
          s.id === row.studentId && (!row.classId || s.classId === row.classId),
      )
    )
      throw new Error("Student access denied.");
    if (
      ["parent", "student"].includes(user.role) &&
      (!["privacy", "notifications", "leaves"].includes(row.module) ||
        row.authorId !== user.id ||
        row.data.status !==
          (row.module === "notifications" ? row.data.status : "Requested"))
    )
      throw new Error("This family request cannot be changed.");
    if (
      row.module === "lessons" &&
      user.role === "teacher" &&
      row.data.status === "Approved"
    )
      throw new Error("Lesson approval is reserved for school leaders.");
    if (
      row.module === "leaves" &&
      user.role === "teacher" &&
      row.data.status !== "Requested"
    )
      throw new Error("Leave approval is reserved for school leaders.");
    const saved = {
      ...row,
      version: old ? old.version + 1 : 1,
      updatedAt: new Date().toISOString(),
    };
    const index = rows.findIndex((r) => r.id === row.id);
    if (index >= 0) rows[index] = saved;
    else rows.unshift(saved);
    const event =
      row.module === "attendance" && row.data.status === "Absent"
        ? "Absence"
        : row.module === "marks" && row.data.status === "Published"
          ? "Result published"
          : row.module === "announcements"
            ? "Announcement"
            : row.module === "fees" && row.data.status !== "Paid"
              ? "Fee reminder"
              : null;
    if (
      event &&
      rows.some(
        (r) =>
          r.module === "automations" &&
          r.schoolId === row.schoolId &&
          r.data.event === event &&
          r.data.status === "Enabled",
      )
    )
      rows.unshift({
        ...saved,
        id: crypto.randomUUID(),
        module: "whatsapp",
        authorId: user.id,
        version: 1,
        data: {
          title: event,
          template: "school_update",
          recipient: "",
          date: new Date().toISOString().slice(0, 10),
          status: "Queued",
          notes: "Waiting for a configured provider and verified recipient.",
        },
      });
    rows.unshift({
      ...saved,
      id: crypto.randomUUID(),
      module: "activity",
      studentId: null,
      classId: null,
      authorId: user.id,
      version: 1,
      data: {
        title: (old ? "Updated " : "Created ") + row.module,
        date: new Date().toISOString().slice(0, 10),
        notes: row.id,
      },
    });
    persist(rows);
    const admin = readRecords();
    admin.audit.unshift({
      id: crypto.randomUUID(),
      schoolId: user.schoolId,
      branchId: row.branchId,
      version: 1,
      actor: user.name,
      action: old ? "Updated" : "Created",
      resource: row.module,
      details: String(row.data.title ?? row.module),
      createdAt: saved.updatedAt,
    });
    writeRecords(admin);
    return saved;
  },
  async remove(row) {
    const user = actor();
    if (
      !["owner", "principal", "accountant"].includes(user.role) ||
      !definition(row.module).writers.includes(user.role) ||
      !canRead(row) ||
      ["privacy", "whatsapp", "activity"].includes(row.module)
    )
      throw new Error("Deletion is not allowed for this record.");
    const rows = records();
    const old = rows.find((r) => r.id === row.id);
    if (!old || old.version !== row.version)
      throw new Error("Record changed. Refresh and retry.");
    persist(rows.filter((r) => r.id !== row.id));
  },
  subscribe(callback) {
    changes.add(callback);
    const sync = (event: StorageEvent) => {
      if (event.key === key) callback();
    };
    window.addEventListener("storage", sync);
    return () => {
      changes.delete(callback);
      window.removeEventListener("storage", sync);
    };
  },
};
export async function payDemoFee(record: FlowRecord) {
  const rows = records();
  const old = rows.find((r) => r.id === record.id);
  if (!old || old.module !== "fees" || !canRead(old))
    throw new Error("Fee access denied.");
  if (old.data.status === "Paid") return old;
  if (old.version !== record.version)
    throw new Error("This fee changed. Refresh before paying.");
  const saved = {
    ...old,
    version: old.version + 1,
    updatedAt: new Date().toISOString(),
    data: {
      ...old.data,
      status: "Paid",
      receipt: `DEMO-${crypto.randomUUID().slice(0, 8)}`,
      paidAt: new Date().toISOString(),
    },
  };
  persist(rows.map((r) => (r.id === saved.id ? saved : r)));
  return saved;
}
export async function sendDemoWhatsApp(
  recipient: string,
  template: string,
  branchId: string,
) {
  const user = actor();
  if (
    user.role !== "owner" ||
    !/^\+[1-9]\d{7,14}$/.test(recipient) ||
    template !== "school_update"
  )
    throw new Error(
      "A verified number and approved demo template are required.",
    );
  const row: FlowRecord = {
    id: crypto.randomUUID(),
    schoolId: user.schoolId,
    branchId,
    classId: null,
    studentId: null,
    authorId: user.id,
    module: "whatsapp",
    version: 1,
    updatedAt: new Date().toISOString(),
    data: {
      title: "Test template",
      recipient,
      template,
      date: new Date().toISOString().slice(0, 10),
      status: "Queued",
      notes: "Local simulation only",
    },
  };
  persist([row, ...records()]);
  for (const [delay, status] of [
    [1000, "Sent"],
    [2200, "Delivered"],
    [4000, "Read"],
  ] as const)
    setTimeout(() => {
      const rows = records();
      const current = rows.find((r) => r.id === row.id);
      if (current)
        persist(
          rows.map((r) =>
            r.id === row.id
              ? {
                  ...r,
                  version: r.version + 1,
                  updatedAt: new Date().toISOString(),
                  data: { ...r.data, status },
                }
              : r,
          ),
        );
    }, delay);
  return row;
}
