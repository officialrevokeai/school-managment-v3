import { Component, type ErrorInfo, type ReactNode } from "react";
import { ErrorState } from "../components/ui/primitives";
export class ErrorBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error(
      "Workspace rendering failed",
      error.message,
      info.componentStack,
    );
  }
  render() {
    return this.state.failed ? (
      <ErrorState
        title="This view needs a fresh start"
        description="Your saved preferences are safe. Reload to try again."
        onRetry={() => window.location.reload()}
      />
    ) : (
      this.props.children
    );
  }
}
