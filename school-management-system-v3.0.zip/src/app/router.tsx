import { lazy, Suspense } from "react";
import {
  createBrowserRouter,
  Navigate,
  Outlet,
  useLocation,
} from "react-router-dom";
import { useAuth } from "../store/auth";
import { hasPermission, homeFor, type Permission } from "../lib/permissions";
import { Skeleton } from "../components/ui/primitives";
import { ErrorBoundary } from "./ErrorBoundary";
import type { Role } from "../types/domain";
import {
  definition,
  moduleKeys,
  workflowPermission,
  type ModuleKey,
} from "../features/school/model";
import { useAccess } from "../hooks/useAccess";
import { devTracker } from "../lib/devTracker";
import Shell from "../components/layout/AppShell";

const Login = lazy(() => import("../features/auth/Login"));
const ResetPassword = lazy(() => import("../features/auth/ResetPassword"));
const Directory = lazy(() => import("../features/workspace/Directory"));
const Preferences = lazy(() => import("../features/system/Preferences"));
const StatusPage = lazy(() => import("../features/workspace/StatusPage"));
const Dashboard = lazy(() => import("../features/owner/Dashboard"));
const Records = lazy(() => import("../features/owner/Records"));
const Permissions = lazy(() => import("../features/owner/Permissions"));
const Settings = lazy(() => import("../features/owner/Settings"));
const Audit = lazy(() => import("../features/owner/Audit"));
const Monitoring = lazy(() => import("../features/owner/Monitoring"));
const ViewAs = lazy(() => import("../features/owner/ViewAs"));
const SchoolHome = lazy(() =>
  import("../features/school/Workspace").then((m) => ({
    default: m.SchoolHome,
  })),
);
const WorkflowPage = lazy(() => import("../features/school/Workspace"));
const WhatsApp = lazy(() => import("../features/whatsapp/Console"));

// Master Panel Pages (Lazy-loaded SaaS Creator Console)
const MasterShell = lazy(() => import("../features/master/MasterShell"));
const MasterLogin = lazy(() => import("../features/master/MasterLogin"));
const MasterOverview = lazy(() => import("../features/master/Overview"));
const MasterSchools = lazy(() => import("../features/master/Schools"));
const MasterCreateSchool = lazy(
  () => import("../features/master/CreateSchool"),
);
const MasterRevenue = lazy(() => import("../features/master/Revenue"));
const MasterPlans = lazy(() => import("../features/master/PlansBilling"));
const MasterRoles = lazy(() => import("../features/master/GlobalRoleControl"));
const MasterMonitoring = lazy(
  () => import("../features/master/PlatformMonitoring"),
);
const MasterAudit = lazy(() => import("../features/master/PlatformAudit"));
const MasterSettings = lazy(() => import("../features/master/MasterSettings"));

const masterBasePath = import.meta.env.VITE_MASTER_PATH || "/sys-master";
const isMasterEnabled = import.meta.env.VITE_ENABLE_MASTER !== "false";

function WorkflowRoute({ module, role }: { module: ModuleKey; role: Role }) {
  const { can } = useAccess();
  return can(workflowPermission(module, role)) ? (
    <WorkflowPage module={module} />
  ) : (
    <StatusPage status="403" />
  );
}

export function RouteLoading() {
  return (
    <div className="route-loading">
      <Skeleton className="title-skeleton" />
      <Skeleton className="hero-skeleton" />
      <div className="loading-grid">
        {[1, 2, 3].map((n) => (
          <Skeleton key={n} className="card-skeleton" />
        ))}
      </div>
    </div>
  );
}

function Root() {
  return (
    <ErrorBoundary>
      <Suspense fallback={<RouteLoading />}>
        <Outlet />
      </Suspense>
    </ErrorBoundary>
  );
}

function RoleGate({
  role,
  permission,
}: {
  role: Role;
  permission: Permission;
}) {
  const { profile, initialized } = useAuth();
  const location = useLocation();

  if (!initialized) return <RouteLoading />;

  // If master is disabled in build/environment, return 404
  if (role === "master" && !isMasterEnabled) {
    return <StatusPage status="404" />;
  }

  if (!profile) {
    return (
      <Navigate
        to={role === "master" ? masterBasePath : "/login"}
        state={{ from: location.pathname }}
        replace
      />
    );
  }

  // Any non-master user hitting master routes gets normal 404
  if (role === "master" && profile.role !== "master") {
    return <StatusPage status="404" />;
  }

  // Master role has superuser access to both the SaaS console and the School Owner dashboard
  const isAuthorized =
    profile.role === role ||
    (profile.role === "master" && role === "owner") ||
    hasPermission(profile.role, permission);

  if (!isAuthorized) {
    return <StatusPage status="403" />;
  }

  return role === "master" ? <MasterShell /> : <Shell />;
}

function HomeRedirect() {
  const { profile, initialized } = useAuth();
  return initialized ? (
    <Navigate to={profile ? homeFor(profile.role) : "/login"} replace />
  ) : (
    <RouteLoading />
  );
}

const schoolRoles = [
  "owner",
  "principal",
  "teacher",
  "parent",
  "student",
  "accountant",
] as const;

const schoolRoleRoutes = schoolRoles.map((role) => ({
  path: `/${role}`,
  element: <RoleGate role={role} permission="workspace.read" />,
  children: [
    {
      index: true,
      element: role === "owner" ? <Dashboard /> : <SchoolHome />,
    },
    ...(role === "owner"
      ? [
          { path: "people", element: <Records resource="users" /> },
          { path: "branches", element: <Records resource="branches" /> },
          { path: "finance", element: <Records resource="finance" /> },
          { path: "roles", element: <Permissions /> },
          { path: "settings", element: <Settings /> },
          { path: "security", element: <Settings security /> },
          { path: "templates", element: <Records resource="templates" /> },
          { path: "audit", element: <Audit /> },
          { path: "monitoring", element: <Monitoring /> },
          { path: "view-as", element: <ViewAs /> },
        ]
      : []),
    { path: "directory", element: <Directory /> },
    { path: "preferences", element: <Preferences /> },
    ...moduleKeys
      .filter((key) => definition(key).readers.includes(role))
      .map((module) => ({
        path: module,
        element:
          module === "whatsapp" ? (
            <WhatsApp />
          ) : (
            <WorkflowRoute module={module} role={role} />
          ),
      })),
    ...(["owner", "principal", "teacher"].includes(role)
      ? [
          {
            path: "academics",
            element: <WorkflowRoute module="classes" role={role} />,
          },
        ]
      : []),
    { path: "*", element: <StatusPage status="404" /> },
  ],
}));

// Master Panel Routes: Dedicated SaaS Creator Console
const masterRoute = {
  path: `${masterBasePath}/workspace`,
  element: <RoleGate role="master" permission="master.manage" />,
  children: [
    { index: true, element: <MasterOverview /> },
    { path: "overview", element: <MasterOverview /> },
    { path: "schools", element: <MasterSchools /> },
    { path: "create-school", element: <MasterCreateSchool /> },
    { path: "schools/new", element: <MasterCreateSchool /> },
    { path: "revenue", element: <MasterRevenue /> },
    { path: "plans", element: <MasterPlans /> },
    { path: "roles", element: <MasterRoles /> },
    { path: "monitoring", element: <MasterMonitoring /> },
    { path: "audit", element: <MasterAudit /> },
    { path: "settings", element: <MasterSettings /> },
    { path: "security", element: <MasterSettings /> },
    { path: "*", element: <StatusPage status="404" /> },
  ],
};

// The master URL is intentionally absent from navigation. Real boundary is trusted claims + database RLS.
export const router = createBrowserRouter([
  {
    element: <Root />,
    children: [
      { path: "/", element: <HomeRedirect /> },
      { path: "/login", element: <Login /> },
      {
        path: masterBasePath,
        element: isMasterEnabled ? (
          <Login master />
        ) : (
          <StatusPage status="404" />
        ),
      },
      {
        path: `${masterBasePath}/login`,
        element: isMasterEnabled ? (
          <MasterLogin />
        ) : (
          <StatusPage status="404" />
        ),
      },
      { path: "/reset-password", element: <ResetPassword /> },
      { path: "/401", element: <StatusPage status="401" /> },
      { path: "/403", element: <StatusPage status="403" /> },
      ...schoolRoleRoutes,
      masterRoute,
      { path: "*", element: <StatusPage status="404" /> },
    ],
  },
]);

router.subscribe((state) => {
  devTracker.logRoute(state.location.pathname);
});
