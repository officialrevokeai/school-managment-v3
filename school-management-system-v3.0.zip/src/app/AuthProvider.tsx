import { useEffect, useState, type ReactNode } from "react";
import { useAuth } from "../store/auth";
import { getRepository } from "../services";
import { ErrorState, NeuButton, Skeleton } from "../components/ui/primitives";
import { NeuModal } from "../components/ui/overlays";
import { devTracker } from "../lib/devTracker";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  const initialized = useAuth((s) => s.initialized);
  const expired = useAuth((s) => s.expired);

  useEffect(() => {
    let active = true;
    let unsubscribe: (() => void) | undefined;
    let revision = 0;
    setError("");

    void getRepository()
      .then(async (repository) => {
        if (!active) return;
        unsubscribe = repository.auth.onChange((profile) => {
          revision++;
          if (!active) return;
          const previous = useAuth.getState().profile;
          if (previous && !profile) {
            useAuth.getState().setExpired(true);
            devTracker.logAuth("EXPIRED", previous.id);
          }
          if (profile) {
            const sameUser = previous?.id === profile.id;
            const sameRole = previous?.role === profile.role;
            const samePolicy = previous?.policyId === profile.policyId;
            const sameBranches =
              previous?.branchIds?.length === profile.branchIds?.length &&
              previous?.branchIds?.every((b, i) => b === profile.branchIds[i]);

            if (sameUser && sameRole && samePolicy && sameBranches) {
              return; // No real change, ignore redundant token refresh/focus event
            }
            devTracker.logAuth("UPDATE", profile.id);
          } else {
            devTracker.logAuth("SIGN_OUT", null);
          }
          useAuth.getState().setProfile(profile);
        });

        const initialRevision = revision;
        const profile = await repository.auth.getProfile();
        if (active && initialRevision === revision) {
          devTracker.logAuth("INITIAL", profile?.id);
          useAuth.getState().setProfile(profile);
        }
      })
      .catch((reason) => {
        if (active)
          setError(
            reason instanceof Error
              ? reason.message
              : "Unable to restore your session.",
          );
      });

    return () => {
      active = false;
      unsubscribe?.();
    };
  }, [attempt]);

  if (error)
    return (
      <main className="full-screen">
        <ErrorState
          title="We couldn’t start your workspace"
          description={error}
          onRetry={() => setAttempt((n) => n + 1)}
        />
      </main>
    );

  if (!initialized) {
    return (
      <main
        className="full-screen"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ textAlign: "center", maxWidth: 280 }}>
          <Skeleton
            className="title-skeleton"
            style={{ width: 140, height: 28, margin: "0 auto 12px" }}
          />
          <Skeleton
            className="hero-skeleton"
            style={{ width: 220, height: 16, margin: "0 auto" }}
          />
        </div>
      </main>
    );
  }

  return (
    <>
      {children}
      <NeuModal
        open={expired}
        onClose={() => useAuth.getState().setExpired(false)}
        title="Your session has ended"
        description="Sign in again to securely return to your workspace."
      >
        <NeuButton
          variant="primary"
          onClick={() => {
            useAuth.getState().setExpired(false);
            window.location.assign("/login");
          }}
        >
          Back to sign in
        </NeuButton>
      </NeuModal>
    </>
  );
}
