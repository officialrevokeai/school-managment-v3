/// <reference types="vitest" />
import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

const securityHeaders = {
  "Content-Security-Policy":
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://*.supabase.co; connect-src 'self' https://*.supabase.co wss://*.supabase.co; font-src 'self' data:; frame-ancestors 'none';",
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "X-Frame-Options": "DENY",
};

export default defineConfig({
  plugins: [react()],
  esbuild: {
    drop: process.env.NODE_ENV === "production" ? ["console", "debugger"] : [],
  },
  test: {
    testTimeout: 30000,
    hookTimeout: 120000,
    fileParallelism: false,
    include: ["src/**/*.test.ts", "database/**/*.test.ts"],
    exclude: ["tests/**", "node_modules/**"],
  },
  optimizeDeps: {
    include: [
      "react",
      "react-dom",
      "react-router-dom",
      "@tanstack/react-query",
      "@tanstack/react-table",
      "@tanstack/react-virtual",
      "framer-motion",
      "lucide-react",
      "date-fns",
      "sonner",
      "zod",
      "zustand",
      "@supabase/supabase-js",
      "recharts",
    ],
  },
  server: {
    headers: securityHeaders,
    watch: {
      ignored: [
        "**/docs/**",
        "**/database/**",
        "**/test-results/**",
        "**/.temp/**",
        "**/.git/**",
        "**/*.tsbuildinfo",
      ],
    },
  },
  preview: {
    headers: securityHeaders,
  },
  build: { target: "es2022", sourcemap: false, manifest: true },
});
