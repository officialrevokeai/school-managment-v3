import type { Config } from "tailwindcss";
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: ["class", '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        base: "var(--base)",
        ink: "var(--text)",
        muted: "var(--muted)",
        accent: "var(--sky)",
      },
      borderRadius: { neu: "20px" },
      boxShadow: {
        "raised-sm": "var(--raised-sm)",
        "raised-md": "var(--raised-md)",
        "inset-pressed": "var(--inset-pressed)",
      },
    },
  },
  plugins: [],
} satisfies Config;
